<?php

$hook_array["FilterApi_addFilter_before"][] = array(
    10,
    "Enhanced filtering for related records",
    null,
    "Sugarcrm\\Sugarcrm\\custom\\wsystems\\QualiaIntegration\\LogicHooks\\OrdersFilterListHook",
    "addFilterBefore",
);

$hook_array["FilterApi_addFilter_before"][] = array(
    10,
    "Enhanced filtering for related records",
    null,
    "Sugarcrm\\Sugarcrm\\custom\\wsystems\\QualiaIntegration\\LogicHooks\\ContactsFilterListHook",
    "addFilterBefore",
);
