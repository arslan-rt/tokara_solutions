<?php
array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\QualiaIntegration\\Jobs\\InsertFailedRecord");
