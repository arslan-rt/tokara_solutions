<?php

$mod_strings["LBL_QUALIA_ID"]           = "Qualia ID";
$mod_strings["LBL_PARTY_TYPES"]         = "Qualia Types";
$mod_strings["LBL_NATIONAL_LICENSE_ID"] = "National License ID";
$mod_strings["LBL_STATE_LICENSE_ID"]    = "State License ID";
$mod_strings["LBL_STATE_LICENSE_STATE"] = "State License State";

$mod_strings["LBL_BILLING_ADDRESS"]            = "Primary Address:";
$mod_strings["LBL_BILLING_ADDRESS_STREET"]     = "Primary Address Street:";
$mod_strings["LBL_BILLING_ADDRESS_STREET_2"]   = "Primary Address Street 2";
$mod_strings["LBL_BILLING_ADDRESS_STREET_3"]   = "Primary Address Street 3";
$mod_strings["LBL_BILLING_ADDRESS_STREET_4"]   = "Primary Address Street 4";
$mod_strings["LBL_BILLING_ADDRESS_CITY"]       = "Primary Address City:";
$mod_strings["LBL_BILLING_ADDRESS_STATE"]      = "Primary Address State:";
$mod_strings["LBL_BILLING_ADDRESS_POSTALCODE"] = "Primary Address Postal Code:";
$mod_strings["LBL_BILLING_ADDRESS_COUNTRY"]    = "Primary Address Country:";

$mod_strings["LBL_SHIPPING_ADDRESS"]            = "Alternate Address:";
$mod_strings["LBL_SHIPPING_ADDRESS_STREET"]     = "Alternate Address Street:";
$mod_strings["LBL_SHIPPING_ADDRESS_STREET_2"]   = "Alternate Address Street 2";
$mod_strings["LBL_SHIPPING_ADDRESS_STREET_3"]   = "Alternate Address Street 3";
$mod_strings["LBL_SHIPPING_ADDRESS_STREET_4"]   = "Alternate Address Street 4";
$mod_strings["LBL_SHIPPING_ADDRESS_CITY"]       = "Alternate Address City:";
$mod_strings["LBL_SHIPPING_ADDRESS_STATE"]      = "Alternate Address State:";
$mod_strings["LBL_SHIPPING_ADDRESS_POSTALCODE"] = "Alternate Address Postal Code:";
$mod_strings["LBL_SHIPPING_ADDRESS_COUNTRY"]    = "Alternate Address Country:";
