<?php

$viewdefs["Contacts"]["base"]["filter"]["basic"]["filters"][] = [
    "id"                => "filterRelatedContacts",
    "name"              => "LBL_QUALIAINTEGRATION_FILTER_RELATED_CONTACTS",
    "filter_definition" => [
        [
            "filter_related_contacts" => "",
        ],
    ],
    "is_template"       => true,
];
