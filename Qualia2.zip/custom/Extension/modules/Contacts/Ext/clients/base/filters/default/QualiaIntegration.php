<?php

$viewdefs["Contacts"]["base"]["filter"]["default"]["fields"]["filter_related_contacts"] = [];
