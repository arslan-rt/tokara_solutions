<?php

$mod_strings["LBL_QUALIA_ID"]                                 = "Qualia ID";
$mod_strings["LBL_MARITAL_STATUS"]                            = "Marital Status";
$mod_strings["LBL_NATIONAL_LICENSE_ID"]                       = "National License ID";
$mod_strings["LBL_STATE_LICENSE_ID"]                          = "State License ID";
$mod_strings["LBL_STATE_LICENSE_STATE"]                       = "State License State";
$mod_strings["LBL_QUALIAINTEGRATION_FILTER_RELATED_CONTACTS"] = "Filtered Contacts";
$mod_strings["LBL_FILTER_RELATED_CONTACTS"]                   = "Fake relation for filtering Contacts on drawer";
