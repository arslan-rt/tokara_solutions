<?php
$dictionary['Contact']['fields']['qualia_diff_hash'] =
array(
    'name'            => 'qualia_diff_hash',
    'label'           => 'Qualia Diff Id',
    'type'            => 'varchar',
    'module'          => 'Contact',
    'mass_update'     => true,
    'required'        => false,
    'reportable'      => true,
    'audited'         => false,
    'importable'      => true,
    'readonly'        => true,
    'duplicate_merge' => false,
);
