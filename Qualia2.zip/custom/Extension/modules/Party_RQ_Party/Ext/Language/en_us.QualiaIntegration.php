<?php

$mod_strings["LBL_QUALIA_ID"]          = "Qualia ID";
$mod_strings["LBL_PARENT_PARTY_TYPE"]  = "Parent Party Type";
$mod_strings["LBL_QUALIA_PARENT_ROLE"] = "Parent's User Role";
