<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wReportsDashlet\Traits;

use BeanFactory;
use Doctrine\DBAL\DBALException;
use Doctrine\DBAL\Exception\InvalidArgumentException;
use DynamicField;
use Exception;
use function \array_key_exists;
use function \boolval;
use function \class_exists;
use function \explode;
use function \in_array;
use function \is_array;
use function \is_bool;
use function \is_numeric;
use function \is_string;
use LoggerManager;
use SugarBean;
use Sugarcrm\Sugarcrm\ProcessManager\Registry;
use SugarException;
use SugarQuery;
use SugarQueryException;
use SugarSystemInfo;

/**
 * *** BeanHandlerTrait ***
 *
 * This trait provides additional features when working with Sugar beans,
 * features like retrieving records by criteria (custom fields, cache, database),
 * working with relationships (get/add/remove), working with fields (values, relationship fields).
 *
 * @package SamplePackage
 * @author Vali Bratulescu
 * @version 1.0.5
 * @since SugarCRM 8.0
 * @since PHP 7.1
 *
 * *** Methods available ***
 *
 * @method beanSave
 * @method beanHasCalculatedFields
 * @method beanFieldChanged
 * @method beanFieldBeforeChange
 * @method beanFieldAfterChange
 * @method beanRelFieldBeforeChange
 * @method beanRelationshipLoad
 * @method beanRelAddRecords
 * @method beanRelRemoveRecords
 * @method beanRelGetIds
 * @method beanRelGetBeans
 * @method beanGet
 * @method beanGetByFields
 * @method beanCreate
 * @method beanDelete
 * @method beanCacheAdd
 * @method beanCacheRemove
 * @method beanCacheClear
 */
trait BeanHandlerTrait
{
    /**
     * Saves the given bean.
     *
     * This can be done either by performing hard-save, and choosing to trigger or not hooks/workflows,
     * or just update bean fields (this will be automatically done by Sugar via SQL).
     *
     * Very important though is that as long as the logic hooks are not triggered,
     * the Elasticsearch will not index the updated bean, as there is an built-in after_save hook,
     * that deals with bean indexing.
     *
     * Another fact here is that not performing hard-save (method = sql),
     * the audit logic will not be applied.
     *
     * <code>
     *
     * $this->beanSave($bean, [
     *     "method"                 => "sugar",
     *     "triggerLogicHooks"      => false,
     *     "triggerLegacyWorkflows" => false,
     *     "updateModifiedFields"   => false
     *     "notifyUser"             => true
     * ]);
     *
     * $this->beanSave($bean, [
     *     "method"                 => "sql",
     *     "updateCalculatedFields" => true
     * ]);
     *
     * $this->beanSave($bean);
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param array $options method - `sugar` to perform hard-save, `sql` to only update fields
     *                       triggerLogicHooks - True to let logic hooks/BPM processes be triggered
     *                       triggerLegacyWorkflows - True to let workflows be triggered
     *                       updateModifiedFields - True to allow updating `date_modified` and `modified_by` fields
     *                       updateCalculatedFields - True to update calculated fields based on their formulas
     *                       notifyUser - True to notify the record assignee via email
     * @return void
     *
     * @throws Exception
     * @throws DBALException
     * @throws InvalidArgumentException
     */
    public function beanSave(SugarBean &$bean, array $options = []): void
    {
        $method = $options["method"] ?? "sugar";

        $triggerLogicHooks      = $options["triggerLogicHooks"] ?? true;
        $triggerLegacyWorkflows = $options["triggerLegacyWorkflows"] ?? true;
        $updateModifiedFields   = $options["updateModifiedFields"] ?? true;
        $updateCalculatedFields = $options["updateCalculatedFields"] ?? true;
        $notifyUser             = $options["notifyUser"] ?? false;

        switch ($method) {
            case "sugar":
                // Fix trigger PMSE for each bean, when it is about a batch of beans.
                $this->beanFixPMSE();

                // Cache bean attributes so to restore their state later
                $cachedFlags = $this->beanCacheAttrs($bean, "processed", "update_date_modified", "update_modified_by");

                // Cache `disable_workflow` flag used to know if to trigger or not legacy workflows
                $disableWorkflow = $_SESSION["disable_workflow"];

                if ($triggerLogicHooks === true) {
                    $bean->processed = null;

                    // Legacy workflows will be triggered by default.
                    // If we want to cancel them, warn the user about it.
                    if ($triggerLegacyWorkflows === false) {
                        $_SESSION["disable_workflow"] = true;

                        LoggerManager::getLogger()->warn(
                            "Legacy workflows have been disabled for {$bean->module_name} - {$bean->id} record."
                        );
                    }
                } else {
                    $bean->processed = true;
                }

                $bean->update_date_modified = $updateModifiedFields;
                $bean->update_modified_by   = $updateModifiedFields;

                $bean->save($notifyUser);

                // Restore bean attributes to their initial state
                $this->beanRestoreAttrs($bean, $cachedFlags);

                // Restore `disable_workflow` flag to its initial state
                if ($disableWorkflow !== $_SESSION["disable_workflow"]) {
                    $_SESSION["disable_workflow"] = $disableWorkflow;
                }

                break;

            case "sql":
                $isUpdate = $bean->isUpdate();

                $bean->update_date_modified = $updateModifiedFields;
                $bean->update_modified_by   = $updateModifiedFields;

                $bean->fixUpFormatting();
                $bean->setModifiedUser();
                $bean->setModifiedDate();

                if ($updateCalculatedFields === true) {
                    $bean->updateCalculatedFields();
                }

                if ($bean->custom_fields instanceof DynamicField === true) {
                    $bean->custom_fields->bean = $bean;
                    $bean->custom_fields->save($isUpdate);
                }

                if ($isUpdate === true) {
                    $bean->db->update($bean);
                } else {
                    $bean->setCreateData($isUpdate);
                    $bean->setDefaultTeam();
                    $bean->assigned_user_id = $bean->created_by;

                    $inserted = $bean->db->insert($bean);

                    if ($inserted === true) {
                        //Now that the record has been saved, we don't want to insert again on further saves
                        $bean->new_with_id = false;
                    }
                }

                break;
        }
    }

    /**
     * Checks if the given bean has calculated fields.
     *
     * @param SugarBean $bean
     *
     * @return bool
     */
    public function beanHasCalculatedFields(SugarBean $bean): bool
    {
        $fieldDefs = $bean->getFieldDefinitions();

        foreach ($fieldDefs as $fieldDef) {
            if (boolval($fieldDef["calculated"]) === true) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the current field value is different than its database value.
     *
     * <code>
     *
     * $this->beanFieldChanged($bean, "first_name");
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $field
     *
     * @return bool
     */
    public function beanFieldChanged(SugarBean $bean, string $field): bool
    {
        $changes = $bean->db->getDataChanges($bean);

        if (empty($changes) === true) {
            return false;
        }

        return array_key_exists($field, $changes) === true;
    }

    /**
     * Retrieves the initial field value.
     *
     * <code>
     *
     * $this->beanFieldBeforeChange($bean, "first_name");
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $field
     *
     * @return mixed|null
     */
    public function beanFieldBeforeChange(SugarBean $bean, string $field)
    {
        return $bean->db->getDataChanges($bean)[$field]["before"];
    }

    /**
     * Retrieves the updated field value.
     *
     * <code>
     *
     * $this->beanFieldAfterChange($bean, "first_name");
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $field
     *
     * @return mixed|null
     */
    public function beanFieldAfterChange(SugarBean $bean, string $field)
    {
        return $bean->db->getDataChanges($bean)[$field]["after"];
    }

    /**
     * Retrieves relationship field value.
     *
     * <code>
     *
     * $this->beanRelFieldBeforeChange($bean, "contacts_users_role");
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $field
     *
     * @return null|mixed
     */
    public function beanRelFieldBeforeChange(SugarBean $bean, string $field)
    {
        if (empty($field) === true) {
            return null;
        }

        return $bean->rel_fields_before_value[$field];
    }

    /**
     * Loads relationship for given bean.
     *
     * @param SugarBean $bean
     * @param string $relationship
     *
     * @return bool True if relationship has been loaded; throw exception otherwise
     *
     * @throws SugarException
     */
    public function beanRelationshipLoad(SugarBean $bean, string $relationship): bool
    {
        $relLoaded = $bean->load_relationship($relationship);

        if ($relLoaded === true) {
            return true;
        }

        $e = new SugarException("Fail to load relationship.");

        $e->setExtraData("module", $bean->module_name);
        $e->setExtraData("record", $bean->id);
        $e->setExtraData("relationship", $relationship);

        throw $e;
    }

    /**
     * Adds/updates relationship records.
     *
     * <code>
     *
     * $this->beanRelAddRecords(
     *     $contact,
     *     "meetings",
     *     [
     *         "f4463652-4540-11e7-9be5-0a88bd1c46b4",
     *         "f42444b6-4540-11e7-823c-0a88bd1c46b4"
     *     ],
     *     [
     *         "accept_status" => "accept"
     *     ]
     * )
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $relationship
     * @param string|SugarBean|string[]|SugarBean[] $relKeys Id of record to be linked
     *                                                       SugarBean to be linked
     *                                                       Id list of records to be linked
     *                                                       SugarBean list to be linked
     * @param array $relFieldValues List of fields => values to be set for relationship fields
     *
     * @return bool|array True if all key have been added
     *                    Array with keys that failed to be added
     *
     * @throws SugarException
     */
    public function beanRelAddRecords(SugarBean $bean, string $relationship, $relKeys, array $relFieldValues = [])
    {
        $this->beanRelationshipLoad($bean, $relationship);

        if (is_string($relKeys) === true || is_array($relKeys) === true || $relKeys instanceof SugarBean === true) {
            return $bean->{$relationship}->add($relKeys, $relFieldValues);
        }

        $e = new SugarException("Fail to add data to relationship. Invalid values.");

        $e->setExtraData("module", $bean->module_name);
        $e->setExtraData("record", $bean->id);
        $e->setExtraData("relationship", $relationship);
        $e->setExtraData("relKeys", $relKeys);

        throw $e;
    }

    /**
     * Removes records from relationship.
     *
     * @param SugarBean $bean
     * @param string $relationship
     * @param string|SugarBean|string[]|SugarBean[] $relKeys Null to unlink the entire relationship data
     *                                                       Id of record to be unlinked
     *                                                       SugarBean to be unlinked
     *                                                       Id list of records to be unlinked
     *                                                       SugarBean list to be unlinked
     *
     * @return bool
     *
     * @throws SugarException
     */
    public function beanRelRemoveRecords(SugarBean $bean, string $relationship, $relKeys): bool
    {
        $this->beanRelationshipLoad($bean, $relationship);

        // Remove all related records from relationship
        if (is_null($relKeys) === true) {
            $bean->{$relationship}->delete($bean->id);

            return true;
        }

        /**
         * `relKeys` is ID of a record to be removed from relationship
         */
        if (is_string($relKeys) === true && empty($relKeys) === false) {
            $bean->{$relationship}->delete($bean->id, $relKeys);

            return true;
        }

        /**
         * `relKeys` is Bean record to be removed from relationship
         */
        if ($relKeys instanceof SugarBean === true) {
            $bean->{$relationship}->delete($bean->id, $relKeys->id);

            return true;
        }

        /**
         * `relKeys` is an array of ids and/or beans to be removed from relationship
         */
        if (is_array($relKeys) === true && empty($relKeys) === false) {
            foreach ($relKeys as $relItem) {
                if (is_string($relItem) === true) {
                    $bean->{$relationship}->delete($bean->id, $relItem);

                    continue;
                }

                if ($relItem instanceof SugarBean === true) {
                    $bean->{$relationship}->delete($bean->id, $relItem->id);

                    continue;
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Fetches related records ids.
     *
     * <code>
     *
     * $this->beanRelGetIds($account, "contacts", [
     *     "where"       => [
     *         "id", "in", ["d518045e-4540-11e7-8ac8-0a88bd1c46b4"],
     *     ],
     *     "limit"       => 40
     *     "offset"      => 10
     *     "orderby"     => "date_modified desc",
     *     "skipDeleted" => true
     * ]);
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $relationship
     * @param array $criteria where - Filter returned records
     *                        limit - How many records to return
     *                        offset - From which position to return records
     *                        orderby - OrderBy and SortOrder
     *                        skipDeleted - True to only retrieve non-deleted relationships
     *
     * @return array
     *
     * @throws SugarException
     */
    public function beanRelGetIds(SugarBean $bean, string $relationship, array $criteria = []): array
    {
        $this->beanRelationshipLoad($bean, $relationship);

        $params = $this->beanRelParseParams($criteria);

        $rows = $bean->{$relationship}->query($params)["rows"];

        return array_keys($rows);
    }

    /**
     * Fetches related beans.
     *
     * <code>
     *
     * $this->beanRelGetBeans($bean, "contacts",
     *     [
     *         "where"   => [
     *             "first_name", "like", "%b%",
     *         ],
     *         "orderby" => "last_name asc",
     *     ]
     * );
     *
     * $this->beanRelGetBeans($bean, "contacts",
     *     [
     *         "where"   => [
     *             "last_name", "=", "Waverly",
     *         ],
     *         "limit" => 3
     *     ]
     * );
     *
     * </code>
     *
     * @param SugarBean $bean
     * @param string $relationship
     * @param array $criteria where - Filter returned records
     *                        limit - How many records to return
     *                        offset - From which position to return records
     *                        orderby - OrderBy and SortOrder
     *                        skipDeleted - True to only retrieve non-deleted relationships
     *
     * @param array $retrieve cache - True to retrieve records from cache
     *                        skipDeleted - True to only retrieve non-deleted records
     *                        encode - True to HTML encode returned records
     *
     * @return array
     *
     * @throws SugarException
     */
    public function beanRelGetBeans(
        SugarBean $bean,
        string $relationship,
        array $criteria = [],
        array $retrieve = []
    ): array
    {
        $this->beanRelationshipLoad($bean, $relationship);

        /**
         * Params used to filter returned records.
         * Applicable for SugarQuery.
         */
        $queryParams = $this->beanRelParseParams($criteria);

        /**
         * Params used to be applied over the returned beans.
         * Same params as the ones used by the retrieveBean method from BeanFactory.
         *
         * @see BeanFactory::retrieveBean
         */
        $retrieveParams = [];

        $cachedBeans = $retrieve["cache"] ?? false;
        $skipDeleted = $retrieve["skipDeleted"] ?? false;
        $encodeBeans = $retrieve["encode"] ?? false;

        if (isset($cachedBeans) === true && is_bool($cachedBeans) === true) {
            $retrieveParams["use_cache"] = $cachedBeans;
        }

        if (isset($skipDeleted) === true && is_bool($skipDeleted) === true) {
            $retrieveParams["deleted"] = $skipDeleted === true ? false : true;
        }

        if (isset($encodeBeans) === true && is_bool($encodeBeans) === true) {
            $retrieveParams["encode"] = $encodeBeans;
        }

        // Store relationship
        $relationship = $bean->{$relationship};

        // Array of related records
        $rows = $relationship->query($queryParams)["rows"];

        // Array of related beans
        $beans = [];

        // Related records module
        $relatedModule = $relationship->getRelatedModuleName();

        // Related records bean
        $relatedBean = $this->beanCreate($relatedModule);

        // Related bean relationship fields
        $relationshipFields = []; // $relationship->getRelationshipFields($relatedBean);

        // Prepare list of SugarBeans
        foreach ($rows as $id => $values) {
            $bean = $this->beanGet(
                $relatedModule, $id, $retrieveParams["use_cache"], $retrieveParams["deleted"], $retrieveParams
            );

            if ($bean instanceof SugarBean === true && empty($relationshipFields) === false) {
                $this->populateRelationshipOnlyFields($relationshipFields, $values, $bean);
            }

            $beans[$id] = $bean;
        }

        return $beans;
    }

    /**
     * Retrieves a bean based on the given id and module.
     *
     * According to the `use_cache` parameter, the bean can be retrieved either from the cached bean list,
     * or directly from database.
     *
     * This method allows retrieve both deleted and non-deleted records.
     * This is made based on the `skipDeleted` flag.
     * Having this flag set to true, it means the logic below will always be looking for non-deleted records.
     * Otherwise, it searches the ones with deleted = 1.
     *
     * <code>
     *
     * $this->beanGet("Accounts", "d9bdd218-4540-11e7-b0f6-0a88bd1c46b4");
     * $this->beanGet("Accounts", "d9bdd218-4540-11e7-b0f6-0a88bd1c46b4", false, true);
     * $this->beanGet("Accounts", "d9bdd218-4540-11e7-b0f6-0a88bd1c46b4", false, true, [
     *     "disable_row_level_security" => true
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param string $id
     * @param bool $cache True to retrieve bean from cache, false to retrieve bean from db.
     * @param bool $skipDeleted True to only retrieve non-deleted records
     * @param array $params encode - True to HTML encode returned bean
     *
     * @return null|SugarBean
     *
     * @throws SugarQueryException
     */
    public function beanGet(
        string $module,
        string $id,
        bool $cache = true,
        bool $skipDeleted = false,
        array $params = []
    ): ?SugarBean {

        if (empty($id) === true) {
            return null;
        }

        $params["use_cache"] = $cache;

        return BeanFactory::retrieveBean($module, $id, $params, $skipDeleted);
    }

    /**
     * Retrieves a bean based on the general fields.
     *
     * This method allows retrieve both deleted and non-deleted records.
     * This is made based on the `skipDeleted` flag.
     * Having this flag set to true, it means the logic below will always be looking for non-deleted records.
     * Otherwise, it searches the ones with deleted = 1.
     *
     * <code>
     *
     * $this->beanGetByFields("Accounts",
     *     [
     *         "name" => "W-Systems",
     *         "type" => "customer"
     *     ],
     *     [
     *         "skipDeleted"  => false,
     *         "teamSecurity" => false,
     *         "erasedFields" => false,
     *     ]
     * );
     *
     * </code>
     *
     * @param string $module
     * @param array $fieldsList Pairs of fields => values to build query where
     * @param array $options skipDeleted - True to only search non-deleted records
     *                       teamSecurity - True to filter records based on team visibility
     *                       erasedFields - True to retrieve erased fields for returned records
     *
     * @return null|SugarBean
     *
     * @throws SugarQueryException
     * @throws DBALException
     */
    public function beanGetByFields(string $module, array $fieldsList, array $options = []): ?SugarBean
    {
        $bean = $this->beanCreate($module);

        $sq = new SugarQuery();
        $sq->select("*");
        $sq->from($bean, [
            /**
             * Let SugarQuery know if it should return deleted records or not.
             *
             * add_deleted = true => "WHERE deleted = 0"
             * add_deleted = false => "WHERE deleted = 1"
             */
            "add_deleted" => $options["skipDeleted"] ?? true,

            /**
             * Make SugarQuery not return records that are not visible.
             * Visibility filtering is managed by the BeanVisibility class.
             *
             * team_security = true => apply visibility filtering
             * team_security = false => does not apply visibility filtering
             *
             * @see BeanVisibility
             */
            "team_security" => $options["teamSecurity"] ?? false,

            /**
             * Let SugarQuery know if it should retrieve information from `erased_fields` table,
             * for returned records.
             *
             * erased_fields = true => fetch erased fields for selected records
             * erased_fields = false => does not fetch erased fields for selected records
             */
            "erased_fields" => $options["erasedFields"] ?? false,
        ]);
        $sq->offset(0);
        $sq->limit(1);

        foreach ($fieldsList as $field => $value) {
            $sq->where()->equals($field, $value);
        }

        $result = $sq->execute();

        if (is_array($result) === true && count($result) > 0) {
            $bean->duplicates_found = true;

            $row = reset($result);
            $row = $bean->convertRow($row);

            $bean->fetched_row = $row;
            $bean->populateFetchedEmail();
            $bean->fromArray($row);
            $bean->fill_in_additional_detail_fields();

            return $bean;
        }

        return null;
    }

    /**
     * Creates a new bean.
     *
     * @param string $module
     * @param array $defaults Array of fields => values to be set on the new bean
     *
     * @return SugarBean
     */
    public function beanCreate(string $module, array $defaults = []): SugarBean
    {
        $bean = BeanFactory::newBean($module);

        if (count($defaults) > 0) {
            foreach ($defaults as $field => $value) {
                $bean->{$field} = $value;

                if ($field === "id" && isset($value) === true) {
                    $bean->new_with_id = true;
                }
            }
        }

        return $bean;
    }

    /**
     * Deletes a bean and plucks it from the cached bean list.
     *
     * @param string $module
     * @param string $id
     *
     * @return null|SugarBean
     *
     * @throws SugarQueryException
     * @throws DBALException
     */
    public function beanDelete(string $module, string $id): ?SugarBean
    {
        return BeanFactory::deleteBean($module, $id);
    }

    /**
     * Adds a bean to the cached bean list.
     *
     * <code>
     *
     * $this->beanCacheAdd($account);
     * $this->beanCacheAdd(null, "Accounts", "d9bdd218-4540-11e7-b0f6-0a88bd1c46b4");
     *
     * </code>
     *
     * @param null|SugarBean $bean
     * @param null|string $module
     * @param null|string $id
     *
     * @return bool
     *
     * @throws SugarQueryException
     */
    public function beanCacheAdd(?SugarBean $bean, ?string $module = null, ?string $id = null): bool
    {
        if ($bean instanceof SugarBean === false) {
            $bean = $this->beanGet($module, $id);
        }

        return BeanFactory::registerBean($bean);
    }

    /**
     * Removes the bean from the cached bean list so the next bean retrieval will be from database.
     *
     * @param string $module
     * @param null|string $id
     *
     * @return bool
     */
    public function beanCacheRemove(string $module, ?string $id = null): bool
    {
        return BeanFactory::unregisterBean($module, $id);
    }

    /**
     * Removes all cached beans.
     *
     * @return void
     */
    public function beanCacheClear(): void
    {
        BeanFactory::clearCache();
    }

    /**
     * In Sugar 7.8, the Process Manager library brought Registry Object
     * to maintain the state of SugarBPM processes during a PHP Process.
     *
     * This change introduced a limitation in SugarBPM that prevents the same process definition
     * from running on multiple records inside the same PHP process.
     *
     * @link https://support.sugarcrm.com/Documentation/Sugar_Developer/Sugar_Developer_Guide_9.1/Architecture/SugarBPM/index.html
     *
     * @access protected
     *
     * @return void
     */
    protected function beanFixPMSE(): void
    {
        $systemInfo   = SugarSystemInfo::getInstance()->getAppInfo();
        $systemFlavor = $systemInfo["sugar_flavor"] ?? $GLOBALS["sugar_flavor"];

        // SugarBPM is exclusive to Enterprise and Ultimate editions of Sugar 7.6.x and later.
        if (in_array(strtoupper($systemFlavor), ["ULT", "ENT"]) === false) {
            return;
        }

        // Check if the Factory class specific to the ProcessManager exists,
        // in order not to call the below logic if it does not apply for the current system.
        // EG: Sugar PRO does not implement Process Management.
        if (class_exists("Sugarcrm\Sugarcrm\ProcessManager\Registry\Registry") === true) {
            Registry\Registry::getInstance()->drop("triggered_starts");
        }
    }

    /**
     * Caches bean properties so to restore them to their initial state after working with it.
     *
     * @param SugarBean $bean
     * @param string[] $flags
     *
     * @return array
     */
    protected function beanCacheAttrs(SugarBean $bean, string...$flags): array
    {
        $cache = [];

        foreach ($flags as $flag) {
            $cache[$flag] = $bean->{$flag};
        }

        return $cache;
    }

    /**
     * Restores bean properties after finishing working with it.
     *
     * @param SugarBean $bean
     * @param array $cachedFlags
     *
     * @return void
     */
    protected function beanRestoreAttrs(SugarBean $bean, array $cachedFlags): void
    {
        foreach ($cachedFlags as $name => $value) {
            if ($bean->{$name} === $value) {
                continue;
            }

            $bean->{$name} === $value;
        }
    }

    /**
     * Parses criteria options as to be able to use them to filter returned relationship records.
     *
     * @access protected
     *
     * @param array $criteria where - Filter returned records
     *                        limit - How many records to return
     *                        offset - From which position to return records
     *                        orderby - OrderBy and SortOrder
     *                        skipDeleted - True to only retrieve non-deleted relationships
     *
     * @return array
     */
    protected function beanRelParseParams(array $criteria = []): array
    {
        if (empty($criteria) === true) {
            return [];
        }

        $params = [];

        $where       = $criteria["where"] ?? [];
        $limit       = $criteria["limit"];
        $offset      = $criteria["offset"] ?? 0;
        $orderby     = $criteria["orderby"] ?? "date_modified desc";
        $skipDeleted = $criteria["skipDeleted"] ?? true;

        if (is_array($where) === true && empty($where) === false && count($where) === 3) {
            $params["where"] = [
                "lhs_field" => $where[0],
                "operator"  => $where[1],
                "rhs_value" => $where[2],
            ];
        }

        if (isset($limit) === true && is_numeric($limit) === true) {
            $params["limit"] = $limit;
        }

        if (isset($offset) === true && is_numeric($offset) === true) {
            $params["offset"] = $offset;
        }

        if (isset($orderby) === true && is_string($orderby) === true) {
            $args = explode(" ", $orderby);

            if (count($args) === 2) {
                $params["orderby"] = $orderby;
            }
        }

        if (isset($skipDeleted) === true && is_bool($skipDeleted) === true) {
            /**
             * If `skipDeleted` is true, it means we only want to retrieve non-deleted relationships.
             * Thus, `deleted` parameter should be 0, as the background SugarQuery will use it to filte returned data.
             *
             * <code>
             *
             * WHERE deleted = 0 when `skipDeleted` = true
             * WHERE deleted = 1 when `skipDeleted` = false
             *
             * </code>
             */
            $params["deleted"] = $skipDeleted === true ? 0 : 1;
        }

        return $params;
    }
}
