<?php

$mod_strings["LBL_WREPORTSDASHLET_PANEL_GROUP_NAME"] = "wReportsDashlet Panels";
$mod_strings["LBL_WREPORTSDASHLET_PANEL_GROUP_DESC"] = "wReportsDashlet settings";

$mod_strings["LBL_WREPORTSDASHLET_PANEL_NAME"] = "wReportsDashlet";
$mod_strings["LBL_WREPORTSDASHLET_PANEL_DESC"] = "wReportsDashlet configuration settings";
