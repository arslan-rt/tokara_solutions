<?php

array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\wReportsDashlet\\Jobs\\ClearReportsCacheJob");
array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\wReportsDashlet\\Jobs\\RemoveOutdatedReportsCacheJob");
