<?php

if (function_exists("pre_install") === false) {
    function pre_install()
    {
        $parentDir = dirname(dirname(__FILE__));

        $devMode = SugarAutoLoader::$devMode;

        // Simulate developer mode as enabled so not to update class_map file from cache
        SugarAutoLoader::$devMode = true;

        // Build class map dictionary composed of namespace => file pairs
        SugarAutoLoader::buildClassCache();

        // Make sure the cached files still point to the right namespace
        SugarAutoLoader::addNamespace(
            "Sugarcrm\\Sugarcrm\\custom\\wsystems\\wmaps",
            "{$parentDir}/custom/src/wsystems/wmaps", "psr4"
        );

        $instance = new Sugarcrm\Sugarcrm\custom\wsystems\wmaps\Setup\Install();

        $instance->preInstall();

        // Restore developer mode state
        SugarAutoLoader::$devMode = $devMode;
    }
}
