<?php

if (!defined('sugarEntry')) {
    define('sugarEntry', true);
}

global $db;

$delete_query = "delete from schedulers where job='function::GeoCodeJob'";
$db->query($delete_query);
