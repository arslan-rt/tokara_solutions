<?php

require_once 'include/database/DBManagerFactory.php';

$GLOBALS['log']->debug("debug starting post_install_actions.php");

try {
    $db         = DBManagerFactory::getInstance();
    $table_name = 'zip_country_cache';
    if (!$db->tableExists($table_name)) {
        $GLOBALS['log']->debug("debug table not exist");
        $fieldDefs = array(
            array(
                'name'     => 'zip',
                'type'     => 'id',
                'required' => true,
            ),
            array(
                'name'     => 'country',
                'type'     => 'varchar',
                'len'      => 100,
                'isnull'   => false,
                'required' => true,
            ),
            array(
                'name'     => 'lat',
                'type'     => 'decimal',
                'len'      => '16,8',
                'required' => true,
            ),
            array(
                'name'     => 'lng',
                'type'     => 'decimal',
                'len'      => '16,8',
                'required' => true,
            ),
        );
        $indices = array(
            array(
                'name'   => 'zip_pk',
                'type'   => 'primary',
                'fields' => array('zip', 'country'),
            ),
        );
        try {
            $db->createTableParams($table_name, $fieldDefs, $indices, null);
            $GLOBALS['log']->debug("debug table created");
        } catch (Exception $ex) {
            $GLOBALS['log']->debug("debug table creating error" . $ex_getMessage);
        } // create table try...catch
    } else {
        $GLOBALS['log']->debug("debug table exists !");
    } // table exists
} catch (Exception $e) {
    $GLOBALS['log']->debug("debug outer catch error" . $e_getMessage);
} // outter try...catch

$fields_on_users = false;
$wmaps_fields    = array('gc_status_c', 'wmaps_balloon_c', 'gc_latitude_c', 'gc_longitude_c', 'gc_status_detail_c', 'gc_date_c', 'wmaps_pushpin_icon_c', 'wmaps_distance_unit_c');

global $sugar_config;

$database_name = $sugar_config['dbconfig']['db_name'];
$dbType        = $sugar_config["dbconfig"]["db_type"];

foreach ($wmaps_fields as $wmap_field) {
    $check_fields_on_users = " select COLUMN_NAME from information_schema.COLUMNS  where table_name ='users' and table_schema='$database_name' and COLUMN_NAME ='$wmap_field' ";
    $result                = $db->query($check_fields_on_users);
    $row                   = $db->fetchByAssoc($result);
    if (!isset($row['COLUMN_NAME'])) {
        if ($wmap_field == "gc_status_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users  add gc_status_c varchar(100)  DEFAULT '' NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users  add COLUMN gc_status_c varchar(100)  DEFAULT '' NULL ;";
            }
            $db->query($add_fields_on_table);
        }
        if ($wmap_field == "wmaps_balloon_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users  add wmaps_balloon_c text  NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users  add COLUMN wmaps_balloon_c text  NULL ;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "gc_latitude_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users  add gc_latitude_c float  DEFAULT 0 NULL;";
            } else {
                $add_fields_on_table = "ALTER TABLE users  add COLUMN gc_latitude_c float(18,8)  DEFAULT 0 NULL;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "gc_longitude_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users    add gc_longitude_c float  DEFAULT 0 NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users    add COLUMN gc_longitude_c float(18,8)  DEFAULT 0 NULL ;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "gc_status_detail_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users   add gc_status_detail_c varchar(255)  DEFAULT '' NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users   add COLUMN gc_status_detail_c varchar(255)  DEFAULT '' NULL ;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "gc_date_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users   add gc_date_c datetime  NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users   add COLUMN gc_date_c datetime  NULL ;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "wmaps_pushpin_icon_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users   add wmaps_pushpin_icon_c text  NULL;";
            } else {
                $add_fields_on_table = "ALTER TABLE users   add COLUMN wmaps_pushpin_icon_c text  NULL;";
            }

            $db->query($add_fields_on_table);
        }

        if ($wmap_field == "wmaps_distance_unit_c") {
            if ($dbType == "mssql") {
                $add_fields_on_table = "ALTER TABLE users  add wmaps_distance_unit_c varchar(100)  DEFAULT '' NULL ;";
            } else {
                $add_fields_on_table = "ALTER TABLE users  add COLUMN wmaps_distance_unit_c varchar(100)  DEFAULT '' NULL ;";
            }
            $db->query($add_fields_on_table);
        }
    }
}

//set wMaps Geocoder default settings
require_once 'modules/Administration/Administration.php';
$admin = new Administration();
$admin->retrieveSettings('wMaps');
$settings = unserialize(base64_decode($admin->settings['wMaps_Settings']));

if (!isset($settings['geocode_opportunities'])) {
    $admin->saveSetting("geocoder", "bing_key", 'AuIEmeKGjvNV037yKiYGV0B3cxqNmx6FWnode0Hj8tjQPjK1zJP-7GAESccoCDUA');
}

if ($settings === false) {
    $wmaps_default_settings                    = array();
    $wmaps_default_settings['version']         = "1.00";
    $wmaps_default_settings['log_level']       = 0;
    $wmaps_default_settings['module_mappings'] = array();

    $wmaps_default_settings['module_mappings']['Accounts'] = array(
        'label'        => translate('LBL_MODULE_NAME', "Accounts"),
        'geocoding_by' => 'fields',
        'mapping'      => array(
            'address_street'     => 'billing_address_street',
            'address_city'       => 'billing_address_city',
            'address_state'      => 'billing_address_state',
            'address_postalcode' => 'billing_address_postalcode',
            'address_country'    => 'billing_address_country',
            'relate_field'       => '',
        ),
    );
    $wmaps_default_settings['module_mappings']['Contacts'] = array(
        'label'        => translate('LBL_MODULE_NAME', "Contacts"),
        'geocoding_by' => 'fields',
        'mapping'      => array(
            'address_street'     => 'primary_address_street',
            'address_city'       => 'primary_address_city',
            'address_state'      => 'primary_address_state',
            'address_postalcode' => 'primary_address_postalcode',
            'address_country'    => 'primary_address_country',
            'relate_field'       => '',
        ),
    );

    $wmaps_default_settings['module_mappings']['Leads'] = array(
        'label'        => translate('LBL_MODULE_NAME', "Leads"),
        'geocoding_by' => 'fields',
        'mapping'      => array(
            'address_street'     => 'primary_address_street',
            'address_city'       => 'primary_address_city',
            'address_state'      => 'primary_address_state',
            'address_postalcode' => 'primary_address_postalcode',
            'address_country'    => 'primary_address_country',
            'relate_field'       => '',
        ),
    );
    $wmaps_default_settings['module_mappings']['Prospects'] = array(
        'label'        => translate('LBL_MODULE_NAME', "Prospects"),
        'geocoding_by' => 'fields',
        'mapping'      => array(
            'address_street'     => 'primary_address_street',
            'address_city'       => 'primary_address_city',
            'address_state'      => 'primary_address_state',
            'address_postalcode' => 'primary_address_postalcode',
            'address_country'    => 'primary_address_country',
            'relate_field'       => '',
        ),
    );
    $wmaps_default_settings['module_mappings']['Users'] = array(
        'label'        => translate('LBL_MODULE_NAME', "Users"),
        'geocoding_by' => 'fields',
        'mapping'      => array(
            'address_street'     => 'address_street',
            'address_city'       => 'address_city',
            'address_state'      => 'address_state',
            'address_postalcode' => 'address_postalcode',
            'address_country'    => 'address_country',
            'relate_field'       => '',
        ),
    );
    $admin->saveSetting('wMaps', 'Settings', base64_encode(serialize($wmaps_default_settings)));
}

//create scheduled job "wMaps Geocoder"
$job                  = BeanFactory::getBean('Schedulers');
$job->name            = 'wMaps Geocoder';
$job->job             = 'function::GeoCodeJob';
$job->date_time_start = '2005-01-01 00:00:00';
$job->job_interval    = '30::1-5::*::*::*';
$job->status          = 'Active';
$job->catch_up        = '1';
$job->save();

global $sugar_config;

$link = $sugar_config['site_url'];

$code = <<<EOQ
<script type="text/javascript">
  $(window).ready(function(){
   	$('input[type="submit"]').parent().prepend('<br>Please click <a href="{$link}/#Home/layout/wmaps-setting-layout" target="_blank">here</a> to navigate to Geocoder Settings Page<br>');
  });
</script>
EOQ;

echo $code;
