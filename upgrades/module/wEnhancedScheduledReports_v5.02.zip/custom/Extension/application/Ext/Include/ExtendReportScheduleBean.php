<?php

$objectList["ReportSchedules"]     = "ReportSchedule";
$beanList["ReportSchedules"]       = "CustomReportSchedule";
$beanFiles["CustomReportSchedule"] = "custom/modules/ReportSchedules/CustomReportSchedule.php";
