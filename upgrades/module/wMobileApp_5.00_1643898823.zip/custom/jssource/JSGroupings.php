<?php

$js_groupings["sugar_grp_mobile"] = $sugar_grp_sugar7 = array(
    "include/javascript/sugar_grp_mobile.js" => "include/javascript/sugar_grp_mobile.min.js",
);
