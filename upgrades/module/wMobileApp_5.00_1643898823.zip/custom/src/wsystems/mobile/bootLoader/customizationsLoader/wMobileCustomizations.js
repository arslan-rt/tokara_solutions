(function initMobileCustomizations(app){
    SUGAR.mobile = {
        widgets    : {},
        views      : {},
        fields     : {},
        layouts    : {},
        dashlets   : {},
        extensions : {},
        styles     : {},
    };
    app.mobile = {
        widgets  : {},
        views    : {},
        fields   : {},
        layouts  : {},
        dashlets : {},
        styles   : {},
    };
})(SUGAR.App);