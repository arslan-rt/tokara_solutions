<?php

class wMobileCustomizationsHash
{
    public static function getCustomizationsHash()
    {
        return false;
    }
}
