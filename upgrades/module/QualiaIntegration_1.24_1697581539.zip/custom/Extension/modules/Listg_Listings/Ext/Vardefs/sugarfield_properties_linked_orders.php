<?php
$dictionary['Listg_Listings']['fields']['property_linked_orders'] =
array(
  'name'         => 'property_linked_orders',
  'type'         => 'link',
  'link_class'    => 'PropertiesParentLinkedOrders',
  'source'       => 'non-db',
  'vname'        => 'Orders Related To Current Property',
  'module'       => 'Order_RQ_Order',
  'bean_name'    => 'Order_RQ_Order',
  'link_type'    => 'many',
  'relationship' => '',
);
