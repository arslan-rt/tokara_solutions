<?php

$dictionary['Listg_Listings']['fields']["legal_description"]["full_text_search"] = array(
  'enabled'    => true,
  'searchable' => true,
  'boost'      => 1.91,
);
