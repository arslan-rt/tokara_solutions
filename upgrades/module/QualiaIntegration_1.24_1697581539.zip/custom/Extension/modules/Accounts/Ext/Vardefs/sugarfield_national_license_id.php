<?php
$dictionary["Account"]["fields"]["national_license_id"] =
array(
    "name"            => "national_license_id",
    "vname"           => "LBL_NATIONAL_LICENSE_ID",
    "type"            => "varchar",
    "module"          => "Account",
    "mass_update"     => true,
    "required"        => false,
    "reportable"      => true,
    "audited"         => false,
    "importable"      => true,
    "readonly"        => true,
    "duplicate_merge" => false,
);
