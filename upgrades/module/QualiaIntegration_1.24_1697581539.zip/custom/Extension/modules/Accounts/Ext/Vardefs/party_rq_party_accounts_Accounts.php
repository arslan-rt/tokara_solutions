<?php
// created: 2019-01-10 13:51:51
$dictionary["Account"]["fields"]["party_rq_party_accounts"] = array(
  'name'         => 'party_rq_party_accounts',
  'type'         => 'link',
  'relationship' => 'party_rq_party_accounts',
  'source'       => 'non-db',
  'module'       => 'Party_RQ_Party',
  'bean_name'    => 'Party_RQ_Party',
  'vname'        => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'id_name'      => 'party_rq_party_accountsparty_rq_party_ida',
);
