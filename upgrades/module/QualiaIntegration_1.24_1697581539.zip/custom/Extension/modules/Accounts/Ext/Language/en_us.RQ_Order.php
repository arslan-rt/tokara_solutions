<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE'] = 'RQ Orders';
$mod_strings['LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ACCOUNTS_TITLE']       = 'RQ Orders';
$mod_strings['LBL_RECORDVIEW_PANEL4']                                 = 'Account Info';
