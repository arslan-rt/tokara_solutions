<?php
 // created: 2019-01-10 13:51:34
$layout_defs["Accounts"]["subpanel_setup"]['order_rq_order_accounts'] = array (
  'order' => 100,
  'module' => 'Order_RQ_Order',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'get_subpanel_data' => 'order_rq_order_accounts',
);
