<?php
// created: 2018-10-15 11:13:01
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'order_rq_order_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'order_rq_order_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'order_rq_order_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'order_rq_order_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'order_rq_order_accounts',
  ),
);