<?php
// created: 2018-10-08 12:16:41
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);