<?php
$viewdefs["Accounts"]["base"]["filter"]["default"]["fields"]["party_types"] = [];
