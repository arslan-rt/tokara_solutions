<?php
 // created: 2019-01-10 13:51:51
$layout_defs["Accounts"]["subpanel_setup"]['party_rq_party_accounts'] = array (
  'order' => 100,
  'module' => 'Party_RQ_Party',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_PARTY_RQ_PARTY_TITLE',
  'get_subpanel_data' => 'party_rq_party_accounts',
);
