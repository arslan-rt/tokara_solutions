<?php
$dictionary["Account"]["fields"]["state_license_id"] =
array(
    "name"            => "state_license_id",
    "vname"           => "LBL_STATE_LICENSE_ID",
    "type"            => "varchar",
    "module"          => "Account",
    "mass_update"     => true,
    "required"        => false,
    "reportable"      => true,
    "audited"         => false,
    "importable"      => true,
    "readonly"        => true,
    "duplicate_merge" => false,
);
