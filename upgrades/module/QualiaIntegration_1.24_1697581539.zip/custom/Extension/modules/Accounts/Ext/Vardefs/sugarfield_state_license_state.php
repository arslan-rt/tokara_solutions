<?php
$dictionary["Account"]["fields"]["state_license_state"] =
array(
    "name"            => "state_license_state",
    "vname"           => "LBL_STATE_LICENSE_STATE",
    "type"            => "varchar",
    "module"          => "Account",
    "mass_update"     => true,
    "required"        => false,
    "reportable"      => true,
    "audited"         => false,
    "importable"      => true,
    "readonly"        => true,
    "duplicate_merge" => false,
);
