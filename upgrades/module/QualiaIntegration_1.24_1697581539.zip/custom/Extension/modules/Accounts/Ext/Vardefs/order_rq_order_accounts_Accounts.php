<?php
// created: 2019-01-10 13:51:34
$dictionary["Account"]["fields"]["order_rq_order_accounts"] = array(
  'name'         => 'order_rq_order_accounts',
  'type'         => 'link',
  'relationship' => 'order_rq_order_accounts',
  'source'       => 'non-db',
  'module'       => 'Order_RQ_Order',
  'bean_name'    => 'Order_RQ_Order',
  'vname'        => 'LBL_ORDER_RQ_ORDER_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name'      => 'order_rq_order_accountsaccounts_ida',
  'link-type'    => 'many',
  'side'         => 'left',
);
