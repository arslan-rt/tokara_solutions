<?php
// created: 2019-01-10 13:51:51
$dictionary["Loans_Loans"]["fields"]["party_rq_party_loans_loans"] = array (
  'name' => 'party_rq_party_loans_loans',
  'type' => 'link',
  'relationship' => 'party_rq_party_loans_loans',
  'source' => 'non-db',
  'module' => 'Party_RQ_Party',
  'bean_name' => 'Party_RQ_Party',
  'vname' => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_PARTY_RQ_PARTY_TITLE',
  'id_name' => 'party_rq_party_loans_loansparty_rq_party_ida',
);
