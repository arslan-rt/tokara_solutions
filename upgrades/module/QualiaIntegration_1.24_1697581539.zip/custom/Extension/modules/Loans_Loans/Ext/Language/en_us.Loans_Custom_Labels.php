<?php
$mod_strings['LBL_LOANTERM']   = 'Loan Term';
$mod_strings['LBL_LOANYEARS']  = 'Loan Years';
$mod_strings['LBL_LENDER']     = 'Lender';
$mod_strings['LBL_LOANMONTHS'] = 'Loan Months';
