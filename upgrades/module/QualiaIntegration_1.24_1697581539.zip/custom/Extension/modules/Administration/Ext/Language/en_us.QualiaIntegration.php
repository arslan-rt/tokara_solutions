<?php

$mod_strings["LBL_QUALIAINTEGRATION_PANEL_GROUP_NAME"] = "Qualia Integration Panels";
$mod_strings["LBL_QUALIAINTEGRATION_PANEL_GROUP_DESC"] = "Settingsfor Qualia Integration";

$mod_strings["LBL_QUALIAINTEGRATION_BASIC_PANEL_NAME"] = "Qualia Integration";
$mod_strings["LBL_QUALIAINTEGRATION_BASIC_PANEL_DESC"] = "Settings for Qualia Integration";
