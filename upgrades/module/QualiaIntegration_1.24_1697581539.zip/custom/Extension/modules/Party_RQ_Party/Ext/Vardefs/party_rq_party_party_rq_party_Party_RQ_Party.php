<?php
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_party_rq_party"] = array(
  'name'         => 'party_rq_party_party_rq_party',
  'type'         => 'link',
  'relationship' => 'party_rq_party_party_rq_party',
  'source'       => 'non-db',
  'module'       => 'Party_RQ_Party',
  'bean_name'    => 'Party_RQ_Party',
  'vname'        => 'LBL_PARTY_RQ_PARTY_PARTY_RQ_PARTY_FROM_PARTY_RQ_PARTY_L_TITLE',
  'id_name'      => 'party_rq_party_party_rq_partyparty_rq_party_ida',
);
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_party_rq_party"] = array(
  'name'         => 'party_rq_party_party_rq_party',
  'type'         => 'link',
  'relationship' => 'party_rq_party_party_rq_party',
  'source'       => 'non-db',
  'module'       => 'Party_RQ_Party',
  'bean_name'    => 'Party_RQ_Party',
  'vname'        => 'LBL_PARTY_RQ_PARTY_PARTY_RQ_PARTY_FROM_PARTY_RQ_PARTY_R_TITLE',
  'id_name'      => 'party_rq_party_party_rq_partyparty_rq_party_ida',
);
