<?php
// created: 2019-01-10 13:51:51
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_listg_listings"] = array(
  'name'         => 'party_rq_party_listg_listings',
  'type'         => 'link',
  'relationship' => 'party_rq_party_listg_listings',
  'source'       => 'non-db',
  'module'       => 'Listg_Listings',
  'bean_name'    => 'Listg_Listings',
  'vname'        => 'LBL_PARTY_RQ_PARTY_LISTG_LISTINGS_FROM_PARTY_RQ_PARTY_TITLE',
  'id_name'      => 'party_rq_party_listg_listingsparty_rq_party_ida',
  'link-type'    => 'many',
  'side'         => 'left',
);
