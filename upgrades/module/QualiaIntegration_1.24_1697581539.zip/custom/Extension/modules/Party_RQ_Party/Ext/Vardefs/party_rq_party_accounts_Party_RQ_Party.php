<?php
// created: 2019-01-10 13:51:51
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_accounts"] = array(
  'name'         => 'party_rq_party_accounts',
  'type'         => 'link',
  'relationship' => 'party_rq_party_accounts',
  'source'       => 'non-db',
  'module'       => 'Accounts',
  'bean_name'    => 'Account',
  'vname'        => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name'      => 'party_rq_party_accountsaccounts_idb',
);
