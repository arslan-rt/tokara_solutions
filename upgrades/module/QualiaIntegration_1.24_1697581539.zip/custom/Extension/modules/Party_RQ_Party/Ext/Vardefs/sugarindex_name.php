<?php

$dictionary['Party_RQ_Party']['indices'][] = array(
  'name'   => 'index_name_index',
  'type'   => 'index',
  'fields' => array(
    'name',
  ),
);
