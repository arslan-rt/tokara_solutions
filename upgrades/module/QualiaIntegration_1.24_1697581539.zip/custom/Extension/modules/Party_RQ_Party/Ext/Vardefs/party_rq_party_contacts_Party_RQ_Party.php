<?php
// created: 2019-01-10 13:51:51
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_contacts"] = array(
  'name'         => 'party_rq_party_contacts',
  'type'         => 'link',
  'relationship' => 'party_rq_party_contacts',
  'source'       => 'non-db',
  'module'       => 'Contacts',
  'bean_name'    => 'Contact',
  'vname'        => 'LBL_PARTY_RQ_PARTY_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name'      => 'party_rq_party_contactscontacts_idb',
);
