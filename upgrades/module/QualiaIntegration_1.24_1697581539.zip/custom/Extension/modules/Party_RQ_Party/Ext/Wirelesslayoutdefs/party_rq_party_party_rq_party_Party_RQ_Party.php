<?php
// created: 2019-01-14 10:18:58
$layout_defs["Party_RQ_Party"]["subpanel_setup"]['party_rq_party_party_rq_party'] = array(
  'order'             => 100,
  'module'            => 'Party_RQ_Party',
  'subpanel_name'     => 'default',
  'title_key'         => 'LBL_PARTY_RQ_PARTY_PARTY_RQ_PARTY_FROM_PARTY_RQ_PARTY_R_TITLE',
  'get_subpanel_data' => 'party_rq_party_party_rq_party',
);
