<?php

$dictionary['Party_RQ_Party']['indices'][] = array(
  'name'   => 'index_party_type_index',
  'type'   => 'index',
  'fields' => array(
    'party_type',
  ),
);
