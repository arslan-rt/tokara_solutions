<?php
// created: 2019-01-10 13:51:51
$layout_defs["Party_RQ_Party"]["subpanel_setup"]['party_rq_party_loans_loans'] = array(
  'order'             => 100,
  'module'            => 'Loans_Loans',
  'subpanel_name'     => 'default',
  'title_key'         => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_LOANS_LOANS_TITLE',
  'get_subpanel_data' => 'party_rq_party_loans_loans',
);
