<?php
// created: 2018-09-25 13:50:11
$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_order_rq_order',
  ),
);