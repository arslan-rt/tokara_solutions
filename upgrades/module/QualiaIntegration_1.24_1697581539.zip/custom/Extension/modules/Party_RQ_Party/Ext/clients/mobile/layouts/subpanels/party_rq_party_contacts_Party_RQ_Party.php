<?php
// created: 2019-01-10 13:39:59
$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_CONTACTS_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_contacts',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_CONTACTS_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_contacts',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_CONTACTS_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_contacts',
  ),
);