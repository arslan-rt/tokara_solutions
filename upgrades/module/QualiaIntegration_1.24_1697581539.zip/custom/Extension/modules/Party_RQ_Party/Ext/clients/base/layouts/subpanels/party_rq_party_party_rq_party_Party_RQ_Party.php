<?php
$viewdefs['Party_RQ_Party']['base']['layout']['subpanels']['components'][] = array(
  'layout'  => 'subpanel',
  'label'   => 'LBL_PARTY_RQ_PARTY_PARTY_RQ_PARTY_FROM_PARTY_RQ_PARTY_R_TITLE',
  'context' => array(
    'link' => 'party_rq_party_party_rq_party',
  ),
);
