<?php
// created: 2019-01-10 13:51:51
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_order_rq_order"] = array(
  'name'         => 'party_rq_party_order_rq_order',
  'type'         => 'link',
  'relationship' => 'party_rq_party_order_rq_order',
  'source'       => 'non-db',
  'module'       => 'Order_RQ_Order',
  'bean_name'    => 'Order_RQ_Order',
  'vname'        => 'LBL_PARTY_RQ_PARTY_ORDER_RQ_ORDER_FROM_ORDER_RQ_ORDER_TITLE',
  'id_name'      => 'party_rq_party_order_rq_orderorder_rq_order_idb',
);
