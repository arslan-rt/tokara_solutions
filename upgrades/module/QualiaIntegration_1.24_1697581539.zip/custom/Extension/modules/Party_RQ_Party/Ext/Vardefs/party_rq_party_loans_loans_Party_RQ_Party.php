<?php
// created: 2019-01-10 13:51:51
$dictionary["Party_RQ_Party"]["fields"]["party_rq_party_loans_loans"] = array(
  'name'         => 'party_rq_party_loans_loans',
  'type'         => 'link',
  'relationship' => 'party_rq_party_loans_loans',
  'source'       => 'non-db',
  'module'       => 'Loans_Loans',
  'bean_name'    => 'Loans_Loans',
  'vname'        => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_LOANS_LOANS_TITLE',
  'id_name'      => 'party_rq_party_loans_loansloans_loans_idb',
);
