<?php
// created: 2019-01-10 13:39:59
$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_LOANS_LOANS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_loans_loans',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_LOANS_LOANS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_loans_loans',
  ),
);

$viewdefs['Party_RQ_Party']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_LOANS_LOANS_FROM_LOANS_LOANS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_loans_loans',
  ),
);