<?php
// created: 2019-01-10 13:39:59
$viewdefs['Party_RQ_Party']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Party_RQ_Party']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);

$viewdefs['Party_RQ_Party']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PARTY_RQ_PARTY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'party_rq_party_accounts',
  ),
);