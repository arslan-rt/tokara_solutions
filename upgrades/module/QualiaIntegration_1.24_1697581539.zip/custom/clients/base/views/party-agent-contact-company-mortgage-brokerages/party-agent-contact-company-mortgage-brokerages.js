({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-mortgage-brokerages",
    agentType        : "MortgageBrokerages",
    partyModule      : "Accounts",
    partyDisplayName : "Mortgage Brokerage",
});