({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-listing-agencies",
    agentType        : "ListingAgencies",
    partyModule      : "Accounts",
    partyDisplayName : "Listing Agency",
});