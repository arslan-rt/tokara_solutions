({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-settlement-team",
    agentType        : "SettlementTeam",
    partyModule      : "Contacts",
    partyDisplayName : "Settlement Team",
    validFields      : [
        "email",
        "phone_mobile",
    ],
});