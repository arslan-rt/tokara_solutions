({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-recording-offices",
    agentType        : "RecordingOffices",
    partyModule      : "Accounts",
    partyDisplayName : "Recording Office",
});