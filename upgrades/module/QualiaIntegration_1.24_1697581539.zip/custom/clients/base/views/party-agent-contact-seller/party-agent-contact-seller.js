({
    extendsFrom      : "PartyAgentContactBorrowerSellerView",
    name             : "party-agent-contact-seller",
    agentType        : "Sellers",
    partyModule      : "Contacts",
    partyDisplayName : "Seller",
});