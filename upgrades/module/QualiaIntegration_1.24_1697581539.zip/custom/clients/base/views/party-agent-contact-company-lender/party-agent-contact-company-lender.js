({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-lender",
    agentType        : "Lenders",
    partyModule      : "Accounts",
    partyDisplayName : "Lender",
});