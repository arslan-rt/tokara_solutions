({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-tax-authorities",
    agentType        : "TaxAuthorities",
    partyModule      : "Accounts",
    partyDisplayName : "Tax Authority",
});