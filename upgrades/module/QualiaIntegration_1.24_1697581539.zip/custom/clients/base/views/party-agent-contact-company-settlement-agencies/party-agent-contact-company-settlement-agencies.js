({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-settlement-agencies",
    agentType        : "SettlementAgencies",
    partyModule      : "Accounts",
    partyDisplayName : "Settlement Agency",
});