({
    extendsFrom      : "PartyAgentView",
    name             : "party-loan",
    agentType        : "Loan",
    partyModule      : "Loans_Loans",
    partyDisplayName : "Loan",
    validFields      : [
        "amount",
        "loan_number",
        "interest_rate"
    ],
});