({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-other-contacts",
    agentType        : "OtherContacts",
    partyModule      : "Accounts",
    partyDisplayName : "OtherContact",
});