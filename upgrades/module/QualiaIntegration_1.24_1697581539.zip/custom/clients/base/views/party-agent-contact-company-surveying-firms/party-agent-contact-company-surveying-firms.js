({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-surveying-firms",
    agentType        : "Surveying Firms",
    partyModule      : "Accounts",
    partyDisplayName : "Surveying Firm",
});