({
    extendsFrom      : "PartyAgentContactBorrowerSellerView",
    name             : "party-agent-contact-borrower",
    agentType        : "Borrowers",
    partyModule      : "Contacts",
    partyDisplayName : "Borrower",
});