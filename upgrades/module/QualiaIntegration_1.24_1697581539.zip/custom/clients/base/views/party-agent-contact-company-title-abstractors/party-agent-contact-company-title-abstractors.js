({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-title-abstractors",
    agentType        : "TitleAbstractors",
    partyModule      : "Accounts",
    partyDisplayName : "Title Abstractor",
});