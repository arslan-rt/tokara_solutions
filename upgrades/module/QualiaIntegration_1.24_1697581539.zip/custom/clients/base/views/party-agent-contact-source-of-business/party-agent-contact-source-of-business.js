({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-source-of-business",
    agentType        : "SourceOfBusiness",
    partyModule      : "Accounts",
    partyDisplayName : "Source Of Business",
});