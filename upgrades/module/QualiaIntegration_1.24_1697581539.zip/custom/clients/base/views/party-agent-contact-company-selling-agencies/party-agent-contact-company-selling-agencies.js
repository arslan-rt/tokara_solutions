({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-selling-agencies",
    agentType        : "SellingAgencies",
    partyModule      : "Accounts",
    partyDisplayName : "Selling Agency",
});