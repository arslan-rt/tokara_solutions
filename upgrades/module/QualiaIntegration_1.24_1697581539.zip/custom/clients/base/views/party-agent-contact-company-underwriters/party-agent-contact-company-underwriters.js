({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-underwriters",
    agentType        : "Underwriters",
    partyModule      : "Accounts",
    partyDisplayName : "Underwriter",
});