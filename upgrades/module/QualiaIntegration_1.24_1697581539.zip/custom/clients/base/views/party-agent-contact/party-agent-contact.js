({
    extendsFrom        : "PartyAgentView",
    name               : "party-agent-contact",
    agentType          : "Associates",
    partyModule        : "Contacts",
    partyDisplayName   : "Associate",
    mainPartiesAllowed : ["SourceOfBusiness", "Borrower", "Seller", "Lenders", "ListingAgencies", "MortgageBrokerages",
        "OtherContacts", "RecordingOffices", "SellingAgencies", "SettlementAgencies", "SurveyingFirms",
        "TaxAuthorities", "TitleAbstractors", "TitleCompanies", "Underwriters", "SettlementTeam"],
    validFields: [],
});