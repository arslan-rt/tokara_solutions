({
    extendsFrom      : "PartyAgentView",
    name             : "party-property",
    agentType        : "Property",
    partyModule      : "Listg_Listings",
    partyDisplayName : "Property",
    validFields      : [
        "address",
        "address2",
        "zip_code",
        "city",
        "state",
        "county"
    ],
});