({
    extendsFrom      : "PartyAgentContactCompanyView",
    name             : "party-agent-contact-company-title-companies",
    agentType        : "TitleCompanies",
    partyModule      : "Accounts",
    partyDisplayName : "Title Company",
});