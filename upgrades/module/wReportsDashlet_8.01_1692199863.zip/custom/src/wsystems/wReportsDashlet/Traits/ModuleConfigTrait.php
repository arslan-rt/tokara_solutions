<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wReportsDashlet\Traits;

use DBManagerFactory;
use Doctrine\DBAL\Portability\Statement as Statement;
use Doctrine\DBAL\Query\QueryException;
use Exception;
use TimeDate;

/**
 * *** ModuleConfigTrait ***
 *
 * This trait manipulates custom configuration table.
 * It takes care of everything, including creating table, deleting table and
 * inserting/updating table records.
 *
 * @package SamplePackage
 * @author Vali Bratulescu
 * @version 1.0.2
 * @since SugarCRM 8.0
 * @since PHP 7.1
 *
 * *** Methods available ***
 *
 * @method modConfigTableCreate
 * @method modConfigTableTruncate
 * @method modConfigSet
 * @method modConfigGet
 */
trait ModuleConfigTrait
{
    /**
     * @var array
     */
    protected $modConfigMetadata = [
        "fields"  => [
            "assigned_user_id" => [
                "name"     => "assigned_user_id",
                "type"     => "id",
                "required" => true,
                "isnull"   => false,
                "default"  => "",
            ],
            "category"         => [
                "name"     => "category",
                "type"     => "varchar",
                "required" => true,
                "isnull"   => false,
            ],
            "name"             => [
                "name"     => "name",
                "type"     => "varchar",
                "required" => true,
                "isnull"   => false,
            ],
            "date_created"     => [
                "name" => "date_created",
                "type" => "datetime",
            ],
            "date_modified"    => [
                "name" => "date_modified",
                "type" => "datetime",
            ],
            "content"          => [
                "name" => "content",
                "type" => "text",
            ],
        ],
        "indices" => [
            [
                "name"   => "config_primary_key",
                "type"   => "primary",
                "fields" => [
                    "assigned_user_id", "category", "name",
                ],
            ],
            [
                "name"   => "idx_category_name",
                "type"   => "index",
                "fields" => [
                    "category", "name",
                ],
            ],
            [
                "name"   => "ids_user_id",
                "type"   => "index",
                "fields" => [
                    "assigned_user_id",
                ],
            ],
        ],
    ];

    /**
     * @return string
     */
    public function modConfigTableCreate(): string
    {
        $db = DBManagerFactory::getInstance();

        $tableName = $this->modConfigTableGetName();

        $fields  = $this->modConfigMetadata["fields"];
        $indices = $this->modConfigMetadata["indices"];

        return $db->repairTableParams($tableName, $fields, $indices);
    }

    /**
     * @return void
     */
    public function modConfigMetaLoad(): void
    {
        global $dictionary;

        if ($this->modConfigTableExists() === false) {
            $this->modConfigTableCreate();
        }

        $tableName = $this->modConfigTableGetName();
        $fields    = $this->modConfigMetadata["fields"];
        $indices   = $this->modConfigMetadata["indices"];

        $dictionary[$tableName] = [
            "table"   => $tableName,
            "fields"  => $fields,
            "indices" => $indices,
        ];
    }

    /**
     * @return void
     */
    public function modConfigTableTruncate(): void
    {
        $db = DBManagerFactory::getInstance();

        $db->query($db->truncateTableSQL($this->modConfigTableGetName()));
    }

    /**
     * Inserts or updates data to the custom config table.
     *
     * <code>
     *
     * $this->configSet([
     *     "sync_settings" => [
     *         "username" => "user",
     *         "password" => "pass"
     *     ],
     *     "logger_settings" => [
     *         "can_log"   => 1,
     *         "log_level" => "fatal"
     *     ],
     * ]);
     *
     * </code>
     *
     * Both `sync_settings` and `logger_settings` keys are going to be category names,
     * when doing the database insert/update.
     *
     * @param array $data
     * @param array $options isCurrentUser True to use the current user id to store data
     *                       userId Id of the user to store settings for
     *
     * @return array
     *
     * @throws Exception
     * @throws QueryException
     * @throws Doctrine\DBAL\Exception
     */
    public function modConfigSet(array $data, array $options = []): array
    {
        global $dictionary;
        global $current_user;

        $isCurrentUser = $options["isCurrentUser"] ?? false;
        $assignedUser  = ($isCurrentUser === true ? $current_user->id : $options["userId"]) ?? "";

        $this->modConfigMetaLoad();

        $status = [
            "status"   => "success",
            "updated"  => 0,
            "inserted" => 0,
        ];

        if (empty($data) === false) {
            $td    = TimeDate::getInstance();
            $db    = DBManagerFactory::getInstance();
            $table = $this->modConfigTableGetName();

            $fieldDefs = $dictionary[$table]["fields"];
            $now       = $td->nowDb();

            $fieldValues = [
                "assigned_user_id" => $assignedUser,
                "date_modified"    => $now,
            ];

            foreach ($data as $category => $fieldsData) {
                foreach ($fieldsData as $fieldName => $fieldValue) {
                    if ($this->modConfigCanUpdate($category, $fieldName, $assignedUser) === true) {
                        $fieldValues["name"]    = $fieldName;
                        $fieldValues["content"] = $fieldValue;

                        $updated = $db->updateParams($table, $fieldDefs, $fieldValues, [
                            "category"         => $category,
                            "name"             => $fieldName,
                            "assigned_user_id" => $assignedUser,
                        ]);

                        if ($updated === true) {
                            $status["updated"]++;
                        }
                    } else {
                        $fieldValues["category"]     = $category;
                        $fieldValues["name"]         = $fieldName;
                        $fieldValues["content"]      = $fieldValue;
                        $fieldValues["date_created"] = $now;

                        $inserted = $db->insertParams($table, $fieldDefs, $fieldValues);

                        if ($inserted === true) {
                            $status["inserted"]++;
                        }
                    }
                }
            }
        }

        return $status;
    }

    /**
     * Retrieves data from the custom config table.
     *
     * @param array $options isCurrentUser True to use the current user id to store data
     *                       userId Id of the user to fetch settings for
     *
     * @return array
     *
     * @throws Exception
     * @throws QueryException
     * @throws Doctrine\DBAL\Exception
     */
    public function modConfigGet(array $options = []): array
    {
        global $current_user;

        if ($this->modConfigTableExists() === false) {
            return [];
        }

        $qb = DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("category", "name", "content");
        $qb->from($this->modConfigTableGetName());

        $isCurrentUser = $options["isCurrentUser"] ?? true;
        $assignedUser  = ($isCurrentUser === true ? $current_user->id : $options["userId"]) ?? "";

        if (empty($assignedUser) === false) {
            $qb->where($qb->expr()->eq("assigned_user_id", ":assignedUser"));
            $qb->setParameter("assignedUser", $assignedUser);
        }

        $result = $qb->executeQuery();

        if ($result instanceof Statement === true) {
            $result = $result->fetchAllAssociative();
        }

        $data = [];

        foreach ($result as $item) {
            $category = $item["category"];
            $field    = $item["name"];
            $value    = $item["content"];

            if (isset($data[$category]) === false) {
                $data[$category] = [];
            }

            $data[$category][$field] = $value;
        }

        return $data;
    }

    /**
     * <code>
     *
     * $this->modConfigRemove(
     *     [
     *         "category" => "user-pref",
     *         "name"     => "last_state",
     *     ]
     * );
     *
     * </code>
     *
     * @param array $where Dictionary of $field => $value to know what rows to remove from the db
     * @param array $options isCurrentUser True to use the current user id to remove data for
     *                       userId Id of the user to remove settings for
     *
     * @return array
     *
     * @throws Exception
     */
    public function modConfigRemove(array $where, array $options = []): array
    {
        global $current_user;

        if ($this->modConfigTableExists() === false) {
            return [];
        }

        $qb = DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->delete($this->modConfigTableGetName());

        foreach ($where as $field => $value) {
            $qb->andWhere($qb->expr()->eq($field, ":{$field}_value"));
            $qb->setParameter(":{$field}_value", $value);
        }

        $isCurrentUser = $options["isCurrentUser"] ?? true;
        $assignedUser  = ($isCurrentUser === true ? $current_user->id : $options["userId"]) ?? "";

        if (empty($assignedUser) === false) {
            $qb->andWhere($qb->expr()->eq("assigned_user_id", ":assignedUser"));
            $qb->setParameter("assignedUser", $assignedUser);
        }

        $affectedRows = $qb->executeQuery();

        return [
            "status"  => "success",
            "deleted" => $affectedRows,
        ];
    }

    /**
     *
     * Checks if the given field has been already inserted in the config table,
     * so to know if it requires an update or a clean insert.
     *
     * @access protected
     *
     * @param string $category
     * @param string $field
     * @param null|string $assignedUser
     *
     * @return bool
     *
     * @throws Exception
     * @throws QueryException
     * @throws Doctrine\DBAL\Exception
     */
    protected function modConfigCanUpdate(string $category, string $field, ?string $assignedUser = null): bool
    {
        $qb = DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("COUNT(*) AS record_count");
        $qb->from($this->modConfigTableGetName());

        $qb->where($qb->expr()->eq("category", ":category"));
        $qb->andWhere($qb->expr()->eq("name", ":field"));
        $qb->andWhere($qb->expr()->eq("assigned_user_id", ":user"));

        $qb->setParameter("category", $category);
        $qb->setParameter("field", $field);
        $qb->setParameter("user", $assignedUser);

        $result = $qb->executeQuery();

        if ($result instanceof Statement === true) {
            $result = $result->fetchAssociative();
        }

        if (is_array($result) === true && $result["record_count"] > 0) {
            return true;
        }

        return false;
    }

    /**
     * Generates table name based on the namespace.
     *
     * @access protected
     *
     * @return string
     */
    protected function modConfigTableGetName(): string
    {
        $namespaceParts = explode("\\", __NAMESPACE__);

        foreach ($namespaceParts as $key => $part) {
            if ($part === "wsystems") {
                return "config_" . strtolower($namespaceParts[$key + 1]);
            }
        }

        return "";
    }

    /**
     * Checks if the config table already exists.
     *
     * @access protected
     *
     * @return bool
     */
    protected function modConfigTableExists(): bool
    {
        $db = DBManagerFactory::getInstance();

        return $db->tableExists($this->modConfigTableGetName()) === true;
    }
}
