<?php

$admin_option_defs = array();

$admin_option_defs["Administration"]["drilldown-settings"] = array(
    "Administration",
    "LBL_WDRILLDOWN_REPORTS_CHART_SETTINGS", //Link title
    "LBL_WDRILLDOWN_REPORTS_CHART_DESCRIPTION", //Link Description
    "./index.php?module=Home&action=layout/drilldown-settings",
);

$admin_group_header[] = array(
    "LBL_WDRILLDOWN_REPORTS_CHART_TITLE",
    "",
    false,
    $admin_option_defs,
    "", //Description of tab
);
