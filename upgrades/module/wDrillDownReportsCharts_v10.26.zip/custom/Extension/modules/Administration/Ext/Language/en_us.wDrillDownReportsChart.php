<?php

$mod_strings["LBL_WDRILLDOWN_REPORTS_CHART_SETTINGS"]    = "Settings";
$mod_strings["LBL_WDRILLDOWN_REPORTS_CHART_TITLE"]       = "wDrillDownReportsChart";
$mod_strings["LBL_WDRILLDOWN_REPORTS_CHART_DESCRIPTION"] = "Customize chart colors";
