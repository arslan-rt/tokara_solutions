<?php

array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\wDrillDownReportsChart\\Jobs\\ClearDrilldownCacheJob");
array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\wDrillDownReportsChart\\Jobs\\ClearDrilldownRecordsListJob");
array_push($job_strings, "class::Sugarcrm\\Sugarcrm\\custom\\wsystems\\wDrillDownReportsChart\\Jobs\\RemoveOutdatedDrilldownCacheJob");
