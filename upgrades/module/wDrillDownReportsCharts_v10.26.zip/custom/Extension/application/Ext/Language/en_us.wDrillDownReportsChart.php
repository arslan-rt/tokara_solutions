<?php

$app_strings["LBL_WCHART_CONFIG_SORT1_CHART"]                    = "Sort";
$app_strings["LBL_WCHART_CONFIG_SORT2_CHART"]                    = "Sort legend";
$app_strings["LBL_WCHART_CONFIG_SORT_DEFAULT"]                   = "Default";
$app_strings["LBL_WCHART_CONFIG_SORT_GROUP_ASC"]                 = "Labels Asc";
$app_strings["LBL_WCHART_CONFIG_SORT_GROUP_DESC"]                = "Labels Desc";
$app_strings["LBL_WCHART_CONFIG_SORT_VALUE_ASC"]                 = "Leaderboard Asc";
$app_strings["LBL_WCHART_CONFIG_SORT_VALUE_DESC"]                = "Leaderboard Desc";
$app_strings["LBL_WCHART_CONFIG_DEFAULT_LIST"]                   = "Default list shown when click an element";
$app_strings["LBL_WCHART_CONFIG_APPROXIMATE_TOTAL"]              = "Shorten total (e.g. 10k)";
$app_strings["LBL_WCHART_CONFIG_APPROXIMATE_VALUES"]             = "Shorten chart values (e.g. 10k)";
$app_strings["LBL_WCHART_CONFIG_APPROXIMATE_TOOLTIPS"]           = "Shorten values in tooltips (e.g. 10k)";
$app_strings["LBL_WCHART_CONFIG_APPROXIMATE_SHOW_BAR_TOTAL"]     = "Display Bar Total";
$app_strings["LBL_WCHART_CONFIG_TOOLBAR"]                        = "Toolbar Buttons";
$app_strings["LBL_WCHART_CONFIG_TOOLBAR_DRILLDOWN"]              = "DrillDown";
$app_strings["LBL_WCHART_CONFIG_TOOLBAR_COPY_TO_CLIPBOARD"]      = "Copy to clipboard";
$app_strings["LBL_WCHART_CONFIG_TOOLBAR_DOWNLOAD_IMAGE"]         = "Download as Image";
$app_strings["LBL_WCHART_CONFIG_TOOLBAR_TOGGLE_RUNTIME_FILTERS"] = "Runtime Filters";
$app_strings["LBL_CHART_CONFIG_ANIMATIONS"]                      = "Chart animations";

$app_strings["LBL_WCHART_COULD_NOT_APPLY_FILTER"] = "Could not apply the filter";
$app_strings["LBL_WCHART_MISSING_PARAMETER"]      = "Missing parameter";
$app_strings["LBL_WCHART_TOGGLE_LIST"]            = "Toggle list";
$app_strings["LBL_WCHART_LIST_REPORT_CONTENT"]    = "Report content";
$app_strings["LBL_WCHART_LIST_RECORDS"]           = "Records";

$app_strings["LBL_WCHART_SETTINGS_TITLE"]                = "wDrillDown Reports Chart Settings";
$app_strings["LBL_WCHART_SETTINGS_CUSTOM_SUCROSE"]       = "Custom Sucrose";
$app_strings["LBL_WCHART_SETTINGS_PREDEFINED_COLORS"]    = "Predefined Colors";
$app_strings["LBL_WCHART_SETTINGS_ADD_PREDEFINED_COLOR"] = "Add new";
$app_strings["LBL_WCHART_SETTINGS_SAVED_QRR"]            = "Saved! A Quick Repair and Rebuild should be made!";
$app_strings["LBL_WCHART_SETTINGS_SAVE_ERROR"]           = "A problem appeared while save. Please check current settings again!";
$app_strings["LBL_WCHART_SETTINGS_CHART_COLOR"]          = "Chart color";
$app_strings["LBL_WCHART_SETTINGS_CHART_TEXT"]           = "Chart text";

$app_strings["LBL_WCHART_REPORT_WAS_UPDATED"] = "Filters on Report were updated";

$app_strings["LBL_WCHART_DASHLET"]                            = "wChart Dashlet";
$app_strings["LBL_WCHART_DASHLET_SAVED_REPORTS_CHART_DESC"]   = "Displays any chart from a saved report.";
$app_strings["LBL_WCHART_DASHLET_DRILLDOWN_TOOLTIP"]          = "DrillDown";
$app_strings["LBL_WCHART_DASHLET_COPY_IMAGE"]                 = "Copy as Image";
$app_strings["LBL_WCHART_DASHLET_DOWNLOAD_IMAGE"]             = "Download as Image";
$app_strings["LBL_WCHART_DASHLET_PIE_CHART"]                  = "Pie Chart";
$app_strings["LBL_WCHART_DASHLET_VERTICAL_BAR_CHART"]         = "Vertical Bar Chart";
$app_strings["LBL_WCHART_DASHLET_VERTICAL_BAR_GROUPED_CHART"] = "Vertical Bar Grouped Chart";
$app_strings["LBL_WCHART_DASHLET_HORIZONTAL_BAR_CHART"]       = "Horizontal Bar Chart";
$app_strings["LBL_WCHART_DASHLET_HORIZONTAL_GROUPED_CHART"]   = "Horizontal Bar Grouped Chart";
$app_strings["LBL_WCHART_DASHLET_LINE_CHART"]                 = "Line Chart";
$app_strings["LBL_WCHART_DASHLET_FUNNEL_CHART"]               = "Funnel Chart";
$app_strings["LBL_WCHART_DASHLET_CHOOSE_LINK"]                = "Please choose a link";

$app_strings["LBL_WCHART_REPORT_DEPRECATED"]        = "Report chosen is deprecated.";
$app_strings["LBL_WCHART_REPORT_DEPRECATED_DETAIL"] = "Chosen report is deprecated and can not be related to current record. Try to edit the report, save it and come back!";
$app_strings["LBL_WCHART_RUNTIME_FILTER"]           = "Runtime filter based on current record";
$app_strings["LBL_WCHART_CANT_OPEN_LIST"]           = "Can't open the list. Please refresh the page";
$app_strings["LBL_WCHART_COPY_IMAGE_INSTRUCTIONS"]  = "<b>Right Click</b> and <b>Copy image</b>";

$app_strings["LBL_WCHART_ENTRYPOINT_UPDATED_DASHBOARD"]  = "Updated dashboard";
$app_strings["LBL_WCHART_ENTRYPOINT_UPDATED_DASHBOARDS"] = "<p>Checked all dashboards.</p>";

$app_strings["LBL_WCHART_ADMIN_SETTINGS"]             = "DrillDown Settings";
$app_strings["LBL_WCHART_ADMIN_SETTINGS_DESCRIPTION"] = "Configure Charts";
$app_strings["LBL_WCHART_ADMIN_LINK_TITLE"]           = "Settings";
$app_strings["LBL_WCHART_ADMIN_LINK_DESCRIPTION"]     = "Update charts settings";

$app_strings["LBL_WCHART_UPDATED_DASHBOARD"]       = "Updated dashboard";
$app_strings["LBL_WCHART_CONFIG_SHOW_XAXIS_LABEL"] = "Show x-axis label";
$app_strings["LBL_WCHART_CONFIG_SHOW_YAXIS_LABEL"] = "Show y-axis label";

$app_strings["LBL_WCHART_CONFIG_CHART_TYPE"]       = "Chart type";
$app_strings["LBL_WCHART_CONFIG_SHOW_TOTAL"]       = "Show total";
$app_strings["LBL_WCHART_SHOW_LEGEND"]             = "Show legend";
$app_strings["LBL_WCHART_LEGEND_OPEN"]             = "Show legend";
$app_strings["LBL_WCHART_CONFIG_SHOW_YAXIS_LABEL"] = "Show y-axis label";

$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_NONE"]    = "None";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_DEFAULT"] = "Default";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_START"]   = "Start";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_MIDDLE"]  = "Middle";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_END"]     = "End";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_TOP"]     = "Top";
$app_strings["LBL_WCHART_DASHLET_SHOW_VALUE_TOTAL"]   = "Total";

$app_strings["LBL_WCHART_DASHLET_SMALL_BAR_THICKNESS"]  = "Small";
$app_strings["LBL_WCHART_DASHLET_MEDIUM_BAR_THICKNESS"] = "Medium ";
$app_strings["LBL_WCHART_DASHLET_LARGE_BAR_THICKNESS"]  = "Large";

$app_list_strings["drilldown_auto_refresh_options"] = array(
    "0"   => "None",
    "5"   => "Every 5 Minutes",
    "15"  => "Every 15 Minutes",
    "30"  => "Every 30 Minutes",
    "45"  => "Every 45 Minutes",
    "60"  => "Every Hour",
    "120" => "Every 2 Hours",
);

$app_list_strings["drilldown_charts_options"] = array(
    ""                          => "",
    "pie chart"                 => "Pie Chart",
    "funnel chart"              => "Funnel Chart",
    "bar chart"                 => "Vertical Bar Chart",
    "group by chart"            => "Vertical Bar Grouped Chart",
    "horizontal bar chart"      => "Horizontal Bar Chart",
    "horizontal group by chart" => "Horizontal Bar Grouped Chart",
    "line chart"                => "Line Chart",
);
