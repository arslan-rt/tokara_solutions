<?php

//Table used to store runtime filters used in dashlets
$dictionary["wdrilldown_report_filters_dashlets"] = array(
    "table"   => "wdrilldown_report_filters_dashlets",
    "fields"  => array(
        "id"             => array(
            "name"     => "id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "report_id"      => array(
            "name"     => "report_id",
            "type"     => "id",
            "required" => false,
            "isnull"   => true,
        ),
        "dashlet_id"     => array(
            "name"     => "dashlet_id",
            "type"     => "varchar",
            "required" => false,
            "isnull"   => true,
        ),
        "user_id"        => array(
            "name"     => "user_id",
            "type"     => "varchar",
            "required" => false,
            "isnull"   => true,
        ),
        "filters"        => array(
            "name"     => "filters",
            "type"     => "text",
            "required" => false,
            "isnull"   => true,
        ),
        "date_generated" => array(
            "name"   => "date_generated",
            "type"   => "datetime",
            "isnull" => false,
        ),
    ),
    "indices" => array(
        array(
            "name"   => "wdrilldown_report_filters_dashletspk",
            "type"   => "primary",
            "fields" => array(
                "id",
            ),
        ),
        array(
            "name"   => "idx_date_generated",
            "type"   => "index",
            "fields" => array(
                "date_generated",
            ),
        ),
    ),
);
//Table used to store templates filters used in dashboards
$dictionary["wdrilldown_report_filters_templates"] = array(
    "table"   => "wdrilldown_report_filters_templates",
    "fields"  => array(
        "id"             => array(
            "name"     => "id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "dashboard_id"   => array(
            "name"     => "dashboard_id",
            "type"     => "varchar",
            "required" => false,
            "isnull"   => true,
        ),
        "templates"      => array(
            "name"     => "templates",
            "type"     => "text",
            "required" => false,
            "isnull"   => true,
        ),
        "date_generated" => array(
            "name"   => "date_generated",
            "type"   => "datetime",
            "isnull" => false,
        ),
    ),
    "indices" => array(
        array(
            "name"   => "wdrilldown_report_filters_templatespk",
            "type"   => "primary",
            "fields" => array(
                "id",
            ),
        ),
        array(
            "name"   => "idx_date_generated",
            "type"   => "index",
            "fields" => array(
                "date_generated",
            ),
        ),
    ),
);
//Table used to store runtime filters used in dashboards
$dictionary["wdrilldown_report_filters_dashboards"] = array(
    "table"   => "wdrilldown_report_filters_dashboards",
    "fields"  => array(
        "id"             => array(
            "name"     => "id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "dashboard_id"   => array(
            "name"     => "dashboard_id",
            "type"     => "varchar",
            "required" => false,
            "isnull"   => true,
        ),
        "user_id"        => array(
            "name"     => "user_id",
            "type"     => "varchar",
            "required" => false,
            "isnull"   => true,
        ),
        "filters"        => array(
            "name"     => "filters",
            "type"     => "text",
            "required" => false,
            "isnull"   => true,
        ),
        "date_generated" => array(
            "name"   => "date_generated",
            "type"   => "datetime",
            "isnull" => false,
        ),
    ),
    "indices" => array(
        array(
            "name"   => "wdrilldown_report_filters_dashboardspk",
            "type"   => "primary",
            "fields" => array(
                "id",
            ),
        ),
        array(
            "name"   => "idx_date_generated",
            "type"   => "index",
            "fields" => array(
                "date_generated",
            ),
        ),
    ),
);

//Table used to store records when click an element
$dictionary["wdrilldown_report_records"] = array(
    "table"   => "wdrilldown_report_records",
    "fields"  => array(
        "id"             => array(
            "name"     => "id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "drawer_id"      => array(
            "name"     => "drawer_id",
            "type"     => "varchar",
            "required" => true,
            "isnull"   => false,
        ),
        "record_id"      => array(
            "name"     => "record_id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "date_generated" => array(
            "name"   => "date_generated",
            "type"   => "datetime",
            "isnull" => false,
        ),
    ),
    "indices" => array(
        array(
            "name"   => "wdrilldown_report_recordspk",
            "type"   => "primary",
            "fields" => array(
                "id",
            ),
        ),
        array(
            "name"   => "idx_drawer_id",
            "type"   => "index",
            "fields" => array(
                "drawer_id",
            ),
        ),
        array(
            "name"   => "idx_date_generated",
            "type"   => "index",
            "fields" => array(
                "date_generated",
            ),
        ),
    ),
);

//Table used to store report data for the cache mechanism
$dictionary["wdrilldown_report_charts"] = array(
    "table"   => "wdrilldown_report_charts",
    "fields"  => array(
        "id"           => array(
            "name"     => "id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "report_id"    => array(
            "name"     => "report_id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "user_id"      => array(
            "name"     => "user_id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "dashlet_id"   => array(
            "name"     => "dashlet_id",
            "type"     => "id",
            "required" => true,
            "isnull"   => false,
        ),
        "report_data"  => array(
            "name"   => "report_data",
            "type"   => "text",
            "dbType" => "longtext",
            "isnull" => false,
        ),
        "chart_type"   => array(
            "name"   => "chart_type",
            "type"   => "varchar",
            "isnull" => false,
        ),
        "date_created" => array(
            "name"   => "date_created",
            "type"   => "datetime",
            "isnull" => false,
        ),
    ),
    "indices" => array(
        array(
            "name"   => "wdrilldown_report_chartspk",
            "type"   => "primary",
            "fields" => array(
                "id",
            ),
        ),
        array(
            "name"   => "idx_report_id",
            "type"   => "index",
            "fields" => array(
                "report_id",
            ),
        ),
        array(
            "name"   => "idx_dashlet_id",
            "type"   => "index",
            "fields" => array(
                "dashlet_id",
            ),
        ),
        array(
            "name"   => "idx_date_created",
            "type"   => "index",
            "fields" => array(
                "date_created",
            ),
        ),
    ),
);
