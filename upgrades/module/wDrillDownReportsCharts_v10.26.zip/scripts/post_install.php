<?php

function post_install()
{
    global $db, $timedate;

    //job to clear charts cache once a day
    $checkIfJobExists = <<<SQL
SELECT
    count(*) as count
FROM
    schedulers
WHERE
    job='class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\RemoveOutdatedDrilldownCacheJob'
AND
    deleted=0;
SQL;
    $countResult = $db->query($checkIfJobExists);
    $countRow    = $db->fetchByAssoc($countResult);
    $count       = $countRow['count'];

    if ($count == 0) {
        $job                  = BeanFactory::newBean('Schedulers');
        $job->name            = "Remove Outdated DrillDown Reports Charts Cache";
        $job->job             = "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\RemoveOutdatedDrilldownCacheJob";
        $job->date_time_start = $timedate->nowDb();
        $job->date_time_end   = null;
        $job->job_interval    = '0::0::*::*::*'; //once a day
        $job->status          = 'Active';
        $job->catch_up        = true;
        $job->save();
    }

    //job to drop temporary tables used on drilldown-drawer layout
    $checkIfJobExists = <<<SQL
SELECT
    count(*) as count
FROM
    schedulers
WHERE
    job='class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\ClearDrilldownRecordsListJob'
AND
    deleted=0;
SQL;
    $countResult = $db->query($checkIfJobExists);
    $countRow    = $db->fetchByAssoc($countResult);
    $count       = $countRow['count'];

    if ($count == 0) {
        $job                  = BeanFactory::newBean('Schedulers');
        $job->name            = "Delete report records - DrillDown Drawer";
        $job->job             = "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\ClearDrilldownRecordsListJob";
        $job->date_time_start = $timedate->nowDb();
        $job->date_time_end   = null;
        $job->job_interval    = '0::*/12::*::*::*'; //twice a day
        $job->status          = 'Active';
        $job->catch_up        = true;
        $job->save();
    }

    //dependency packages
    $administration = new Administration();
    $category       = "DrillDownDependencies";
    $key            = "mainPackage";
    $value          = "true";
    $platform       = "base";
    $administration->saveSetting($category, $key, $value, $platform);
}
