<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
$manifest = array (
  'acceptable_sugar_versions' =>  
  array (
    0 => '7.*',
    1 => '8.*',
    2 => '9.*',
    3 => '10.*',
    4 => '11.*'
  ),
  'acceptable_sugar_flavors' =>  
  array (

  ),
  'readme' =>  'README.txt',
  'key' =>  'WSYS',
  'author' =>  'Alexandru Prunaru',
  'description' =>  'wDrillDownReportsCharts',
  'icon' =>  '',
  'is_uninstallable' =>  true,
  'name' =>  'wDrillDownReportsCharts',
  'published_date' =>  '2021-09-01 14:17:51',
  'type' =>  'module',
  'version' =>  '10.26',
  'remove_tables' =>  'prompt'
);
$installdefs = array (
  'post_uninstall' =>  
  array (
    0 => '<basepath>/scripts/post_uninstall.php'
  ),
  'pre_uninstall' =>  
  array (
    0 => '<basepath>/scripts/pre_uninstall.php'
  ),
  'post_install' =>  
  array (
    0 => '<basepath>/scripts/post_install.php'
  ),
  'id' =>  'wDrillDownReportsCharts',
  'copy' =>  
  array (
    0 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/JSGroupings/wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/application/Ext/JSGroupings/wDrillDownReportsChart.php'
    ),
    1 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/Language/en_us.wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/application/Ext/Language/en_us.wDrillDownReportsChart.php'
    ),
    2 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/LogicHooks/wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/application/Ext/LogicHooks/wDrillDownReportsChart.php'
    ),
    3 =>     array (
      'from' =>  '<basepath>/custom/Extension/application/Ext/TableDictionary/wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/application/Ext/TableDictionary/wDrillDownReportsChart.php'
    ),
    4 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Administration/Ext/Administration/drilldown-settings.php',
      'to' =>  'custom/Extension/modules/Administration/Ext/Administration/drilldown-settings.php'
    ),
    5 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Administration/Ext/Language/en_us.wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/modules/Administration/Ext/Language/en_us.wDrillDownReportsChart.php'
    ),
    6 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Dashboards/Ext/LogicHooks/wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/modules/Dashboards/Ext/LogicHooks/wDrillDownReportsChart.php'
    ),
    7 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Reports/Ext/LogicHooks/RemoveChangedReportFromDrillDownCacheHook.php',
      'to' =>  'custom/Extension/modules/Reports/Ext/LogicHooks/RemoveChangedReportFromDrillDownCacheHook.php'
    ),
    8 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Schedulers/Ext/Language/en_us.wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/modules/Schedulers/Ext/Language/en_us.wDrillDownReportsChart.php'
    ),
    9 =>     array (
      'from' =>  '<basepath>/custom/Extension/modules/Schedulers/Ext/ScheduledTasks/wDrillDownReportsChart.php',
      'to' =>  'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/wDrillDownReportsChart.php'
    ),
    10 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/wDrillDownReportsChartApi.php',
      'to' =>  'custom/clients/base/api/wDrillDownReportsChartApi.php'
    ),
    11 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/wDrillDownReportsChartSettingsApi.php',
      'to' =>  'custom/clients/base/api/wDrillDownReportsChartSettingsApi.php'
    ),
    12 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/wDrillDownReportsDrawerApi.php',
      'to' =>  'custom/clients/base/api/wDrillDownReportsDrawerApi.php'
    ),
    13 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/wDrillDownReportsFilterApi.php',
      'to' =>  'custom/clients/base/api/wDrillDownReportsFilterApi.php'
    ),
    14 =>     array (
      'from' =>  '<basepath>/custom/clients/base/api/wDrillDownReportsListApi.php',
      'to' =>  'custom/clients/base/api/wDrillDownReportsListApi.php'
    ),
    15 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-chart/detail.hbs',
      'to' =>  'custom/clients/base/fields/drilldown-chart/detail.hbs'
    ),
    16 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-chart/drilldown-chart.js',
      'to' =>  'custom/clients/base/fields/drilldown-chart/drilldown-chart.js'
    ),
    17 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-collection-count/detail.hbs',
      'to' =>  'custom/clients/base/fields/drilldown-collection-count/detail.hbs'
    ),
    18 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-collection-count/drilldown-collection-count.js',
      'to' =>  'custom/clients/base/fields/drilldown-collection-count/drilldown-collection-count.js'
    ),
    19 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-header-title/detail.hbs',
      'to' =>  'custom/clients/base/fields/drilldown-header-title/detail.hbs'
    ),
    20 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-header-title/drilldown-header-title.js',
      'to' =>  'custom/clients/base/fields/drilldown-header-title/drilldown-header-title.js'
    ),
    21 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-labels/detail.hbs',
      'to' =>  'custom/clients/base/fields/drilldown-labels/detail.hbs'
    ),
    22 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/drilldown-labels/drilldown-labels.js',
      'to' =>  'custom/clients/base/fields/drilldown-labels/drilldown-labels.js'
    ),
    23 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/radio-group/edit.hbs',
      'to' =>  'custom/clients/base/fields/radio-group/edit.hbs'
    ),
    24 =>     array (
      'from' =>  '<basepath>/custom/clients/base/fields/radio-group/radio-group.js',
      'to' =>  'custom/clients/base/fields/radio-group/radio-group.js'
    ),
    25 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-drawer/drilldown-drawer.js',
      'to' =>  'custom/clients/base/layouts/drilldown-drawer/drilldown-drawer.js'
    ),
    26 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-drawer/drilldown-drawer.php',
      'to' =>  'custom/clients/base/layouts/drilldown-drawer/drilldown-drawer.php'
    ),
    27 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-filter-drawer/drilldown-filter-drawer.php',
      'to' =>  'custom/clients/base/layouts/drilldown-filter-drawer/drilldown-filter-drawer.php'
    ),
    28 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-filter-drawer-groups/drilldown-filter-drawer-groups.js',
      'to' =>  'custom/clients/base/layouts/drilldown-filter-drawer-groups/drilldown-filter-drawer-groups.js'
    ),
    29 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-filter-panel/drilldown-filter-panel.js',
      'to' =>  'custom/clients/base/layouts/drilldown-filter-panel/drilldown-filter-panel.js'
    ),
    30 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-report-base-list/drilldown-report-base-list.js',
      'to' =>  'custom/clients/base/layouts/drilldown-report-base-list/drilldown-report-base-list.js'
    ),
    31 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-report-base-list/drilldown-report-base-list.php',
      'to' =>  'custom/clients/base/layouts/drilldown-report-base-list/drilldown-report-base-list.php'
    ),
    32 =>     array (
      'from' =>  '<basepath>/custom/clients/base/layouts/drilldown-settings/drilldown-settings.php',
      'to' =>  'custom/clients/base/layouts/drilldown-settings/drilldown-settings.php'
    ),
    33 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-drawer-group/drilldown-filter-drawer-group.hbs',
      'to' =>  'custom/clients/base/views/drilldown-filter-drawer-group/drilldown-filter-drawer-group.hbs'
    ),
    34 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-drawer-group/drilldown-filter-drawer-group.js',
      'to' =>  'custom/clients/base/views/drilldown-filter-drawer-group/drilldown-filter-drawer-group.js'
    ),
    35 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-drawer-header/drilldown-filter-drawer-header.hbs',
      'to' =>  'custom/clients/base/views/drilldown-filter-drawer-header/drilldown-filter-drawer-header.hbs'
    ),
    36 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-drawer-header/drilldown-filter-drawer-header.js',
      'to' =>  'custom/clients/base/views/drilldown-filter-drawer-header/drilldown-filter-drawer-header.js'
    ),
    37 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-panel-group/drilldown-filter-panel-group.hbs',
      'to' =>  'custom/clients/base/views/drilldown-filter-panel-group/drilldown-filter-panel-group.hbs'
    ),
    38 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-panel-group/drilldown-filter-panel-group.js',
      'to' =>  'custom/clients/base/views/drilldown-filter-panel-group/drilldown-filter-panel-group.js'
    ),
    39 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-filter-panel-group/qualifier.hbs',
      'to' =>  'custom/clients/base/views/drilldown-filter-panel-group/qualifier.hbs'
    ),
    40 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-pane/drilldown-pane.hbs',
      'to' =>  'custom/clients/base/views/drilldown-pane/drilldown-pane.hbs'
    ),
    41 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-pane/drilldown-pane.js',
      'to' =>  'custom/clients/base/views/drilldown-pane/drilldown-pane.js'
    ),
    42 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-pane/drilldown-pane.php',
      'to' =>  'custom/clients/base/views/drilldown-pane/drilldown-pane.php'
    ),
    43 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-report-group-list/drilldown-report-group-list.hbs',
      'to' =>  'custom/clients/base/views/drilldown-report-group-list/drilldown-report-group-list.hbs'
    ),
    44 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-report-group-list/drilldown-report-group-list.js',
      'to' =>  'custom/clients/base/views/drilldown-report-group-list/drilldown-report-group-list.js'
    ),
    45 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.hbs',
      'to' =>  'custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.hbs'
    ),
    46 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.js',
      'to' =>  'custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.js'
    ),
    47 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.php',
      'to' =>  'custom/clients/base/views/drilldown-report-selection-headerpane/drilldown-report-selection-headerpane.php'
    ),
    48 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-settings/drilldown-settings.hbs',
      'to' =>  'custom/clients/base/views/drilldown-settings/drilldown-settings.hbs'
    ),
    49 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-settings/drilldown-settings.js',
      'to' =>  'custom/clients/base/views/drilldown-settings/drilldown-settings.js'
    ),
    50 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/drilldown-settings/predefined-chart-pair.hbs',
      'to' =>  'custom/clients/base/views/drilldown-settings/predefined-chart-pair.hbs'
    ),
    51 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-report-chart-filter/qualifier.hbs',
      'to' =>  'custom/clients/base/views/w-saved-report-chart-filter/qualifier.hbs'
    ),
    52 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-report-chart-filter/w-saved-report-chart-filter.hbs',
      'to' =>  'custom/clients/base/views/w-saved-report-chart-filter/w-saved-report-chart-filter.hbs'
    ),
    53 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-report-chart-filter/w-saved-report-chart-filter.js',
      'to' =>  'custom/clients/base/views/w-saved-report-chart-filter/w-saved-report-chart-filter.js'
    ),
    54 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.hbs',
      'to' =>  'custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.hbs'
    ),
    55 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.js',
      'to' =>  'custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.js'
    ),
    56 =>     array (
      'from' =>  '<basepath>/custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.php',
      'to' =>  'custom/clients/base/views/w-saved-reports-chart/w-saved-reports-chart.php'
    ),
    57 =>     array (
      'from' =>  '<basepath>/custom/clients/mobile/dashlets/w-saved-reports-chart/w-saved-reports-chart.js',
      'to' =>  'custom/clients/mobile/dashlets/w-saved-reports-chart/w-saved-reports-chart.js'
    ),
    58 =>     array (
      'from' =>  '<basepath>/custom/metadata/wDrillDownReportsChart.php',
      'to' =>  'custom/metadata/wDrillDownReportsChart.php'
    ),
    59 =>     array (
      'from' =>  '<basepath>/custom/modules/Reports/RemoveChangedReportFromDrillDownCacheHook.php',
      'to' =>  'custom/modules/Reports/RemoveChangedReportFromDrillDownCacheHook.php'
    ),
    60 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/mobile/include/javascript/FixSugarChartsDashlet.js',
      'to' =>  'custom/src/wsystems/mobile/include/javascript/FixSugarChartsDashlet.js'
    ),
    61 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Assets/css/drawer-style.css',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Assets/css/drawer-style.css'
    ),
    62 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html'
    ),
    63 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartColors.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartColors.js'
    ),
    64 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/Chart.bundle.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/Chart.bundle.js'
    ),
    65 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/Chart.bundle.min.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/Chart.bundle.min.js'
    ),
    66 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/barChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/barChartDataLabelsPlugin.js'
    ),
    67 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chart.funnel.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chart.funnel.js'
    ),
    68 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chart.funnel.min.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chart.funnel.min.js'
    ),
    69 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisLabelsPlugin.js'
    ),
    70 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisTicksLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisTicksLabelsPlugin.js'
    ),
    71 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartBackgroundColorPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartBackgroundColorPlugin.js'
    ),
    72 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartColorOpacityPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartColorOpacityPlugin.js'
    ),
    73 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartFixedAxisPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartFixedAxisPlugin.js'
    ),
    74 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/elementShadingPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/elementShadingPlugin.js'
    ),
    75 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/funnelBarChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/funnelBarChartDataLabelsPlugin.js'
    ),
    76 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/groupedBarChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/groupedBarChartDataLabelsPlugin.js'
    ),
    77 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarChartDataLabelsPlugin.js'
    ),
    78 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarGroupedChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarGroupedChartDataLabelsPlugin.js'
    ),
    79 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/legendLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/legendLabelsPlugin.js'
    ),
    80 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/pieChartDataLabelsPlugin.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/pieChartDataLabelsPlugin.js'
    ),
    81 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/bar.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/bar.js'
    ),
    82 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/funnel.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/funnel.js'
    ),
    83 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/groupedBar.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/groupedBar.js'
    ),
    84 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBar.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBar.js'
    ),
    85 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBarGrouped.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBarGrouped.js'
    ),
    86 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/line.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/line.js'
    ),
    87 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/pie.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/pie.js'
    ),
    88 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/dashletRefresh.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/dashletRefresh.js'
    ),
    89 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/filterReportsAvailableOnDrilldown.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/filterReportsAvailableOnDrilldown.js'
    ),
    90 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadDashboardFilter.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadDashboardFilter.js'
    ),
    91 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadUsers.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadUsers.js'
    ),
    92 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/plugins/component.extend.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/plugins/component.extend.js'
    ),
    93 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/previewEventsFix.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/previewEventsFix.js'
    ),
    94 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/processFiltersOnDashboardDuplicate.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/processFiltersOnDashboardDuplicate.js'
    ),
    95 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnMerge.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnMerge.js'
    ),
    96 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnPreviewEdit.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnPreviewEdit.js'
    ),
    97 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/removeNavigationInPreview.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/removeNavigationInPreview.js'
    ),
    98 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/resourcesLoader.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/resourcesLoader.js'
    ),
    99 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/JSGroupings/utils.js',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/JSGroupings/utils.js'
    ),
    100 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Jobs/ClearDrilldownCacheJob.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Jobs/ClearDrilldownCacheJob.php'
    ),
    101 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Jobs/ClearDrilldownRecordsListJob.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Jobs/ClearDrilldownRecordsListJob.php'
    ),
    102 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Jobs/RemoveOutdatedDrilldownCacheJob.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Jobs/RemoveOutdatedDrilldownCacheJob.php'
    ),
    103 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardDuplicateHook.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardDuplicateHook.php'
    ),
    104 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsAppendRuntimesHook.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsAppendRuntimesHook.php'
    ),
    105 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsRemoveDrilldownReferenceHook.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsRemoveDrilldownReferenceHook.php'
    ),
    106 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/LogicHooks/RemoveFiltersOnDashboardDeleteHook.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/RemoveFiltersOnDashboardDeleteHook.php'
    ),
    107 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/RecordsQuery.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/RecordsQuery.php'
    ),
    108 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/SummaryQuery.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/SummaryQuery.php'
    ),
    109 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Traits/VardefsHandlerTrait.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Traits/VardefsHandlerTrait.php'
    ),
    110 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Utils/FilterUtils.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Utils/FilterUtils.php'
    ),
    111 =>     array (
      'from' =>  '<basepath>/custom/src/wsystems/wDrillDownReportsChart/Utils/Utils.php',
      'to' =>  'custom/src/wsystems/wDrillDownReportsChart/Utils/Utils.php'
    )
  )
);