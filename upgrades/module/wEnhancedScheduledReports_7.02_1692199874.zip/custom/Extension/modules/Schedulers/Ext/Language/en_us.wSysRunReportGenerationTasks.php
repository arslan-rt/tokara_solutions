<?php

$mod_strings["LBL_ADDWSYSRUNREPORTGENERATIONSCHEDULEDTASKS"] = "WSystems Run Report Generation Scheduled Tasks";
