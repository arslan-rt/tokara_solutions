<?php

$app_list_strings["reportschedule_time_interval_dom"]["1"]  = "1st of Month";
$app_list_strings["reportschedule_time_interval_dom"]["2"]  = "Monthly";
$app_list_strings["reportschedule_time_interval_dom"]["15"] = "15th of Month";
$app_list_strings["reportschedule_time_interval_dom"]["31"] = "Last Day of Month";
