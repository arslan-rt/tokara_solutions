<?php

$hook_array["job_failure"][] = array(
    1,
    "Log more verbose errors",
    null,
    "Sugarcrm\\Sugarcrm\\custom\\wsystems\\wEnhancedScheduledReports\\LogicHooks\\SchedulersJobsVerboseLoggerHook",
    "logErrors",
);
