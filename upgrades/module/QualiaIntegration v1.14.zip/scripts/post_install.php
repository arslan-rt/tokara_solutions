<?php

if (function_exists("post_install") === false) {
    function post_install()
    {
        $instance = new Sugarcrm\Sugarcrm\custom\wsystems\QualiaIntegration\Setup\Install();
        $instance->postInstall();
    }
}
