<?php

function pre_uninstall()
{
    $administration = new Administration();
    $category       = "DrillDownDependencies";
    $clean          = true;
    $administration->retrieveSettings($category, $clean);
    $packagesThatNeedToBeUninstalledFirst = array(
        "defaultOrder" => "DrillDownDefaultOrder",
    );

    $dependentPackagesAreInstalled = false;
    foreach ($packagesThatNeedToBeUninstalledFirst as $packageId => $pacakgeName) {
        $key = $category . "_" . $packageId;

        if (array_key_exists($key, $administration->settings) && $administration->settings[$key] === 'true') {
            echo "<p>Please uninstall {$pacakgeName} first!</p>";
            $GLOBALS["log"]->fatal("User tried to uninstall {$pacakgeName} before uninstalling uDrillDown package");
            $dependentPackagesAreInstalled = true;
        } else {
            // dependent package is not installed
        }
    }

    if ($dependentPackagesAreInstalled) {
        die();
    }
}
