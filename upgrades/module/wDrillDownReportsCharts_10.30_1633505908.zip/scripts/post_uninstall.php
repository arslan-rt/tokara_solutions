<?php

include_once 'modules/Configurator/Configurator.php';
global $db;
$conn = $db->getConnection();
//update engine if current value was our custom one
$configurator = new Configurator();
$configurator->loadConfig();
$currentSavedEngine = $configurator->config['chartEngine'];
if ($currentSavedEngine === 'customsucrose') {
    $configurator->config['chartEngine'] = 'sucrose';
    $configurator->handleOverride(); //at the moment we only update the config_override and not config.php
    echo "<p>Updated chartEngine config back to 'sucrose'.</p>";
}

if (array_key_exists('remove_tables', $_REQUEST) && $_REQUEST['remove_tables'] == "true") {
    $conn->executeQuery("drop table wdrilldown_report_charts;", array());
}

//delete scheduled jobs to: remove outdated caches & remove temporary drilldown tables
$deleteScheduleQuery = <<<SQL
DELETE
FROM
    schedulers
WHERE
    job=?
OR
    job=?;
SQL;

$deleteParams = array(
    "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\RemoveOutdatedDrilldownCacheJob",
    "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\ClearDrilldownRecordsListJob",
);
$conn->executeQuery($deleteScheduleQuery, $deleteParams);

//delete from queue existing jobs scheduled
$deleteJobQueueQuery = <<<SQL
DELETE
FROM
    job_queue
WHERE
    target = ?
OR
    target = ?;
SQL;
$deleteQueueParams = array(
    "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\RemoveOutdatedDrilldownCacheJob",
    "class::Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs\ClearDrilldownRecordsListJob",
);
$conn->executeQuery($deleteJobQueueQuery, $deleteQueueParams);

//dependency packages
$administration = new Administration();
$category       = "DrillDownDependencies";
$key            = "mainPackage";
$value          = "false";
$platform       = "base";
$administration->saveSetting($category, $key, $value, $platform);
