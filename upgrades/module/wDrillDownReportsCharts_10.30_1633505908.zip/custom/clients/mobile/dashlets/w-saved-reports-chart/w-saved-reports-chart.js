({
    extendsFrom: {
        baseType: "saved-reports-chart",
    },

    getChartModel: function(params, config) {
        var chart = this._super("getChartModel", arguments);

        // temp fix for SUGARCrm bug
        if (!chart.fmtCount) {
            chart.fmtCount = function fmtCount() {
                return {fmtValue: function fmtValue(){
                    return false;
                }};
            };
        }

        return chart;
    },

    loadChartData: function loadChartData(loadChartDataCallback) {
        var reportId = this.meta.view.saved_report_id; //eslint-disable-line camelcase
        var screenContext = app.controller.getScreenContext();
        var parentModel = app.controller.layoutManager.getRootLayout().context.get("parentModel");
        var recordName = parentModel ? (parentModel.get("name") ? parentModel.get("name") : parentModel.get("first_name")) : "Record";

        var dataToSendForChartLoading = {
            groupType         : "simple",
            reportId          : reportId,
            record_id         : screenContext.parentModelId, //eslint-disable-line camelcase
            record_name       : recordName, //eslint-disable-line camelcase
            link              : this.meta.view.link,
            module            : screenContext.parentModule,
            dashletChartType  : this.meta.view.chart_type,
            approximateTotal  : true,
            approximateValues : true,
            hideEmptyGroups   : false
        };

        app.api.call("create", app.api.buildURL("Reports/" + reportId + "/wchart"), dataToSendForChartLoading, {
            success: _.bind(function successRetrieveWChart(data) {
                data.chartData.properties = [{type: this.meta.view.chart_type, "base_module": data.reportDefs.module}];
                data.chartData.values = [];
                data.chartData.label = ["Column"];
                data.reportData = data.reportDefs;

                _.each(data.chartData.data, function restructureData(columnData, key){
                    data.chartData.values[key] = {};
                    data.chartData.values[key].values = [columnData.recordsCount];
                    data.chartData.values[key].label = [columnData.group1_label];
                });
                
                var enumsToFetch = this.getEnums(data.reportDefs);

                if (!_.isEmpty(enumsToFetch) && !this.enums) {
                    this._loadEnumOptions(enumsToFetch, data.reportDefs)
                        .then(enums => {
                            this.enums = enums;
                            loadChartDataCallback(null, data);
                        })
                        .catch(error => {
                            loadChartDataCallback(error);
                        });
                } else {
                    loadChartDataCallback(null, data);
                }
            }, this),
            error: loadChartDataCallback,
        }, {
            skipMetadataHash: true,
        });
    },
});
