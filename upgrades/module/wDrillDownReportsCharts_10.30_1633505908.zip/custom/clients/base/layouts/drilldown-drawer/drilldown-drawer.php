<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$viewdefs['base']['layout']['drilldown-drawer'] = [
    'components' => [
        [
            'layout' => [
                'type'         => 'default',
                'name'         => 'sidebar',
                'default_hide' => '0',
                'hide_key'     => 'drilldown-element-chart',
                'css_class'    => "chart-drawer",
                'components'   => [
                    [
                        'layout' => [
                            'type'       => 'base',
                            'name'       => 'main-pane',
                            'css_class'  => 'main-pane span8',
                            'components' => [
                                array(
                                    'view' => 'drilldown-report-selection-headerpane',
                                ),
                                array(
                                    'view' => 'drilldown-report-group-list',
                                ),
                                array(
                                    'layout' => 'drilldown-report-base-list',
                                ),
                            ],
                        ],
                    ],
                    [
                        "layout" => [
                            "type"       => "base",
                            "name"       => "dashboard-pane",
                            "css_class"  => "dashboard-pane",
                            "components" => [
                                [
                                    "view" => "drilldown-pane",
                                ],
                            ],
                        ],
                    ],
                    [
                        'layout' => [
                            'type'       => 'base',
                            'css_class'  => 'preview-pane',
                            'name'       => 'preview-pane',
                            'components' => [
                                [
                                    'layout' => 'preview',
                                    'xmeta'  => [
                                        'editable'           => true,
                                        'isDrilldownPreview' => true,
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
];
