({
    initialize: function(options) {
        var initRes = this._super("initialize", arguments);

        this.context.on("drawer:refreshReportList", this.refreshReportList.bind(this));
        this.context.on("drawer:refreshRecordsList", this.refreshRecordsList.bind(this));

        return initRes;
    },

    /**
     * Updates report list OR base records list upon chart click in already opened drawer
     * We'll use view id of the initial dashlet, not the one in the panel.
     * Firstly will update the temp table. Then update the lists.
     */
    updateLists: function() {
        if (this.disposed) {
            return;
        }
        var params = this.model.attributes.settings.attributes;
        params.reportModule = this.model.attributes.reportDefs.module;
        
        app.alert.show("updatingDrilldownDrawer", {
            level : "process",
            title : app.lang.get("LBL_LOADING")
        });

        app.wsystems.wDrillDownReportsChart._updatingATempTable = true;
        app.api.call("create", app.api.buildURL("Reports/drawerRecords/update"), params, {
            success: function successCallback(res) {
                if (res == true) {
                    this.refreshReportList();
                    this.refreshRecordsList();
                } else {
                    app.alert.show("errorUpdatingTable", {
                        level     : "error",
                        messages  : app.lang.get("LBL_WCHART_COULD_NOT_APPLY_FILTER"),
                        autoClose : true
                    });
                    window.console.log("Could not apply the filter");
                }
            }.bind(this),
            error: function() {
                app.alert.show("errorUpdatingTable", {
                    level     : "error",
                    messages  : app.lang.get("LBL_WCHART_MISSING_PARAMETER"),
                    autoClose : true
                });
                window.console.log("Could not apply the filter");
            },
            complete: function() {
                app.alert.dismiss("updatingDrilldownDrawer");
                delete app.wsystems.wDrillDownReportsChart._updatingATempTable;
            }
        }, {
            skipMetadataHash: true,
        });
    },

    refreshReportList: function() {
        var params = this.context.attributes.model.attributes.settings.attributes;
        if (this.disposed) {
            return;
        }
        var header = this.getComponent("sidebar").getComponent("main-pane").getComponent("drilldown-report-selection-headerpane");
        if (header.drawerListDisplayState !== "report-group-list") {
            return;
        }
        params = params || {};
        var reportId = this.context.attributes.model.attributes.settings.attributes.reportId;
        var reportGroupList = this.getComponent("sidebar")
            .getComponent("main-pane")
            .getComponent("drilldown-report-group-list");

        reportGroupList.model.attributes = _.extend(reportGroupList.model.attributes, params);
        //eslint-disable-next-line camelcase
        reportGroupList.model.attributes.next_offset = 0;
        reportGroupList.resetServerData();
        reportGroupList.getSavedReportById(reportId);
    },

    /**
     * Update Records list component with records from selected element.
     * For Trackers module, this mean we need to reinitialize the component
     * @method
     * @return {[type]} [description]
     */
    refreshRecordsList: function() {
        if (this.disposed) {
            return;
        }
        var params = this.context.attributes.model.attributes.settings.attributes;
        var header = this.getComponent("sidebar").getComponent("main-pane").getComponent("drilldown-report-selection-headerpane");
        if (header.drawerListDisplayState !== "report-base-list") {
            return;
        }
        params = params || {};
        var reportBaseList;
        if (params.reportModule == "Trackers") {
            //create the new list and replace it
            reportBaseList = this.getComponent("sidebar")
                .getComponent("main-pane")
                .getComponent("drilldown-report-base-list");
            var newListOptions = reportBaseList.options;
            newListOptions.context = this.context;
            var newListLayout = app.view.createLayout(newListOptions);
            reportBaseList.dispose();
            var mainLayout = this.getComponent("sidebar").getComponent("main-pane");
            var layoutIdx = 2;
            mainLayout._components[layoutIdx] = newListLayout;
            mainLayout._placeComponent(newListLayout);

            newListLayout.initComponents();
            newListLayout.render();
            newListLayout.collection.fetch();
        } else {
            reportBaseList = this.getComponent("sidebar")
                .getComponent("main-pane")
                .getComponent("drilldown-report-base-list");

            reportBaseList.options.params = _.extend({}, reportBaseList.options.params, params);
            reportBaseList.collection.fetch();
        }
    },

    /**
     * When a create/update/delete is made, we check if the chart is visible.
     * If it's not, we'll wait for preview to close in order to refresh it.
     * @method
     * @return {[type]} [description]
     */
    updatePanelChartWhenPossible: function() {
        var dashboardPane = this.getComponent("sidebar").getComponent("dashboard-pane");
        var drilldownPane = dashboardPane.getComponent("drilldown-pane");
        var dashboardOpened = drilldownPane.$el.is(":visible");
        if (dashboardOpened) {
            this.reloadPanelChart();
        } else {
            var previewPane = this.getComponent("sidebar").getComponent("preview-pane");
            var previewLayout = previewPane.getComponent("preview");
            var previewOpened = previewLayout.$el.is(":visible");
            if (previewOpened) {
                app.events.once("preview:close", this.reloadPanelChart);
            }
        }
    },

    reloadPanelChart: function() {
        var drawer = app.drawer.getActive();
        if (typeof drawer != "undefined" && drawer.type == "drilldown-drawer") {
            var dashboardPane = drawer.getComponent("sidebar").getComponent("dashboard-pane");
            var dashlet = dashboardPane
                .getComponent("drilldown-pane")
                .getComponent("dashlet")
                .getComponent("w-saved-reports-chart");
            dashlet.loadData({ forceRefresh: true });
        }
    }
});