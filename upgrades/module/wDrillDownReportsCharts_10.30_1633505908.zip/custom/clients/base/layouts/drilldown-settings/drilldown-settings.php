<?php
$viewdefs['base']['layout']['drilldown-settings'] = array(
    'type'       => 'simple',
    'components' => array(
        array(
            'view' => 'drilldown-settings',
        ),
    ),
);
