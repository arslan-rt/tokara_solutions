({
    className: "hide", //hide this component when open the drawer. on toggle it will be available

    /**
     * Create new model, collection and context in order to isolate this dynamic layout.
     * In Tracker case, we'll have different modules represented, so we need to generate the correct environment
     *
     * @method
     * @param  {[type]} options [description]
     * @return {[type]} [description]
     */
    initialize: function(options) {
        var dashletSettings = options.context.attributes.model.attributes.settings;
        var reportModule = options.context.attributes.model.attributes.settings.attributes.reportModule;
        if (reportModule == "Trackers") {
            //for this module we show real records, not tracker's data
            var groupDefs = options.context.attributes.model.attributes.reportData.attributes.reportDefs.group_defs;
            if (groupDefs[0]["table_key"] == "self" && groupDefs[0]["name"] == "module_name") {
                reportModule = options.context.attributes.model.attributes.settings.attributes.group1_filter_value;
            } else if (
                //the module is either on the group1 or on group2.
                groupDefs.length > 1 &&
                groupDefs[1]["table_key"] == "self" &&
                groupDefs[1]["name"] == "module_name"
            ) {
                reportModule = options.context.attributes.model.attributes.settings.attributes.group2_filter_value;
            }
        }

        var baseModel = app.data.createBean(reportModule, {
            module  : reportModule,
            _module : reportModule
        });
        var baseCollection = app.data.createBeanCollection(reportModule);
        var reportId = dashletSettings.attributes.reportId;
        var waitForANewRequest = 500;
        /**
         * After merge, Sugar will make a fetch on base collection. We also update the Temp Table.
         * Both requests use the same TT. This causes the select to not find it, and return the sql in the page.
         *
         * After update the temp table, we make a refresh on this base collection
         *
         * So, solution is to debounce the endpoint + check against an executing update, before starting to fetch collection
         */
        var endpoint = _.debounce(function debouncedBaseListEndPoint(method, model, options, callbacks) {
            if (app.wsystems.wDrillDownReportsChart._updatingATempTable) {
                //merge records use case
                window.console.log(
                    "Do not fetch base list. An update is currently executing on temp table and it is locked."
                );
                return {
                    count       : 0,
                    next_offset: -1, //eslint-disable-line
                    records     : []
                };
            }
            var params = _.extend(
                {view: "list"},
                options.params,
                dashletSettings.attributes
            );

            //for some reason, the reportModule gets overriden sometimes, easy fix for now is to set it again
            params.reportModule = this.context.attributes.reportData.attributes.reportDefs.module;

            var url = app.api.buildURL("Reports/" + reportId + "/baselist");
            return app.api.call("create", url, params, callbacks);
        }, waitForANewRequest);
        baseCollection.setOption("endpoint", _.bind(endpoint, this));

        var listContext = new app.Context({
            module     : reportModule,
            model      : baseModel,
            collection : baseCollection,
            settings   : options.context.attributes.model.attributes.settings,
            reportData : options.context.attributes.model.attributes.reportData,
        });

        options.module = reportModule;
        options.context = listContext;

        if ( options.context.attributes.settings.attributes.defaultListShown === "report-group-list") {
            options.context.set("skipFetch", true);
        }

        // filter enabled would always make a call when open the drawer
        options.context.set("filterOptions", {
            auto_apply: false, //eslint-disable-line camelcase
        });

        this.once("render", _.debounce(function makeAgainTheListFiltrable(){
            var listHeader = this.layout.getComponent("drilldown-report-selection-headerpane");
            if (listHeader.drawerListDisplayState == "report-base-list") {
                if (!this.$el.hasClass("hide")) {
                    if (!this.collection.dataFetched) {
                        this.collection.fetch();
                    }
                }
            }

            //add back the auto apply in order for the filter to work
            this.context.set("filterOptions", {
                auto_apply: true //eslint-disable-line camelcase
            });
        }.bind(this), 0));

        var initRes = this._super("initialize", [options]);

        baseCollection.on("data:sync:complete", function dataSyncComplete(method, options, request) {
            var drawer;
            //reload list
            if (method == "update") {
                drawer = app.drawer.getActive();
                if (typeof drawer != "undefined" && drawer.type == "drilldown-drawer") {
                    drawer.updateLists();
                }
            }
            if (method == "read") {
                drawer = App.drawer.getActive();
                if (typeof drawer == "undefined" || drawer.type !== "drilldown-drawer") {
                    return;
                }

                var header = drawer
                    .getComponent("sidebar")
                    .getComponent("main-pane")
                    .getComponent("drilldown-report-selection-headerpane");
                var count;
                try {
                    if (
                        this._activeFetchRequest != "undefined" &&
                        this._activeFetchRequest != null &&
                        typeof this._activeFetchRequest.xhr != "undefined"
                    ) {
                        count = this._activeFetchRequest.xhr.responseJSON.count; //7.10
                    } else {
                        count = request.xhr.responseJSON.count; //7.11
                    }

                    if (typeof request.xhr.responseJSON.total === "number") {
                        count = request.xhr.responseJSON.total;
                    }
                    /**
                     * A read will be made both on collection load AND on preview fetch.
                     * We send the count paramter only on collection load.
                     * So this following if will check if we're on the correct use case
                     */
                    if (typeof count != "undefined") {
                        header.context.set("listCount", count);
                    }
                } catch (e) {
                    // request was not for collection fetch
                }
            }
            this.broadcastCollectionFetch();
        }.bind(this));

        this.layout.on("selection:togglelist:fire", this.fixListComponent);
        return initRes;
    },

    broadcastCollectionFetch: function() {
        this.layout.context.trigger("update:drilldown:header");
    },

    initComponents: function(components, context, module) {
        var initRes = this._super("initComponents", arguments);
        try {
            var recordlist = this.getComponent("main-pane")
                .getComponent("filterpanel")
                .getComponent("list")
                .getComponent("recordlist");
            recordlist.on("mergeduplicates:complete", this.triggerRefresh);
        } catch (e) {
            window.console.log(e);
        }
        return initRes;
    },

    triggerRefresh: function() {
        app.events.trigger("drilldown:update");
        app.DrillDownRefreshNeeded = true;
    },

    render: function() {
        //remove the initial hide class if this list it's visible at the moment
        var listHeader = this.layout.getComponent("drilldown-report-selection-headerpane");
        if (listHeader.drawerListDisplayState == "report-base-list") {
            if (this.$el.hasClass("hide")) {
                this.$el.removeClass("hide");
            }
        } else {
            this.$el.addClass("hide");
        }
        var renderRes = this._super("render", arguments);

        return renderRes;
    },

    /**
     * When collection is fetched and plugins applied, sugar expects the list to be visible. That's how it applies
     * plugins like ResizableColumns.
     * Still, in our case, this component might be hidded.
     * So, we're listening for toggle click in order to fix this problem
     * This will both make columns resizable and add the scrool bar on ox
     * @method
     * @return {[type]} [description]
     */
    fixListComponent: function() {
        var header = this.getComponent("drilldown-report-selection-headerpane");
        if (header.drawerListDisplayState == "report-base-list") {
            $(window).resize();
        }
    }
});