<?php

$viewdefs['base']['layout']['drilldown-filter-drawer'] = array(
    'components' => array(
        array(
            'view' => 'drilldown-filter-drawer-header',
        ),
        array(
            'layout' => 'drilldown-filter-drawer-groups',
        ),
    ),
);
