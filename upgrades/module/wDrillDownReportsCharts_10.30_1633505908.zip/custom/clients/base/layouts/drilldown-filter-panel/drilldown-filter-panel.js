({
    className: "drilldown-filter-panel",

    // Format of a patch we work with further: 
    // [
    //     {
    //         name     : "type group",
    //         templateId : "asdf",
    //         dashlets : ["dashletUID1"],
    //         filter   : {
    //             fields: [
    //                 {
    //                     dashlet              : "dashletUID1",
    //                     reportId             : "efc0fedc-7905-11e9-a594-f218983a1c3e",
    //                     tableKey             : "self",
    //                     fieldName            : "account_type",
    //                     pathInReportFilters  : [0],
    //                 },
    //             ],
    //             qualifier    : "is",
    //             input_name0  : "Customer"
    //             input_name1  : ""
    //         },
    //     },
    // ];
    initialize: function (options) {
        var initRes = this._super("initialize", arguments);
        
        window["drilldownFilterPanelLayout" + this.cid] = this;

        var dashboardComponent = this.closestComponent("dashboard");
        this.listenTo(dashboardComponent, "dashboardInfo:received", function () {
            var model = this.model;
            while (this._components.length > 0) {
                this._components[0].remove();
                this.removeComponent(this._components[0]);
            }

            var groups = [];
                     
            var dashboardRuntimeTemplates = model.attributes.dashboardRuntimeTemplates;
            var dashboardFilters = model.attributes.dashboardFilters;

            groups = _.map(dashboardRuntimeTemplates, function (template) {
                var filterValue = _.find(dashboardFilters, function (filter) {
                    return template.templateId === filter.templateId;
                });
                var dashboardFilter = {};
                if (typeof filterValue !== "undefined") { 
                    dashboardFilter = filterValue;
                }
                var newGroup = _.extend({
                    name       : template.name, 
                    templateId : template.templateId,
                    dashlets   : template.dashlets
                }, {
                    filter: {
                        fields      : template.fields,
                        qualifier   : dashboardFilter.qualifier,
                        input_name0 : dashboardFilter.input_name0, //eslint-disable-line camelcase
                    },
                });
                if (typeof dashboardFilter.input_name1 !== "undefined") { 
                    newGroup.filter["input_name1"] = dashboardFilter.input_name1;
                }
                return newGroup;
            });

            if (typeof groups === "undefined") {
                groups = [];
            }
            
            if (groups.length === 0) { 
                this.layout.toggleRuntimePanel(false);
            }
            _.each(groups, function (group, groupIdx) {
                if (this.isValidGroup(group) === true) { 
                    this.addGroupToLayout(group, groupIdx);
                }
            }.bind(this));
            
        }.bind(this));
        
        return initRes;
    },

    /**
     * Check if group still exists on the report
     * 
     * @param {*} group 
     */
    isValidGroup: function (group) {
        if (typeof (group) === "undefined") { 
            return false;
        }
        if (typeof group.filter === "undefined") { 
            return false;
        }
        if (Array.isArray(group.filter.fields) === false) { 
            return false;
        }
        if (group.filter.fields.length === 0) { 
            return false;
        }

        return true; 
    },

    addGroupToLayout: function (group, groupIdx) {
        var groupView = app.view.createView({
            context  : this.context,
            type     : "drilldown-filter-panel-group",
            layout   : this,
            module   : "Home",
            group    : group,
            groupIdx : groupIdx
        });

        this.addComponent(groupView);

        groupView.render();

        //after save the groups from drawer, we need to rerender panels
        var informationsAboutDashboard = this.closestComponent("dashboard").informationsAboutDashboard;
        if (typeof informationsAboutDashboard === "object" && _.isEmpty(informationsAboutDashboard) === false) { 
            groupView.render();    
        } 
    },

});
