({
    className: "main-pane span12 drilldown-filter-drawer-content",

    initialize: function () {        
        var initRes = this._super("initialize", arguments);
        
        window["drilldownFilterDrawerGroupsLayout" + this.cid] = this;

        this.listenTo(this, "group:delete", this.deleteGroup.bind(this));
        this.listenTo(this.layout, "group:add", this.addGroup.bind(this));
        
        var dashboardRuntimeTemplates = this.closestComponent("drilldown-filter-drawer").options.def.dashboardRuntimeTemplates;
        _.each(dashboardRuntimeTemplates, function (group, groupIdx) {
            if (this.groupIsValid(group) === true) {
                this._addGroupToLayout(group, groupIdx);
            }
        }.bind(this));
        
        return initRes;
    },

    /**
     * check group has at least one field still at his place (report on dashlet for now) 
     */
    groupIsValid: function (group) { 
        var dashboardRuntimeTemplates = this.closestComponent("drilldown-filter-drawer").options.def.dashboardRuntimeTemplates;
        var dashboardMetadata = this.closestComponent("drilldown-filter-drawer").options.def.dashboardMetadata;
        var reportIdsOnThisDashboard = [];

        _.each(dashboardMetadata.dashlets, function (dashlet) {
            if (typeof dashlet.view !== "undefined" && _.isString(dashlet.view.label)
                        && dashlet.view.type === "w-saved-reports-chart") {
                reportIdsOnThisDashboard.push(dashlet.view.saved_report_id);
            }
        });

        var res = true;
        _.each(dashboardRuntimeTemplates, function(template){
            _.each(template.fields, function (field) {
                if (reportIdsOnThisDashboard.indexOf(field.reportId) === -1) { 
                    res = false;
                }
            }.bind(this));
        }.bind(this));
        return res;
    },
    
    addGroup: function () { 
        var group = {
            templateId : app.wsystems.wDrillDownReportsChart.generateSimpleUID(),
            name       : "",
            dashlets   : [],
            fields     : [
            ],
        };
        var maxGroupIdx = this._getMaxGroupIdx();
        var groupIdx = maxGroupIdx + 1;
        var groupView = this._addGroupToLayout(group, groupIdx);
        groupView.render();
    },

    _getMaxGroupIdx: function () { 
        var groupsIdxs = _.pluck(this._components, "groupIdx");
        if (groupsIdxs.length === 0) { 
            return 0;
        }
        return _.max(_.map(groupsIdxs, function convertIdxsToInt(input) {
            return parseInt(input); 
        }));
    },

    deleteGroup: function (groupIdxToRemove) {
        var componentToRemove = _.find(this._components, function findCompToRemove(component) {
            return parseInt(component.groupIdx) === parseInt(groupIdxToRemove);
        });
        componentToRemove.remove();
        this.removeComponent(componentToRemove);
    }, 

    /**
     * 
     * @param {*} group 
     * @param {*} groupIdx
     * @return group view 
     */
    _addGroupToLayout: function (group, groupIdx) {
        var groupView = app.view.createView({
            context  : this.context,
            type     : "drilldown-filter-drawer-group",
            layout   : this,
            module   : "Home",
            group    : JSON.parse(JSON.stringify(group)),
            groupIdx : groupIdx
        });

        this.addComponent(groupView);

        return groupView;
    },

    render: function () {
        var initRes = this._super("render", arguments);
        return initRes;
    },
    
});