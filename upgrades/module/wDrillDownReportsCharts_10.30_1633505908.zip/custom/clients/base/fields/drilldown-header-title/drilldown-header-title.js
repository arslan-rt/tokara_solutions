({

    initialize: function(options) {
        this._super("initialize", [options]);

        this.context.on("update:drilldown:header", this.render, this);
    },

    format: function(value) {
        var formatRes = this._super("format", arguments);
        var dashConfig = this.context.attributes.model.attributes.settings.attributes;
        var groupDefs = this.context.attributes.model.attributes.reportData.attributes.reportDefs.group_defs;
        this.group1 = {
            field : groupDefs[0].label,
            value : dashConfig.group1_filter_label
        };
        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(dashConfig.chart_type);
        if (
            chartType === "group by chart" 
            || chartType === "horizontal group by chart"
            || (chartType === "line chart" && dashConfig.groupType === "group") 
        ) {
            this.group2 = {
                field : groupDefs[1].label,
                value : dashConfig.group2_filter_label
            };
        }

        return formatRes;
    },

    render: function() {
        this.setTitle();
        this.setCount();
        var initRes = this._super("render", arguments);
        return initRes;
    },

    setTitle: function() {
        if (this.view.drawerListDisplayState == "report-group-list") {
            this.title = app.lang.get("LBL_WCHART_LIST_REPORT_CONTENT");
        } else {
            this.title = app.lang.get("LBL_WCHART_LIST_RECORDS");
        }
    },

    setCount: function() {
        if (this.view.drawerListDisplayState == "report-group-list") {
            this.count = parseInt(this.context.get("groupCount"));
        } else if (this.view.drawerListDisplayState == "report-base-list") {
            this.count = parseInt(this.context.get("listCount"));
        }
    }
});
