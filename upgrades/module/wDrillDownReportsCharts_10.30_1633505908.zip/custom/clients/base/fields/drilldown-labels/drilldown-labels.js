({
    group1: {
        field : "",
        value : ""
    },
    group2: {
        field : "",
        value : ""
    },

    initialize: function(options) {
        this._super("initialize", [options]);

        this.context.on("update:drilldown:labels", this.render, this);
    },

    format: function(value) {
        var formatRes = this._super("format", arguments);
        var dashConfig = this.context.get("dashConfig");
        var groupDefs = this.context.get("groupDefs");
        this.group1.field = groupDefs[0].label;
        this.group1.value = dashConfig.group1_filter_label;
        if (typeof dashConfig.group2_filter_value != "undefined") {
            this.group2.field = groupDefs[1].label;
            this.group2.value = dashConfig.group2_filter_label;
        }

        return formatRes;
    }
});
