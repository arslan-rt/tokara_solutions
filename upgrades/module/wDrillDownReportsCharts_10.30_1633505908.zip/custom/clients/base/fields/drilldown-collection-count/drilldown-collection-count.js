({
    initialize: function(options) {
        var initRes = this._super("initialize", [options]);
        this.context.on("collection:count:update", _.bind(this.render, this));
        return initRes;
    },

    render: function() {
        this.setCountForCorrespondingView();
        var initRes = this._super("render", arguments);
        return initRes;
    },

    setCountForCorrespondingView: function() {
        if (this.view.drawerListDisplayState == "report-group-list") {
            this.count = parseInt(this.context.get("groupCount"));
        } else if (this.view.drawerListDisplayState == "report-base-list") {
            this.count = parseInt(this.context.get("listCount"));
        }
    }
});
