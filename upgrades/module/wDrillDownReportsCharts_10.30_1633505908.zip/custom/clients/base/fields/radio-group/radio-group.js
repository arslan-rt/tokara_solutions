({
    extendsFrom: "FieldsetField",

    initialize: function(options) {
        var initRes = this._super("initialize", arguments);
        return initRes;
    },
    render: function() {
        var initRes = this._super("render", arguments);
        return initRes;
    },

    _render: function() {
        this.radioFieldGroups = this.def.groups;
        var initRes = this._super("_render", arguments);
        return initRes;
    }
});
