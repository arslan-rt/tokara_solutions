({
    extendsFrom: "ChartField",

    initialize: function initializeChartField(options) {
        window.f = this;
        this.initVars(options);

        var initRes = this._super("initialize", arguments);

        return initRes;
    },

    initVars: function (options) {
        this.chartLoaded = false;

        /**
         * Chart id. Something like chart_view211
         * @type {String}
         */
        this.chartId = "chart_" + this.cid;
        
        this.showLegendLabel = "Show legend";
        this.hideLegendLabel = "Hide legend";

        this.legendToggleSelector = ".chart_legend.block .toggle_legend";

        this.blockLegendSelector = ".chart_legend.block";
        this.blockLegendListDivSelector = ".chart_legend.block .legend_wrapper .legend_list";

        this.inlineLegendSelector = ".chart_legend.inline";
        this.inlineLegendListDivSelector = ".chart_legend.inline .legend_wrapper .legend_list";
        /**
         * condition for old charts with no default size set as well
         * when no size is selected the default will be medium
        */
        if (_.isEmptyValue(this.options.view.settings.get("barThickness"))) {
            this.options.view.settings.set("barThickness", "30");
        }

        /**
         * Number of rows we agree the legend to have when shown horizontally
         * If the number of items or their content is larger, we'll show them in a panel
         */
        this.maxNumberOfRowsHorizontalLegend = 2;

        /**
         * Flag to indicate whether we'll show the legend
         */
        //remove temporary legend for bar chart and horizontal bar chart
        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(options.view.settings.get("chart_type"));
        var chartsWithNoLegend = ["bar chart", "horizontal bar chart"];
        if (options.view.settings.get("show_legend") === true && chartsWithNoLegend.indexOf(chartType) === -1) {
            this.show_legend = true;//eslint-disable-line camelcase
        } else {
            this.show_legend = false;//eslint-disable-line camelcase
        }
    },

    handleLegend: function () {
        if (typeof this.chart === "undefined") { 
            return;
        }
        
        var legendUL = this.chart.generateLegend();
        this._cachedLegend = legendUL;

        //update DOM
        if (this.isHorizontalLegendVisible() === true) {
            this.$el.find(this.inlineLegendListDivSelector).html(legendUL);
        } else {
            this.$el.find(this.blockLegendListDivSelector).html(legendUL);
        }

        //position legend
        if (this.isHorizontalLegendVisible() === true) {
            this.$el.find(this.blockLegendSelector).css("display", "none");

            var lineHeight = parseInt(this.$el.find(".chart_container").css("line-height").replace("px", ""));

            var legendHeight = lineHeight * this.getNumberOfRowsForHorizontalLegend();

            this.$el.find(this.inlineLegendSelector).height(legendHeight);
            
            this.$el.find(".chart_legend.inline .legend_wrapper").css("margin-top", "0px");
            
            var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.view.settings.attributes.chart_type);
            if (chartType === "funnel chart") {
                this.$el.find(".chart_container").css("margin-top", "30px");
            } else {
                this.$el.find(".chart_container").css("margin-top", "0px");
            }
            
        } else {
            this.$el.find(this.blockLegendSelector).css("display", "block");
            
            this.$el.find(this.inlineLegendSelector).css("height", "20px");
            
            this.$el.find(this.legendToggleSelector).on("click", this.showLegendPanel.bind(this));
        }

        this.$el.find(".chart_category").on("click", function clickLegendElement(e) {
            var indexToToggle = parseInt(e.currentTarget.dataset.index);
            var chart = this.chart;
            var meta, datasets, i;
            if (
                this.view.settings.attributes.chart_type === "pie chart"
                || this.view.settings.attributes.chart_type === "funnel chart"
            ) {
                //pie chart has only one dataset so we'll handle this dataset's data for visibility
                datasets = chart.data.datasets || [];
                for (i = 0; i < datasets.length; ++i) {
                    meta = chart.getDatasetMeta(i);
                    // toggle visibility of index if exists
                    if (meta.data[indexToToggle]) {
                        meta.data[indexToToggle].hidden = !meta.data[indexToToggle].hidden;
                    }
                }

                // We update visibility in the dataset ... rerender the chart
                chart.update();

                if (meta.data[indexToToggle].hidden) {
                    $(e.currentTarget).css("text-decoration", "line-through");
                } else {
                    $(e.currentTarget).css("text-decoration", "initial");
                }
            } else if (this.view.settings.attributes.chart_type === "line chart") {
                if (this.view.settings.attributes.groupType == "simple") {
                    datasets = chart.data.datasets || [];
                    for (i = 0; i < datasets.length; ++i) {
                        meta = chart.getDatasetMeta(i);
                        // toggle visibility of index if exists
                        // eslint-disable-next-line max-depth
                        if (meta.data[indexToToggle]) {
                            meta.data[indexToToggle].hidden = !meta.data[indexToToggle].hidden;
                        }
                    }
                } else { //line grouped
                    meta = chart.getDatasetMeta(indexToToggle);
                    // See controller.isDatasetVisible comment
                    meta.hidden = meta.hidden === null ? !chart.data.datasets[indexToToggle].hidden : null;
                }
                // We update visibility in the dataset ... rerender the chart
                chart.update();

                if (meta.hidden) {
                    $(e.currentTarget).css("text-decoration", "line-through");
                } else {
                    $(e.currentTarget).css("text-decoration", "initial");
                }
            } else {
                //multibar charts know about multiple datasets.
                //so we'll update the visibility directly on the dataset
                meta = chart.getDatasetMeta(indexToToggle);

                // See controller.isDatasetVisible comment
                meta.hidden = meta.hidden === null ? !chart.data.datasets[indexToToggle].hidden : null;

                // We update the visibility in the dataset ... rerender the chart
                chart.update();

                if (meta.hidden) {
                    $(e.currentTarget).css("text-decoration", "line-through");
                } else {
                    $(e.currentTarget).css("text-decoration", "initial");
                }
            }
        }.bind(this));
    },

    isHorizontalLegendVisible: function () {
        if (typeof this._cachedLegend !== "string") {
            window.console.log("Could not check if horizontal legend is shown");
            return false;
        }
        var numberOfRows = this.getNumberOfRowsForHorizontalLegend();
        return numberOfRows <= this.maxNumberOfRowsHorizontalLegend;
    },

    showLegendPanel: function (e) {
        var currentLegendLabel = this.$el.find(this.legendToggleSelector).html();
        if (currentLegendLabel !== this.showLegendLabel) {
            return;
        }

        this.$el.find(this.blockLegendListDivSelector).show();

        this.$el.find(this.legendToggleSelector).html(this.hideLegendLabel);

        this.$el.off("click.hideLegendNamespace");
        this.$el.on("click.hideLegendNamespace", this.checkLegendNeedsToBeHidden.bind(this));

        e.stopPropagation();
    },

    checkLegendNeedsToBeHidden: function (e) {
        var clickSource = $(e.originalEvent.target).parent();
        if (
            clickSource.hasClass("chart_category") || clickSource.is("ul")
            || clickSource.hasClass("legend_list")
        ) {
            return;
        }
        this.closeLegendPanel();
    },

    closeLegendPanel: function () {
        this.$el.find(this.blockLegendListDivSelector).hide();

        this.$el.find(this.legendToggleSelector).html(this.showLegendLabel);

        this.$el.off("click.hideLegendNamespace");
    },

    bindDataChange: function () {
        this.listenTo(this.model, "change:chartData", this.generateChart.bind(this));
    },

    generateChart: function (model, newChartData) {
        var reportDefs = this.model.get("reportDefs");
        var chartData = this.model.get("chartData");
        if (typeof newChartData !== "undefined") {
            chartData = newChartData;
        }
        var chartConfig = this.view.settings.attributes;
    
        var ctx = $("#" + this.chartId);

        //make sure the container is visible - when filtes are applied and no data is returned, the continaer is hide
        //so here we make sure at this moment we have it visible
        this.$el.find(".chart_container").show();

        // if the chart already exists, remove it before we generate the new one
        if (this.chartLoaded === true && this.chart instanceof window.Chart) {
            this.destroyChart();
            this.destroyLegend();
        }

        if (typeof chartData === "undefined" || typeof chartData.properties === "undefined") {
            window.console.log("Does this report still exist?");
            return;
        }

        if (_.isEmptyValue(chartData.data.error) === false) {
            var first = 0;
            var firstErrorMessage = App.lang.get("LBL_DELETED_FIELD_IN_REPORT1", "Reports");
            var secondErrorMessage = App.lang.get("LBL_DELETED_FIELD_IN_REPORT2", "Reports");
            this.$el.find(".chart_container")[first].innerHTML = firstErrorMessage + " <b>" + chartData.data.error + "</b> " + secondErrorMessage;
           
            return;
        }

        if (
            typeof chartData === "undefined" || typeof chartData.data === "undefined"
            || chartData.data.length === 0
        ) {
            this.displayNoData();
            return;
        }

        if (ctx.length === 0) {
            window.console.log("Could not find the chart element in DOM");
            return;
        }

        if (reportDefs.group_defs.length == 1) {
            chartConfig.groupType = "simple";
        } else {
            chartConfig.groupType = "group";
        }

        chartConfig.chartId = this.chartId;

        this.chart = this.loadChart(chartData, chartConfig, this.view);

        //this part is only for the charts which comes up from an older version and needs to be removed in the future
        var noScroll = ["funnel", "pie"];
        if (noScroll.indexOf(this.chart.config.type) >= 0) {
            chartConfig.allowScroll = false;
        }

        this.calculateChartSizes();
        
        //lengend positioning
        if (this.show_legend === true) {
            this.$el.find(".chart_legend").removeClass("hide");
            this.handleLegend();

            if (this.isHorizontalLegendVisible() === true) {
                var lineHeight = parseInt(this.$el.find(".chart_container").css("line-height").replace("px", ""));
                var legendHeight = lineHeight * this.getNumberOfRowsForHorizontalLegend();

                var initialChartContainerHeight = parseInt(this.$el.find(".chart_container").css("height").replace("px", ""));
                var paddingTop = 0;
                
                // var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.view.settings.attributes.chart_type);
                // if (chartType !== "pie chart") {    
                this.$el.find(".chart_container").css("height", initialChartContainerHeight - legendHeight - paddingTop);
                // }
            }
        } else {
            this.$el.find(".chart_legend").addClass("hide");
        }
  
        var eventName = "gsresizestop.chartRegeneration." + this.cid;
        this.$el.closest(".dashboard-grid").off(eventName);
        this.$el.closest(".dashboard-grid").on(eventName, this._regenerateChart.bind(this));

        if (this.view.name === "drilldown-pane") {
            this.view.$el.find(".panel_body").css("overflow-x", "auto");
        }
    },

    _regenerateChart: function() {
        if (this.disposed === true) {
            return;
        }

        this.generateChart();
    },

    calculateChartSizes: function (newChartData) {
        var reportDefs = this.model.get("reportDefs");
        var chartConfig = this.view.settings.attributes;
        var chartData = this.model.get("chartData");
        if (Array.isArray(newChartData)) {
            chartData = newChartData;
        }

        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.view.settings.attributes.chart_type);
        var chartParentWrapperHeight, chartParentWrapperWidth;
        if (this.view.name === "drilldown-pane") {
            chartParentWrapperHeight = app.view.layouts.BaseDrawerLayout.prototype._determineDrawerHeight();
            chartParentWrapperHeight -= 30;//subtract header and eventual scroll

            var windowWidth = $(window).width();
            chartParentWrapperWidth = windowWidth / 12 * 4;//calculate span4 size
        } else {
            var $chartParentWrapper = this.view.$el.closest(".dashlet");
            chartParentWrapperHeight = parseInt($chartParentWrapper.css("height"));
            chartParentWrapperWidth = parseInt($chartParentWrapper.css("width"));
        }

        switch (chartType) {
            case "bar chart":
            case "horizontal bar chart":
            case "group by chart":
            case "horizontal group by chart":
                var chartWidthMinim = this.calculateChartWidthMinim(chartData, chartConfig, reportDefs);
                var chartContainerWidth = chartWidthMinim;
                if (chartParentWrapperWidth > chartWidthMinim) {
                    //subtract something for case when a scroll bar is shown.
                    //chart size needs to consider those pixels
                    chartContainerWidth = chartParentWrapperWidth - 20; 
                }
                this.$el.find(".chart_container").css("width", chartContainerWidth);

                var headerAndEventualOverflowX = 75;
                var legendHeight = parseInt(this.$el.find(".chart_container").css("margin-top"));
                var chartHeightMinim = this.calculateChartHeightMinim(chartData, chartConfig, reportDefs);
                var chartContainerHeight = chartParentWrapperHeight - headerAndEventualOverflowX - legendHeight;
                if (chartContainerHeight < chartHeightMinim) {
                    chartContainerHeight = chartHeightMinim;
                }
                
                this.$el.find(".chart_container").css("height", chartContainerHeight);
                break;
            case "pie chart":
                this.$el.find(".chart_container").css("width", chartParentWrapperWidth - 40);
                this.$el.find(".chart_container").css("height", chartParentWrapperHeight - 40);
                break;
            case "funnel chart":
                var maxWindowHeight = $(window).height();
                this.$el.find(".chart_container").css("height", chartParentWrapperHeight - 80);
                this.$el.find(".chartjs-render-monitor").css("max-height", maxWindowHeight);

                break;
            case "line chart":
                this.$el.find(".chart_container").css("height", chartParentWrapperWidth - 40);
                this.$el.find(".chart_container").css("height", chartParentWrapperHeight - 40);
                break;
        }
    },
    
    calculateChartWidthMinim: function(data, chartConfig, reportDefs) {
        var chartWidth = 500,
                yAxis, barMargins;
        var minimDashletWidthInSugar = 280; //in sugar this dimention is percentage. we hardced a value
        var xAxisNumberOfItems;
        if (typeof data === "undefined" || Array.isArray(data.data) === false) {
            return chartWidth;
        }

        var barThickness = parseInt(chartConfig.barThickness);

        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.view.settings.attributes.chart_type);

        switch (chartType) {
            case "bar chart":
                barMargins = 10; //left and right space between bars
                xAxisNumberOfItems = data.data.length;
                yAxis = _.find(this.chart.boxes, function getSpecificBox(box) {
                    if (box.id === "y-axis-0") {
                        return true;
                    }
                    return false;
                }.bind(this));

                chartWidth = yAxis.width + (barThickness * xAxisNumberOfItems) + (barMargins * xAxisNumberOfItems);
                break;
            case "horizontal bar chart":
                chartWidth = 500;
                break;
            case "group by chart":
                barMargins = 10; //left and right space between bars
                xAxisNumberOfItems = _.uniq(_.pluck(data.data, "group1_value")).length;
                yAxis = _.find(this.chart.boxes, function getSpecificBox(box) {
                    if (box.id === "y-axis-0") {
                        return true;
                    }
                    return false;
                }.bind(this));
    
                chartWidth = yAxis.width + (barThickness * xAxisNumberOfItems) + (barMargins * xAxisNumberOfItems);   
                break;
            case "horizontal group by chart":
                chartWidth = 500;
                break;
        }

        if (chartWidth < minimDashletWidthInSugar) {
            chartWidth = minimDashletWidthInSugar;
        }

        return chartWidth;
    },

    calculateChartHeightMinim: function(data, chartConfig, reportDefs) {
        var chartHeight = 500,
                xAxis;
        var minimDashletHeightInSugar = 200 - 10; //found in Home. subtract something to make sure no scroll appears
        var yAxisNumberOfItems;
        if (typeof data === "undefined" || Array.isArray(data.data) === false) {
            return chartHeight;
        }

        var barThickness = parseInt(chartConfig.barThickness);
        var barMargins = 10; //top and bottom space between bars

        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.view.settings.attributes.chart_type);

        switch (chartType) {
            case "bar chart":
                chartHeight = 400;
                break;
            case "horizontal bar chart":
                yAxisNumberOfItems = data.data.length;
                xAxis = _.find(this.chart.boxes, function getSpecificBox(box) {
                    if (box.id === "x-axis-0") {
                        return true;
                    }
                    return false;
                }.bind(this));

                chartHeight = xAxis.height + (barThickness * yAxisNumberOfItems) + (barMargins * yAxisNumberOfItems);
                break;
            case "group by chart":
                chartHeight = 400;
                break;
            case "horizontal group by chart":
                yAxisNumberOfItems = _.uniq(_.pluck(data.data, "group1_value")).length;
                xAxis = _.find(this.chart.boxes, function getSpecificBox(box) {
                    if (box.id === "x-axis-0") {
                        return true;
                    }
                    return false;
                }.bind(this));
                chartHeight = xAxis.height + (barThickness * yAxisNumberOfItems) + (barMargins * yAxisNumberOfItems) + 20;
                break;
        }

        if (chartHeight < minimDashletHeightInSugar) {
            chartHeight = minimDashletHeightInSugar;
        }

        return chartHeight;
    },

    displayNoData: function () {
        var initRes = this._super("displayNoData", arguments);

        this.$el.find(".chart_container").hide();

        return initRes;
    },

    destroyChart: function () {
        this.chartLoaded = false;
        this.chart.destroy();
    },

    destroyLegend: function () {
        if (this.$el instanceof window.jQuery) {
            this.$el.find(".chart_legend ul").remove();
        }
    },

    /**
     * Load a chart
     * @param {Object} serverData                    Data
     * @param {Object} chartConfig                   Chart configuration
     * @param {Field|View|Layout} wrapperComponent   Wrapper of the chart
     * @return Chart
     */
    loadChart: function (
        serverData,
        chartConfig,
        wrapperComponent
    ) {
        var chart;

        // update default params from chartConfig
        var options = _.extend(
            {
                allowScroll      : true,
                baseModule       : "Reports",
                colorData        : "default",
                direction        : "ltr",
                hideEmptyGroups  : true,
                label            : SUGAR.charts.translateString("LBL_DASHLET_SAVED_REPORTS_CHART"),
                margin           : { top: 10, right: 10, bottom: 10, left: 10 },
                module           : "Reports",
                overflowHandler  : false,
                reduceXTicks     : false,
                rotateTicks      : true,
                saved_report_id  : chartConfig.chartId, //eslint-disable-line camelcase
                show_controls    : false, //eslint-disable-line camelcase
                show_legend      : true, //eslint-disable-line camelcase
                show_title       : false, //eslint-disable-line camelcase
                show_tooltips    : true, //eslint-disable-line camelcase
                show_x_label     : false, //eslint-disable-line camelcase
                show_y_label     : false, //eslint-disable-line camelcase
                showValues       : false,
                stacked          : true,
                staggerTicks     : true,
                vertical         : true,
                wrapTicks        : true,
                x_axis_label     : "", //eslint-disable-line camelcase
                y_axis_label     : "", //eslint-disable-line camelcase
                allow_drillthru  : true, //eslint-disable-line camelcase,
                wrapperComponent : wrapperComponent,
                barThickness     : 30
                
            },
            serverData.properties,
            chartConfig
        );

        options.vertical = chartConfig.orientation ? chartConfig.orientation === "vertical" : false;

        var dataTranslated = [];

        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(options.chart_type);
        switch (chartType) {
            case "bar chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.bar.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.bar.loadChart(dataTranslated, options);
                break;
            case "horizontal bar chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.horizontalBar.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.horizontalBar.loadChart(dataTranslated, options);
                break;
            case "group by chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.groupedBar.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.groupedBar.loadChart(dataTranslated, options);
                break;
            case "horizontal group by chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.horizontalBarGrouped.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.horizontalBarGrouped.loadChart(dataTranslated, options);
                break;
            case "pie chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.pie.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.pie.loadChart(dataTranslated, options);
                break;
            case "funnel chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.funnel.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.funnel.loadChart(dataTranslated, options);
                break;
            case "line chart":
                dataTranslated = app.wsystems.wDrillDownReportsChart.charts.line.translateData(serverData, options);
                chart = app.wsystems.wDrillDownReportsChart.charts.line.loadChart(dataTranslated, options);
                break;
        }

        this.chartLoaded = true;

        this.$el.find(".chart_container").on("scroll", _.debounce(function () {
            this.chart.update();
        }.bind(this), 0));

        return chart;
    },

    /**
     * Calculates number of rows needed to show the legend horizontally
     */
    getNumberOfRowsForHorizontalLegend: function () {
        if (typeof this._cachedLegend !== "string") {
            window.console.log("Could not check if horizontal legend is shown");
            return false;
        }

        var width = this.view.$el.width();
        var items = $(this._cachedLegend).find("li");

        var legendLength = 0;
        _.each(items, function (item) {
            var offset = 25;//number of pixels for the icon and padding
            var fontPixelRatio = 6; // ratio of pixels / number of characters (default font)
            legendLength += $(item).text().length * fontPixelRatio + offset;
        });

        return Math.ceil(legendLength / width);
    },

    render: function () {
        var initRes = this._super("render", arguments);

        return initRes;
    },

    resize: function () {
        //if user edits one dashlet in the page and there are multiple dashlets out there, we don't want a resize
        //the same in any drawer opening case
        var activeDrawer = App.drawer.getActive();
        if (typeof activeDrawer != "undefined") {
            return this;
        }
        var initRes = this._super("resize", arguments);
        return initRes;
    },

    _dispose: function () {
        var initRes = this._super("_dispose", arguments);

        if (this.chart instanceof window.Chart) {
            this.destroyChart();
        }
        this.destroyLegend();

        return initRes;
    }

});