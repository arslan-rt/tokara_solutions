<?php

use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\RecordsQuery;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;

if (SugarAutoLoader::existing("custom/modules/Reports/CustomReport.php")) {
    include_once "custom/modules/Reports/CustomReport.php";
}

class wDrillDownReportsDrawerApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'storeRecords'        => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', 'drawerRecords', 'set'),
                'pathVars'  => array('', '', ''),
                'method'    => 'storeRecords',
                'shortHelp' => 'store records',
                'longHelp'  => '',
            ),
            'deleteStoredRecords' => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', 'drawerRecords', 'delete'),
                'pathVars'  => array('', '', ''),
                'method'    => 'deleteStoredRecords',
                'shortHelp' => 'delete stored records',
                'longHelp'  => '',
            ),
            'updateRecordsStored' => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', 'drawerRecords', 'update'),
                'pathVars'  => array('', '', ''),
                'method'    => 'updateRecordsStored',
                'shortHelp' => 'update records stored',
                'longHelp'  => '',
            ),
        );
    }

    /**
     * Store records - source of some element in the chart
     * @method storeRecords
     * @param  SugarApi          $api
     * @param  Array             $args
     * @return Boolean           Whether creation was complete or anything bad happened
     */
    public function storeRecords($api, $args)
    {
        global $db, $current_user;
        $this->requireArgs($args, array('drawerUID', 'reportId'));

        $groupType = "simple";
        $filters   = array($args['group1_filter_value']);
        if ($args["dashletChartType"] === "group by chart" || $args["dashletChartType"] === "horizontal group by chart") {
            $groupType = "group";
            $filters   = array($args['group1_filter_value'], $args['group2_filter_value']);
        }

        $chartReport = BeanFactory::getBean("Reports", $args['reportId'], array("encode" => false));
        if (!empty($chartReport)) {
            $reportClass = SugarAutoLoader::customClass("Report");
            if ($reportClass == "Report") {
                $reporter = new Report($chartReport->content);
            }
            if ($reportClass == "CustomReport") {
                $reporter = new CustomReport($chartReport->content);
            }
        }

        if (isset($args["dashletId"])) {
            $customFilterRawInDb = FilterUtils::getFilterFromDb("wdrilldown_report_filters_dashlets", [
                "dashletId" => $args["dashletId"],
                "userId"    => $current_user->id,
            ]);
            if (empty($customFilterRawInDb)) {
                $customFilterInDb = [];
            } else {
                $customFilterInDb = json_decode($customFilterRawInDb["filters"], true);
            }
            if (is_array($customFilterInDb)) {
                foreach ($customFilterInDb as $idx => $patch) {
                    if ($idx !== "operator") {
                        FilterUtils::applyFilterPatch($patch, $patch["pathInReportFilters"], $reporter->report_def['filters_def']['Filter_1']);
                    }
                }
                $args["customFilter"] = $reporter->report_def['filters_def']['Filter_1'];
            }
        }

        // by default we supposed line charts consist of one group type. still there are cases
        // when they are used to render reports with two grouping types
        // so here we adjust the type
        if ($args['dashletChartType'] == 'line chart' && count($reporter->report_def['group_defs']) == 2) {
            $filters   = array($args['group1_filter_value'], $args['group2_filter_value']);
            $groupType = "group";
        }

        if (!empty($chartReport)) {
            // by default we supposed line charts consist of one group type. still there are cases when they are used to render reports with two grouping types
            // so here we adjust the type
            if ($args['dashletChartType'] == 'line chart' && count($reporter->report_def['group_defs']) == 2) {
                $groupType = 'group';
                $filters   = array($args['group1_filter_value'], $args['group2_filter_value']);
            }

            $recordsPerPage = -1;
            $nextOffset     = 0;
            $recordsQuery   = new RecordsQuery($reporter, $groupType, $filters, $nextOffset, $recordsPerPage);
            $recordsQuery->parseRequest($args);
            $baseTable  = $recordsQuery->getBaseTable();
            $idToSelect = $this->getRecordsUIDField($reporter, $args);

            //tracker holds data for every change. We only show modified records, not each change tracked
            $fieldsToSelect = array("distinct " . $baseTable . "." . $idToSelect);

            $recordsQuery->setFieldsToSelect($fieldsToSelect);

            $recordsQuery->generateQuery($args);

            $dbRes   = $db->query($recordsQuery->getQuery());
            $records = array();
            while ($row = $db->fetchByAssoc($dbRes)) {
                $records[] = $row;
            }

            if ($args["module"] === "Trackers") {
                $tempRecords = [];
                foreach ($records as $record) {
                    $tempRecords[] = [
                        "id" => $record["item_id"],
                    ];
                }
                $records = $tempRecords;
            }

            $this->insertRecordsInTempTable($args["drawerUID"], $records);
        }

        return true;
    }

    public function insertRecordsInTempTable(string $drawerUID, array $records): array
    {
        global $dictionary, $timedate;

        $status = [
            "status" => "success",
        ];

        try {
            foreach ($records as $record) {

                $db    = DBManagerFactory::getInstance();
                $table = "wdrilldown_report_records";

                $fieldDefs = $dictionary[$table]["fields"];

                if (is_string($drawerUID) === false) {
                    $status["status"]        = "input_error";
                    $status["error_message"] = "No drawerId given";
                    return $status;
                }

                $data = [
                    "id"             => Sugarcrm\Sugarcrm\Util\Uuid::uuid1(),
                    "drawer_id"      => $drawerUID,
                    "record_id"      => $record["id"],
                    "date_generated" => $timedate->nowDb(),
                ];

                $inserted = $db->insertParams($table, $fieldDefs, $data);
            }
        } catch (\Exception $e) {
            if ($inserted !== true) {
                $GLOBALS["log"]->fatal("Error while inserting data in the temp table. " . $e->getMessage() . $db->lastError());

                $status["status"]        = "insert_error";
                $status["error_message"] = $e->getMessage() . $db->lastError();
            }
        }

        return $status;
    }

    /**
     * Delete old records
     * @method deleteStoredRecords
     * @param  SugarApi          $api
     * @param  Array             $args
     * @return Boolean
     */
    public function deleteStoredRecords($api, $args)
    {
        $this->requireArgs($args, array('drawerUID'));

        $qb = DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->delete("wdrilldown_report_records");
        $qb->where("drawer_id = :drawer_id");
        $qb->setParameter(":drawer_id", $args["drawerUID"]);
        $qb->execute();

        return true;
    }

    /**
     * Useful when edit is made inside a drawer. Report might be updated in this case, so we need to reflect the changed
     *  record list we show
     *  There might exist action buttons that both remove a record from the report and the other side.
     * Also usefull when initial element clicked is changed (filter on some other category)
     * So best solution to keep the records in sync is to delete existing content and insert the new ones
     * @method updateRecordsStored
     * @param  SugarApi          $api
     * @param  Array             $args
     * @return Boolean           Whether update was complete or anything bad happened
     */
    public function updateRecordsStored($api, $args)
    {
        $this->requireArgs($args, array('drawerUID', 'reportId'));

        $dropRes   = $this->deleteStoredRecords($api, $args);
        $createRes = $this->storeRecords($api, $args);

        if ($dropRes && $createRes) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns record id field in Report sql.
     * Reports made on most modules will have "id" as one of the fields selected.
     * Trackers, still, hold actual record id in "item_id".
     *
     * @method getRecordsUIDField
     *
     * @param  [type]             $reporter [description]
     * @param  [type]             $args     [description]
     * @return [type]             [description]
     */
    public function getRecordsUIDField($reporter, $args)
    {
        $fieldName = "id";

        if ($args["reportModule"] == "Trackers") {
            $groupDefs = $reporter->report_def["group_defs"];

            //At the moment, sugar does not show any chart if a report is set to group multiple times on the same column
            if ($groupDefs[0]['table_key'] == "self" && $groupDefs[0]['name'] == "module_name") {
                $fieldName = "item_id";
            } elseif ($groupDefs[1]['table_key'] == "self" && $groupDefs[1]['name'] == "module_name") {
                $fieldName = "item_id";
            }
        }

        return $fieldName;
    }
}
