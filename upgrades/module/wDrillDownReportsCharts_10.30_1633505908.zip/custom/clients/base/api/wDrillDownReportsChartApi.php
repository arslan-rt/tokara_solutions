<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\RecordsQuery;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\SummaryQuery;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;

include_once 'clients/base/api/FilterApi.php';
include_once 'include/SugarQuery/SugarQuery.php';
include_once "include/SugarCharts/ChartDisplay.php";
include_once "modules/Reports/Report.php";

if (SugarAutoLoader::existing("custom/modules/Reports/CustomReport.php")) {
    include_once "custom/modules/Reports/CustomReport.php";
}

class wDrillDownReportsChartApi extends FilterApi
{
    public function registerApiRest()
    {
        return array(
            'chartContent'                    => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', '?', 'wchart'),
                'pathVars'  => array('', 'reportId', ''),
                'method'    => 'getSavedReportChartById',
                'shortHelp' => 'get saved report chart by id',
                'longHelp'  => '',
            ),
            'reportList'                      => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', '?', 'reportlist'),
                'pathVars'  => array('', 'reportId', ''),
                'method'    => 'getReportContentList',
                'shortHelp' => 'get report content list',
                'longHelp'  => '',
            ),
            'wGetSavedReportBaseListViewById' => array(
                'reqType'   => 'POST',
                'path'      => array('Reports', '?', 'baselist'),
                'pathVars'  => array('', 'reportId', ''),
                'method'    => 'getBaseListRecords',
                'shortHelp' => 'get base list records',
                'longHelp'  => '',
            ),
            'testDeprecated'                  => array(
                'reqType'   => 'GET',
                'path'      => array('Reports', 'testDeprecated', '?'),
                'pathVars'  => array('Reports', '', 'reportId'),
                'method'    => 'isReportDeprecated',
                'shortHelp' => 'is report deprecated',
                'longHelp'  => '',
            ),
            'getUsers'                        => array(
                'reqType'   => 'GET',
                'path'      => array('wDrillDown', 'getUsers'),
                'pathVars'  => array('wDrillDown', 'getUsers'),
                'method'    => 'getUsers',
                'shortHelp' => 'get users',
                'longHelp'  => '',
            ),
        );
    }

    /**
     * Retrieves a saved report and chart data, given a report ID in the args
     * If reportDefinitionOnly received, we'll not fetch the report nor cache it
     *
     * @param $api ServiceBase The API class of the request
     * @param $args array The arguments array passed in from the API
     * @return array
     */
    public function getSavedReportChartById($api, $args)
    {
        global $log, $current_user;
        $result = array(
            'chartData'  => array(),
            'reportDefs' => array(),
        );
        $groupType = "simple";
        if ($args["dashletChartType"] === "group by chart" || $args["dashletChartType"] === "horizontal group by chart") {
            $groupType = "group";
        }
        $reportDefinitionOnly = (bool) $args["reportDefinitionOnly"];

        $chartReport  = BeanFactory::getBean("Reports", $args['reportId'], array("encode" => false));
        $forceRefresh = (array_key_exists('forceRefresh', $args)) ? $args['forceRefresh'] : false;
        //when in Record View, user might have set the dashlet to relate to current record. So no cache should be used for this use case
        if (array_key_exists('link', $args) && !empty($args['link'])) {
            $forceRefresh = true;
        }

        if (empty($chartReport->id)) {
            $reportId = $args['reportId'];
            $userId   = $current_user->id;
            $log->debug("Report {$reportId} is not accessible for user {$userId}");
        } else {
            $reportClass = SugarAutoLoader::customClass("Report");
            if ($reportClass == "Report") {
                $reporter = new Report($chartReport->content);
            }
            if ($reportClass == "CustomReport") {
                $reporter = new CustomReport($chartReport->content);
            }
            // by default we supposed line charts consist of one group type. still there are cases when they are used to render reports with two grouping types
            // so here we adjust the type
            if ($args['dashletChartType'] == 'line chart' && count($reporter->report_def['group_defs']) == 2) {
                $groupType = "group";
            }

            if ($this->givenReportCanBeRepresentedOnChart($reporter, $groupType)) {
                $cachedReportData = $this->getCachedReportData($args['reportId'], $args['dashletId'], $args['dashletChartType']);

                if ($cachedReportData && $forceRefresh === false) {
                    return json_decode(base64_decode($cachedReportData), true);
                }

                if (isset($args["dashletId"]) && empty($args["reportDefinitionOnly"])) {

                    $customFilterRawInDb = FilterUtils::getFilterFromDb("wdrilldown_report_filters_dashlets", [
                        "dashletId" => $args["dashletId"],
                        "userId"    => $current_user->id,
                    ]);

                    if (empty($customFilterRawInDb)) {
                        $customFilterInDb = [];
                    } else {
                        $customFilterInDb = json_decode($customFilterRawInDb["filters"], true);
                    }
                    if (empty($customFilterInDb) || is_array($customFilterInDb) === false) {
                        //we need to set the filter once for new dashlets cases
                        $customFilter = $this->resetCustomFilter($api, $args);
                        if (is_array($customFilter)) {
                            $args["customFilter"] = $customFilter;
                        }
                    } else {
                        $keysInFilterDefs = array_keys($customFilterInDb);
                        if (count($keysInFilterDefs) != 0 || $keysInFilterDefs[0] !== "operator") {
                            $this->flagFiltersWhichCanBeApplied($customFilterInDb, $reporter->report_def['filters_def']['Filter_1']);

                            $temp = [];
                            foreach ($customFilterInDb as $filterInDb) {
                                if (isset($filterInDb["filterStillExists"]) && $filterInDb["filterStillExists"] === true) {
                                    unset($filterInDb["filterStillExists"]);
                                    $temp[] = $filterInDb;
                                }
                            }
                            $customFilterInDb = $temp;

                            foreach ($customFilterInDb as $patch) {
                                FilterUtils::applyFilterPatch($patch, $patch["pathInReportFilters"], $reporter->report_def['filters_def']['Filter_1']);
                            }
                        }
                        $args["customFilter"] = $reporter->report_def['filters_def']['Filter_1'];
                    }
                }

                $summaryQuery = new SummaryQuery($reporter, $groupType);
                if (!$reportDefinitionOnly) {
                    $unformattedData = $summaryQuery->getData($args);

                    if (empty($unformattedData) === false) {
                        $formattedData = $summaryQuery->formatData($unformattedData);
                    }

                    if (empty($args["error"]) === false) {
                        $formattedData           = ["error" => $args["error"]];
                        $args["hideEmptyGroups"] = false;
                    }

                    if (array_key_exists("hideEmptyGroups", $args) && $args["hideEmptyGroups"] === true) {
                        $formattedData = $summaryQuery->hideEmptyGroups($formattedData);
                    }

                    if ($args["dashletChartType"] == "funnel chart") {
                        //funnels expect data in reverse mode from what we retrieve from db
                        $formattedData = array_reverse($formattedData);
                    }
                    $result['chartData']['data']               = $formattedData;
                    $result['chartData']['properties']         = array();
                    $result['chartData']['properties']['sort'] = $summaryQuery->getSugarSort($formattedData, $args);
                }

                $numericalConfigured                                     = $summaryQuery->getNumericalColumn($reporter->report_def);
                $numericalType                                           = $numericalConfigured[1];
                $result['chartData']['properties']['numericalChartType'] = $numericalType;

                $summaryTotalQuery                          = new SummaryQuery($reporter, $groupType);
                $total                                      = $summaryTotalQuery->getTotal($args);
                $result['chartData']['properties']['title'] = "Total is {$total}";

                if (is_array($customFilterInDb)) {
                    $result["customFilter"] = $customFilterInDb;
                }

                //filters were altered by now. that's why we need te fetch the report content
                $chartReport->retrieve();
                if ($reportClass == "Report") {
                    $reporter = new Report($chartReport->content);
                }
                if ($reportClass == "CustomReport") {
                    $reporter = new CustomReport($chartReport->content);
                }

                $result['reportDefs'] = $reporter->report_def;
                if (!$reportDefinitionOnly) {
                    $newEntry = true;
                    if ($cachedReportData) {
                        $newEntry = false;
                    }
                    if (!array_key_exists('link', $args) || empty($args['link'])) { //we don't cache dashlets related to current record
                        // cache the result
                        $this->cacheReportData($args, $result, $newEntry);
                    }
                }
            }
        }

        return $result;
    }

    public function cacheReportData($args, $returnData, $isNewEntry)
    {
        global $db, $timedate, $current_user;

        $reportId  = $args["reportId"];
        $dashletId = $args["dashletId"];
        $chartType = $args["dashletChartType"];

        $cacheId     = $db->quote(Sugarcrm\Sugarcrm\Util\Uuid::uuid1());
        $reportId    = $db->quote($reportId);
        $userId      = $current_user->id;
        $reportData  = $db->quote(base64_encode(json_encode($returnData)));
        $dateCreated = $db->quote($timedate->getInstance()->nowDb());

        $cacheReportDataQuery = <<<SQL
UPDATE
    wdrilldown_report_charts
SET
    report_data='{$reportData}',
    date_created='{$dateCreated}'
WHERE
    report_id='{$reportId}'
AND
    user_id='{$userId}'
AND
    dashlet_id='{$dashletId}'
AND
    chart_type='{$chartType}'
SQL;

        if ($isNewEntry) {
            $cacheReportDataQuery = <<<SQL
INSERT INTO
    wdrilldown_report_charts (
        id,
        report_id,
        user_id,
        dashlet_id,
        report_data,
        date_created,
        chart_type
    )
VALUES (
    '{$cacheId}',
    '{$reportId}',
    '{$userId}',
    '{$dashletId}',
    '{$reportData}',
    '{$dateCreated}',
    '{$chartType}'
)
SQL;
        }

        $db->query($cacheReportDataQuery);
    }

    /**
     * @param $reportId String
     * @param $dashletId String
     * @param $chartType String
     * @return mixed Array|False
     */
    public function getCachedReportData($reportId, $dashletId, $chartType)
    {
        global $db, $timedate, $current_user;

        $reportId                 = $db->quote($reportId);
        $userId                   = $current_user->id;
        $getCachedReportDataQuery = <<<SQL
SELECT
    report_data,
    date_created
FROM
    wdrilldown_report_charts w
WHERE
    w.report_id = '{$reportId}'
AND
    w.user_id = '{$userId}'
AND
    w.dashlet_id = '{$dashletId}'
AND
    w.chart_type = '{$chartType}'
SQL;

        $getCachedReportDataQueryResult = $db->query($getCachedReportDataQuery);
        $dbReportData                   = $db->fetchByAssoc($getCachedReportDataQueryResult);
        $cachedReportData               = false;

        if ($dbReportData) {
            if ($dbReportData['date_created']) {
                $cachingDate     = new DateTime($dbReportData['date_created']);
                $currentDate     = new DateTime($timedate->getInstance()->nowDb());
                $cachingDuration = $cachingDate->diff($currentDate);

                //only use cache from today
                if ($cachingDuration->d == 0 && $cachingDuration->m == 0 && $cachingDuration->y == 0) {
                    $cachedReportData = $dbReportData['report_data'];
                }
            }
        }

        return $cachedReportData;
    }

    protected function flagFiltersWhichCanBeApplied(&$filterPatches, $filtersInDb)
    {
        foreach ($filterPatches as $idx => &$patch) {
            if (is_array($patch)) { // we want to ommit the operator
                $pathInReportFilters        = $patch["pathInReportFilters"];
                $patch["filterStillExists"] = $this->checkFilterApplies($filtersInDb, $patch, $pathInReportFilters);
            }
        }
    }

    protected function checkFilterApplies(&$filterDef, $patch, $pathInReportFilters)
    {
        if (empty($pathInReportFilters)) {
            return $filterDef["name"] === $patch["fieldName"] && $filterDef["runtime"] === 1;
        } else {
            $idx = array_shift($pathInReportFilters);
            do {
                return $this->checkFilterApplies($filterDef[$idx], $patch, $pathInReportFilters);
            } while ($idx = array_shift($pathInReportFilters));
        }
    }

    /**
     * @return mixed Array|false - filter or false
     */
    public function resetCustomFilter(ServiceBase $api, array $args)
    {
        $chartReport = BeanFactory::getBean("Reports", $args["reportId"], array("encode" => false));
        $reporter    = new Report($chartReport->content);

        if (empty($reporter->report_def["filters_def"]) === false) {
            /**
             * @var array
             */
            $dbFilter = $reporter->report_def["filters_def"]["Filter_1"];

            $args["customFilter"] = [];
            foreach ($dbFilter as $idx => $filter) {
                if ($idx !== "operator") {
                    $args["customFilter"][] = $filter;
                }
            }
            $filterApi = new wDrillDownReportsFilterApi();
            $filterApi->setDashletFilter($api, $args);

            return $dbFilter;
        }

        return false;
    }

    /*
     * Retrieves record list filtered by clicked chart element
     *
     * @param $api ServiceBase The API class of the request
     * @param $args array The arguments array passed in from the API
     * @return array
     */
    public function getReportContentList($api, $args)
    {
        global $sugar_config, $current_user;
        $recordsPerPage = $sugar_config['list_max_entries_per_page'];
        $returnData     = array();

        $nextOffset = ($args['next_offset']) ? $args['next_offset'] : 0;
        if ($nextOffset != -1) {
            $groupType = "simple";
            $filters   = array($args['group1_filter_value']);
            if ($args["dashletChartType"] === "group by chart" || $args["dashletChartType"] === "horizontal group by chart") {
                $groupType = "group";
                $filters   = array($args['group1_filter_value'], $args['group2_filter_value']);
            }

            $chartReport = BeanFactory::getBean("Reports", $args['reportId'], array("encode" => false));

            if (!empty($chartReport)) {
                $reportClass = SugarAutoLoader::customClass("Report");
                if ($reportClass == "Report") {
                    $reporter = new Report($chartReport->content);
                }
                if ($reportClass == "CustomReport") {
                    $reporter = new CustomReport($chartReport->content);
                }

                if (isset($args["dashletId"])) {
                    $customFilterRawInDb = FilterUtils::getFilterFromDb("wdrilldown_report_filters_dashlets", [
                        "dashletId" => $args["dashletId"],
                        "userId"    => $current_user->id,
                    ]);
                    if (empty($customFilterRawInDb)) {
                        $customFilterInDb = [];
                    } else {
                        $customFilterInDb = json_decode($customFilterRawInDb["filters"], true);
                    }
                    if (is_array($customFilterInDb)) {
                        foreach ($customFilterInDb as $idx => $patch) {
                            if ($idx !== "operator") {
                                FilterUtils::applyFilterPatch($patch, $patch["pathInReportFilters"], $reporter->report_def['filters_def']['Filter_1']);
                            }
                        }
                        $args["customFilter"] = $reporter->report_def['filters_def']['Filter_1'];
                    }
                }

                // by default we supposed line charts consist of one group type. still there are cases when they are used to render reports with two grouping types
                // so here we adjust the type
                if ($args['dashletChartType'] == 'line chart' && count($reporter->report_def['group_defs']) == 2) {
                    $groupType = 'group';
                    $filters   = array($args['group1_filter_value'], $args['group2_filter_value']);
                }

                $recordsQuery    = new RecordsQuery($reporter, $groupType, $filters, $nextOffset, $recordsPerPage);
                $unformattedData = $recordsQuery->getData($args);

                if ($recordsPerPage < count($unformattedData)) {
                    array_pop($unformattedData);
                    $returnData['next_offset'] = $nextOffset + $recordsPerPage;
                } else {
                    $returnData['next_offset'] = -1;
                }

                //format raw data and add it to returnData
                $formattedData            = $recordsQuery->formatData($unformattedData);
                $returnData['collection'] = $formattedData['collection'];
                $returnData['meta']       = $this->addDirectionWhenOrderBy($formattedData['meta'], $args);

                if ($args["module"] === "Trackers") {
                    $recordsCountQuery           = new RecordsQuery($reporter, $groupType, $filters, $nextOffset, $recordsPerPage);
                    $recordsCountQuery->paginate = false;
                    $unformattedCountData        = $recordsCountQuery->getData($args);

                    $totalCount = $unformattedCountData;
                    if (is_array($totalCount)) {
                        $returnData["count"] = count($totalCount);
                    }
                } else {
                    $count               = $this->getSavedReportListViewCountById($api, $args);
                    $returnData["count"] = $count;
                }
            }
        }

        return $returnData;
    }

    /**
     * Returns report count based on id and element clicked.
     * Consider that when user clicks on a element, we first update the helper table, then we return results
     * That's why we can base on the helper table for this count.
     * @method getSavedReportListViewCountById
     */
    public function getSavedReportListViewCountById(ServiceBase $api, array $args, $acl = 'list'): int
    {
        global $db;
        $conn = $db->getConnection();

        $sql = <<<SQL
SELECT
    count(*) as count
FROM
    wdrilldown_report_records
WHERE
    drawer_id = '{$args["drawerUID"]}'
SQL;

        $dbRes = $conn->executeQuery($sql, array());
        if ($dbRes) {
            $row = $dbRes->fetch();
            if ($row && array_key_exists('count', $row)) {
                $count = $row["count"];
                return $count;
            }
        }
        return 0;
    }

    /**
     * Returns records list
     * For Tracker module, we will update module to the one selected in chart.
     * We show user the actual records composing selected element.
     *
     * @method getBaseListRecords
     * @param  ServiceBase               $api  [description]
     * @param  array                     $args [description]
     * @param  string                    $acl  [description]
     * @return [type]                    [description]
     */
    public function getBaseListRecords(ServiceBase $api, array $args, $acl = 'list')
    {
        if ($args["module"] == "Trackers") {
            $chartReport = BeanFactory::getBean("Reports", $args['reportId'], array("encode" => false));
            $reportClass = SugarAutoLoader::customClass("Report");
            if ($reportClass == "Report") {
                $reporter = new Report($chartReport->content);
            }
            if ($reportClass == "CustomReport") {
                $reporter = new CustomReport($chartReport->content);
            }
            $groupDefs = $reporter->report_def["group_defs"];
            if ($groupDefs[0]['table_key'] == "self" && $groupDefs[0]['name'] == "module_name") {
                $args["module"] = $args["group1_filter_value"];
            } elseif (count($groupDefs) > 1 && $groupDefs[1]['table_key'] == "self" && $groupDefs[1]['name'] == "module_name") {
                $args["module"] = $args["group2_filter_value"];
            }
        } else {
            if (empty($args["link"]) === false) {
                //for this case we'll need to know who is the parent of the link
                $args["module"] = $args["reportModule"];
            }
        }

        $res = parent::filterList($api, $args, $acl);

        //Add count for base Records list.
        //This count reflects report count for current group selected AND filters applied directly on the list
        $countResult  = $this->getFilterListCount($api, $args, $acl);
        $res["count"] = $countResult["record_count"];

        return $res;
    }

    /**
     * Preprocess the args array to set filter options.
     *
     * @param ServiceBase $api The REST API object.
     * @param array $args REST API arguments.
     * @param string $acl Which type of ACL to check.
     * @return array An array containing the modified args array, a query object
     *   with all the filters applied, the modified options array, and a
     *   SugarBean for the chosen module.
     */
    public function filterListSetup(ServiceBase $api, array $args, $acl = 'list')
    {
        global $beanList, $dictionary, $objectList;

        list($args, $q, $options, $seed) = parent::filterListSetup($api, $args, $acl);

        if (array_key_exists("id_query", $options)) {
            //this query is automatically set up by Sugar and it filters on it
            unset($options["id_query"]);
        }

        // add our filter
        $subqueryWithRecordIds = <<<SQL
SELECT
    record_id
FROM
    wdrilldown_report_records
WHERE
    drawer_id = '{$args["drawerUID"]}'
SQL;
        $beanName = $objectList[$args['module']];
        if (empty($beanName)) {
            $beanName = $beanList[$args['module']];
        }
        if ($beanName == "aCase") {
            $beanName = "Case";
        }
        $baseTable = $dictionary[$beanName]['table'];

        $q->whereRaw("{$baseTable}.id in ({$subqueryWithRecordIds})");

        $filterListSetupResult = array($args, $q, $options, $seed);

        return $filterListSetupResult;
    }

    protected function addDirectionWhenOrderBy($formattedMeta, $args)
    {
        if (array_key_exists('orderBy', $args)) {
            $orderBy = $args['orderBy'];
            foreach ($formattedMeta['panel']['fields'] as $key => $field) {
                if ($orderBy['fieldname'] == $field['name']) {
                    $formattedMeta['panel']['fields'][$key]['direction'] = $orderBy['direction'];
                }
            }
        }

        return $formattedMeta;
    }

    /*
    Used in order to not generate queries if report does not have groups to make the chart on
     */
    protected function givenReportCanBeRepresentedOnChart($report, $groupType)
    {
        if ($groupType == 'simple' && count($report->report_def['group_defs']) >= 1) {
            return true;
        } elseif ($groupType == 'group' && count($report->report_def['group_defs']) >= 2) {
            return true;
        }

        return false;
    }

    /**
     * Retrieves a saved Report by Report Id
     * @param $reportId
     *
     * @return SugarBean
     */
    protected function getSavedReportById($reportId)
    {
        return BeanFactory::getBean("Reports", $reportId, array("encode" => false));
    }

    public function isReportDeprecated($api, $args)
    {
        $deprecated = false;
        include_once "include/SugarCharts/ChartDisplay.php";

        $chartReport = $this->getSavedReportById($args['reportId']);

        if (!empty($chartReport)) {
            if (!$chartReport->ACLAccess('view')) {
                throw new SugarApiExceptionNotAuthorized('No access to view this report');
            }

            include_once "modules/Reports/Report.php";

            $report_info = json_decode($chartReport->content, true);

            // some old reports have deprecated keys in full_table_list that cause problems when we add custom filters
            $full_table_list = $report_info['full_table_list'];
            if (!is_array($full_table_list) || count($full_table_list) == 0 || !array_key_exists('self', $full_table_list)) {
                $deprecated = true;
            } else {
                foreach ($full_table_list as $table_key => $table_data) {
                    if (preg_match('/self_/', $table_key) == 1) {
                        $deprecated = true;
                    }
                }
            }
        }

        return array('deprecated' => $deprecated);
    }

    /**
     * Get all users from the system
     *
     * @return array
     */
    public function getUsers(ServiceBase $api, array $args): array
    {
        $beansRaw = [];
        $bean     = BeanFactory::newBean("Users");

        $sq = new SugarQuery();
        $sq->select([
            "id",
            "first_name",
            "last_name",
        ]);

        $sq->from($bean, [
            "team_security" => true,
            "erased_fields" => false,
        ]);

        $andWhere = $sq->where();
        $andWhere->equals("portal_only", 0);
        $andWhere->equals("status", "active");

        $sq->offset(0);

        $result = $sq->execute();

        if (count($result) === 0) {
            return [];
        } else {
            foreach ($result as $row) {
                $beanRaw = [
                    "id"   => $row["id"],
                    "name" => trim("{$row["first_name"]} {$row["last_name"]}"),
                ];

                $beansRaw[] = $beanRaw;
            }
        }

        return $beansRaw;
    }

}
