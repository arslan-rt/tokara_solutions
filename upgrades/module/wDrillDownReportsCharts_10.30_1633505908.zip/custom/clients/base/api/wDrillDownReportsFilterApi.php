<?php
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\Utils as Utils;

class wDrillDownReportsFilterApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'dashboardTemplate'          => array(
                'reqType'   => 'POST',
                'path'      => array('wDrillDown', 'dashboardTemplate', 'setDashboardTemplate'),
                'pathVars'  => array('wDrillDown', 'dashboardTemplate', 'setDashboardTemplate'),
                'method'    => 'setDashboardTemplate',
                'shortHelp' => 'set dashboard template',
                'longHelp'  => 'custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html',
            ),
            'setDashletFilter'           => array(
                'reqType'   => 'POST',
                'path'      => array('wDrillDown', 'dashletFilter', 'setDashletFilter'),
                'pathVars'  => array('wDrillDown', 'dashletFilter', 'setDashletFilter'),
                'method'    => 'setDashletFilter',
                'shortHelp' => 'set dashlet filter',
                'longHelp'  => 'custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html',
            ),
            'getDashboardReportsContent' => array(
                'reqType'   => 'GET',
                'path'      => array('wDrillDown', 'runtime', 'getDashboardReportsContent', '?'),
                'pathVars'  => array('', '', '', 'dashboardId'),
                'method'    => 'getDashboardReportsContent',
                'shortHelp' => 'get dashboard reports content',
                'longHelp'  => 'custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html',
            ),
            'setDashboardFilter'         => array(
                'reqType'   => 'POST',
                'path'      => array('wDrillDown', 'dashboardFilter', 'dashboardFilter', '?'),
                'pathVars'  => array('', '', '', 'dashboardId'),
                'method'    => 'setDashboardFilter',
                'shortHelp' => 'set dashboard filter',
                'longHelp'  => 'custom/src/wsystems/wDrillDownReportsChart/Help/drilldown_filters_help.html',
            ),
        );
    }

    public function setDashboardTemplate(ServiceBase $api, array $args): array
    {
        global $dictionary, $timedate;

        $db    = DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_templates";

        $fieldDefs = $dictionary[$table]["fields"];

        $status = [
            "status"   => "success",
            "updated"  => 0,
            "inserted" => 0,
        ];

        if (is_string($args["dashboardId"]) === false) {
            $status["status"]        = "input_error";
            $status["error_message"] = "No dashboardId given";
            return $status;
        }

        $dataToSave = [
            "dashboard_id"   => $args["dashboardId"],
            "templates"      => json_encode($args["runtimeTemplates"]),
            "date_generated" => $timedate->nowDb(),
        ];

        if (FilterUtils::filterExistsInDb($table, ["dashboardId" => $args["dashboardId"]]) === true) {
            $where = [
                "dashboard_id" => $args["dashboardId"],
            ];
            $updated = $db->updateParams($table, $fieldDefs, $dataToSave, $where);

            if ($updated === true) {
                $status["updated"]++;
            } else {
                $status["status"]        = "update_error";
                $status["error_message"] = $db->lastError();
            }
        } else {
            $dataToSave["id"] = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();

            $inserted = FilterUtils::insertDashboardTemplatesInDb($dataToSave);

            if ($inserted === true) {
                $status["inserted"]++;
            } else {
                $status["status"]        = "insert_error";
                $status["error_message"] = $db->lastError();
            }
        }

        return $status;
    }

    /**
     * This entrypoint is also used to reset dashlet filters durring a wChart fetch
     */
    public function setDashletFilter(ServiceBase $api, array $args): array
    {
        global $dictionary, $timedate, $current_user;

        $db    = DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_dashlets";

        $fieldDefs = $dictionary[$table]["fields"];

        $status = [
            "status"   => "success",
            "updated"  => 0,
            "inserted" => 0,
        ];

        if (is_string($args["dashletId"]) === false) {
            $status["status"]        = "input_error";
            $status["error_message"] = "No dashletId given";
            return $status;
        }

        $dataToSave = [
            "report_id"      => $args["reportId"],
            "dashlet_id"     => $args["dashletId"],
            "user_id"        => $current_user->id,
            "filters"        => json_encode($args["customFilter"]),
            "date_generated" => $timedate->nowDb(),
        ];

        $filterExistsInDb = FilterUtils::filterExistsInDb($table, [
            "dashletId" => $args["dashletId"],
            "userId"    => $current_user->id,
        ]);
        if ($filterExistsInDb === true) {
            $where = [
                "dashlet_id" => $args["dashletId"],
                "user_id"    => $current_user->id,
            ];

            $updated = $db->updateParams($table, $fieldDefs, $dataToSave, $where);

            if ($updated === true) {
                $status["updated"]++;
            } else {
                $status["status"]        = "update_error";
                $status["error_message"] = $db->lastError();
            }
        } else {
            $dataToSave["id"] = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();
            $inserted         = $db->insertParams($table, $fieldDefs, $dataToSave);

            if ($inserted === true) {
                $status["inserted"]++;
            } else {
                $status["status"]        = "insert_error";
                $status["error_message"] = $db->lastError();
            }
        }

        return $status;
    }

    /**
     * @method getDashboardReportsContent
     * @param  RestService       $api
     * @param  Array             $args
     * @param String             $args $dashboardId
     * @return Array
     *  "hasRuntimes" means that in given dashboard there is at least one runtime filter
     */
    public function getDashboardReportsContent(RestService $api, array $args): array
    {
        $data = [
            "hasRuntimes"     => false,
            "reportsDashlets" => [],
        ];

        $dashboard = BeanFactory::retrieveBean("Dashboards", $args["dashboardId"]);
        $metadata  = json_decode($dashboard->metadata, true);

        $dashlets = Utils::getwChartDashlets($metadata);

        foreach ($dashlets as $dashlet) {
            $reportContent = $this->getReportContent($dashlet["saved_report_id"]);

            $reportContent["dashletId"] = $dashlet["dashletId"];
            $reportContent["reportId"]  = $dashlet["saved_report_id"];
            $data["reportsDashlets"][]  = $reportContent;

            $reportHasRuntimes = $this->hasRuntimeFilters($reportContent["filters_def"]["Filter_1"]);
            if ($reportHasRuntimes === true) {
                $data["hasRuntimes"] = true;
            }
        }

        return $data;
    }

    protected function getReportContent(string $reportId): array
    {
        $chartReport = BeanFactory::getBean('Reports', $reportId, array("encode" => false, "strict_retrieve" => true));
        $content     = json_decode($chartReport->content, true);

        return $content;
    }

    protected function hasRuntimeFilters($filter): bool
    {
        if (array_key_exists("operator", $filter) === false) {
            return is_array($filter) && isset($filter["runtime"]) && $filter["runtime"] === 1;
        }
        if (array_key_exists("operator", $filter)) {
            foreach ($filter as $subFilter) {
                if (is_array($subFilter)) {
                    $subRes = $this->hasRuntimeFilters($subFilter);
                    if ($subRes === true) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public function setDashboardFilter(RestService $api, array $args): array
    {
        global $dictionary, $timedate;

        $db    = DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_dashboards";

        $fieldDefs = $dictionary[$table]["fields"];

        $status = [
            "status"   => "success",
            "updated"  => 0,
            "inserted" => 0,
        ];

        if (is_string($args["dashboardId"]) === false) {
            $status["status"]        = "input_error";
            $status["error_message"] = "No dashboardId given";
            return $status;
        }
        if (is_string($args["templateId"]) === false) {
            $status["status"]        = "input_error";
            $status["error_message"] = "No templateId given";
            return $status;
        }

        $receivedFilter = [
            "templateId"  => $args["templateId"],
            "qualifier"   => $args["qualifier"],
            "input_name0" => $args["input_name0"],
            "input_name1" => $args["input_name1"],
        ];

        $filterModified = false;
        $filterInDb     = FilterUtils::getFilterFromDb($table, [
            "dashboardId" => $args["dashboardId"],
            "userId"      => $GLOBALS["current_user"]->id,
        ]);
        $filters = @json_decode($filterInDb["filters"], true);
        if (is_array($filters)) {
            foreach ($filters as &$filter) {
                if ($filter["templateId"] === $args["templateId"]) {
                    $filter         = $receivedFilter;
                    $filterModified = true;
                    break;
                }
            }
        } else {
            $filters = [];
        }
        if ($filterModified === false) {
            if (is_array($filters)) {
                $filters[] = $receivedFilter;
            } else {
                $filters = [$receivedFilter];
            }
        }

        $dataToSave = [
            "dashboard_id"   => $args["dashboardId"],
            "filters"        => json_encode($filters),
            "date_generated" => $timedate->nowDb(),
            "user_id"        => $GLOBALS["current_user"]->id,
        ];

        $filterExistsInDb = FilterUtils::filterExistsInDb($table, [
            "dashboardId" => $args["dashboardId"],
            "userId"      => $GLOBALS["current_user"]->id,
        ]);
        if ($filterExistsInDb === true) {
            $filterInDb = FilterUtils::getFilterFromDb($table, [
                "dashboardId" => $args["dashboardId"],
                "userId"      => $GLOBALS["current_user"]->id,
            ]);
            $where = [
                "id" => $filterInDb["id"],
            ];

            $updated = $db->updateParams($table, $fieldDefs, $dataToSave, $where);

            if ($updated === true) {
                $status["updated"]++;
            } else {
                $status["status"]        = "update_error";
                $status["error_message"] = $db->lastError();
            }
        } else {
            $dataToSave["id"] = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();
            $inserted         = $db->insertParams($table, $fieldDefs, $dataToSave);

            if ($inserted === true) {
                $status["inserted"]++;
            } else {
                $status["status"]        = "insert_error";
                $status["error_message"] = $db->lastError();
            }
        }

        return $status;
    }

}
