<?php
include_once 'include/api/SugarApi.php';
include_once 'modules/ModuleBuilder/parsers/parser.label.php';

class wDrillDownReportsChartSettingsApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'getSettings'  => array(
                'reqType'   => 'GET',
                'path'      => array('getDrilldownSettings'),
                'pathVars'  => array(''),
                'method'    => 'getDrilldownSettings',
                'shortHelp' => 'get drilldown settings',
                'longHelp'  => '',
            ),
            'saveSettings' => array(
                'reqType'   => 'PUT',
                'path'      => array('saveDrilldownSettings'),
                'pathVars'  => array(''),
                'method'    => 'saveDrilldownSettings',
                'shortHelp' => 'save drilldown settings',
                'longHelp'  => '',
            ),
        );
    }

    public function getDrilldownSettings($api, $args)
    {
        include_once 'include/utils.php';
        $res              = array();
        $predefinedColors = array();

        $home_strings = return_module_language('en_us', 'Home', false); //third parameter - true would refresh the cache and a lot more stuff we don't need
        if (array_key_exists('predefinedColors', $home_strings)) {
            $predefinedColors = json_decode($home_strings['predefinedColors'], true);
        }
        $res['predefinedColors'] = $predefinedColors;

        return $res;
    }

    public function saveDrilldownSettings($api, $args)
    {
        include_once 'modules/Configurator/Configurator.php';
        global $log;
        $result = 'success';

        try {
            $newEngine        = $args['data']['engine'];
            $predefinedColors = array(
                'predefinedColors' => json_encode($args['data']['predefinedColors']),
                'chartEngine'      => empty($newEngine) ? "sucrose" : $newEngine,
            );

            ParserLabel::addLabels("en_us", $predefinedColors, 'Home'); //this method needs a module

            global $mod_strings, $sugar_config;
            include_once 'include/SugarObjects/LanguageManager.php';
            //remove the js language files
            LanguageManager::removeJSLanguageFiles();
            //remove language cache files
            LanguageManager::clearLanguageCache();

            //update engine if current value was modified
            $configurator = new Configurator();
            $configurator->loadConfig();
            $currentSavedEngine = empty($configurator->config['chartEngine']) ? '' : $configurator->config['chartEngine'];
            if ($currentSavedEngine != $newEngine) {
                $configurator->config['chartEngine'] = $newEngine;
                $configurator->handleOverride();
                $result = 'qrr';
            }
        } catch (Exception $e) {
            $log->fatal($e->getMessage());
            return 'error';
        }

        return $result;
    }
}
