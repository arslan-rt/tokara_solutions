<?php
include_once 'clients/base/api/PersonFilterApi.php';

class wDrillDownReportsListApi extends PersonFilterApi
{
    public function registerApiRest()
    {
        return array(
            'retrieveReportsForDrilldown' => array(
                'reqType'   => 'GET',
                'path'      => array('Reports', 'drilldown'),
                'pathVars'  => array('module', 'action'),
                'method'    => 'retrieveReportsForDrilldown',
                'shortHelp' => 'retrieve reports for drilldown',
                'longHelp'  => '',
            ),
        );
    }

    public function retrieveReportsForDrilldown(ServiceBase $api, array $args)
    {
        if (!array_key_exists("filter", $args)) {
            $args["filter"] = array('$and' => array());
        }
        $args["filter"]['$and'] = array(
            "report_type" => array(
                '$not_in' => array(
                    0 => "tabular",
                ),
            ),
        );
        $args["module_list"] = $args["module"];

        $parentReports = parent::filterList($api, $args);
        return $parentReports;
    }
}
