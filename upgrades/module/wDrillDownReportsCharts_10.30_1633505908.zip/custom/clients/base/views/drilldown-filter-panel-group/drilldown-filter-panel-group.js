({
    className: "runtime-filter-panel-group",
    
    initialize: function (options) {        
        var initRes = this._super("initialize", arguments);
        
        window["drilldownFilterPanelGroupView" + this.cid] = this;

        this.group = options.group;
        this.groupIdx = options.groupIdx;

        /**
         * Number of characters visible to show as group name in the width given for the current panel
         */
        this.numberOfCharactersVisible = 25;

        var dashboardComponent = this.closestComponent("dashboard");

        this.groupMeta = []; //helper for processing and UI 

        this.events = _.extend({}, this.events, {
            "change select[name=qualifier]": "qualifierChanged"
        });
        
        // this.listenTo(dashboardComponent, "dashboardInfo:received", this.renderPanel.bind(this));

        this.listenTo(dashboardComponent, "filters:clear", this.clearDashboardFilters.bind(this));

        return initRes;
    },
    
    /**
     * Check group here because we are dependent on informations about the dashboard
     * Only after informations are received, we can validate groups
     */
    reportsOnThisGroupAreStillHere: function () { 
        var dashboard = this.closestComponent("dashboard") || this.options.layout.closestComponent("dashboard"); 
        this.informationsAboutDashboard = dashboard.informationsAboutDashboard;
       
        var reportIdsOnThisGroup = _.pluck(this.group.filter.fields, "reportId");
        
        var res = true;
        _.each(reportIdsOnThisGroup, function iterateOverReports(reportIdOnGroup) {
            var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                return reportDashlet.reportId === reportIdOnGroup;
            });
            if (typeof reportDefs === "undefined") {
                res = false;
            }
        }.bind(this));
        return res;
    },

    render: function () {
        if (this.disposed === true) { 
            return;
        }

        var dashboard = this.closestComponent("dashboard") || this.options.layout.closestComponent("dashboard"); 
        this.informationsAboutDashboard = dashboard.informationsAboutDashboard;
        
        //when edit the dashlet and change the report, remove group
        if (this.layout instanceof app.view.Layout && this.reportsOnThisGroupAreStillHere() === false) { 
            this.dispose();
            this.layout.removeComponent(this);
            this.options.layout.closestComponent("dashboard").trigger("drilldown-group:removed");
            return;
        }
        this.setQualifiers();

        if (this.group.name.length > this.numberOfCharactersVisible) {
            this.group.nameShortened = this.shortenLabel(this.group.name, this.numberOfCharactersVisible);
        }
        var initRes = this._super("render", arguments);
        this.$el.attr("group-idx", this.groupIdx);
        
        //setup value field
        this.groupMeta = this.groupMeta || {};
        this.groupMeta.qualifier = this.group.filter.qualifier;
        this.groupMeta.input0 = this.group.filter.input_name0;
        this.groupMeta.input1 = this.group.filter.input_name1;
        
        this.groupMeta.fieldName = this.group.filter.fields[0].fieldName;
        this.groupMeta.tableKey = this.group.filter.fields[0].tableKey;
        
        this.refreshFilterInput();

    },

    shortenLabel: function (label, numberOfChars) { 
        return label.substr(0, numberOfChars - 3) + "...";
    },
    /**
     * Get qualifiers based on the first type. All of them have the same field type
     */
    setQualifiers: function () {
        var reportId = this.group.filter.fields[0].reportId;
        var tableKey = this.group.filter.fields[0].tableKey;
        var fieldName = this.group.filter.fields[0].fieldName;
        var dashletId = this.group.filter.fields[0].dashlet;
        var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
            return reportDashlet.reportId === reportId
                && reportDashlet.dashletId === dashletId;
        });
        var fieldModule = reportDefs.full_table_list[tableKey].module;

        var fieldType = app.metadata.getModule(fieldModule).fields[fieldName].type;
        
        this.qualifiers = app.wsystems.wDrillDownReportsChart.getFieldQualifiers(fieldType);
        this.qualifier = this.group.filter.qualifier;
    },

    clearFiltersInUI: function () { 
        this.group.filter.qualifier = this.qualifiers[0].name;
        this.$el.find("select[name=qualifier]").val(this.qualifiers[0].name);

        this.groupMeta = this.groupMeta || {};
        this.groupMeta.qualifier = this.qualifiers[0].name;
        this.groupMeta.input0 = "";
        this.groupMeta.input1 = "";

        this.groupMeta.fieldName = this.group.filter.fields[0].fieldName;
        this.groupMeta.tableKey = this.group.filter.fields[0].tableKey;
        
        this.refreshFilterInput();
    },

    clearDashboardFilters: function () { 
        this.clearFiltersInUI();
        this.saveFiltersAndReset();
    },

    qualifierChanged: function (e) {
        this.group.filter.qualifier = $(e.currentTarget).val();

        this.groupMeta = this.groupMeta || {};
        this.groupMeta.qualifier = $(e.currentTarget).val();
        this.groupMeta.input0 = "";
        this.groupMeta.input1 = "";

        this.groupMeta.fieldName = this.group.filter.fields[0].fieldName;
        this.groupMeta.tableKey = this.group.filter.fields[0].tableKey;
        
        this.refreshFilterInput();
        
        if (this.qualifierIsUnary(this.groupMeta.qualifier) === true) { 
            this.saveFiltersChanged();
        }
    },

    qualifierIsUnary: function (qualifier) { 
        var firstFieldReportId = this.group.filter.fields[0].reportId;
        var firstFieldDashletId = this.group.filter.fields[0].dashlet;
        var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
            return reportDashlet.reportId === firstFieldReportId
                && reportDashlet.dashletId === firstFieldDashletId;
        });

        var fieldDefs = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(
            this.group.filter.fields[0].fieldName,
            this.group.filter.fields[0].tableKey,
            reportDefs
        );
        var fieldType = fieldDefs.type;

        if (fieldType === "date" || fieldType === "datetime" || fieldType === "datetimecombo") { 
            if (qualifier.indexOf("tp_") >= 0) { 
                return true;
            }
        }

        if (qualifier === "empty" || qualifier === "not_empty") { 
            return true;
        }

        return false;
    },

    /**
     * Save the qualifier in dashboard AND also in dashlet config
     */
    saveFiltersAndReset: _.debounce(function () {
        var dashboardId = this.model.id;
        var dashboardFilterData = this.getFilter();
        app.api.call("create", app.api.buildURL("wDrillDown/dashboardFilter/dashboardFilter/" + dashboardId), dashboardFilterData, {
            success: function successUpdate(res) { 
                this.layout.closestComponent("dashboard").trigger("filter:reset");              
            }.bind(this),
            error: function () { 
                window.console.log("error updating filter");
            },
        });
    }, 100),

    /**
     * Save the qualifier in dashboard AND also in dashlet config
     */
    saveFiltersChanged: _.debounce(function (model) {
        if (this.disposed) { 
            return;
        }
        var dashboardId = this.model.id;
        var dashboardFilterData = this.getFilter();
        app.api.call("create", app.api.buildURL("wDrillDown/dashboardFilter/dashboardFilter/" + dashboardId), dashboardFilterData, {
            success: function successUpdate(res) { 
                var filterChanged = _.extend({}, this.group, {
                    qualifier   : dashboardFilterData.qualifier,
                    input_name0 : dashboardFilterData.input_name0, //eslint-disable-line camelcase
                    input_name1 : dashboardFilterData.input_name1//eslint-disable-line camelcase
                });
                this.layout.closestComponent("dashboard").trigger("filter:changed", filterChanged);              
            }.bind(this),
            error: function () { 
                window.console.log("error updating filter");
            },
        });
    }, 100),

    getFilter: function () { 
        var dashboardFilterData = {};
        dashboardFilterData["templateId"] = this.group.templateId;

        var qualifier = this.$el.find("select[name=qualifier]").val();
        dashboardFilterData["qualifier"] = qualifier;
        
        var fieldName = this.groupMeta["fieldName"];
        var firstFieldReportId = this.group.filter.fields[0].reportId;
        var firstFieldDashletId = this.group.filter.fields[0].dashlet;
        var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
            return reportDashlet.reportId === firstFieldReportId
                && reportDashlet.dashletId === firstFieldDashletId;
        });

        var fieldDefinition = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(fieldName, this.groupMeta.tableKey, reportDefs);
        var fieldType = fieldDefinition["type"];

        if (qualifier === "empty" || qualifier === "not_empty") {
            dashboardFilterData.input_name0 = qualifier;//eslint-disable-line camelcase
            delete dashboardFilterData.input_name1;
        } else if (fieldType === "date") {
            if (
                qualifier === "tp_next_n_days" || qualifier === "tp_last_n_days"
            ) {
                dashboardFilterData.input_name0 = this.groupMeta.field0.model.get(fieldName);//eslint-disable-line camelcase
            } else {
                dashboardFilterData.input_name0 = window.moment(this.groupMeta.field0.model.get(fieldName)).format("YYYY-MM-DD");//eslint-disable-line camelcase
            }
            if (
                this.groupMeta.field1 instanceof app.view.Field
                && this.groupMeta.field1.model instanceof Backbone.Model
                && this.groupMeta.field1.model.attributes[fieldName] !== ""
            ) {
                dashboardFilterData.input_name1 = window.moment(this.groupMeta.field1.model.get(fieldName)).format("YYYY-MM-DD");//eslint-disable-line camelcase
            }
        } else if (fieldType === "datetime" || fieldType === "datetimecombo") {
            if (qualifier === "tp_next_n_days" || qualifier === "tp_last_n_days") {
                dashboardFilterData.input_name0 = this.groupMeta.field0.model.get(fieldName);//eslint-disable-line camelcase
            } else {
                dashboardFilterData.input_name0 = window.moment(this.groupMeta.field0.model.get(fieldName)).format("YYYY-MM-DD hh:mm:ss");//eslint-disable-line camelcase
            }
            if (
                this.groupMeta.field1 instanceof app.view.Field
                && this.groupMeta.field1.model instanceof Backbone.Model
                && this.groupMeta.field1.model.attributes[fieldName] !== ""
            ) {
                dashboardFilterData.input_name1 = window.moment(this.groupMeta.field1.model.get(fieldName)).format("YYYY-MM-DD hh:mm:ss");//eslint-disable-line camelcase
            }
        } else if (fieldType === "relate") {
            var idName = fieldDefinition.id_name;
            dashboardFilterData.input_name0 = this.groupMeta.field0.model.attributes[idName];//eslint-disable-line camelcase
            dashboardFilterData.input_name1 = this.groupMeta.field0.model.attributes[fieldName];//eslint-disable-line camelcase
        } else if (
            (fieldType === "id" || fieldType === "name" || fieldType === "fullname")
            && (qualifier === "is" || qualifier === "is_not"
            || qualifier === "one_of" || qualifier === "not_one_of")
        ) {
            dashboardFilterData.input_name0 = this.groupMeta.field0.model.attributes["id"];//eslint-disable-line camelcase
            dashboardFilterData.input_name1 = this.groupMeta.field0.model.attributes[fieldName];//eslint-disable-line camelcase
        } else if (fieldType === "enum") {
            dashboardFilterData.input_name0 = this.groupMeta.field0.model.get(fieldName);//eslint-disable-line camelcase
            if (Array.isArray(dashboardFilterData.input_name0) === false) {
                dashboardFilterData.input_name0 = [dashboardFilterData.input_name0];//eslint-disable-line camelcase
            }
            delete dashboardFilterData.input_name1;
        } else {
            if (this.groupMeta.field0.model instanceof Backbone.Model) {
                dashboardFilterData.input_name0 = this.groupMeta.field0.model.get(fieldName);//eslint-disable-line camelcase
            }
            if (
                this.groupMeta.field1 instanceof app.view.Field
                && this.groupMeta.field1.model instanceof Backbone.Model
            ) {
                dashboardFilterData.input_name1 = this.groupMeta.field1.model.get(fieldName);//eslint-disable-line camelcase
            }
        }

        return dashboardFilterData;
    },

    refreshFilterInput: function () {
        $(this.$el.find(".input0")).html("");
        $(this.$el.find(".input1")).html("");
        $(this.$el.find(".input1")).addClass("hide");

        //remove previous field components
        var groupMeta = this.groupMeta;
        var fieldKeys, i;

        if (groupMeta.field0 instanceof app.view.Field) {
            fieldKeys = _.keys(this.fields);
            for (i = 0; i < fieldKeys.length; i++) {
                if (this.fields[fieldKeys[i]].cid === groupMeta.field0.cid) {
                    this.fields[fieldKeys[i]].remove();
                    delete this.fields[fieldKeys[i]];
                }
            }
            delete groupMeta.field0;
        }
        if (groupMeta.field1 instanceof app.view.Field) {
            fieldKeys = _.keys(this.fields);
            for (i = 0; i < fieldKeys.length; i++) {
                if (this.fields[fieldKeys[i]].cid === groupMeta.field1.cid) {
                    this.fields[fieldKeys[i]].remove();
                    delete this.fields[fieldKeys[i]];
                }
            }
            delete groupMeta.field1;
        }

        this.addFilterInput();

        this.groupMeta.field0.model.on("change", this.saveFiltersChanged.bind(this));
        if (this.groupMeta.field1 instanceof app.view.Field) { 
            this.groupMeta.field1.model.on("change", this.saveFiltersChanged.bind(this));
        }
    },

    /**
     * Creates one or two inputs for a filter (field + qualifier)
     */
    addFilterInput: function () {
        var filterRow = this.groupMeta;

        var firstFieldReportId = this.group.filter.fields[0].reportId;
        var firstFieldDashletId = this.group.filter.fields[0].dashlet;
        var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
            return reportDashlet.reportId === firstFieldReportId
                && reportDashlet.dashletId === firstFieldDashletId;
        });

        var qualifierName = filterRow.qualifier;
        var tableKey = filterRow.tableKey;

        var fieldName = filterRow.fieldName;

        var fieldModule = reportDefs.full_table_list[tableKey].module;

        var fieldDefinition = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(fieldName, tableKey, reportDefs);

        if (typeof (qualifierName) == "undefined" || qualifierName == "") {
            if (fieldDefinition.type === "name" || fieldDefinition.type === "id" || fieldDefinition === "fullName") { 
                qualifierName = "is";
            } else {
                qualifierName = "equals";
            }
        }

        var fieldType = fieldDefinition.type;
        if (typeof (fieldDefinition.custom_type) != "undefined") {
            fieldType = fieldDefinition.custom_type;
        }

        if (qualifierName == "between") {
            this.addFilterInputTextBetween(fieldDefinition);
        } else if (qualifierName == "between_dates") {
            this.addFilterInputDateBetween(fieldDefinition);
        } else if (qualifierName == "between_datetimes") {
            this.addFilterInputDatetimesBetween(fieldDefinition);
        } else if (qualifierName.indexOf("_n_days") != -1) {
            this.addFilterInputText(fieldDefinition);
        } else if (qualifierName == "empty" || qualifierName == "not_empty") {
            this.addFilterNoInput(fieldDefinition);
        } else if (fieldType == "date" || fieldType == "datetime") {
            if (qualifierName.indexOf("tp_") === 0) {
                this.addFilterInputEmpty(fieldDefinition);
            } else {
                this.addFilterInputDate(fieldDefinition);
            }
        } else if (fieldType == "datetimecombo") {
            if (qualifierName.indexOf("tp_") === 0) {
                this.addFilterInputEmpty(fieldDefinition);
            } else {
                this.addFilterInputDatetimecombo(fieldDefinition);
            }
        } else if (fieldType == "id" || fieldType == "name" || fieldType == "fullname") {
            var fieldDefinitionCustomized;
            if (qualifierName == "is" || qualifierName == "is_not") {    
                fieldDefinitionCustomized = {
                    custom_module : "Accounts", //eslint-disable-line camelcase
                    ext2          : fieldModule,
                    id_name       : "id", //eslint-disable-line camelcase
                    module        : fieldModule,
                    name          : fieldDefinition.name,
                    quicksearch   : "enabled",
                    required      : false,
                    source        : "non-db",
                    type          : "relate"
                };

                this.addFilterInputRelate(fieldDefinitionCustomized);
            } else if (qualifierName == "one_of" || qualifierName == "not_one_of") { 
                fieldDefinitionCustomized = {
                    custom_module : "Accounts", //eslint-disable-line camelcase
                    ext2          : fieldModule,
                    id_name       : "id", //eslint-disable-line camelcase
                    module        : fieldModule,
                    name          : fieldDefinition.name,
                    quicksearch   : "enabled",
                    required      : false,
                    source        : "non-db",
                    // type          : "drilldown-multirelate",
                    // isMultiEnum   : true
                    type          : "relate",
                    isMultiSelect : true,
                };

                this.addFilterInputMultiRelate(fieldDefinitionCustomized);
            } else {
                this.addFilterInputText(fieldDefinition);
            }
        } else if (fieldType == "relate") {
            if (qualifierName == "is" || qualifierName == "is_not") {
                this.addFilterInputRelate(fieldDefinition);
            } else {
                this.addFilterInputText(fieldDefinition);
            }
        } else if (fieldType == "username" || fieldType == "assigned_user_name") {
            var usersArray = {};
            usersArray["Current User"] = "Current User";
            var users = app.wsystems.wDrillDownReportsChart.users || [];
            _.each(users, function eachUser(user) {
                usersArray[user.id] = user.name;
            });

            if (qualifierName == "one_of" || qualifierName == "not_one_of") {
                this.addFilterInputSelectMultiple(usersArray, fieldDefinition);
            } else {
                this.addFilterInputSelectSingle(usersArray, fieldDefinition);
            }
        } else if (fieldType == "enum" || fieldType == "multienum" || fieldType == "parent_type" || fieldType == "timeperiod" || fieldType == "currency_id") {
            fieldDefinition.module = fieldModule;//enum needs module to fetch for options sometimes
            var fieldOptions = fieldDefinition.options;
            if (qualifierName == "one_of" || qualifierName == "not_one_of") {
                this.addFilterInputSelectMultiple(fieldOptions, fieldDefinition);
            } else {
                this.addFilterInputSelectSingle(fieldOptions, fieldDefinition);
            }
        } else if (fieldType == "bool") {
            var options = ["No", "Yes"];
            this.addFilterInputSelectSingle(options, fieldDefinition);
        } else {
            this.addFilterInputText(fieldDefinition);
        }
    },

    addFilterInputTextBetween: function(fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model0 = new Backbone.Model();
        model0.set(fieldName, filterMeta.input0);

        var field0 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model0,
            module   : fieldModule
        });
        field0.render();

        this.groupMeta.field0 = field0;

        $(this.$el.find(".input0")).html(field0.$el);

        $(this.$el.find(".input1")).removeClass("hide");

        var model1 = new Backbone.Model();
        model1.set(fieldName, filterMeta.input1);

        var field1 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model1,
            module   : fieldModule
        });
        field1.render();

        this.groupMeta.field1 = field1;

        $(this.$el.find(".input1")).html(field1.$el);
    },

    /**
       * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
       * @param {*} fieldDefinition 
     */
    addFilterInputDateBetween: function(fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model0 = new Backbone.Model();
        model0.set(fieldName, filterMeta.input0 || new Date());

        var field0 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name : fieldName,
                type : "date",
            },
            context : this.context,
            model   : model0,
            module  : fieldModule
        });
        field0.render();

        this.groupMeta.field0 = field0;

        $(this.$el.find(".input0")).html(field0.$el);

        $(this.$el.find(".input1")).removeClass("hide");

        var model1 = new Backbone.Model();
        model1.set(fieldName, filterMeta.input1 || new Date());

        var field1 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name : fieldName,
                type : "date",
            },
            context : this.context,
            model   : model1,
            module  : fieldModule
        });
        field1.render();

        this.groupMeta.field1 = field1;

        $(this.$el.find(".input1")).html(field1.$el);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} fieldDefinition 
     */
    addFilterInputDatetimesBetween: function(fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }
        var field, model;
        
        model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);

        $(this.$el.find(".input1")).removeClass("hide");

        model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);
        field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field1 = field;

        $(this.$el.find(".input1")).html(field.$el);
    },

    addFilterNoInput: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set("text_input", filterMeta.qualifier);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                dbType : "varchar",
                len    : 150,
                name   : "text_input",
                type   : "varchar",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        field.$el.hide();

        this.groupMeta.field0 = field;
        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputEmpty: function (fieldDefinition) {
        this.addFilterNoInput(fieldDefinition);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} fieldDefinition 
     */
    addFilterInputDate: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "date",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} fieldDefinition 
     */
    addFilterInputDatetimecombo: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0 || new Date());

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputRelate: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldModule = fieldDefinition.ext2;
        var predefinedValues = {};
        if (filterMeta.input0 === "is" || filterMeta.input0 === "is_not") {
            predefinedValues[fieldDefinition.id_name] = "";
        } else { 
            predefinedValues[fieldDefinition.id_name] = filterMeta.input0;
        }
        predefinedValues[fieldDefinition.name] = filterMeta.input1;

        var model = new Backbone.Model();
        model.set(predefinedValues);

        var createOptions = {
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model
        };
        if (_.isUndefined(fieldModule) === false && _.isEmpty(fieldModule) === false) {
            createOptions.module = fieldModule;
        }
        var field = app.view.createField(createOptions);
        field.render();
        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputMultiRelate: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var predefinedValues = {};
        if (filterMeta.input0 === "one_of" || filterMeta.input0 === "not_one_of") {
            predefinedValues[fieldDefinition.id_name] = "";
        } else {
            predefinedValues[fieldDefinition.id_name] = filterMeta.input0;
        }
        predefinedValues[fieldDefinition.name] = filterMeta.input1;

        var fieldModule = fieldDefinition.ext2;

        var model = new Backbone.Model();
        model.set(predefinedValues);

        var createOptions = {
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model,
        };

        if (_.isUndefined(fieldModule) === false && _.isEmpty(fieldModule) === false) {
            createOptions.module = fieldModule;
        }
        
        var field = app.view.createField(createOptions);
        field.render();
        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputText: function (fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        
        if (
            filterMeta.input0 === "equals"
            || filterMeta.input0 === "not_equals_str"
            || filterMeta.input0 === "contains"
            || filterMeta.input0 === "does_not_contain"
            || filterMeta.input0 === "starts_with"
            || filterMeta.input0 === "ends_with"
            || filterMeta.input0 === "tp_next_n_days"
            || filterMeta.input0 === "tp_last_n_days"
        ) {
            model.set(fieldName, "");//put an empty input when operator changed
        } else { 
            model.set(fieldName, filterMeta.input0);
        }

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                dbType : "varchar",
                len    : 150,
                name   : fieldName,
                type   : "varchar",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputSelectMultiple: function (options, fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name          : fieldName,
                options       : options,
                type          : "enum",
                isMultiSelect : true,
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },

    addFilterInputSelectSingle: function (options, fieldDefinition) {
        var filterMeta = this.groupMeta;
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var input0 = filterMeta.input0;
        if (Array.isArray(input0) && input0.length === 1) {
            input0 = input0[0];
        }
        if (input0 === "Yes" || input0 === "yes") {
            input0 = 1;
        } else if (input0 === "No" || input0 === "no") {
            input0 = 0;
        }

        var model = new Backbone.Model();
        model.set(fieldName, input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : options,
                type    : "enum",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.groupMeta.field0 = field;

        $(this.$el.find(".input0")).html(field.$el);
    },
});