/**
 * View used to show chart element records
 *
 * @class report-group-list
 */
({
    extendsFrom: "BaseListView",

    events: {
        "click [data-action=\"show-more\"]"        : "showMoreRecords",
        "click [data-event=\"list:preview:fire\"]" : "togglePreview",
        "click [class*=\"orderBy\"]"               : "setOrderBy"
    },

    className: "hide", //hide this component when open the drawer. on toggle it will be available

    /**
     * Sort order at current moment.
     * We need it mostly for making sure direction is gonna be changed when sort on the same field
     * @type {Object}
     */
    orderBy: {
        direction : "",
        fieldname : "",
        tableKey  : ""
    },

    /*We use these to toggle between opening preview or closing it.
  Just record id is not sufficient because there are reports
  */
    rowIndexInPreview   : -1,
    fieldIndexInPreview : -1,

    /**
     * Initialize the view and sets some attributes.
     * @method initialize
     * @param  {Object} opts default initialize options
     * @return {Parent} Parent component -> 'initialize' call response
     */
    initialize: function (opts) {
        var initCallRes = this._super("initialize", arguments);
        this.resetServerData();

        var listHeader = this.layout.getComponent("drilldown-report-selection-headerpane");
        if (listHeader.drawerListDisplayState == "report-group-list") {
            if (typeof this.model.attributes.next_offset !== "undefined") {
                delete this.model.attributes.next_offset;//reset offset from previous list
            }
            this.getSavedReportById(this.model.attributes.settings.attributes.saved_report_id);
        }

        app.events.on("list:preview:decorate", this.removeDecorationsOnReportGroupList.bind(this));
        app.events.on("preview:close", this.previewClosed.bind(this));

        return initCallRes;
    },

    broadcastCollectionFetch: function () {
        this.context.trigger("update:drilldown:header");
    },

    render: function () {
        //remove the initial hide class if this list it's visible at the moment
        var listHeader = this.layout.getComponent("drilldown-report-selection-headerpane");
        if (listHeader.drawerListDisplayState == "report-group-list") {
            this.$el.removeClass("hide");
        } else {
            this.$el.addClass("hide");
        }
        var sugarVersion = app.metadata.getServerInfo().version;

        if (_.isEmpty(sugarVersion) === false && sugarVersion === "11.1.0") {
            this.acceptSugarVersion = true;
        }

        var initRes = this._super("render", arguments);
        return initRes;
    },

    /**
     * Show More click handler.
     * @method showMoreRecords
     * @return undefined
     */
    showMoreRecords: function () {
        this.$el.find(".btn[data-action=show-more]").hide();
        this.$el.find(".block-footer").show();

        this.getSavedReportById(this.model.attributes.settings.attributes.saved_report_id);
    },

    /**
     * Based on model.attributes.next_offset the api will return correct page of records
     * @method getSavedReportById
     * @param  {String} reportId saved report id
     * @return undefined
     */
    getSavedReportById: function (reportId) {
        var params = this.model.attributes.settings.attributes;
        if (_.isEmpty(this.orderBy.fieldname) === false) {
            params.orderBy = this.orderBy;
        }
        params.next_offset = this.model.attributes.next_offset;//eslint-disable-line

        if (typeof this.context.get("customFilter") !== "undefined") {
            params.customFilter = this.context.get("customFilter");
        }
        
        if (_.isEmpty(params.link) === false) { 
            //the link needs to know who is the parent
            params.module = app.controller.context.attributes.module;
        }

        app.api.call("create", app.api.buildURL("Reports/" + reportId + "/reportlist"), params, {
            success: this.loadSavedReportData.bind(this)
        }, {
            skipMetadataHash: true,
        });
    },

    /**
     * Rerenders the view with received records and handles preview decorations
     * @method loadSavedReportData
     * @param  {Array} serverData records received from api
     * @return undefined
     */
    loadSavedReportData: function (serverData) {
        if (this.disposed) {
            return;
        }
        _.extend(this.meta, serverData.meta);

        _.each(this.meta.panel.fields, function addCSSStyle(fieldMeta) {
            if (
                fieldMeta.type == "name" ||
                fieldMeta.type == "relate" ||
                fieldMeta.type == "parent" ||
                fieldMeta.type == "fullName"
            ) {
                fieldMeta.cssStyle = "cell-xlarge";
            }
        });

        if (typeof serverData.count != "undefined") {
            this.context.set("groupCount", serverData.count);
        }

        //eslint-disable-next-line camelcase
        this.model.attributes.next_offset = serverData.next_offset;
        serverData.collection = this.formatLinkFieldsOnCollection(serverData);
        serverData.collection = this.formatWattachmentsFieldDisplay(serverData);

        this.serverData.collection = this.serverData.collection.concat(serverData.collection);
        //eslint-disable-next-line camelcase
        this.serverData.next_offset = serverData.next_offset;
        this.serverData.dataFetched = true;
        this.render();

        //decorate preview. needed after edit a record from preview
        var sidebar = this.closestComponent("sidebar");
        if (sidebar && sidebar.isSidePaneVisible() && this.modelUsedInPreview != null) {
            var selector = "a[data-record_id=\"" + this.modelUsedInPreview.get("id") + "\"]";
            var previewLink = this.$el.find(selector);
            if (previewLink.length >= 1) {
                this.decorateIcon(previewLink[0], true);
            }
        }

        this.broadcastCollectionFetch();
    },

    /**
     * For name and relate types we store label, model and id so now we format them to create links from them
     * @method formatLinkFieldsOnCollection
     * @param  {Array} serverData records
     * @return {Array} serverData.collection updated to contain links
     */
    formatLinkFieldsOnCollection: function (serverData) {
        var idxOfNameFieldTypes = [];
        _.each(serverData.meta.panel.fields, function fieldsIterator(field, index) {
            if (field.type == "name" || field.type == "fullname" || field.type == "relate" || field.type == "parent") {
                idxOfNameFieldTypes.push(index);
            }
        });
        _.each(serverData.collection, function collectionIterator(row) {
            for (var i = 0; i < idxOfNameFieldTypes.length; i++) {
                var fieldIndex = idxOfNameFieldTypes[i];
                var fieldVal = row["fields"][fieldIndex];
                var module = serverData.meta.panel.fields[fieldIndex].module;
                // eslint-disable-next-line camelcase
                fieldVal.is_link = false;

                if (typeof fieldVal.id == "string" && fieldVal.id.length > 0) {
                    // eslint-disable-next-line camelcase
                    fieldVal.is_link = true;
                    fieldVal.urlToRecord =
                        "<a target='_blank' href='#" + module + "/" + fieldVal.id + "'> " + fieldVal.label + "</a>";
                    // eslint-disable-next-line camelcase

                    if (app.metadata.getModule(module).isBwcEnabled) {
                        // eslint-disable-next-line camelcase
                        fieldVal.bwc_module = true;
                        // eslint-disable-next-line camelcase
                        fieldVal.show_preview = false;
                    } else {
                        // eslint-disable-next-line camelcase
                        fieldVal.show_preview = true;
                    }
                }
            }
        });

        return serverData.collection;
    },

    /**
     * Formats wAttachmentsField types
     * @method formatWattachmentsFieldDisplay
     * @param  {Array} serverData records
     * @return {Array} serverData.collection updated to show this field types correct
     */
    formatWattachmentsFieldDisplay: function (serverData) {
        var wAttachmentsIndexArray = new Array();

        _.each(serverData.meta.panel.fields, function fieldsIterator(field, index) {
            if (field.type == "wAttachmentsField") {
                wAttachmentsIndexArray.push(index);
            }
        });
        _.each(serverData.collection, function collectionIterator(row) {
            for (var i = 0; i < wAttachmentsIndexArray.length; i++) {
                var fieldIndex = wAttachmentsIndexArray[i];
                var fieldVal = row["fields"][fieldIndex];
                var wAttachmentsFieldValue;
                try {
                    wAttachmentsFieldValue = JSON.parse(fieldVal.label);
                } catch (err) {
                    wAttachmentsFieldValue = fieldVal.label;
                }

                if (_.isArray(wAttachmentsFieldValue)) {
                    fieldVal.label = "";

                    _.each(wAttachmentsFieldValue, function attachmentIterator(item) {
                        var wAttId = item.id;
                        var wAttName = item.text;

                        fieldVal.label +=
                            "<a href=\"index.php?entryPoint=wAttachmentsFieldDownload&file_id=" +
                            wAttId +
                            "&file_name=" +
                            wAttName +
                            "\" download rel=\"tooltip\" title=\"" +
                            wAttName +
                            "\"><i class=\"fa fa-file-o\"></i></a>" +
                            "&nbsp;";
                    });
                } else if (_.isString(wAttachmentsFieldValue) && _.isEmpty(wAttachmentsFieldValue)) {
                    fieldVal.label = "<i>" + app.lang.get("LBL_WATTACHMENTS_NO_ATTACHMENTS") + "</i>";
                }
            }
        });
        return serverData.collection;
    },

    togglePreview: function (e) {
        var closePreview = false;

        var clickedIndex = e.currentTarget.dataset.row_index;

        var fieldIndex = parseInt(e.currentTarget.dataset.field_index);
        var module = this.meta.panel.fields[fieldIndex].module;
        if (app.metadata.getModule(module).isBwcEnabled) {
            //we only show a title saying we don't show preview on bwc modules
            return;
        }

        /*
        We need to check agains model id too because we change the collection after save.
        Row number and field number might be the same but models might be changed.
        So if for ex we change row 2, make a save, row 2 comes on row 1 so if we now open the new row 2,
        we need to make sure we're still on the same record. This way we don't close the preview unnecessary
        */
        var row = _.filter(this.serverData.collection, function getClickedRow(row) {
            return row.row_index == clickedIndex;
        });
        var recordIdSelectedRightNow = row[0]["fields"][fieldIndex].id;

        if (
            this.rowIndexInPreview === clickedIndex &&
            this.fieldIndexInPreview === fieldIndex &&
            typeof this.modelUsedInPreview != "undefined" &&
            this.modelUsedInPreview.id === recordIdSelectedRightNow
        ) {
            closePreview = true;
        }

        if (closePreview) {
            app.events.trigger("preview:close");
            this.previewClosed();
            this.decorateIcon(e.currentTarget, false);
        } else {
            this.showPreview(e);
            this.decorateIcon(e.currentTarget, true);
        }
    },

    /**
     * Preview click handler
     * Prepares preview component and triggers event to show it
     * @method showPreview
     * @param  {Event} e click event
     * @return undefined
     */
    showPreview: function (e) {
        var clickedIndex = e.currentTarget.dataset.row_index;
        var row = _.filter(this.serverData.collection, function getClickedRow(row) {
            return row.row_index == clickedIndex;
        });

        var fieldIndex = parseInt(e.currentTarget.dataset.field_index);
        var module = this.meta.panel.fields[fieldIndex].module;
        if (app.metadata.getModule(module).isBwcEnabled) {
            //we only show a title saying we don't show preview on bwc modules
            return;
        }

        var recordId = row[0]["fields"][fieldIndex].id;
        var modelForPreview = App.data.createBean(module, { id: recordId });
        var collectionForPreview;
        this.modelUsedInPreview = modelForPreview;
        this.rowIndexInPreview = clickedIndex;
        this.fieldIndexInPreview = fieldIndex;

        //When preview is opened for a module, sugar will create a collection and add some SugarLogic events on it.
        //So we'll need to make sure we use the same collection for as long as we use the same module
        try {
            var drawerComponent = App.drawer.getActive();
            var previewComponent = drawerComponent
                .getComponent("sidebar")
                .getComponent("preview-pane")
                .getComponent("preview");
            var previewView = previewComponent.getComponent("preview");

            if (previewView.collection && previewView.collection.module === module) {
                collectionForPreview = previewView.collection;
                collectionForPreview.reset();
            }
        } catch (e) {
            //drawer did his job without errors
        }

        if (typeof collectionForPreview === "undefined") {
            collectionForPreview = new App.data.createBeanCollection(module);
            collectionForPreview.on(
                "data:sync:complete",
                function updateList(method) {
                    if (method == "update") {
                        //reload list
                        var drawer = app.drawer.getActive();
                        drawer.updateLists();
                    }
                }.bind(this)
            );
        }
        var fetchModel = true;
        collectionForPreview.add(modelForPreview);

        app.events.trigger("preview:render", modelForPreview, collectionForPreview, fetchModel);
    },

    /**
     * Close Preview click handler
     * @method previewClosed
     * @return undefined
     */
    previewClosed: function () {
        if (this.disposed) {
            return;
        }

        this.modelUsedInPreview = null;
        this.rowIndexInPreview = -1;
        this.fieldIndexInPreview = -1;
    },

    /**
     * Make sure all preview icons show as not clicked
     * @method removeDecorations
     * @return undefined
     */
    removeDecorations: function () {
        this.$el.find("a[data-event=\"list:preview:fire\"]").css("background", "#f6f6f6");
        this.$el.find("a[data-event=\"list:preview:fire\"] > i").css("color", "#555");
    },

    /**
     * Decorate preview icon
     * @method decorateIcon
     * @param  {HTML Element} target            icon to decorate
     * @param  {Boolean} showAsPreviewOpen      show icon as in preview
     * @return undefined
     */
    decorateIcon: function (target, showAsPreviewOpen) {
        this.removeDecorations();

        //hightline the clicked one
        if (showAsPreviewOpen) {
            $(target).css("background", "#555");
            $(target)
                .find("i")
                .css("color", "#f6f6f6 !important");
        }
    },

    /**
     * Resets this.serverData content
     * @method resetServerData
     * @return undefined
     */
    resetServerData: function () {
        this.serverData = {
            dataFetched : false,
            collection  : [],
            next_offset : -1 //eslint-disable-line camelcase
        };
    },

    /**
     * Order By click handler
     * @method setOrderBy
     * @param  {Event} e click column header event
     * @return undefined
     */
    setOrderBy: function (e) {
        var currentTarget = e.currentTarget;
        // eslint-disable-next-line camelcase
        this.model.attributes.next_offset = 0;
        this.resetServerData();

        var direction = this.orderBy.direction;
        var fieldname = this.orderBy.fieldname;
        var tableKey = currentTarget.dataset.table_key;
        if (fieldname == currentTarget.dataset.fieldname) {
            direction = direction === "desc" ? "asc" : "desc";
        } else {
            direction = "desc";
            fieldname = currentTarget.dataset.fieldname;
        }

        this.orderBy = this.model.attributes.orderBy = {
            direction : direction,
            fieldname : fieldname,
            // eslint-disable-next-line
            table_key: tableKey
        };

        this.getSavedReportById(this.context.attributes.model.attributes.settings.attributes.saved_report_id);
    },

    /**
     * Make sure no preview icon in record list is show as active.
     * It's used in list:preview:decorate event so we make sure component is disposed
     * @method removeDecorationsOnReportGroupList
     * @param  {Boolean} decorate
     * @return undefined
     */
    removeDecorationsOnReportGroupList: function (decorate) {
        if (!this.disposed && !decorate) {
            this.removeDecorations();
        }
    }
});