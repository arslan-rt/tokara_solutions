({
    initialize: function (options) {
        this.events = {
            "click button[name=applyFilter]" : "applyFilter",
            "click button[name=resetFilter]" : "resetFilter",
            "change select[name=qualifier]"  : "qualifierChanged"
        };

        this.filtersMeta = []; //helper for processing and UI - includes all dependencies 

        var initRes = this._super("initialize", arguments);

        window["wSavedReportChartFilter" + this.cid] = this;

        var dashletView = this.layout.getComponent("w-saved-reports-chart");
        if (_.isEmpty(dashletView.reportData.attributes) || dashletView.reportData.inSync) {
            this.listenTo(dashletView.reportData, "change:reportDefs", this.setupComponent.bind(this));
        } else {
            this.setupComponent();
        }

        this.listenTo(this.layout.closestComponent("dashboard"), "filter:changed", this.checkFilterNeedsUpdate.bind(this));
        this.listenTo(this.layout.closestComponent("dashboard"), "filter:reset", _.debounce(this.resetAndApplyFilter.bind(this), 500));

        return initRes;
    },

    /**
     * Filter object format {
        reportId            : string,
        tableKey            : string,
        fieldName           : string,
        pathInReportFilters : array,
        qualifier           : string,
        input_name0         : string|array,
        input_name1         : string
    }
     */
    setupComponent: function () {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        //get report filter
        var reportDefFilters;
        try {
            reportDefFilters = JSON.parse(JSON.stringify(dashletView.reportData.attributes.reportDefs.filters_def));
        } catch (e) {
            reportDefFilters = { Filter_1: {} };//eslint-disable-line camelcase
        }

        //get dashlet filter
        var dashletFilters;
        try {
            var reportFiltersCopy = JSON.parse(JSON.stringify(reportDefFilters.Filter_1));

            this._runtimeFilterLeafs = [];
            app.wsystems.wDrillDownReportsChart.getRuntimeFilterLeafsFromFilterDef.apply(this, [reportFiltersCopy]);

            this._runtimeFiltersFormatted = [];
            this.formatRuntimeFilters(this._runtimeFilterLeafs, this._runtimeFiltersFormatted, {});

            if (_.isEmpty(dashletView.customFilter)) {
                dashletFilters = this._runtimeFiltersFormatted;
            } else {
                dashletFilters = JSON.parse(JSON.stringify(dashletView.customFilter));
                this._runtimeFilterLeafs = this.removeFiltersNotAccessibleAnymore(dashletView.customFilter, reportDefFilters.Filter_1);
                this._runtimeFilterLeafs = this.addFiltersAddedOnReportSinceLastReset(this._runtimeFilterLeafs, this._runtimeFiltersFormatted);
                dashletFilters = JSON.parse(JSON.stringify(this._runtimeFilterLeafs));
            }
        } catch (e) {
            dashletFilters = {};
        }

        this.filtersMeta = [];

        this._filterLeafs = dashletFilters;

        this.filtersMeta = [];
        this.buildFieldsMeta();

        this.render();
    },

    formatRuntimeFilters: function (leafs, leafsFormatted, options) {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        _.each(leafs, function (filter) {
            var filterAndContextDetails = _.extend({
                reportId            : dashletView.settings.attributes.saved_report_id,
                tableKey            : filter.table_key,
                fieldName           : filter.name,
                pathInReportFilters : filter.pathInReportFilters,
                qualifier           : filter.qualifier_name,
                input_name0         : filter.input_name0, //eslint-disable-line camelcase
            }, options);

            if (typeof filter.input_name1 != "undefined") {
                filterAndContextDetails.input_name1;//eslint-disable-line camelcase
            }
            leafsFormatted.push(filterAndContextDetails);
        }.bind(this));
    },

    removeFiltersNotAccessibleAnymore: function (patches, reportFilters) {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        patches = _.filter(patches, function (patch) {
            var reportFiltersCopy = JSON.parse(JSON.stringify(reportFilters));
            var patchCopy = JSON.parse(JSON.stringify(patch));
            if (patchCopy.reportId !== dashletView.settings.attributes.saved_report_id) {
                return false;
            }

            var filterExists = true;
            var numberOfNodesInPath = patchCopy.pathInReportFilters.length;
            _.each(patchCopy.pathInReportFilters, function (key, keyIdx) {
                if (keyIdx === numberOfNodesInPath - 1) {
                    filterExists = typeof reportFiltersCopy[key] !== "undefined" && patchCopy.fieldName === reportFiltersCopy[key].name;
                } else {
                    //test current item then go to the next one
                    if (typeof reportFiltersCopy[key] === "undefined") {
                        filterExists = false;
                    } else {
                        reportFiltersCopy = reportFiltersCopy[key];
                    }
                }
            });

            return filterExists;
        });
        return patches;
    },

    addFiltersAddedOnReportSinceLastReset: function (filterLeafs, runtimeFilters) {
        var filterLeafsCopy = JSON.parse(JSON.stringify(filterLeafs));
        var runtimeFiltersCopy = JSON.parse(JSON.stringify(runtimeFilters));

        runtimeFiltersCopy = _.map(runtimeFilters, function (runtimeFilter, idx) {
            var filterSavedInDashlet = _.find(filterLeafsCopy, function searchForFilterSavedInDashlet(filterLeaf) {
                return runtimeFilter.reportId === filterLeaf.reportId
                    && runtimeFilter.fieldName === filterLeaf.fieldName
                    && JSON.stringify(runtimeFilter.pathInReportFilters) === JSON.stringify(filterLeaf.pathInReportFilters);
            });
            if (typeof filterSavedInDashlet === "undefined") {
                return runtimeFilter;
            } else {
                return filterSavedInDashlet;
            }
        });

        return runtimeFiltersCopy;
    },

    /**
     * Prepare filterDefs with some more informations
     * @param {Object} filterDefs 
     */
    prepareFilters: function (filterDefs) {
        filterDefs = JSON.parse(JSON.stringify(filterDefs));

        this._filterLeafs = [];
        this._runtimeFilterLeafs = [];
        app.wsystems.wDrillDownReportsChart.getRuntimeFilterLeafsFromFilterDef.apply(this, [filterDefs]);
        this._filterLeafs = this._runtimeFilterLeafs;
    },

    buildFieldsMeta: function () {
        _.each(this._filterLeafs, function (filter) {
            this._addFilterMeta(filter);
        }.bind(this));
    },

    _addFilterMeta: function (dashletFilter) {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");
        if (typeof dashletView.reportData.attributes.reportDefs !== "undefined") {
            var filterName = dashletView.reportData.attributes.reportDefs.full_table_list[dashletFilter.tableKey].name;

            if (typeof filterName === "undefined") {
                var moduleName = dashletView.reportData.attributes.reportDefs.full_table_list[dashletFilter.tableKey].module;
                filterName = app.lang.getModuleName(moduleName, { plural: true });
            }

            var fieldModule = dashletView.reportData.attributes.reportDefs.full_table_list[dashletFilter.tableKey].module;

            var fieldLabel = app.metadata.getModule(fieldModule).fields[dashletFilter.fieldName].vname;
            filterName += " > " + app.lang.get(fieldLabel, fieldModule);

            var fieldType = app.metadata.getModule(fieldModule).fields[dashletFilter.fieldName].type;

            var qualifiers = app.wsystems.wDrillDownReportsChart.getFieldQualifiers(fieldType);
           
            var filterMeta = {
                tableKey            : dashletFilter.tableKey,
                filterIdx           : dashletFilter.pathInReportFilters,
                filterName          : filterName,
                fieldName           : dashletFilter.fieldName,
                qualifier           : dashletFilter.qualifier,
                qualifiers          : qualifiers,
                input0              : dashletFilter.input_name0,
                input1              : dashletFilter.input_name1 || "",
                fieldType           : fieldType,
                reportId            : dashletView.settings.attributes.saved_report_id,
                pathInReportFilters : dashletFilter.pathInReportFilters
            };

            this.filtersMeta.push(filterMeta);
        }

    },

    render: function () {
        var initRes = this._super("render", arguments);

        this.$el.find("select[name=qualifier]").select2({
            width                   : "170px",
            minimumResultsForSearch : 7,
        });

        for (var index = 0; index < this.filtersMeta.length; index++) {
            this.addFilterInput(index);
        }

        return initRes;
    },

    checkFilterNeedsUpdate: function (filterChanged) {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        //test filter updated is in this dashlet
        if (filterChanged.dashlets.indexOf(dashletView.settings.attributes.dashletId) >= 0) {
            var filtersStillExist = false;
            _.each(filterChanged.filter.fields, function (fieldChanged) {
                var filterMetaIdx = -1;
                var filterMetaToUpdate = _.find(this.filtersMeta, function (filterMeta, idx) {
                    filterMetaIdx = idx;
                    return filterMeta.fieldName === fieldChanged.fieldName
                        && JSON.stringify(filterMeta.pathInReportFilters) === JSON.stringify(fieldChanged.pathInReportFilters);
                });

                //update filters in ui
                if (typeof filterMetaToUpdate !== "undefined") {
                    filtersStillExist = true;

                    this.$(this.$el.find("select[name=qualifier]")[filterMetaIdx]).val(filterChanged.qualifier);
                    this.$(this.$el.find("select[name=qualifier]")[filterMetaIdx]).change();

                    if (filterMetaToUpdate.field0 instanceof app.view.Field) {
                        filterMetaToUpdate.input0 = filterChanged.input_name0;
                        filterMetaToUpdate.field0.model.set(filterMetaToUpdate.fieldName, filterChanged.input_name0);

                        if (
                            (
                                filterMetaToUpdate.qualifier === "is" || filterMetaToUpdate.qualifier === "is_not"
                                || filterMetaToUpdate.qualifier === "one_of" || filterMetaToUpdate.qualifier === "not_one_of"
                            )
                            && (
                                filterMetaToUpdate.fieldType === "name" || filterMetaToUpdate.fieldType === "fullname"
                                || filterMetaToUpdate.fieldType === "id"
                            )
                        ) {
                            filterMetaToUpdate.field0.model.set("id", filterChanged.input_name0);
                            filterMetaToUpdate.field0.model.set("name", filterChanged.input_name1);
                        }

                        if (filterMetaToUpdate.fieldType === "relate") { 
                            filterMetaToUpdate.field0.model.set("id", filterChanged.input_name0);
                            filterMetaToUpdate.field0.model.set("name", filterChanged.input_name1);     
                        } 
                    }

                    if (filterMetaToUpdate.field1 instanceof app.view.Field) {
                        filterMetaToUpdate.input1 = filterChanged.input_name1;
                        filterMetaToUpdate.field1.model.set(filterMetaToUpdate.fieldName, filterChanged.input_name1);
                    }
                }
            }.bind(this));

            //applyFilter
            if (filtersStillExist) {
                this.applyFilter();
            }
        }
    },

    applyFilter: function () {
        var customFilter = this.getFilter();
        customFilter = _.map(customFilter, function (filter) {
            var newFilter = {
                reportId            : filter.reportId,
                pathInReportFilters : filter.pathInReportFilters,
                fieldName           : filter.fieldName,
                name                : filter.name,
                qualifier_name      : filter.qualifier_name, //eslint-disable-line camelcase
                qualifier           : filter.qualifier_name, //eslint-disable-line camelcase
                tableKey            : filter.tableKey,
                input_name0         : filter.input_name0, //eslint-disable-line camelcase
            };
            if (typeof filter.input_name1 !== "undefined") { 
                newFilter.input_name1 = filter.input_name1;//eslint-disable-line camelcase
            }
            return newFilter;
        });
        this.saveFilter(customFilter);
    },

    /**
     * Get current filters (incldues modifications made by user)
     */
    getFilter: function () {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");
        var reportDefs = dashletView.reportData.attributes.reportDefs;

        try {
            _.each(this.filtersMeta, function filterMetaIterator(filterMeta, filterIdx) {
                var filterLeaf = this._filterLeafs[filterIdx];
                var fieldDefinition = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(filterMeta.fieldName, filterMeta.tableKey, reportDefs);

                //set default values
                filterLeaf.qualifier_name = filterMeta.qualifier;//eslint-disable-line camelcase
                filterLeaf.input_name0 = "";//eslint-disable-line camelcase
                filterLeaf.input_name1 = "";//eslint-disable-line camelcase
                //be more specific if possible
                if (filterMeta.qualifier === "empty" || filterMeta.qualifier === "not_empty") {
                    filterLeaf.input_name0 = filterMeta.qualifier;//eslint-disable-line camelcase
                    delete filterLeaf.input_name1;
                } else if (filterMeta.fieldType === "date") {
                    if (
                        filterMeta.qualifier === "tp_next_n_days"
                        || filterMeta.qualifier === "tp_last_n_days"
                    ) {
                        filterLeaf.input_name0 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                    } else {
                        filterLeaf.input_name0 = window.moment(filterMeta.field0.model.attributes[filterMeta.fieldName]).format("YYYY-MM-DD");//eslint-disable-line camelcase
                    }
                    if (
                        filterMeta.field1 instanceof app.view.Field
                        && filterMeta.field1.model instanceof Backbone.Model
                        && filterMeta.field1.model.attributes[filterMeta.fieldName] !== ""
                    ) {
                        filterLeaf.input_name1 = window.moment(filterMeta.field1.model.attributes[filterMeta.fieldName]).format("YYYY-MM-DD");//eslint-disable-line camelcase
                    }
                } else if (filterMeta.fieldType === "datetime" || filterMeta.fieldType === "datetimecombo") {
                    if (
                        filterMeta.qualifier === "tp_next_n_days"
                        || filterMeta.qualifier === "tp_last_n_days"
                    ) {
                        filterLeaf.input_name0 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                    } else {
                        filterLeaf.input_name0 = window.moment(filterMeta.field0.model.attributes[filterMeta.fieldName]).format("YYYY-MM-DD hh:mm:ss");//eslint-disable-line camelcase
                    }
                    if (
                        filterMeta.field1 instanceof app.view.Field
                        && filterMeta.field1.model instanceof Backbone.Model
                        && filterMeta.field1.model.attributes[filterMeta.fieldName] !== ""
                    ) {
                        filterLeaf.input_name1 = window.moment(filterMeta.field1.model.attributes[filterMeta.fieldName]).format("YYYY-MM-DD hh:mm:ss");//eslint-disable-line camelcase
                    }
                } else if (filterMeta.fieldType === "relate") {
                    var idName = fieldDefinition.id_name;
                    filterLeaf.input_name0 = filterMeta.field0.model.attributes[idName];//eslint-disable-line camelcase

                    filterLeaf.input_name1 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                } else if (
                    (filterMeta.fieldType === "id" || filterMeta.fieldType === "name" || filterMeta.fieldType === "fullname")
                    && (filterMeta.qualifier === "is" || filterMeta.qualifier === "is_not"
                    || filterMeta.qualifier === "one_of" || filterMeta.qualifier === "not_one_of")
                ) {
                    filterLeaf.input_name0 = filterMeta.field0.model.attributes["id"];//eslint-disable-line camelcase
                    filterLeaf.input_name1 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                } else if (filterMeta.fieldType === "enum") {
                    filterLeaf.input_name0 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                    if (Array.isArray(filterLeaf.input_name0) === false) {
                        filterLeaf.input_name0 = [filterLeaf.input_name0];//eslint-disable-line camelcase
                    }
                    delete filterLeaf.input_name1;
                } else {
                    if (filterMeta.field0.model instanceof Backbone.Model) {
                        filterLeaf.input_name0 = filterMeta.field0.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                    }
                    if (
                        filterMeta.field1 instanceof app.view.Field
                        && filterMeta.field1.model instanceof Backbone.Model
                    ) {
                        filterLeaf.input_name1 = filterMeta.field1.model.attributes[filterMeta.fieldName];//eslint-disable-line camelcase
                    }
                }
            }.bind(this));
        } catch (e) {
            app.logger.fatal("Could not get filter. Error: " + e);
        }
        return this._filterLeafs;
    },

    /**
     * Saves dashlet metadata and this triggers a chart reload
     * @param {*} customFilter 
     */
    saveFilter: function (customFilter) {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        if (typeof dashletView.settings.get("dashletId") === "undefined") {
            app.alert.show("error-save-custom-filter", {
                level     : "warning",
                messages  : "Please edit the dashlet and Save it again before apply a filter",
                autoClose : true
            });
            return;
        }

        app.alert.show("loading-save-custom-filter", {
            level     : "process",
            autoClose : false
        });

        _.each(customFilter, function addReportIdOnPatch(filter) {
            filter.reportId = dashletView.settings.get("saved_report_id");
        });

        app.api.call("create", app.api.buildURL("wDrillDown/dashletFilter/setDashletFilter"), {
            dashletId    : dashletView.settings.get("dashletId"),
            reportId     : dashletView.settings.get("saved_report_id"),
            customFilter : customFilter,
        }, {
            success: function successSaveCustomFilter() {
                // app.alert.show("success-save-custom-filter", {
                //     level     : "success",
                //     messages  : "Filter updated!",
                //     autoClose : true
                // }); 

                //force a refresh of the dashlet
                _.defer(function deferLayoutApply() {
                    this.layout.trigger("applyFilterOnChart");
                }.bind(this));
            }.bind(this),
            error: function () {
                app.alert.show("error-save-custom-filter", {
                    level     : "error",
                    messages  : "Filter did not update. Please edit the dashlet and Save it again",
                    autoClose : true
                });
            },
            complete: function () {
                app.alert.dismiss("loading-save-custom-filter");
            }
        }, {
            skipMetadataHash: true
        });
    },

    resetFilter: function () {
        var dashletView = this.layout.getComponent("w-saved-reports-chart");

        var reportDefFilters = dashletView.reportData.attributes.reportDefs.filters_def;
        var reportFiltersCopy = JSON.parse(JSON.stringify(reportDefFilters.Filter_1));

        this.filtersMeta = [];

        this.fields = {};

        this.prepareFilters(reportFiltersCopy);

        this.filtersMeta = [];
        this.buildFieldsMeta();

        this.render();
    },

    resetAndApplyFilter: function () {
        this.resetFilter();
        this.applyFilter();
    },

    /**
     * Filter type or Qualifier has changed
     * @param {*} e 
     */
    qualifierChanged: function (e) {
        var index = $(e.currentTarget).parent().parent().index();

        var filterLeaf = this._runtimeFilterLeafs[index];
        filterLeaf.qualifier_name = $(e.currentTarget).val();//eslint-disable-line camelcase
        filterLeaf.input_name0 = $(e.currentTarget).val();//eslint-disable-line camelcase

        this.filtersMeta[index].qualifier = $(e.currentTarget).val();
        this.filtersMeta[index].input0 = $(e.currentTarget).val();
        this.filtersMeta[index].input1 = "";

        this.refreshFilterInput(index);
    },

    refreshFilterInput: function (index) {
        $(this.$el.find(".input0")[index]).html("");
        $(this.$el.find(".input1")[index]).html("");
        $(this.$el.find(".input1")[index]).addClass("hide");

        //remove previous field components
        var filtersMeta = this.filtersMeta[index];
        var fieldKeys, i;

        if (filtersMeta.field0 instanceof app.view.Field) {
            fieldKeys = _.keys(this.fields);
            for (i = 0; i < fieldKeys.length; i++) {
                if (this.fields[fieldKeys[i]].cid === filtersMeta.field0.cid) {
                    this.fields[fieldKeys[i]].remove();
                    delete this.fields[fieldKeys[i]];
                }
            }
            delete filtersMeta.field0;
        }
        if (filtersMeta.field1 instanceof app.view.Field) {
            fieldKeys = _.keys(this.fields);
            for (i = 0; i < fieldKeys.length; i++) {
                if (this.fields[fieldKeys[i]].cid === filtersMeta.field1.cid) {
                    this.fields[fieldKeys[i]].remove();
                    delete this.fields[fieldKeys[i]];
                }
            }
            delete filtersMeta.field1;
        }

        this.addFilterInput(index);
    },

    /**
     * Creates one or two inputs for a filter (field + qualifier)
     * @param {number} index 
     */
    addFilterInput: function (index) {
        var filterRow = this.filtersMeta[index];

        var dashletView = this.layout.getComponent("w-saved-reports-chart");
        var reportDefs = dashletView.reportData.attributes.reportDefs;

        var qualifierName = filterRow.qualifier;
        var tableKey = filterRow.tableKey;

        if (typeof (qualifierName) == "undefined" || qualifierName == "") {
            if (fieldDefinition.type === "name" || fieldDefinition.type === "id" || fieldDefinition === "fullName") { 
                qualifierName = "is";
            } else {
                qualifierName = "equals";
            }
        }

        var fieldName = filterRow.fieldName;

        var fieldModule = reportDefs.full_table_list[tableKey].module;

        var fieldDefinition = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(fieldName, tableKey, reportDefs);

        var fieldType = fieldDefinition.type;
        if (typeof (fieldDefinition.custom_type) != "undefined") {
            fieldType = fieldDefinition.custom_type;
        }

        if (qualifierName == "between") {
            this.addFilterInputTextBetween(index, fieldDefinition);
        } else if (qualifierName == "between_dates") {
            this.addFilterInputDateBetween(index, fieldDefinition);
        } else if (qualifierName == "between_datetimes") {
            this.addFilterInputDatetimesBetween(index, fieldDefinition);
        } else if (qualifierName.indexOf("_n_days") != -1) {
            this.addFilterInputText(index, fieldDefinition);
        } else if (qualifierName == "empty" || qualifierName == "not_empty") {
            this.addFilterNoInput(index, fieldDefinition);
        } else if (fieldType == "date" || fieldType == "datetime") {
            if (qualifierName.indexOf("tp_") === 0) {
                this.addFilterInputEmpty(index, fieldDefinition);
            } else {
                this.addFilterInputDate(index, fieldDefinition);
            }
        } else if (fieldType == "datetimecombo") {
            if (qualifierName.indexOf("tp_") === 0) {
                this.addFilterInputEmpty(index, fieldDefinition);
            } else {
                this.addFilterInputDatetimecombo(index, fieldDefinition);
            }
        } else if (fieldType == "id" || fieldType == "name" || fieldType == "fullname") {
            var fieldDefinitionCustomized; 
            if (qualifierName == "is" || qualifierName == "is_not") {
                fieldDefinitionCustomized = {
                    custom_module : "Accounts", //eslint-disable-line camelcase
                    ext2          : fieldModule,
                    id_name       : "id", //eslint-disable-line camelcase
                    module        : fieldModule,
                    name          : fieldDefinition.name,
                    quicksearch   : "enabled",
                    required      : false,
                    source        : "non-db",
                    type          : "relate"
                };

                this.addFilterInputRelate(index, fieldDefinitionCustomized);
            } else if (qualifierName == "one_of" || qualifierName == "not_one_of") { 
                fieldDefinitionCustomized = {
                    custom_module : "Accounts", //eslint-disable-line camelcase
                    ext2          : fieldModule,
                    id_name       : "id", //eslint-disable-line camelcase
                    module        : fieldModule,
                    name          : fieldDefinition.name,
                    quicksearch   : "enabled",
                    required      : false,
                    source        : "non-db",
                    type          : "relate",
                    isMultiSelect : true,
                };

                this.addFilterInputMultiRelate(index, fieldDefinitionCustomized);
            } else {
                this.addFilterInputText(index, fieldDefinition);
            }
        } else if (fieldType == "relate") {
            if (qualifierName == "is" || qualifierName == "is_not") {
                this.addFilterInputRelate(index, fieldDefinition);
            } else {
                this.addFilterInputText(index, fieldDefinition);
            }
        } else if (fieldType == "username" || fieldType == "assigned_user_name") {
            var usersArray = {};
            usersArray["Current User"] = "Current User";
            var users = app.wsystems.wDrillDownReportsChart.users || [];
            _.each(users, function iterateUsers(user) {
                usersArray[user.id] = user.name;
            });

            if (qualifierName == "one_of" || qualifierName == "not_one_of") {
                this.addFilterInputSelectMultiple(usersArray, index, fieldDefinition);
            } else {
                this.addFilterInputSelectSingle(usersArray, index, fieldDefinition);
            }
        } else if (fieldType == "enum" || fieldType == "multienum" || fieldType == "parent_type" || fieldType == "timeperiod" || fieldType == "currency_id") {
            fieldDefinition.module = fieldModule;//enum needs module to fetch for options sometimes
            
            var fieldOptions = fieldDefinition.options;
            if (qualifierName == "one_of" || qualifierName == "not_one_of") {
                this.addFilterInputSelectMultiple(fieldOptions, index, fieldDefinition);
            } else {
                this.addFilterInputSelectSingle(fieldOptions, index, fieldDefinition);
            }
        } else if (fieldType == "bool") {
            var options = ["No", "Yes"];
            this.addFilterInputSelectSingle(options, index, fieldDefinition);
        } else {
            this.addFilterInputText(index, fieldDefinition);
        }
    },

    addFilterInputTextBetween: function(index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model0 = new Backbone.Model();
        model0.set(fieldName, filterMeta.input0);

        var field0 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model0,
            module   : fieldModule
        });
        field0.render();

        this.filtersMeta[index].field0 = field0;

        $(this.$el.find(".input0")[index]).html(field0.$el);

        $(this.$el.find(".input1")[index]).removeClass("hide");

        var model1 = new Backbone.Model();
        model1.set(fieldName, filterMeta.input1);

        var field1 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model1,
            module   : fieldModule
        });
        field1.render();

        this.filtersMeta[index].field1 = field1;

        $(this.$el.find(".input1")[index]).html(field1.$el);
    },

    /**
       * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
       * @param {*} index 
       * @param {*} fieldDefinition 
     */
    addFilterInputDateBetween: function(index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model0 = new Backbone.Model();
        model0.set(fieldName, filterMeta.input0 || new Date());

        var field0 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name : fieldName,
                type : "date",
            },
            context : this.context,
            model   : model0,
            module  : fieldModule
        });
        field0.render();

        this.filtersMeta[index].field0 = field0;

        $(this.$el.find(".input0")[index]).html(field0.$el);

        $(this.$el.find(".input1")[index]).removeClass("hide");

        var model1 = new Backbone.Model();
        model1.set(fieldName, filterMeta.input1 || new Date());

        var field1 = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name : fieldName,
                type : "date",
            },
            context : this.context,
            model   : model1,
            module  : fieldModule
        });
        field1.render();

        this.filtersMeta[index].field1 = field1;

        $(this.$el.find(".input1")[index]).html(field1.$el);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} index 
     * @param {*} fieldDefinition 
     */
    addFilterInputDatetimesBetween: function(index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);

        $(this.$el.find(".input1")[index]).removeClass("hide");

        model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);
        field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.filtersMeta[index].field1 = field;

        $(this.$el.find(".input1")[index]).html(field.$el);
    },

    addFilterNoInput: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set("text_input", filterMeta.qualifier);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                dbType : "varchar",
                len    : 150,
                name   : "text_input",
                type   : "varchar",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        field.$el.hide();

        this.filtersMeta[index].field0 = field;
        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputEmpty: function (index, fieldDefinition) {
        this.addFilterNoInput(index, fieldDefinition);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} index 
     * @param {*} fieldDefinition 
     */
    addFilterInputDate: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "date",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    /**
     * The new field needs to be hardcoded to Date - that's how base Reports module work with it 
     * @param {*} index 
     * @param {*} fieldDefinition 
     */
    addFilterInputDatetimecombo: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0 || new Date());

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : "date_range_search_dom",
                type    : "datetimecombo",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputRelate: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var predefinedValues = {};
        if (filterMeta.input0 === "is" || filterMeta.input0 === "is_not") {
            predefinedValues[fieldDefinition.id_name] = "";
        } else {
            predefinedValues[fieldDefinition.id_name] = filterMeta.input0;
        }
        predefinedValues[fieldDefinition.name] = filterMeta.input1;

        var fieldModule = fieldDefinition.ext2;

        var model = new Backbone.Model();
        model.set(predefinedValues);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model,
            module   : fieldModule
        });
        field.render();
        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputMultiRelate: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var predefinedValues = {};
        if (filterMeta.input0 === "one_of" || filterMeta.input0 === "not_one_of") {
            predefinedValues[fieldDefinition.id_name] = "";
        } else {
            predefinedValues[fieldDefinition.id_name] = filterMeta.input0;
        }
        predefinedValues[fieldDefinition.name] = filterMeta.input1;

        var fieldModule = fieldDefinition.ext2;

        var model = new Backbone.Model();
        model.set(predefinedValues);

        var createOptions = {
            view     : this,
            viewName : "edit",
            def      : fieldDefinition,
            context  : this.context,
            model    : model,
            module   : fieldModule
        };
        
        if (_.isUndefined(fieldModule) === false && _.isEmpty(fieldModule) === false) {
            createOptions.module = fieldModule;
        }

        var field = app.view.createField(createOptions);
        field.render();
        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputText: function (index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();

        if (
            filterMeta.input0 === "equals"
            || filterMeta.input0 === "not_equals_str"
            || filterMeta.input0 === "contains"
            || filterMeta.input0 === "does_not_contain"
            || filterMeta.input0 === "starts_with"
            || filterMeta.input0 === "ends_with"
            || filterMeta.input0 === "tp_next_n_days"
            || filterMeta.input0 === "tp_last_n_days"
        ) {
            model.set(fieldName, "");//put an empty input when operator changed
        } else {
            model.set(fieldName, filterMeta.input0);
        }

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                dbType : "varchar",
                len    : 150,
                name   : fieldName,
                type   : "varchar",
            },
            context : this.context,
            model   : model,
            module  : fieldModule,
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputSelectMultiple: function (options, index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var model = new Backbone.Model();
        model.set(fieldName, filterMeta.input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name          : fieldName,
                options       : options,
                type          : "enum",
                isMultiSelect : true,
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },

    addFilterInputSelectSingle: function (options, index, fieldDefinition) {
        var filterMeta = this.filtersMeta[index];
        var fieldName = filterMeta.fieldName;
        var fieldModule = fieldDefinition.module;
        if (_.isEmpty(fieldModule) && _.isString(fieldDefinition.custom_module)) {
            fieldModule = fieldDefinition.custom_module;
        }

        var input0 = filterMeta.input0;
        if (Array.isArray(input0) && input0.length === 1) {
            input0 = input0[0];
        }
        if (input0 === "Yes" || input0 === "yes") {
            input0 = 1;
        } else if (input0 === "No" || input0 === "no") {
            input0 = 0;
        }

        var model = new Backbone.Model();
        model.set(fieldName, input0);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name    : fieldName,
                options : options,
                type    : "enum",
            },
            context : this.context,
            model   : model,
            module  : fieldModule
        });
        field.render();

        this.filtersMeta[index].field0 = field;

        $(this.$el.find(".input0")[index]).html(field.$el);
    },
}); 