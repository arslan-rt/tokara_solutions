/**
 * View used to set global configs for charts
 *
 * @class drilldown-settings
 */
({
    events: {
        "click button[name=\"save\"]"   : "saveSettings",
        "click button[name=\"cancel\"]" : "goToHomePage",
        "click input[name=\"add_new\"]" : "addNewPair",
        "click input[name=\"remove\"]"  : "removePair"
    },

    /**
     * Default initialization and loading of current settings
     * @method initialize
     * @param  {Object} options
     * @return {Parent} Parent component -> 'initialize' call response
     */
    initialize: function(options) {
        var initCallRes = this._super("initialize", arguments);
        this.loadCurrentSettings();

        return initCallRes;
    },

    /**
     * Populates DOM with current settings
     * @method loadCurrentSettings
     * @return undefined
     */
    loadCurrentSettings: function () {
        try {
            this.predefinedColorsSettings = JSON.parse(App.lang.get("predefinedColors", "Home"));
            _.each(this.predefinedColorsSettings, function updateColors(colorSettings) {
                if (colorSettings.text === "") {
                    colorSettings.text = "Undefined";
                }
            });
        } catch (exception) {
            this.predefinedColorsSettings = [];
        }

        this.render();
    },

    /**
     * Call Save Settings API
     * @method saveSettings
     * @return undefined
     */
    saveSettings: function () {
        var settings = this.getCurrentSettings();
        app.api.call(
            "update",
            "rest/v10/saveDrilldownSettings",
            { data: settings },
            {
                success: function saveDrilldownSettingsSuccess(saved) {
                    if (saved == "success") {
                        window.top.location.reload();
                        app.alert.show("save-succes", {
                            level     : "success",
                            messages  : app.lang.get("LBL_SAVED"),
                            autoClose : true
                        });
                    } else if (saved == "qrr") {
                        window.location = "#bwc/index.php?module=Administration&action=index";
                        app.alert.show("save-succes-qrr", {
                            level          : "success",
                            messages       : app.lang.get("LBL_WCHART_SETTINGS_SAVED_QRR"),
                            autoClose      : true,
                            autoCloseDelay : "10000"
                        });
                    } else {
                        //error
                        app.alert.show("save-problem", {
                            level          : "warning",
                            messages       : "LBL_WCHART_SETTINGS_SAVE_ERROR",
                            autoClose      : true,
                            autoCloseDelay : "10000"
                        });
                    }
                }.bind(this),
                error: function(error) {
                    //probably immediately after a qrr
                    app.alert.show("save-problem", {
                        level          : "error",
                        messages       : error.message,
                        autoClose      : true,
                        autoCloseDelay : "10000"
                    });
                }
            }
        );
    },

    /**
     * Gets settings from DOM in order to be saved in db
     * @method getCurrentSettings
     * @return Object
     */
    getCurrentSettings: function () {
        var result = {},
                text,
                color,
                predefinedColors = [];
        var texts = this.$el.find("input[name=\"chart_text\"]");
        var colors = this.$el.find("input[name=\"chart_color\"]");
        var numberOfPairs = texts.length;
        for (var i = 0; i < numberOfPairs; i++) {
            text = $(texts[i]).val();
            color = $(colors[i]).val();
            if (text === "Undefined") {
                text = "";
            }
            if (color != "") {
                predefinedColors.push({
                    text  : text,
                    color : color
                });
            }
        }
        result.predefinedColors = predefinedColors;

        return result;
    },

    /**
     * Add a new color pair element on DOM
     * @method addNewPair
     * @return undefined
     */
    addNewPair: function () {
        var newPairTemplate = app.template.getView("drilldown-settings.predefined-chart-pair");
        var newPair = newPairTemplate({
            text  : "",
            color : "#FFFFFF"
        });

        var $newPair = $(newPair);
        $newPair.appendTo("#predefined_colors_list");
        $newPair.find(".color").colorpicker();
    },

    /**
     * Remove color pair
     * @method removePair
     * @param  {Event} e Click event
     * @return undefined
     */
    removePair: function(e) {
        e.target.parentNode.remove();
    },

    /**
     * Render
     * @method render
     * @return {Parent} Parent component -> 'render' call response
     */
    render: function() {
        var renderCallRes = this._super("render", arguments);

        this.$el.find(".color").colorpicker();

        return renderCallRes;
    },

    /**
     * Redirect to Administration page
     * @method goToHomePage
     * @return undefined
     */
    goToHomePage: function() {
        window.location = "#bwc/index.php?module=Administration&action=index";
    }
});
