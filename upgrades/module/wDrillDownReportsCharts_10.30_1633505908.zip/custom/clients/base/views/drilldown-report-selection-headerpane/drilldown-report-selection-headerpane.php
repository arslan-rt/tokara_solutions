<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$viewdefs['base']['view']['drilldown-report-selection-headerpane'] = array(
    'fields'  => array(
        array(
            'name' => 'drilldown-header-title',
            'type' => 'drilldown-header-title',
        ),
    ),
    'buttons' => array(
        array(
            'name'   => 'list_toggle',
            'type'   => 'button',
            'label'  => 'LBL_WCHART_TOGGLE_LIST',
            'events' => array(
                'click' => 'selection:togglelist:fire',
            ),
        ),
        array(
            'name'      => 'close',
            'type'      => 'button',
            'label'     => 'LBL_CANCEL_BUTTON_LABEL',
            'events'    => array(
                'click' => 'selection:closedrawer:fire',
            ),
            'css_class' => 'btn-invisible btn-link',
        ),
        array(
            'name' => 'sidebar_toggle',
            'type' => 'sidebartoggle',
        ),
    ),
);
