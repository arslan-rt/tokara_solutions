/**
 * Headerpane for records list
 *
 * @class drilldown-report-selection-headerpane
 */
({
    extendsFrom: "SelectionHeaderpaneView",

    /**
     * Initialize component and sets title
     * @method initialize
     * @param {Object} options
     * @return {Parent} Parent component -> 'initialize' call response
     */

    drawerListDisplayState: "report-group-list", //default view

    initialize: function(options) {
        var initCallRes = this._super("initialize", arguments);

        if (options.context.attributes.model.attributes.settings.attributes.defaultListShown) {
            this.drawerListDisplayState = options.context.attributes.model.attributes.settings.attributes.defaultListShown;
        }

        this.layout.on("selection:togglelist:fire", this.toggleList, this);
        return initCallRes;
    },

    toggleList: function() {
        //When toggle the list view, we need to close the preview panel (if opened)
        app.events.trigger("preview:close");

        if (this.drawerListDisplayState == "report-group-list") {
            this.drawerListDisplayState = "report-base-list";
        } else {
            this.drawerListDisplayState = "report-group-list";
        }

        this.context.trigger("update:drilldown:header");

        if (this.layout.getComponent("drilldown-report-group-list").$el.is(":visible")) {
            this.layout.getComponent("drilldown-report-group-list").hide();

            //trick to make sure default hide class does not make problems
            this.layout.getComponent("drilldown-report-base-list").hide();
            this.layout.getComponent("drilldown-report-base-list").show();

            this.context.trigger("drawer:refreshRecordsList");
        } else {
            this.layout.getComponent("drilldown-report-group-list").show();
            this.layout.getComponent("drilldown-report-base-list").hide();

            this.context.trigger("drawer:refreshReportList");
        }
    },

    adjustHeaderpaneFields: function() {
        return;
    }
});