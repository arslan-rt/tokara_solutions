<?php

$viewdefs['base']['view']['w-saved-reports-chart'] = array(
    'dashlets' => array(
        array(
            'label'          => 'LBL_WCHART_DASHLET',
            'description'    => 'LBL_WCHART_DASHLET_SAVED_REPORTS_CHART_DESC',
            'config'         => array(

            ),
            'preview' => array(

            ),
        ),
    ),
    'custom_toolbar' => array(
        'buttons' => array(
            array(
                "type"      => "dashletaction",
                "css_class" => "btn btn-invisible hidden",
                "icon"      => "fa-filter",
                "action"    => "toggleRuntimeFilters",
                "tooltip"   => "LBL_WCHART_CONFIG_TOOLBAR_TOGGLE_RUNTIME_FILTERS",
            ),
            array(
                "type"      => "dashletaction",
                "css_class" => "btn btn-invisible hidden",
                "icon"      => "fa-bar-chart-o",
                "action"    => "goToReport",
                'tooltip'   => 'LBL_WCHART_DASHLET_DRILLDOWN_TOOLTIP',
            ),
            array(
                "type"      => "dashletaction",
                "css_class" => "btn btn-invisible hidden",
                "icon"      => "fa-file-image-o",
                "action"    => "copyAsImage",
                'tooltip'   => 'LBL_WCHART_DASHLET_COPY_IMAGE',
            ),

            array(
                "type"      => "dashletaction",
                "css_class" => "btn btn-invisible hidden",
                "icon"      => "fa-download",
                "action"    => "downloadAsImage",
                'tooltip'   => 'LBL_WCHART_DASHLET_DOWNLOAD_IMAGE',
            ),

            array(
                "type"      => "dashletaction",
                "css_class" => "dashlet-toggle btn btn-invisible minify",
                "icon"      => "fa-chevron-up",
                "action"    => "toggleMinify",
                "tooltip"   => "LBL_DASHLET_TOGGLE",
            ),

            array(
                'dropdown_buttons' => array(
                    array(
                        'type'   => 'dashletaction',
                        'action' => 'editClicked',
                        'label'  => 'LBL_DASHLET_CONFIG_EDIT_LABEL',
                    ),
                    array(
                        'type'   => 'dashletaction',
                        'action' => 'refreshClicked',
                        'label'  => 'LBL_DASHLET_REFRESH_LABEL',
                    ),
                    array(
                        'type'   => 'dashletaction',
                        'action' => 'removeClicked',
                        'label'  => 'LBL_DASHLET_REMOVE_LABEL',
                    ),
                ),
            ),
        ),
    ),

    'panels' => array(
        array(
            'name'         => 'panel_body',
            'columns'      => 2,
            'labelsOnTop'  => true,
            'placeholders' => true,
            'fields'       => array(
                array(
                    'name'    => 'saved_report',
                    'label'   => 'LBL_REPORT_SELECT',
                    'type'    => 'relate',
                    'id_name' => 'saved_report_id',
                    'module'  => 'Reports',
                    'rname'   => 'name',
                ),
                array(
                    'name'    => 'auto_refresh',
                    'label'   => 'LBL_REPORT_AUTO_REFRESH',
                    'type'    => 'enum',
                    'options' => 'drilldown_auto_refresh_options',
                ),
                array(
                    'name'               => 'chart_type',
                    'label'              => 'LBL_WCHART_CONFIG_CHART_TYPE',
                    'type'               => 'enum',
                    'sort_alpha'         => true,
                    'ordered'            => true,
                    'required'           => true,
                    'searchBarThreshold' => -1,
                    'options'            => "drilldown_charts_options",
                ),

                array(
                ),

                array(
                    'name'    => 'show_title',
                    'label'   => 'LBL_WCHART_CONFIG_SHOW_TOTAL',
                    'type'    => 'bool',
                    'default' => 0,
                ),

                array(
                    'name'    => 'show_legend',
                    'label'   => 'LBL_WCHART_SHOW_LEGEND',
                    'type'    => 'bool',
                    'default' => 1,
                ),

                array(
                    'name'              => 'x_label_options',
                    'type'              => 'fieldset',
                    'inline'            => true,
                    'show_child_labels' => false,
                    'label'             => 'Show x-axis label',
                    'toggle'            => 'show_x_label',
                    'dependent'         => 'x_axis_label',
                    'fields'            => array(
                        array(
                            'name'    => 'show_x_label',
                            'type'    => 'bool',
                            'default' => 0,
                        ),
                        array(
                            'name' => 'x_axis_label',
                        ),
                    ),
                ),

                array(
                    'name'              => 'tickDisplayMethods',
                    'type'              => 'fieldset',
                    'inline'            => true,
                    'show_child_labels' => true,
                    'label'             => 'LBL_CHART_CONFIG_TICK_DISPLAY',
                    'css_class'         => 'fieldset-wrap',
                    'fields'            => array(
                        array(
                            'name'    => 'wrapTicks',
                            'text'    => 'LBL_CHART_CONFIG_TICK_WRAP',
                            'type'    => 'bool',
                            'default' => true,
                        ),
                        array(
                            'name'    => 'staggerTicks',
                            'text'    => 'LBL_CHART_CONFIG_TICK_STAGGER',
                            'type'    => 'bool',
                            'default' => true,
                        ),
                        array(
                            'name'    => 'rotateTicks',
                            'text'    => 'LBL_CHART_CONFIG_TICK_ROTATE',
                            'type'    => 'bool',
                            'default' => true,
                        ),
                    ),
                ),

                array(
                    'name'              => 'y_label_options',
                    'type'              => 'fieldset',
                    'inline'            => true,
                    'show_child_labels' => false,
                    'label'             => 'Show y-axis label',
                    'toggle'            => 'show_y_label',
                    'dependent'         => 'y_axis_label',
                    'fields'            => array(
                        array(
                            'name'    => 'show_y_label',
                            'type'    => 'bool',
                            'default' => 0,
                        ),
                        array(
                            'name' => 'y_axis_label',
                        ),
                    ),
                ),

                array(
                    'name'              => 'toolbarButtons',
                    'type'              => 'fieldset',
                    'inline'            => true,
                    'show_child_labels' => true,
                    'label'             => 'LBL_WCHART_CONFIG_TOOLBAR',
                    'css_class'         => 'fieldset-wrap',
                    'fields'            => array(
                        array(
                            'name'    => 'show_drilldown_button',
                            'text'    => 'LBL_WCHART_CONFIG_TOOLBAR_DRILLDOWN',
                            'type'    => 'bool',
                            'default' => false,
                        ),
                        array(
                            'name'    => 'show_copy_clipboard_button',
                            'text'    => 'LBL_WCHART_CONFIG_TOOLBAR_COPY_TO_CLIPBOARD',
                            'type'    => 'bool',
                            'default' => false,
                        ),
                        array(
                            'name'    => 'show_download_image_button',
                            'text'    => 'LBL_WCHART_CONFIG_TOOLBAR_DOWNLOAD_IMAGE',
                            'type'    => 'bool',
                            'default' => false,
                        ),
                        array(
                            'name'    => 'toggle_runtime_filters',
                            'text'    => 'LBL_WCHART_CONFIG_TOOLBAR_TOGGLE_RUNTIME_FILTERS',
                            'type'    => 'bool',
                            'default' => false,
                        ),
                    ),
                ),

                array(
                    'name'    => 'showValues',
                    'label'   => 'LBL_CHART_CONFIG_VALUE_PLACEMENT',
                    'type'    => 'enum',
                    'default' => false,
                    'options' => array(
                        "0"      => translate('LBL_WCHART_DASHLET_SHOW_VALUE_NONE'),
                        "1"      => translate('LBL_WCHART_DASHLET_SHOW_VALUE_DEFAULT'),
                        "start"  => translate('LBL_WCHART_DASHLET_SHOW_VALUE_START'),
                        "middle" => translate('LBL_WCHART_DASHLET_SHOW_VALUE_MIDDLE'),
                        "end"    => translate('LBL_WCHART_DASHLET_SHOW_VALUE_END'),
                        "top"    => translate('LBL_WCHART_DASHLET_SHOW_VALUE_TOP'),
                        "total"  => translate('LBL_WCHART_DASHLET_SHOW_VALUE_TOTAL'),
                    ),
                ),

                array(
                    'name'              => 'groupDisplayOptions',
                    'type'              => 'fieldset',
                    'inline'            => true,
                    'show_child_labels' => false,
                    'label'             => 'LBL_CHART_CONFIG_BAR_CHART_OPTIONS',
                    'css_class'         => 'fieldset-wrap',
                    'fields'            => array(

                        // array(
                        //     'name'    => 'allowScroll',
                        //     'text'    => 'LBL_CHART_CONFIG_ALLOW_SCROLLING',
                        //     'type'    => 'bool',
                        //     'default' => 1,
                        // ),

                        array(
                            'name'    => 'stacked',
                            'text'    => 'LBL_CHART_CONFIG_STACK_DATA',
                            'type'    => 'bool',
                            'default' => 1,
                        ),
                        array(
                            'name'    => 'hideEmptyGroups',
                            'text'    => 'LBL_CHART_CONFIG_HIDE_EMPTY_GROUPS',
                            'type'    => 'bool',
                            'default' => 1,
                        ),
                    ),
                ),

                array(
                    'name'    => 'defaultListShown',
                    'type'    => 'enum',
                    'label'   => 'LBL_WCHART_CONFIG_DEFAULT_LIST',
                    'options' => array(
                        'report-group-list' => translate("LBL_WCHART_LIST_REPORT_CONTENT"),
                        'report-base-list'  => translate("LBL_WCHART_LIST_RECORDS"),
                    ),
                ),

                array(
                    'name'              => 'group1Sort',
                    'type'              => 'radio-group',
                    'inline'            => true,
                    'show_child_labels' => false,
                    'label'             => 'LBL_WCHART_CONFIG_SORT1_CHART',
                    'css_class'         => 'fieldset-wrap',
                    'groups'            => array(
                        array(
                            'value' => 'default',
                            'label' => 'LBL_WCHART_CONFIG_SORT_DEFAULT',
                        ),
                        array(
                            'value' => 'asc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_GROUP_ASC',
                        ),
                        array(
                            'value' => 'desc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_GROUP_DESC',
                        ),
                        array(
                            'value' => 'value-asc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_VALUE_ASC',
                        ),
                        array(
                            'value' => 'value-desc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_VALUE_DESC',
                        ),
                    ),
                ),

                array(),

                array(
                    'name'              => 'group2Sort',
                    'type'              => 'radio-group',
                    'inline'            => true,
                    'show_child_labels' => false,
                    'label'             => 'LBL_WCHART_CONFIG_SORT2_CHART',
                    'css_class'         => 'fieldset-wrap',
                    'groups'            => array(
                        array(
                            'value' => 'default',
                            'label' => 'LBL_WCHART_CONFIG_SORT_DEFAULT',
                        ),
                        array(
                            'value' => 'asc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_GROUP_ASC',
                        ),
                        array(
                            'value' => 'desc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_GROUP_DESC',
                        ),
                        array(
                            'value' => 'value-asc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_VALUE_ASC',
                        ),
                        array(
                            'value' => 'value-desc',
                            'label' => 'LBL_WCHART_CONFIG_SORT_VALUE_DESC',
                        ),
                    ),
                ),

                array(
                    'name'  => 'intelligent',
                    'label' => 'LBL_DASHLET_CONFIGURE_INTELLIGENT',
                    'type'  => 'bool',
                ),
                array(
                    'name'     => 'link',
                    'label'    => 'LBL_DASHLET_CONFIGURE_LINKED',
                    'type'     => 'enum',
                    'options'  => array(),
                    'required' => true,
                ),

                array(
                    'name'    => 'approximate_total',
                    'label'   => 'LBL_WCHART_CONFIG_APPROXIMATE_TOTAL',
                    'type'    => 'bool',
                    'default' => 0,
                ),

                array(
                    'name'    => 'approximate_values',
                    'label'   => 'LBL_WCHART_CONFIG_APPROXIMATE_VALUES',
                    'type'    => 'bool',
                    'default' => 0,
                ),
                array(
                    'name'    => 'approximate_tooltips',
                    'label'   => 'LBL_WCHART_CONFIG_APPROXIMATE_TOOLTIPS',
                    'type'    => 'bool',
                    'default' => 0,
                ),
                array(
                    'name'    => 'showBarTotal',
                    'label'   => 'LBL_WCHART_CONFIG_APPROXIMATE_SHOW_BAR_TOTAL',
                    'type'    => 'bool',
                    'default' => 0,
                ),
                array(
                    'name'    => 'animations',
                    'text'    => 'LBL_CHART_CONFIG_ANIMATIONS',
                    'type'    => 'bool',
                    'default' => 1,
                ),
                array(
                    'name'    => 'barThickness',
                    'label'   => 'Minimum bar size',
                    'type'    => 'enum',
                    'default' => false,
                    'options' => array(
                        "10" => translate('LBL_WCHART_DASHLET_SMALL_BAR_THICKNESS'),
                        "30" => translate('LBL_WCHART_DASHLET_MEDIUM_BAR_THICKNESS'),
                        "60" => translate('LBL_WCHART_DASHLET_LARGE_BAR_THICKNESS'),
                    ),
                ),
            ),
        ),
    ),
    'chart' => array(
        'name'  => 'chart',
        'label' => 'LBL_CHART',
        'type'  => 'drilldown-chart',
        'view'  => 'detail',
    ),
);
