/**
 * W Saved Reports Chart Dashlet
 *
 * @class w-saved-reports-chart
 */
({
    plugins: ["Dashlet"],

    extendsFrom: "SavedReportsChartView",

    initialize: function (options) {
        window["d" + this.cid] = this; //dev only
        this.initVars();

        var initRes = this._super("initialize", arguments);

        if (this.meta.config !== true) {
            var dashboard = this.closestComponent("dashboard");
            this.listenTo(dashboard, "dashboard:drilldown:refresh", this.refreshDashletWithDataFromDashboardRuntime.bind(this));
        }

        this.listenTo(this, "init", function () {
            if (this.isNewDashlet() === true) {
                var dashletId = app.wsystems.wDrillDownReportsChart.generateSimpleUID();
                this.settings.set("dashletId", dashletId);
            }
        }.bind(this));

        this.on("chart:click", this.elementClick);

        if (this.meta.config !== true) {
            this.setToolbarButtonsVisibility();
        }

        this.listenTo(this.layout, "applyFilterOnChart", this.reloadChartWithFilters.bind(this));

        return initRes;
    },

    /**
     * Refresh button click handler
     * @method makeADashletRefresh
     * @return undefined
     */
    makeADashletRefresh: function (options) {
        options = _.extend({}, options, {
            forceRefresh: true
        });

        this.loadData(options);
    },

    refreshDashletWithDataFromDashboardRuntime: function (runtimePatch) {
        var options = {
            dashboardRuntimePatch: {
                operator: "AND"
            }
        };

        var filtersInDashlet = [];
        _.each(runtimePatch, function getFiltersInCurrentDashlet(group) {
            var filter = group.filter;
            _.each(group.filter.fields, function getFieldsInGroup(field) {
                if (
                    field.dashlet.toLowerCase() === this.settings.attributes.label.toLowerCase()
                    && field.reportId === this.settings.attributes.saved_report_id
                ) {
                    var filterSetup = _.extend({}, filter, field);
                    delete filterSetup.fields; 1;

                    filtersInDashlet.push(filterSetup);
                    filtersIdx++;
                }
            }.bind(this));
        }.bind(this));

        var filtersIdx = 0;
        _.each(filtersInDashlet, function addFiltersInAFilterDefinition(patch) {
            options.dashboardRuntimePatch[filtersIdx] = patch;
            filtersIdx++;
        }.bind(this));

        this.makeADashletRefresh(options);
    },

    initVars: function () {
        /**
         * timeout timer till refresh
         */
        this._timerId = false;
        this.events = this.events || {};
        this.events = _.extend(this.events, {
            "click [data-fieldname=\"intelligent\"] input": "setLinkedFieldsVisibility",
        });
        this.customFilter = {};
    },

    isNewDashlet: function () {
        return this.meta.config === true && _.isEmpty(this.meta.dashletId);
    },

    setToolbarButtonsVisibility: function () {
        var toolbarComponent, button;

        if (this.meta.show_drilldown_button) {
            toolbarComponent = this.layout.meta.components[1];
            button = _.find(toolbarComponent.view.toolbar.buttons, function addButton(b) {
                return b.action == "goToReport";
            });
            button.css_class = button.css_class.replace(" hidden", "");//eslint-disable-line camelcase
        }

        if (this.meta.show_copy_clipboard_button) {
            toolbarComponent = this.layout.meta.components[1];
            button = _.find(toolbarComponent.view.toolbar.buttons, function addButton(b) {
                return b.action == "copyAsImage";
            });
            button.css_class = button.css_class.replace(" hidden", "");//eslint-disable-line camelcase
        }

        if (this.meta.show_download_image_button) {
            toolbarComponent = this.layout.meta.components[1];
            button = _.find(toolbarComponent.view.toolbar.buttons, function addButton(b) {
                return b.action == "downloadAsImage";
            });
            button.css_class = button.css_class.replace(" hidden", "");//eslint-disable-line camelcase
        }

        if (this.meta.toggle_runtime_filters) {
            toolbarComponent = this.layout.meta.components[1];
            button = _.find(toolbarComponent.view.toolbar.buttons, function addButton(b) {
                return b.action == "toggleRuntimeFilters";
            });
            button.css_class = button.css_class.replace(" hidden", ""); //eslint-disable-line camelcase
        }
    },

    reloadChartWithFilters: function () {
        var options = {
            forceRefresh : true,
            success      : function successCallback() {
                //when filter view was shown, we hide the cart, so make it visible again
                this.$el.find(".runtime_filter").hide();
                this.$el.find(".chart_container").parent().show();

                //render the chart once again
                var chartField = this.getField("chart");
                chartField.generateChart();
            }.bind(this),
        };
        this.loadData(options);
    },

    /**
     * Initializes dashlet settings like:
     * - remove intelligent fields on Home and list views.
     * - add validation on settings view
     * @method initDashlet
     * @param {Component} view
     * @return undefined
     */
    initDashlet: function (view) {
        if (this.meta.config === true) {
            this._handleReportField();

            if (
                app.controller.context.attributes.module === "Home"
                || app.controller.context.attributes.layout === "records"
            ) {
                this._removeFieldsFromMetadata(["intelligent", "link"]);
            }

            this.layout.before(
                "dashletconfig:save",
                function refreshChart() {
                    if (this.validateFields() === false) {
                        return false;
                    }
                    // flag the chart to force refresh 
                    app.wsystems.wDrillDownReportsChart.forceRefresh = true;

                    //Home dashboard view needs barThickness manually copied
                    this.dashModel.set("barThickness", this.settings.get("barThickness"));
                },
                this
            );
 
            if (
                app.controller.context.attributes.module !== "Home"
                && app.controller.context.attributes.layout === "record"
            ) {
                this.layout.before(
                    "dashletconfig:save",
                    function validateInteligentDashlet() {
                        var dh = this.layout.getComponent("dashletconfiguration-headerpane");
                        this.settings.set("label", dh.model.get("label"));
                        
                        if (this.validateFields() === false) {
                            return false;
                        }
                        
                        if (this.settings.get("intelligent") === false) {
                            this.settings.set("link", "");
                        }
                        
                        // in record view, componentType is required in order to setup the dashlet
                        // so as long as we save this.settings, we'll have to manually set the componentType
                        this.settings.set("componentType", "view");
                        
                        app.drawer.close(this.settings);
                        
                        // NOTE: This prevents the drawer from closing prematurely.
                        //eslint-disable-next-line
                        return false;
                    },
                    this
                );
            }

        } else {
            var autoRefresh = this.settings.get("auto_refresh");

            if (autoRefresh > 0) {
                if (this._timerId) {
                    clearTimeout(this._timerId);
                }
                var oneSecondInMili = 1000;
                var oneMinuteInSeconds = 60;
                this._scheduleReload(autoRefresh * oneSecondInMili * oneMinuteInSeconds);
            }
        }

        this.settings.set("reportModule", this.settings.attributes.module);
    },

    /**
     * Validates dashlet fields, especially the ones marked as required
     *
     * @return {Boolean}
     */
    validateFields: function () {
        var _validModel = true;

        var _lastFieldsIndex = parseInt(_.last(_.keys(this.fields)));

        _lastFieldsIndex++;

        this.fields[_lastFieldsIndex] = this.layout.getComponent("dashletconfiguration-headerpane").getField("label");

        _.each(this.fields, function checkRequired(field) {
            if (field.name !== "link" && field.def.required === true
                && _.isEmptyValue(this.dashModel.get(field.name)) === true
            ) {
                field.model.trigger("error:validation:" + field.name, {
                    "required": true
                });

                _validModel = false;
            }

            //require link field if inteligent is enabled
            if (field.name === "link" && this.settings.get("intelligent") === true
                && _.isEmpty(this.settings.get("link"))
            ) {
                field.model.trigger("error:validation:" + field.name, {
                    "required": true
                });

                _validModel = false;
            }
        }.bind(this));

        return _validModel;
    },

    /**
     * Updates the Report field on dashlet config. 
     * We need it to show the latest name of the report
     */
    _handleReportField: function () {
        if (_.isEmpty(this.settings.attributes.saved_report_id) === false) {
            var reportURL = app.api.buildURL("Reports/" + this.settings.attributes.saved_report_id);

            app.api.call("read", reportURL, {}, {
                success: function renderReportField(reportRecordData) {
                    var reportField = this.getField("saved_report");

                    this.settings.attributes.saved_report = reportRecordData.name; //eslint-disable-line

                    if (reportField instanceof app.view.Field) {
                        reportField.render();
                    }
                }.bind(this),
                error: function () { }
            }, {
                skipMetadataHash: true
            });
        }
    },

    _removeFieldsFromMetadata: function (fields) {
        this.meta.panels[0].fields = _.filter(this.meta.panels[0].fields, function fieldsIterator(field) {
            return fields.indexOf(field.name) === -1;
        });
    },

    loadData: function (options) {
        options = options || {};

        var successCallback = options.success;
        var reportId = this.settings.get("saved_report_id");

        if (_.isEmpty(reportId) === true) {
            return;
        }

        if (this.meta.config === true) {
            // set callback for successful get of report data in getSavedReportById()
            _.extend(options, {
                success: _.bind(function bindFunction(data) {
                    if (this.disposed) {
                        return;
                    }
                    if (successCallback) {
                        successCallback.apply(arguments, this);
                    }

                    this.setChartParams(data, false);
                    this._toggleChartFields();
                }, this)
            });
        } else {
            // set callback for successful get of report data in getSavedReportById()
            // we call setChartParams in order to set the colorData attribute
            _.extend(options, {
                success: _.bind(function bindFunction(data) {
                    if (successCallback) {
                        successCallback.apply(arguments, this);
                    }
                    if (
                        typeof data == "undefined" ||
                        typeof data.reportDefs == "undefined" ||
                        typeof data.reportDefs.module == "undefined"
                    ) {
                        return;
                    }
                    this.setChartParams(data, false);
                }, this)
            });
        }

        options = _.extend(options, {
            record_name : this.model.get("name"), //eslint-disable-line camelcase
            record_id   : this.model.get("id")//eslint-disable-line camelcase
        });

        if (app.wsystems.wDrillDownReportsChart.forceRefresh) {
            options.forceRefresh = true;
            app.wsystems.wDrillDownReportsChart.forceRefresh = false;
        }

        this.getSavedReportById(reportId, options);
    },

    render: function () {
        var renderCallRes = this._super("render", arguments);

        if (this.meta.config === true) {
            this.makeSureToHaveChangeEventOnFields();
        } else {
            var chartField = this.getField("chart");
            if (!_.isEmpty(this.reportData.attributes)) {
                chartField.generateChart();
            }
        }

        if (this.meta.config !== true && typeof this.runtimeFiltersView === "undefined") {
            if (this.settings.attributes.toggle_runtime_filters === true) {
                this.runtimeFiltersView = app.view.createView({
                    type    : "w-saved-report-chart-filter",
                    name    : "w-saved-report-chart-filter",
                    context : this.context,
                    layout  : this.layout
                });

                this.runtimeFiltersView.render();
            }
        }

        this.$el.closest(".dashlet-content").find(":first-child").css("overflow-x", "auto");

        return renderCallRes;
    },

    /**
     * Radio buttons won't trigger a change and update the model. This trick solves the problem
     */
    makeSureToHaveChangeEventOnFields: function () {
        this.$el.find("input[name=group1Sort]").off("change");
        this.$el.find("input[name=group1Sort]").on("change", function updateGroup1OnSettings(e) {
            var sort = e.currentTarget.value;
            this.settings.set("group1Sort", sort);
        }.bind(this));

        this.$el.find("input[name=group2Sort]").off("change");
        this.$el.find("input[name=group2Sort]").on("change", function updateGroup2OnSettings(e) {
            var sort = e.currentTarget.value;
            this.settings.set("group2Sort", sort);
        }.bind(this));
    },

    /**
     * Makes a call to Reports/:id/wchart to fetch specific saved report data
     *
     * @param {String} reportId the ID for the report we're looking for
     */
    getSavedReportById: function (reportId, options) {
        var dt = this.layout.getComponent("dashlet-toolbar");
        if (dt) {
            // manually set the icon class to spiny
            this.$("[data-action=loading]")
                .removeClass(dt.cssIconDefault)
                .addClass(dt.cssIconRefresh);
        }
        var settings = this.settings;

        this.dataToSendForChartLoading = {
            reportId          : reportId,
            record_id         : this.model.get("id"), //eslint-disable-line camelcase
            record_name       : this.model.get("name"), //eslint-disable-line camelcase
            link              : settings.get("link"),
            module            : app.controller.context.attributes.module,
            dashletChartType  : settings.attributes.chart_type || "",
            approximateTotal  : settings.attributes.approximate_total || false,
            approximateValues : settings.attributes.approximate_values || false,
            dashletId         : settings.attributes.dashletId
        };
        if (typeof options != "undefined" && typeof options.forceRefresh != "undefined") {
            this.dataToSendForChartLoading.forceRefresh = true;
        }
        if (this.meta.config) {
            this.dataToSendForChartLoading.reportDefinitionOnly = true;
        }
        if (settings.attributes.hideEmptyGroups === true) {
            this.dataToSendForChartLoading.hideEmptyGroups = true;
        }

        if (typeof options != "undefined" && typeof options.dashboardRuntimePatch != "undefined") {
            this.dataToSendForChartLoading.dashboardRuntimePatch = options.dashboardRuntimePatch;
        }

        app.api.call("create", app.api.buildURL("Reports/" + reportId + "/wchart"), this.dataToSendForChartLoading, {
            success: _.bind(function successRetrieveWChart(serverData) {
                if (this.disposed === true) {
                    return;
                }

                this.customFilter = {};
                if (typeof serverData.customFilter === "undefined") {
                    if (typeof serverData.reportDefs.filters_def !== "undefined") {
                        this.customFilter = serverData.reportDefs.filters_def.Filter_1;
                    }
                } else {
                    this.customFilter = serverData.customFilter;
                }

                //trigger filter component setup 
                this.reportData.set("reportDefs", serverData.reportDefs);

                //trigger chart generate
                this.reportData.set("chartData", serverData.chartData);

                //call success with reportDefs and chartData loaded
                if (options && options.success) {
                    options.success.apply(this, arguments);
                }

                if (options.forceRefresh) {
                    if (this.settings.attributes.toggle_runtime_filters === true) {
                        var hideFilterPanel;
                        if (this.$el.find(".runtime_filter").is(":visible") === true) {
                            hideFilterPanel = false;
                        } else {
                            hideFilterPanel = true;
                        }

                        this.runtimeFiltersView.setupComponent();

                        if (hideFilterPanel === true) {
                            this.$el.find(".runtime_filter").hide();
                            this.$el.find(".chart_container").parent().show();
                        } else {
                            this.$el.find(".runtime_filter").show();
                            this.$el.find(".chart_container").parent().hide();
                        }
                    }
                }
            }, this),
            error: function (response) {
                if (response.responseText === "error") {
                    app.alert.show("bad_report", {
                        level     : "error",
                        messages  : app.lang.get("LBL_WCHART_REPORT_DEPRECATED"),
                        autoClose : false
                    });
                    return;
                }
            },
            complete: options ? options.complete : null
        }, {
            skipMetadataHash: true,
        });
    },

    //this method is also overwritted for saved-reports-charts
    getDefaultSettings: function () {
        var defaultRes = this._super("getDefaultSettings", arguments);
        var chartEngine = app.lang.getModString("chartEngine", "Home");
        if (typeof chartEngine != "undefined" && chartEngine == "customsucrose") {
            defaultRes.colorData = "default";
        }
        defaultRes.group1Sort = defaultRes.group1Sort || "default";
        defaultRes.group2Sort = defaultRes.group2Sort || "default";
        return defaultRes;
    },

    /**
     * Process the chart data from the server
     *
     * @param {Object|String} serverData The Report Data from the server
     * @param {Boolean} [update] Is this an update to the report?
     */
    setChartParams: function (serverData, update) {
        //sets ticks checkboxes
        var defaultSettings = this.getDefaultSettings();
        this.settings.set(defaultSettings);

        this.settings.set("module", serverData.reportDefs.module);

        //only for the old charts whithout the animations option, to be removed in the future
        if (this.settings.attributes.animations === undefined) {
            this.settings.set("animations", true);
        }

        var updated = _.isUndefined(update) ? false : update;
        if (updated) {
            this.settings.set("label", serverData.reportDefs.report_name);
            var chartType = app.wsystems.wDrillDownReportsChart.getChartType(serverData.reportDefs.chart_type);
            if (_.isEmpty(chartType) || chartType === "none") {
                this.settings.set("chart_type", "bar chart");
            } else {
                if (chartType === "bar chart" && serverData.reportDefs.group_defs.length === 2) {
                    chartType = "group by chart";
                }
                if (chartType === "horizontal bar chart" && serverData.reportDefs.group_defs.length === 2) {
                    chartType = "horizontal group by chart";
                }
                this.settings.set("chart_type", chartType);
            }
            if (chartType === "bar chart" || chartType === "horizontal bar chart"
                || chartType === "group by chart" || chartType === "horizontal group by chart") {
                this.settings.set("x_axis_label", this._getXaxisLabel(serverData.reportDefs));
                this.settings.set("y_axis_label", this._getYaxisLabel(serverData.reportDefs));

                this.settings.set("barThickness", "30");
            }

            this.settings.set("show_legend", true);
            this.settings.set("animations", true);

            //set stacked checkbox true by default
            if (typeof this.settings.attributes.stacked === "undefined") {
                this.settings.set("stacked", true);
            }
        }

        var reportBaseModule = serverData.reportDefs.module;
        this.linkedFields = this.getLinkedFields(reportBaseModule);
        this.setLinkedFields(reportBaseModule);
    },

    /**
     * Add forceRefresh on reload run by the scheduler
     * @method _scheduleReload
     * @param  {Number} delay Miliseconds interval
     * @return undefined
     */
    _scheduleReload: function (delay) {
        this._timerId = setTimeout(
            _.bind(function timeoutHandler() {
                this.context.resetLoadFlag();
                this.loadData({
                    success: function successCallback() {
                        this._scheduleReload(delay);

                        //render the chart once again
                        var chartField = this.getField("chart");
                        chartField.generateChart();
                    }.bind(this),
                    forceRefresh: true //force chart to refresh
                });
            }, this),
            delay
        );
    },

    /**
     * We use app.DrillDownRefreshNeeded as a flag to know a create a CRUD action has been made inside drilldown drawer.
     * If it's set to true, we'll update the chart
     * @method
     * @return {[type]} [description]
     */
    checkRefreshNeeded: function () {
        if (app.DrillDownRefreshNeeded === true) {
            this.makeADashletRefresh();
            app.DrillDownRefreshNeeded = false;
        }
    },

    /**
     * Checks if report definition is deprecated
     * @method changeSavedReportIdHandler
     * @param  {Model} model settngs model
     * @return undefined
     */
    checkReportDefinitionIsDeprecated: function (model) {
        var reportId = model.get("saved_report_id");

        if (
            app.controller.context.attributes.module != "Home" &&
            App.controller.context.attributes.layout == "record"
        ) {
            App.api.call("GET", App.api.buildURL("Reports/testDeprecated/" + reportId), undefined, {
                /**
                 * Description
                 * @method success
                 * @param {Object} data
                 * @return
                 */
                success: function (data) {
                    if (data.deprecated) {
                        app.alert.show("deprecated_report", {
                            level    : "warning",
                            messages :
                                app.lang.get("LBL_WCHART_REPORT_DEPRECATED_DETAIL"),
                            autoClose: false
                        });
                    }
                }
            });
        }

        this.settings.set("reportModule", this.settings.attributes.module);
        this.settings.set("intelligent", false);
        this.settings.set("link", "");

        if (_.isEmpty(reportId)) {
            return;
        }

        //chart_type should not be sent here in order to make sure we initially populate chart type with that set on report
        var prevChartType = this.settings.get("chart_type");

        this.settings.set("chart_type", undefined);

        this.getSavedReportById(reportId, {
            success: _.bind(function getSavedReportIdHandler(data) {
                if (this.meta.config) {
                    this.setChartParams(data, true);
                    this._toggleChartFields();
                }
            }, this),
        });

        this.settings.set("chart_type", prevChartType);
    },

    /**
     * Handles visibility of fields that only make sense for speciffic chart types
     * @method bindDataChange
     * @return undefined
     */
    bindDataChange: function () {
        if (this.meta.config) {
            this.settings.on("change:saved_report_id", this.checkReportDefinitionIsDeprecated, this);

            this.settings.on(
                "change:chart_type",
                function changeChartTypeHandler(model) {
                    var noScroll = ["funnel chart", "pie chart", "line chart"];
                    if (noScroll.indexOf(model.get("chart_type")) >= 0) {
                        model.set("allowScroll", false);
                    }
                    
                    var chartType = model.attributes.chart_type;
                    var data = this.reportData.attributes.reportDefs;
                    var groupDefsCount = 2;
                    var previousChartType = model._previousAttributes.chart_type;

                    if (_.isString(model._syncedAttributes.chart_type)) {
                        previousChartType = model._syncedAttributes.chart_type;
                    }

                    if (chartType === "line chart" && data.group_defs.length === groupDefsCount) {
                        var axisLabel = _.last(data.group_defs).label;

                        if (previousChartType === "horizontal bar chart" || previousChartType === "horizontal group by chart") {
                            model.set("y_axis_label", axisLabel);
                        } else if (
                            previousChartType === "bar chart" || previousChartType === "group by chart"
                            || previousChartType === "pie chart" || previousChartType === "funnel chart"
                        ) {
                            model.set("x_axis_label", axisLabel);
                        }

                    } else if (chartType !== "line chart" && previousChartType === "line chart" && data.group_defs.length === groupDefsCount) {
                        model.set("x_axis_label", this._getYaxisLabel(data));
                        model.set("y_axis_label", this._getXaxisLabel(data));
                    }

                    //switch the values from x-axis-label and y-axis-label
                    var xAxisValue = model.get("x_axis_label");
                    var yAxisValue = model.get("y_axis_label");
                    
                    if (
                        (
                            (previousChartType === "horizontal bar chart" || previousChartType === "horizontal group by chart")
                            && (chartType !== "horizontal bar chart" && chartType !== "horizontal group by chart")
                        )
                        || (
                            (previousChartType !== "horizontal bar chart" && previousChartType !== "horizontal group by chart" )
                            && (chartType === "horizontal bar chart" || chartType === "horizontal group by chart")
                        )
                    ) {
                        model.set("x_axis_label", yAxisValue);
                        model.set("y_axis_label", xAxisValue);
                    }

                    // toggle display of chart display option controls based on chart type
                    this._toggleChartFields();
                },
                this
            );

            this.settings.on(
                "change:show_title",
                function changeShowTitleHandler(model) {
                    this._toggleApproximateFields();
                },
                this
            );
            this.settings.on(
                "change:showValues",
                function changeShowValuesHandler(model) {
                    this._toggleApproximateFields();
                },
                this
            );

            //if we have stack data series set to false then set barThickness as default to small
            this.settings.on(
                "change:stacked",
                function changeStackDataSeries(model) {
                    if (model.get("stacked") === false) {
                        model.set("barThickness", "10");
                    }
                }
            );
        }
    },

    _toggleChartFields: function () {
        var initToggleRes = this._super("_toggleChartFields", arguments);

        //set back the x and y labels modified in parent 
        var xOptionsFieldset = this.getField("x_label_options");
        var yOptionsFieldset = this.getField("y_label_options");
        var chartType = this.settings.get("chart_type");
        if (chartType === "horizontal bar chart" || chartType === "horizontal group by chart") {
            var xOptionsLabel = app.lang.get("LBL_CHART_CONFIG_SHOW_XAXIS_LABEL");
            xOptionsFieldset.$el.closest(".record-cell").find(".record-label").text(xOptionsLabel);
            var yOptionsLabel = app.lang.get("LBL_CHART_CONFIG_SHOW_YAXIS_LABEL");
            yOptionsFieldset.$el.closest(".record-cell").find(".record-label").text(yOptionsLabel);
        }
            
        this._toggleApproximateFields();

        this.setLinkedFieldsVisibility();
        this.setRelateToCurrentRecordVisibility();

        this._toggleShowBarTotalField();

        this._toggleSortButtons();
        
        this._toggleMinimumBarSize();
        return initToggleRes;
    },

    /**
     * Handles visibility of the Sort by Second Group By
     * @return undefined
     */
    _toggleSortButtons: function () {
        var chartType = this.settings.get("chart_type");
        chartType = app.wsystems.wDrillDownReportsChart.getChartType(chartType);

        var showFirstGroupBy = false;
        var showSecondGroupBy = false;
        var chartSort1Field = this.getField("group1Sort");
        var chartSort2Field = this.getField("group2Sort");

        showFirstGroupBy = true;

        if (
            chartType == "horizontal group by chart" ||
            chartType == "group by chart" ||
            (chartType == "line chart" && this.reportData.attributes.reportDefs.group_defs.length >= 2)//eslint-disable-line
        ) {
            showSecondGroupBy = true;
        } else {
            showSecondGroupBy = false;
        }

        chartSort1Field.$el.closest(".record-cell").toggleClass("hide", !showFirstGroupBy);
        chartSort2Field.$el.closest(".record-cell").toggleClass("hide", !showSecondGroupBy);
    },

    //Add showBarTotal checkbox on dashlet settings when chart type is a grouped one
    _toggleShowBarTotalField: function () {
        var showBarTotal = false;

        var chartType = this.settings.get("chart_type");
        if (
            chartType == "horizontal group by chart" ||
            chartType == "group by chart"
        ) {
            showBarTotal = true;
        } else {
            //make sure it won't remain set true
            this.settings.set("showBarTotal", false);
        }

        var showTotalField = this.getField("showBarTotal");
        if (showTotalField) {
            showTotalField.$el.closest(".record-cell").toggleClass("hide", !showBarTotal);
        }
    },

    _toggleMinimumBarSize: function () {
        var show = false;
        var chartType = this.settings.get("chart_type");

        if (
            chartType == "bar chart" ||
            chartType == "group by chart" ||
            chartType == "horizontal bar chart" ||
            chartType == "horizontal group by chart"
        ) {
            show = true;
        }

        var field = this.getField("barThickness");
        field.$el.closest(".record-cell").toggleClass("hide", !show);
    },

    /**
     * Returns relations between context module and Report module
     * @method getLinkedFields
     * @param {String} moduleName
     * @return {Object} result field name => field label
     */
    getLinkedFields: function (moduleName) {
        if (this.disposed) {
            return;
        }

        var fieldDefs = app.metadata.getModule(this.layout.module).fields;
        var relates = _.filter(
            fieldDefs,
            function fieldsDefIterator(field) {
                if (!_.isUndefined(field.type) && field.type === "link") {
                    if (app.data.getRelatedModule(this.layout.module, field.name) === moduleName) {
                        return true;
                    }
                }
                return false;
            },
            this
        );
        var result = {};
        _.each(
            relates,
            function relatesIterator(field) {
                result[field.name] = app.lang.get(field.vname || field.name, [this.layout.module, moduleName]);
            },
            this
        );

        return result;
    },

    /**
     * This method will make "Relate to current record" button clickable or not,
     * considering there are links between the context module and selected report's base module
     * @method
     * @return undefined
     */
    setRelateToCurrentRecordVisibility: function () {
        var relateToCurrentRecordField = this.getField("intelligent");

        if (typeof relateToCurrentRecordField === "undefined") return;

        var linkedFieldsNames = _.keys(this.linkedFields);
        if (linkedFieldsNames.length == 0) {
            //no relations between context module and Report's base module
            relateToCurrentRecordField.setDisabled(true);
        } else {
            //make sure it's visible and clickable
            relateToCurrentRecordField.setDisabled(false);
        }
    },

    /**
     * Sets options for the link dropdown field
     * @method setLinkedFields
     * @param {string}
     * @return undefined
     */
    setLinkedFields: function () {
        var linkedField = this.getField("link");

        if (typeof linkedField == "undefined") return;

        var linkedFieldsNames = _.keys(this.linkedFields);
        if (linkedFieldsNames.length == 0) {
            linkedField.items = undefined;
        } else {
            linkedField.items = this.linkedFields;
        }
        linkedField._render();
        var linkedFieldsOnSettings = this.settings.get("link");
        if (typeof linkedFieldsOnSettings != "undefined" && linkedFieldsOnSettings != "") {
            //link fied has an presaved value. we're on the case when settings are opened
        } else {
            if (
                (typeof linkedFieldsOnSettings == "undefined" || linkedFieldsOnSettings == "") &&
                linkedFieldsNames.length > 0
            ) {
                this.settings.set("link", linkedFieldsNames[0]);
            } else {
                this.settings.set("link", "");
            }
        }
    },

    /**
     * Makes link field visible or hidden based on intelligent field
     * @method setLinkedFieldsVisibility
     * @return undefined
     */
    setLinkedFieldsVisibility: function () {
        var field = this.getField("link"),
                fieldEl;
        if (!field) {
            return;
        }
        var intelligent = 0;
        if ($("[data-fieldname=\"intelligent\"] input").is(":checked")) {
            intelligent = 1;
        }
        fieldEl = this.$("[data-name=link]");
        if (intelligent === 1) {
            fieldEl.show();
        } else {
            fieldEl.hide();
        }
    },

    /**
     * Toggle approximate_total and approximate_values visibility based on chart_type
     * @method _toggleApproximateFields
     * @return undefined
     */
    _toggleApproximateFields: function () {
        if (this.meta.config) {
            var approximateTotalField = this.getField("approximate_total");
            var approximateValuesField = this.getField("approximate_values");

            if (approximateTotalField instanceof app.view.Field === false
                || approximateValuesField instanceof app.view.Field === false
            ) {
                window.console.log("Could not toggle approximate fields");
                return;
            }

            var approximateTotalVisibility = this.settings.attributes.show_title;
            approximateTotalField.$el.closest(".record-cell").toggleClass("hide", !approximateTotalVisibility);

            if (this.settings.attributes.showValues === "0") {
                approximateValuesField.$el.closest(".record-cell").toggleClass("hide", true);
            } else {
                var chartType = app.wsystems.wDrillDownReportsChart.getChartType(this.settings.attributes.chart_type);
                if (chartType === "funnel chart") {
                    //always show this on funnels
                    approximateValuesField.$el.closest(".record-cell").toggleClass("hide", false);

                } else if (chartType === "pie chart") {
                    //pie charts don't show element values at all
                    approximateValuesField.$el.closest(".record-cell").toggleClass("hide", true);
                } else if (
                    chartType === "bar chart" || chartType === "horizontal bar chart"
                    || chartType === "group by chart" || chartType === "horizontal group by chart"
                ) {
                    approximateValuesField.$el.closest(".record-cell").toggleClass("hide", false);
                } else if (
                    typeof this.settings.attributes.chart_type != "undefined" &&
                    this.settings.attributes.chart_type.indexOf("line") >= 0
                ) {
                    approximateValuesField.$el.closest(".record-cell").toggleClass("hide", true);
                }
            }
        }
    },

    elementClick: function (filters) {
        if (this.disposed)
            return;

        this.settings.set("group1_filter_value", "");
        this.settings.set("group1_filter_label", "");
        this.settings.set("group2_filter_value", "");
        this.settings.set("group2_filter_label", "");

        if (filters.group1_filter_value) {
            this.settings.set("group1_filter_value", filters.group1_filter_value);
            this.settings.set("group1_filter_label", filters.group1_filter_label);
        }
        if (filters.group2_filter_value) {
            this.settings.set("group2_filter_value", filters.group2_filter_value);
            this.settings.set("group2_filter_label", filters.group2_filter_label);
        }

        this.storeRecords();
    },

    /**
     * Executes a call in order to populate the temp table with record ids
     * needed for Records list view.
     */
    storeRecords: function () {
        if (this.disposed) {
            return;
        }
        app.alert.show("openingDrilldownDrawer", {
            level : "process",
            title : app.lang.get("LBL_LOADING")
        });

        this.drawerUID = app.wsystems.wDrillDownReportsChart.generateSimpleUID();

        var tempTableData = _.extend(this.settings.attributes, {
            drawerUID        : this.drawerUID,
            reportId         : this.settings.get("saved_report_id"),
            dashletChartType : this.settings.attributes.chart_type,
            reportModule     : this.reportData.attributes.reportDefs.module,
            record_name      : this.model.get("name"), //eslint-disable-line camelcase
            record_id        : this.model.get("id"), //eslint-disable-line camelcase
            dashletId        : this.settings.get("dashletId")
        });

        if (_.isEmpty(this.settings.attributes.link) === false) {
            //the link needs to know who is the parent
            tempTableData.module = app.controller.context.attributes.module;
        }

        app.api.call("create", app.api.buildURL("Reports/drawerRecords/set"), tempTableData, {
            success : this.openDrawerCallback.bind(this),
            error   : function () {
                app.alert.show("errorDrawerRecordsSet", {
                    level     : "error",
                    messages  : app.lang.get("LBL_WCHART_CANT_OPEN_LIST"),
                    autoClose : true
                });
                window.console.log("Could not set records in temp table");
            },
            complete: function () {
                app.alert.dismiss("openingDrilldownDrawer");
            }
        });
    },

    openDrawerCallback: function (data) {
        if (this.disposed) {
            return;
        }
        this.currentModule = app.drawer.context.get("module");

        //This needs to set to target module for Merge to show the target module fields
        if (data === true) {
            this.settings.set("reportModule", this.settings.get("module"));
            this.dashModel.set("settings", this.settings);
            this.dashModel.set("reportData", this.reportData);

            var contextParams = {
                module        : this.dashModel.module,
                model         : this.dashModel,
                filterOptions : {
                    stickiness   : false, // Prevent other similar components from using the same filter id (it is cached in LocalStorage)
                    show_actions : true, //eslint-disable-line camelcase
                },
                forceNew: true,
            };
            var drawerContext = this.context.getChildContext(contextParams);
            app.drawer.open(
                {
                    layout  : "drilldown-drawer",
                    context : drawerContext
                },
                _.bind(this.closeDrawer, this)
            );
        } else {
            app.alert.show("errorSettingRecords", {
                level     : "error",
                messages  : app.lang.get("LBL_WCHART_CANT_OPEN_LIST"),
                autoClose : true
            });
            window.console.log("Could not store records in temp table");
        }
    },

    /**
     * Remove records from temp table when drawer closes
     *
     * @method
     * @return undefined
     */
    closeDrawer: function () {
        //set back the context module on drawer component
        app.drawer.context.set("module", this.currentModule);

        var tempTableData = {
            drawerUID: this.drawerUID
        };

        // On low bandwidth, an update on a temp table can take a longer time.
        // We need to make sure it was finished before we delete that table
        var waitForANewCheck = 500;
        var deleteFunction = setInterval(function deleteTempTableAfterAllRequestsWereFinished() {
            if (app.wsystems.wDrillDownReportsChart._updatingATempTable) {
                return;
            }
            app.api.call("create", app.api.buildURL("Reports/drawerRecords/delete"), tempTableData, {
                error: function () {
                    window.console.log("Something happened while deleting temp informations about filter appliedrecords.");
                }
            });
            clearInterval(deleteFunction);
        }, waitForANewCheck);

        this.checkRefreshNeeded();
    },

    /**
     * Update the record list in drill down drawer.
     *
     */
    updateList: function () {
        var drawer = this.closestComponent("drawer").getComponent("drilldown-drawer");
        drawer.updateLists();
    },

    /**
     * @return {String}
     */
    _getXaxisLabel: function (data) {
        var label = "";
        var chartType = App.wsystems.wDrillDownReportsChart.getChartType(data.chart_type);

        if (chartType === "none") {
            chartType = "bar chart"; //first option
        }

        if (chartType === "horizontal bar chart" || chartType === "horizontal group by chart") {
            if (data && data.summary_columns) {
                _.each(data.summary_columns, function summaryIterator(column) {
                    if (!_.isUndefined(column.group_function)) {
                        label = column.label;
                    }
                });
            }
        } else {
            if (data && data.group_defs) {
                label = _.first(data.group_defs).label;
            }   
        }
        return label;
    },

    /**
     * @return {String}
     */
    _getYaxisLabel: function (data) {
        var label = "";
        var chartType = App.wsystems.wDrillDownReportsChart.getChartType(data.chart_type);

        if (chartType === "none") {
            chartType = "bar chart"; //first option
        }

        if (chartType === "horizontal bar chart" || chartType === "horizontal group by chart") { 
            if (data && data.group_defs) {
                label = _.first(data.group_defs).label;
            }   
        } else {
            if (data && data.summary_columns) {
                _.each(data.summary_columns, function summaryIterator(column) {
                    if (!_.isUndefined(column.group_function)) {
                        label = column.label;
                    }
                });
            } 
        }
     
        return label;
    },

    goToReport: function () {
        var reportId = this.settings.get("saved_report_id");
        window.open("#bwc/index.php?module=Reports&action=DetailView&record=" + reportId);
    },

    copyAsImage: function (e) {
        /**
         * Adds the image on alert
         */
        function showAlert() {
            var imgUri = this.chartField.chart.toBase64Image();

            app.alert.show("copy-image", {
                level     : "success",
                messages  : "<img src=\"" + imgUri + "\"><br />" + app.lang.get("LBL_WCHART_COPY_IMAGE_INSTRUCTIONS"),
                autoClose : false,
            });

            delete this.chartField.chart.options.entireChartShown;
            this.chartField.chart.options.legend.display = false;
            this.chartField.chart.update();
        }

        //increase the height of the chart in order to see the full chart
        var initialHeight = this.$el.find(".chart_container").outerHeight();
        var addHeight = 80;
        var finalHeight = initialHeight + addHeight + "px";
        this.$el.find(".chart_container").css("height", finalHeight);
        
        //scroll the chart in order to have the axis correctly aligned
        this.$el.find(".chart_container").scrollLeft(0);

        this.chartField.chart.options.legend.display = true;
        this.chartField.chart.options.entireChartShown = true;
        this.chartField.chart.update();

        var showAlertCallback = _.debounce(showAlert.bind(this), this.chartField.chart.options.animation.duration);
        showAlertCallback();
    },

    downloadAsImage: function () {
        this.chartField.chart.options.legend.display = true;
        this.chartField.chart.options.entireChartShown = true;

        //increase the height of the chart in order to see the full chart
        var initialHeight = this.$el.find(".chart_container").outerHeight();
        var addHeight = 80;
        var finalHeight = initialHeight + addHeight + "px";
        this.$el.find(".chart_container").css("height", finalHeight);

        //scroll the chart in order to have the axis correctly aligned
        this.$el.find(".chart_container").scrollLeft(0);
        this.$el.find(".chart_container").scrollTop($(window).height());
        this.chartField.chart.update();

        var downloadCallback = _.debounce(this._downloadAsImage.bind(this), this.chartField.chart.options.animation.duration);
        downloadCallback();
    },

    /**
     * Downloads the chart as a png
     */
    _downloadAsImage: function (e) {
        var img = this.chartField.chart.toBase64Image();
        this.openTab(img);

        //remove the height added at the chart
        var currentHeight = this.$el.find(".chart_container").outerHeight();
        var removeHeight = 80;
        var finalHeight = currentHeight - removeHeight + "px";
        this.$el.find(".chart_container").css("height", finalHeight);

        delete this.chartField.chart.options.entireChartShown;
        this.chartField.chart.options.legend.display = false;
        this.chartField.chart.update();
    },

    /**
     * Open a tab with given uri
     * @param  {String} uri Expected uri will be a png base 64 text
     * @return {undefined}
     */
    openTab: function (uri) {
        var a = window.document.createElement("a")
                , evt = new MouseEvent("click", {
                    bubbles    : false,
                    cancelable : true,
                    view       : window
                });
        a.target = "_blank",
        a.href = uri;
        var downloadFileName = this.settings.attributes.label.replace(/ /g, "-");
        downloadFileName = downloadFileName.toLowerCase();
        a.download = downloadFileName + ".png";
        document.body.appendChild(a);
        a.addEventListener("click", function clickTheNewUrlToDownloadTheImage(e) {
            a.parentNode.removeChild(a);
        });
        a.dispatchEvent(evt);
    },

    toggleRuntimeFilters: function () {
        if (this.$el.find(".runtime_filter").length === 0) {
            this.$el.prepend(this.runtimeFiltersView.$el);
            this.$el.find(".runtime_filter").hide();
        }

        if (this.$el.find(".runtime_filter").is(":visible") === true) {
            this.$el.find(".runtime_filter").hide();
            this.$el.find(".chart_container").parent().show();
        } else {
            this.$el.find(".runtime_filter").show();
            this.$el.find(".chart_container").parent().hide();
        }
    },

    /**
     * Make sure the _timerId is deleted. We don't need any refresh if the dashlet was disposed
     * @return {[type]} [description]
     */
    _dispose: function () {
        var initRes = this._super("_dispose", arguments);
        delete window["d" + this.cid];

        if (this.runtimeFiltersView instanceof App.view.View) {
            this.runtimeFiltersView.dispose();
            
        }
        
        if (this._timerId) {
            clearTimeout(this._timerId);
        }
        return initRes;
    }
}); 