({
    className: "headerpane",
    
    initialize: function () {
        window.filterDrawerHeaderLayout = this;

        this.events = _.extend({}, this.events, {
            "click button[name=cancel]" : "closeDrawer",
            "click button[name=save]"   : "save",
            "click button[name=add]"    : "add",
        });
        
        var initRes = this._super("initialize", arguments);
        
        return initRes;
    },

    closeDrawer: function () { 
        app.drawer.close();
    },

    save: function () { 
        var groupsLayout = this.layout.getComponent("drilldown-filter-drawer-groups");
        
        var validGroups = true; 
        _.each(groupsLayout._components, function validateTemplates(component) {
            if (component.group.dashlets.length === 0) {
                component.getField("dashlets").decorateError("Dashlets needs to be set");
                validGroups = false;
            } else { 
                component.getField("dashlets").clearErrorDecoration();
            }
            if (component.group.fields.length === 0) { 
                component.getField("fields").decorateError("Fields needs to be set");
                validGroups = false;
            } else { 
                component.getField("fields").clearErrorDecoration();
            }
        });

        if (validGroups === false) { 
            app.alert.show("invalid-group", {
                level     : "error",
                messages  : "Can not save these configurations. Please verify them again!",
                autoClose : true
            });
            return;
        }

        var runtimeTemplates = _.map(groupsLayout._components, function (component) {
            var group = component.group;
            group.fields = _.map(group.fields, function (field) {
                if (_.isString(field)) { 
                    field = component._fieldsItemsHashes[field];
                    return app.wsystems.wDrillDownReportsChart.parseFieldUIDStringGetObject(field);
                }

                return field;
            }.bind(this));
            return group;
        }.bind(this));

        app.drawer.close(runtimeTemplates);
    },

    add: function () { 
        this.layout.trigger("group:add");
    },

    render: function () {
        var initRes = this._super("render", arguments);
        return initRes;
    }
});