({
    initialize: function (options) {
        this._super("initialize", [options]);

        window.drilldownPanel = this;//dev only

        this.on("chart:click", this.elementClick);

        this.settings = this.context.attributes.model.attributes.settings;

        this.model = this.context.attributes.model;

        this.model.set("reportDefs", this.model.attributes.reportData.attributes.reportDefs);
        this.model.set("chartData", this.model.attributes.reportData.attributes.chartData);
    },

    elementClick: function (filters) {
        if (this.disposed) {
            return;
        }

        this.model.get("settings").set("group1_filter_value", "");
        this.model.get("settings").set("group1_filter_label", "");
        this.model.get("settings").set("group2_filter_value", "");
        this.model.get("settings").set("group2_filter_label", "");
        this.model.get("settings").set("reportModule", "");

        if (filters.group1_filter_value) {
            this.model.get("settings").set("group1_filter_value", filters.group1_filter_value);
            this.model.get("settings").set("group1_filter_label", filters.group1_filter_label);
        }
        if (filters.group2_filter_value) {
            this.model.get("settings").set("group2_filter_value", filters.group2_filter_value);
            this.model.get("settings").set("group2_filter_label", filters.group2_filter_label);
            this.model.get("settings").set("reportModule", this.settings.attributes.module);
        }

        this.markSelected(this.model.get("settings"));

        this.updateList();
    },

    markSelected: function (settings) {
        var dataset;
        var chartType = app.wsystems.wDrillDownReportsChart.getChartType(settings.get("chart_type"));
        var datasetIdx;
        var dataIdx;
        //remove previous flags
        _.each(this.chartField.chart.data.datasets, function (dataset, datasetIdx) {
            _.each(dataset.data, function (data, dataIdx) {
                if (typeof this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected !== "undefined") {
                    delete this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected;
                }
            }.bind(this));
        }.bind(this));

        if (chartType === "group by chart" || chartType === "horizontal group by chart") {
            datasetIdx = 0;
            dataset = _.find(this.chartField.chart.data.datasets, function (dataset, idx) {
                if (dataset.group2_value === settings.get("group2_filter_value")) {
                    datasetIdx = idx;
                    return true;
                }
                return false;
            });
            dataIdx = 0;
            _.each(dataset.data, function (data, idx) {
                if (data.group1_value === settings.get("group1_filter_value")) {
                    dataIdx = idx;
                }
            });
            this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;

        } else if (chartType === "bar chart" || chartType === "horizontal bar chart") {
            datasetIdx = 0;
            dataset = this.chartField.chart.data.datasets[datasetIdx];
            dataIdx = dataset.dataValues.indexOf(settings.get("group1_filter_value"));

            this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;
        } else if (chartType === "pie chart") {
            datasetIdx = 0;
            dataset = this.chartField.chart.data.datasets[datasetIdx];
            dataIdx = dataset.dataValues.indexOf(settings.get("group1_filter_value"));

            this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;
        } else if (chartType === "funnel chart") {
            datasetIdx = 0;
            dataset = this.chartField.chart.data.datasets[datasetIdx];
            dataIdx = dataset.dataValues.indexOf(settings.get("group1_filter_value"));

            this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;
        } else if (chartType === "line chart") {
            var groupType = settings.get("groupType");
            if (groupType === "simple") {
                datasetIdx = 0;
                dataset = this.chartField.chart.data.datasets[datasetIdx];
                dataIdx = dataset.dataValues.indexOf(settings.get("group1_filter_value"));

                this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;
            } else {
                datasetIdx = 0;
                dataset = _.find(this.chartField.chart.data.datasets, function (dataset, idx) {
                    if (dataset.categoryValue === settings.get("group1_filter_value")) {
                        datasetIdx = idx;
                        return true;
                    }
                    return false;
                });
                dataIdx = 0;
                _.each(this.chartField.chart.data.baseAxisValues, function (baseAxisValue, idx) {
                    if (baseAxisValue === settings.get("group2_filter_value")) {
                        dataIdx = idx;
                    }
                });
                this.chartField.chart.getDatasetMeta(datasetIdx).data[dataIdx].selected = true;
            }
        }

        this.chartField.chart.update(); //if mouse stops over an element, we still want the selection to happen
    },

    /**
     * Update the record list in drill down drawer.
     *
     */
    updateList: function () {
        var drawer = this.closestComponent("drawer").getComponent("drilldown-drawer");
        drawer.updateLists();
    },

    render: function () {
        var config = this.context.attributes.model.attributes;

        // Set the title of the side pane
        this.model.attributes.title = config.settings.get("label");
        //this.chartHeight = "500px";

        this._super("render");

        //sidebar component needs to be open in order for chart to render correct
        var defaultLayout = this.closestComponent("sidebar");
        if (defaultLayout) {
            defaultLayout.trigger("sidebar:toggle", true);
        }

        this.chartField = _.find(this.fields, function findChartField(field) {
            return field.name == "chart";
        });
        if (this.chartField instanceof app.view.Field) {
            this.chartField.generateChart();
            this.markSelected(this.model.get("settings"));
        }

        return this;
    },
});