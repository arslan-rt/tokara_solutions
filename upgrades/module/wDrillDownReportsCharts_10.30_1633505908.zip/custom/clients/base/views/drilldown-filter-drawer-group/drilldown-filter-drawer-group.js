({
    className: "drilldown-filter-drawer-group",

    initialize: function (options) {
        window["drilldownFilterDrawerGroupView" + this.cid] = this;

        this.events = _.extend({}, this.events, {
            "change input[name=groupName]" : "updateGroupNameFromUI",
            "change input[name=dashlets]"  : "updateDashletsFromUI",
            "change input[name=fields]"    : "updateFieldsFromUI",
            "click i[name=delete]"         : "deleteTemplate"
        });

        var initRes = this._super("initialize", arguments);
        
        this.informationsAboutDashboard = this.closestComponent("drilldown-filter-drawer").options.def.informationsAboutDashboard;
        this.dashletsDef = this.getDashletsInDashboard();
        this.groupIdx = options.groupIdx;

        this.group = this.options.group;

        return initRes;
    },

    updateGroupNameFromUI: function () { 
        this.group.name = this.$el.find("input[name=groupName]").val();
    },

    updateDashletsFromUI: function () {
        this.group.dashlets = _.pluck(this.$el.find("input[name=dashlets]").select2("data"), "id");
        
        this.updateFieldsFromSelectedDashlets(this.group.dashlets);
    },

    updateFieldsFromUI: function () {
        this.group.fields = _.pluck(this.$el.find("input[name=fields]").select2("data"), "id");
    },

    deleteTemplate: function (evt) { 
        var groupIdx = $(evt.currentTarget).closest(".drilldown-filter-drawer-group").attr("group-idx");
        this.layout.trigger("group:delete", groupIdx);
    },
    
    /**
     * @return array      Array of objects with dashlets metadata 
     */
    getDashletsInDashboard: function () {
        var drawerLayout = this.closestComponent("drilldown-filter-drawer");
        var dashboardMetadata = drawerLayout.options.def.dashboardMetadata;
        var dashlets = [];

        if (Array.isArray(dashboardMetadata.dashlets)) {
            _.each(dashboardMetadata.dashlets, function (dashlet) {
                if (typeof dashlet.view !== "undefined" && _.isString(dashlet.view.label)) {
                    dashlets.push(dashlet.view);
                }
            });
        } else {
            //bwc dashboards
            _.each(dashboardMetadata.components, function (component) {
                _.each(component.rows, function (row) {
                    _.each(row, function (dashlet) {
                        if (typeof dashlet.view !== "undefined" && _.isString(dashlet.view.label)) {
                            dashlets.push(dashlet.view);
                        }
                    });
                });
            });
        }

        return dashlets;
    },

    /**
     * Show all the fields used in runtime filters across dashlets selected
     * Also updates the group
     */
    updateFieldsFromSelectedDashlets: function (dashletsSelectedList) { 
        //update the group (if needed)
        if (dashletsSelectedList.length === 0) {
            this.group.fields = [];
        } else { 
            this.group.fields = _.filter(this.group.fields, function (field) {
                if (_.isString(field)) {
                    field = this._fieldsItemsHashes[field];
                    field = app.wsystems.wDrillDownReportsChart.parseFieldUIDStringGetObject(field);
                } 
                return dashletsSelectedList.indexOf(field.dashlet) >= 0;
            }.bind(this));            
        }
        
        //update UI
        var dashletsSelected = this.getDashletsSelected();
        var fields = this.getFieldsInDashletsSelected(dashletsSelected);
        this.setupAndRenderFieldsField(fields);
    },

    /**
     * 
     * @param {Array} dashletsSelected Array with dashlets metadata selected
     */
    getFieldsInDashletsSelected: function (dashletsSelected) { 
        this._filterLeafs = [];

        _.each(dashletsSelected, function (dashlet) { 
            var report = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                return reportDashlet.reportId === dashlet.saved_report_id
                    && reportDashlet.dashletId === dashlet.dashletId;
            });

            if (typeof report !== "undefined") { 
                this._runtimeFilterLeafs = [];
                app.wsystems.wDrillDownReportsChart.getRuntimeFilterLeafsFromFilterDef.apply(this, [report.filters_def.Filter_1]);
                _.each(this._runtimeFilterLeafs, function (filterLeaf) { 
                    filterLeaf.reportId = dashlet.saved_report_id; 
                    filterLeaf.dashlet = dashlet.saved_report; 
                    filterLeaf.dashletId = dashlet.dashletId; 
                });
                this._filterLeafs = this._filterLeafs.concat(this._runtimeFilterLeafs);
            }
        }.bind(this));

        return this._filterLeafs;
    },

    /**
     * @return Array Array all dashlets metadata selected
     */
    getDashletsSelected: function () { 
        var dashletIdsSelected = _.pluck(this.$el.find("input[name=dashlets]").select2("data"), "id");
        var dashletsInDashboard = this.getDashletsInDashboard();
        var dashletsSelected = _.filter(dashletsInDashboard, function (dashlet) {
            if (dashletIdsSelected.indexOf(dashlet.dashletId) >= 0) {
                return true;
            }
            return false;
        });
        return dashletsSelected;
    },

    render: function () {
        var initRes = this._super("render", arguments);
        
        this.$el.attr("group-idx", this.groupIdx);

        this.setupAndRenderDashletsField();

        var dashletsSelected = this.getDashletsSelected();
        var fields = this.getFieldsInDashletsSelected(dashletsSelected);
       
        this.setupAndRenderFieldsField(fields);
        
        return initRes;
    },

    setupAndRenderDashletsField: function () {
        this.itemsDashlets = {};
        _.each(this.dashletsDef, function (dashlet) {
            this.itemsDashlets[dashlet.dashletId] = dashlet.label;
        }.bind(this));

        var model = new Backbone.Model();
        model.set("dashlets", this.group.dashlets);

        var field = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name          : "dashlets",
                type          : "enum",
                options       : this.itemsDashlets,
                isMultiSelect : true,
                required      : true
            },
            context : this.context,
            model   : model,
        });

        field.render();

        this.$el.find(".dashlets .record-cell .edit").remove();
        this.$el.find(".dashlets .record-cell .normal.index").html(field.$el);
    },
    
    setupAndRenderFieldsField: function (availableFields) {
        var options = {};

        //setup items
        if (this.group.fields.length >= 1) { 
            var firstField;
            if (_.isString(this.group.fields[0].dashlet)) {
                firstField = this.group.fields[0];                
            } else { 
                firstField = this._fieldsItemsHashes[this.group.fields[0]];
                firstField = app.wsystems.wDrillDownReportsChart.parseFieldUIDStringGetObject(firstField);
            }
            var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                return reportDashlet.reportId === firstField.reportId
                    && reportDashlet.dashletId === firstField.dashlet;
            });
            
            if (typeof reportDefs !== "undefined") {
                var firstFieldDef = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(firstField.fieldName, firstField.tableKey, reportDefs);
            
                options.filterFieldsShown = true;
                options.fieldType = firstFieldDef["type"];
                if (firstFieldDef["type"] === "enum") {
                    options.options = firstFieldDef["options"];
                }
            }
        }
        var fieldItems = this.getFieldsSelectItems(availableFields, options);

        //setup model
        this.group.fields = _.filter(this.group.fields, function removeFieldsWhichAreNotOnSelectedDashlets(field) { 
            var fieldUIDHash, fieldString;
            if (_.isString(field.dashlet)) {
                //field is an object
                fieldString = app.wsystems.wDrillDownReportsChart.parseFieldUIDObjectGetString(field);
                fieldUIDHash = app.wsystems.wDrillDownReportsChart.getHash(fieldString);
                fieldUIDHash = "" + fieldUIDHash; //cast to string to work fine on following check
                return _.keys(fieldItems).indexOf(fieldUIDHash) >= 0;
            } else { 
                if (fieldItems[field] !== "undefined") { 
                    //field is a hash 
                    return true;
                } 
                
                //field is a string representation of the object
                fieldString = app.wsystems.wDrillDownReportsChart.parseFieldUIDObjectGetString(field);
                fieldUIDHash = app.wsystems.wDrillDownReportsChart.getHash(fieldString);
                fieldUIDHash = "" + fieldUIDHash; //cast to string to work fine on following check
                return _.keys(fieldItems).indexOf(fieldUIDHash) >= 0;
            }
        }.bind(this));

        var fieldsKeys = [];
        if (this.group.fields.length > 0) { 
            if (typeof this.group.fields[0].dashlet === "string") {
                fieldsKeys = _.map(this.group.fields, function (field) {
                    var fieldUID = app.wsystems.wDrillDownReportsChart.parseFieldUIDObjectGetString(field);
                    var fieldUIDHash = app.wsystems.wDrillDownReportsChart.getHash(fieldUID);
                    return fieldUIDHash;
                });
            } else { 
                fieldsKeys = this.group.fields;
            }
        }

        var model = new Backbone.Model();
        model.set("fields", fieldsKeys);

        //render field
        this.fieldsField = app.view.createField({
            view     : this,
            viewName : "edit",
            def      : {
                name          : "fields",
                type          : "enum",
                options       : fieldItems,
                isMultiSelect : true,
                required      : true
            },
            context : this.context,
            model   : model,
        });

        this.fieldsField.render();

        model.on("change:fields", this.filterFieldItems.bind(this));

        this.$el.find(".fields .record-cell .edit").remove();
        this.$el.find(".fields .record-cell .normal.index").html(this.fieldsField.$el);
    },

    /**
     * Get all items and puts them on this.itemsFields
     * @param {*} fieldsInDashlets 
     * @param {*} options 
     * @return 
     */
    getFieldsSelectItems: function (fieldsInDashlets, options) { 
        options = options || {};

        this._fieldsItemsHashes = {};
        this.itemsFields = {};
        _.each(fieldsInDashlets, function iterateLeafs(field) {
            var dashlet = this.itemsDashlets[field.dashletId];
            var dashletId = field.dashletId;
            var report = field.reportId;
            var fieldName = field.name;
            var tableKey = field.table_key;
            var pathInReportFilters = JSON.stringify(field.pathInReportFilters);
            var sameType = false;
            var reportDefs;

            if (options.filterFieldsShown === true) { 
                reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                    return reportDashlet.reportId === field.reportId
                        && reportDashlet.dashletId === field.dashletId;
                });

                var fieldDef = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(fieldName, tableKey, reportDefs);
                if (options.fieldType === fieldDef.type) { 
                    sameType = true;
                    if (options.fieldType === "enum" && options.options !== fieldDef.options) {
                        sameType = false;
                    }
                }
            }

            if (typeof options.filterFieldsShown === "undefined" || sameType === true) {
                var fieldUID = dashletId + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                    + report + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                    + tableKey + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                    + fieldName + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                    + pathInReportFilters;
            
                var fieldUIDHash = app.wsystems.wDrillDownReportsChart.getHash(fieldUID);

                this._fieldsItemsHashes[fieldUIDHash] = fieldUID;

                reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                    return reportDashlet.reportId === field.reportId
                        && reportDashlet.dashletId === field.dashletId;
                });
                var fieldModule = reportDefs.full_table_list[field.table_key].module;

                var fieldLabel = app.metadata.getModule(fieldModule).fields[fieldName].vname;
                var filterLabelTranslated = app.lang.getModString(fieldLabel, fieldModule) || app.lang.get(fieldLabel, fieldModule) || "";
            
                var selectOptionLabel = dashlet + " > " + filterLabelTranslated;
                this.itemsFields[fieldUIDHash] = selectOptionLabel;
            }
        }.bind(this));

        return this.itemsFields;
    },

    /**
     * Filter fields items based on first one selected
     * debounce it to wait the click event to finish
     */
    filterFieldItems: _.debounce(function (model, values) {
        var fields;
        var dashletsSelected = this.getDashletsSelected();

        if (values.length === 1 && model._previousAttributes.fields.length === 0) {
            
            var firstField = this._fieldsItemsHashes[values[0]];
            firstField = app.wsystems.wDrillDownReportsChart.parseFieldUIDStringGetObject(firstField);
            var reportDefs = _.find(this.informationsAboutDashboard.reportsDashlets, function (reportDashlet) { 
                return reportDashlet.reportId === firstField.reportId
                    && reportDashlet.dashletId === firstField.dashlet;
            });
            var fieldDef = app.wsystems.wDrillDownReportsChart.getFieldDefByKey(firstField.fieldName, firstField.tableKey, reportDefs);
            var fieldType = fieldDef.type;

            fields = this.getFieldsInDashletsSelected(dashletsSelected);
            var options = {
                filterFieldsShown : true,
                fieldType         : fieldType
            };
            if (fieldType === "enum") {
                options.options = fieldDef.options;
            }
            this.fieldsField.items = this.getFieldsSelectItems(fields, options);
            this.fieldsField.render();
        } else if (values.length === 0) { 
            fields = this.getFieldsInDashletsSelected(dashletsSelected);
            this.fieldsField.items = this.getFieldsSelectItems(fields);
            this.fieldsField.render();
        }
    }, 0)
});