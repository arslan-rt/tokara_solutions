(function fixSugarChartsDashlet(app) {
    SUGAR.mobile.extensions["fixSugarChartsDashlet"] = {
        extendsFrom: {
            baseType: "saved-reports-chart"
        },

        _getModuleFromRelationship: function (relationship, module) {
            const firstPosition = 0;
            const cutAfterIndex = 1;

            let fieldsMeta = app.metadata.getModule(module, "fields");
            let targetField = _.filter(fieldsMeta, function getFieldByRelationship(fieldData) {
                return (fieldData.relationship === relationship);
            });

            let targetFieldName = targetField[firstPosition].name;
            let undescorePos = targetFieldName.indexOf("_");
            
            if (undescorePos > -1) {
                targetFieldName = targetFieldName.slice(undescorePos + 1);
            }

            targetFieldName = targetFieldName.charAt(firstPosition).toUpperCase() + targetFieldName.slice(cutAfterIndex);

            return targetFieldName;
        },
    };
})(SUGAR.App);