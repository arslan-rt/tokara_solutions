// eslint-disable-next-line
; (function loadDashboardFilter(app) {
    var dashboardLayoutExtension = {
        initialize: function (options) {
            /**
             * Whether any of the dashlet componnents has a Runtime Filter 
             */
            this.runtimeEnabled = false;

            /**
             * Stores all necesary data about dashboard like fields in the tables, filters, runetimes,....
             */
            this.informationsAboutDashboard = {};

            if (_.isUndefined(options.meta) === false && Array.isArray(options.meta.components) === false) {
                return this._super("initialize", arguments);
            }

            if (options.context.attributes.create !== true && _.isUndefined(options.meta) === false) {
                options.meta.components.splice(1, 0, {
                    layout: "drilldown-filter-panel"
                });
            }

            var parent = this._super("initialize", arguments);

            if (this.context.attributes.create === true) {
                return parent;
            }

            this.model.on("setMode", function (mode) {
                if (this.runtimeEnabled === false) {
                    return;
                }

                if (mode === "edit" || mode === "create") {
                    this.$el.find(".drilldown-filter-panel").hide();
                } else {
                    this.$el.find(".drilldown-filter-panel").show();
                    this.$el.find(".drilldown-filter-panel").css("display", "flex");
                }
            }, this);
            
            this.listenTo(this.model, "sync", this.getDashletsDetails.bind(this));
            
            this.on("drilldown-group:removed", this.reviewPanelVisibility.bind(this));

            return parent;
        },

        toggleRuntimePanel: function (show) {
            if (_.isBoolean(show)) {                
                if (show === true) {
                    this.$el.find(".drilldown-filter-panel").css("display", "flex");
                } else { 
                    this.$el.find(".drilldown-filter-panel").toggle(false);
                }
                this.runtimeEnabled = show;
            } else {
                this.runtimeEnabled = !this.$el.find(".drilldown-filter-panel").is(":visible");
                if (this.runtimeEnabled === true) { 
                    this.$el.find(".drilldown-filter-panel").css("display", "flex");
                } else { 
                    this.$el.find(".drilldown-filter-panel").toggle(false);
                }
            }
        },

        reviewPanelVisibility: function () {
            var filterPanelLayout = this.getComponent("drilldown-filter-panel");
            if (filterPanelLayout._components.length === 0) { 
                this.toggleRuntimePanel(false);
            }
        },

        getDashletsDetails: function () { 
            app.api.call("read", app.api.buildURL("wDrillDown/runtime/getDashboardReportsContent/" + this.model.get("id")), {}, {
                success: function (data) {
                    this.informationsAboutDashboard = data;
                    this.trigger("dashboardInfo:received");

                    var filterPanelLayout = this.getComponent("drilldown-filter-panel");
            
                    if (data.hasRuntimes === true) {
                        _.defer(function () {
                            this.$el.find("a[name=runtime_filters_clear]").removeClass("hide");
                            this.$el.find("a[name=runtime_filters_apply]").removeClass("hide");
                        }.bind(this));
                                               
                        // this.toggleRuntimePanel(true);
                        if (
                            _.isNull(this.model.get("dashboardRuntimeTemplates"))
                            || _.isUndefined(this.model.get("dashboardRuntimeTemplates"))  
                            || this.model.get("dashboardRuntimeTemplates").length === 0
                        ) {
                            this.toggleRuntimePanel(false);
                        } else { 
                            if (filterPanelLayout._components.length >= 1) { 
                                this.toggleRuntimePanel(true);    
                            }
                        }
                    }
                }.bind(this),
                error: function (data) {
                    app.logger.error("Could not run the api to check dashboard");
                }.bind(this)
            });
        }
    };

    var headerpaneViewExtension = {
        initialize: function (options) { 
            options.meta.buttons.unshift({
                name       : "runtime_filters_apply",
                type       : "button",
                label      : " apply",
                acl_action: "edit",//eslint-disable-line
                tooltip    : "Runtime Filters Config",
                css_class: "hide", //eslint-disable-line
                showOn     : "view"
            });
            options.meta.buttons.unshift({
                name       : "runtime_filters_clear",
                type       : "button",
                label      : " clear",
                acl_action : "edit",//eslint-disable-line
                tooltip    : "Clear filters",
                css_class: "hide", //eslint-disable-line
                showOn     : "view"
            });

            this.events = _.extend({}, this.events, {
                "click a[name=runtime_filters_clear]" : "clearFilters",
                "click a[name=runtime_filters_apply]" : "openRuntimeFiltersDrawer",
            });

            var initRes = this._super("initialize", arguments);
            return initRes;
        },

        clearFilters: function () { 
            var dashboardLayout = this.layout;
            dashboardLayout.trigger("filters:clear");
            dashboardLayout.trigger("filters:save");
        },

        openRuntimeFiltersDrawer: function () { 
            app.drawer.open({
                layout                     : "drilldown-filter-drawer",
                context                    : this.context,
                dashboardMetadata          : this.closestComponent("dashboard").model.attributes.metadata,
                informationsAboutDashboard : this.closestComponent("dashboard").informationsAboutDashboard,
                dashboardRuntimeTemplates  : this.model.attributes.dashboardRuntimeTemplates,
                dashboardFilters           : this.model.attributes.dashboardFilters,
            }, function onDrawerClose(runtimeTemplates) {
                if (typeof runtimeTemplates === "undefined") { 
                    return;
                }

                runtimeTemplates = _.map(runtimeTemplates, function (runtimeTemplate) {
                    return {
                        templateId : runtimeTemplate.templateId,
                        name       : runtimeTemplate.name,
                        dashlets   : runtimeTemplate.dashlets,
                        fields     : runtimeTemplate.fields,
                    };
                });
                    
                var data = {
                    dashboardId      : this.model.get("id"),
                    runtimeTemplates : runtimeTemplates
                };

                app.api.call("create", app.api.buildURL("wDrillDown/dashboardTemplate/setDashboardTemplate"), data, {
                    success: function () { 
                        app.router.refresh();
                    },
                    error: function (e) { 
                        app.alert.show("error", {
                            level     : "error",
                            messages  : "Could not save the filter. Try to reload the page.",
                            autoClose : true
                        });
                        app.logger.fatal("wDrilldown: could not save dashboard template");
                    },
                });
                    
            }.bind(this));
        },

        _renderFields: function () { 
            var initRes = this._super("_renderFields", arguments);
            this.$el.find("a[name=runtime_filters_clear]").html("<i class=\"fa fa-filter\"></i><i class=\"fa fa-remove\"></i>");//remove the empty space of run button. leave just the icon
            this.$el.find("a[name=runtime_filters_apply]").html("<i class=\"fa fa-filter\"></i><i class=\"fa fa-gear\"></i>");//remove the empty space of run button. leave just the icon
            return initRes;
        }
    };
    //remove default funtionality for buttons visibility (on record/list view)
    var buttonExtension = {
        show: function() {
            if (this.name === "runtime_filters_clear" || this.name === "runtime_filters_apply") {
                return;
            }
            return this._super("show", arguments);//eslint-disable-line consistent-return
        },
        hide: function() {
            if (this.name === "runtime_filters_clear" || this.name === "runtime_filters_apply") {
                return;
            }
            return this._super("hide", arguments);//eslint-disable-line consistent-return
        },
    };

    app.events.once("app:sync:complete", function loadFilter() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", "Dashboards", "layout", "dashboard", dashboardLayoutExtension);
    });
    app.events.once("app:start", function loadFilterOnRecordAndList() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "view", "headerpane", headerpaneViewExtension);
    });
    app.events.once("app:start", function removeFieldVisibilityProcessing() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "field", "button", buttonExtension);
    });

})(SUGAR.App);
