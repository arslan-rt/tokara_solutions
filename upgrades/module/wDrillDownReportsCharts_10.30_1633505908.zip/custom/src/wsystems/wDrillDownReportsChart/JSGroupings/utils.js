/**
 * utils
 */
/*eslint-disable*/
; (function utils(app) {
    app.wsystems = app.wsystems || {};
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};

    app.wsystems.wDrillDownReportsChart.numberOfCharsToShowOnBaseAxis = 10;

    app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR = "_::_";

    var chartHelpers = {
        /**
         * Based on given list and sort type, return the corresponding indexes in source list
         * @param  String   sort          Dashlet paramerter - sort type (asc or desc)
         * @param  Array    list          Sort target
         * @param  Array    labels        Sort target labels, in case we have to sort at this level
         * @return Array                  Indexes sorted
        */
         getSortMask: function (sortType, list, labels) {
            var newOrderIDX = []; //array to hold new order (by indexes)
        
            var tempArrayToSortOn;
            var tempArrayDepentent;
            
            if (sortType === "asc" || sortType === "desc") {
                tempArrayToSortOn = _.clone(labels);
                tempArrayDepentent = _.clone(list);
            } else {
                tempArrayToSortOn = _.clone(list);
                tempArrayDepentent = _.clone(labels);
            }
            
            for (var i = 0; i < tempArrayToSortOn.length; i++) {
                newOrderIDX.push(i);
            }
            _.each(tempArrayToSortOn, function (label, idx) {
                if (sortType == "asc" || sortType == "desc") {
                    if (label === "") {
                        tempArrayToSortOn[idx] = "undefined"; //sucrose label of this value
                        tempArrayDepentent[idx] = "undefined";
                    }
                    tempArrayToSortOn[idx] = tempArrayToSortOn[idx].trim().toLowerCase();
                    tempArrayDepentent[idx] = tempArrayDepentent[idx].trim().toLowerCase();
                }
            });
        
            //update new order based on current dashlet setting - sort asc by first group
            if (sortType == "asc" || sortType == "value-asc") {
                for (var i = 0; i < tempArrayToSortOn.length - 1; i++) {
                    for (var j = i + 1; j < tempArrayToSortOn.length; j++) {
                        if (tempArrayToSortOn[i] > tempArrayToSortOn[j]) {
                            var aux = tempArrayToSortOn[i];
                            tempArrayToSortOn[i] = tempArrayToSortOn[j];
                            tempArrayToSortOn[j] = aux;
        
                            aux = tempArrayDepentent[i];
                            tempArrayDepentent[i] = tempArrayDepentent[j];
                            tempArrayDepentent[j] = aux;
        
                            aux = newOrderIDX[i];
                            newOrderIDX[i] = newOrderIDX[j];
                            newOrderIDX[j] = aux;
                        }
                    }
                }
        
                // in case of "value-asc" we will sort egual values based on labels ascending
                if (sortType == "value-asc") {
                    for (var i = 0; i < tempArrayToSortOn.length - 1; i++) {
                        var egualValSubIndex = 0;
                        do {
                            var j = i + egualValSubIndex;
                            if (tempArrayToSortOn[i] === tempArrayToSortOn[j]) {
                                if (tempArrayDepentent[i] > tempArrayDepentent[j]) {
                                    var aux = tempArrayToSortOn[i];
                                    tempArrayToSortOn[i] = tempArrayToSortOn[j];
                                    tempArrayToSortOn[j] = aux;
        
                                    aux = tempArrayDepentent[i];
                                    tempArrayDepentent[i] = tempArrayDepentent[j];
                                    tempArrayDepentent[j] = aux;
        
                                    aux = newOrderIDX[i];
                                    newOrderIDX[i] = newOrderIDX[j];
                                    newOrderIDX[j] = aux;
                                }
                            }
                            egualValSubIndex = egualValSubIndex + 1;
                        } while (tempArrayToSortOn[i] === tempArrayToSortOn[j]);
                    }
                }
            }
            //update new order based on current dashlet setting - sort desc by first group
            if (sortType == "desc" || sortType == "value-desc") {
                for (var i = 0; i < tempArrayToSortOn.length - 1; i++) {
                    for (var j = i + 1; j < tempArrayToSortOn.length; j++) {
                        if (tempArrayToSortOn[i] < tempArrayToSortOn[j]) {
                            var aux = tempArrayToSortOn[i];
                            tempArrayToSortOn[i] = tempArrayToSortOn[j];
                            tempArrayToSortOn[j] = aux;
                            aux = newOrderIDX[i];
                            newOrderIDX[i] = newOrderIDX[j];
                            newOrderIDX[j] = aux;
                        }
                    }
                }
        
                // in case of "value-desc" we will sort egual values based on labels descending
                if (sortType == "value-desc") {
                    for (var i = 0; i < tempArrayToSortOn.length - 1; i++) {
                        var egualValSubIndex = 0;
                        do {
                            var j = i + egualValSubIndex;
                            if (tempArrayToSortOn[i] === tempArrayToSortOn[j]) {
                                if (tempArrayDepentent[i] < tempArrayDepentent[j]) {
                                    var aux = tempArrayToSortOn[i];
                                    tempArrayToSortOn[i] = tempArrayToSortOn[j];
                                    tempArrayToSortOn[j] = aux;
        
                                    aux = tempArrayDepentent[i];
                                    tempArrayDepentent[i] = tempArrayDepentent[j];
                                    tempArrayDepentent[j] = aux;
        
                                    aux = newOrderIDX[i];
                                    newOrderIDX[i] = newOrderIDX[j];
                                    newOrderIDX[j] = aux;
                                }
                            }
                            egualValSubIndex = egualValSubIndex + 1;
                        } while (tempArrayToSortOn[i] === tempArrayToSortOn[j]);
                    }
                }
            }
        
            return newOrderIDX;
        },

        /**
         * Based on a key received, return an unique color.
         * If key has a predefined color, return it, else generates one.
         * @method
         * @param  {String} value A key value in a chart
         * @return {String} Color code
         */
        _getColorBasedOnValue: function (value) {
            var predefinedColorsUnformatted = [];
            try {
                predefinedColorsUnformatted = JSON.parse(App.lang.get("predefinedColors", "Home"));
            } catch (exception) {
                predefinedColorsUnformatted = [];
            }
            var predefinedColorsFormatted = {};
            var predefinedColorUnformatted;
            for (var iUnformatted = 0; iUnformatted < predefinedColorsUnformatted.length; iUnformatted++) {
                predefinedColorUnformatted = predefinedColorsUnformatted[iUnformatted];
                predefinedColorsFormatted[predefinedColorUnformatted.text] = predefinedColorUnformatted.color;
            }

            var color;
            if (typeof predefinedColorsFormatted[value] != "undefined") {
                color = predefinedColorsFormatted[value];
            } else if (typeof predefinedColorsFormatted[value] == "undefined") {
                color = value.pastelColor();
            }
            return color;
        },

        _colorizeOneGroupReport: function (opaque, ctx) {
            var v = ctx.dataset.data[ctx.dataIndex];
            var value = v.group_value;
            if (value === "" && typeof v.group1_value !== "undefined") {
                value = v.group1_value;
            }
            return app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(value);
        },
        _colorizeTwoGroupsReport: function (opaque, ctx) {
            return app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(ctx.dataset.label);
        },
        _colorizePieReport: function (opaque, ctx) {
            return app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(ctx.chart.data.labels[ctx.dataIndex]);
        },
        _colorizeFunnelReport: function (opaque, ctx) {
            return app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(ctx.chart.data.labels[ctx.dataIndex]);
        },
        _colorizeLineReport: function (opaque, ctx) {
            return app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(ctx.dataset.label);
        },
        /**
         * Trim a text based on the specified length
         * @param  {string} label
         * @param  {number} numberOfCharsToShow
         * @return {string}
         */
        _trimText: function (label, numberOfCharsToShow) {
            if (label.length > numberOfCharsToShow) {

                return label.substr(0, numberOfCharsToShow - 1) + "...";
            }

            return label;
        },

        _trimBaseAxisLabel: function (label) {
            return app.wsystems.wDrillDownReportsChart._trimText(label, app.wsystems.wDrillDownReportsChart.numberOfCharsToShowOnBaseAxis);
        },

        /**
        * Covers different types of chart naming (current Reports module, dashlets, bwc)
        * param {String} chartType 
        * @return {String} Chart type (bar chart, horizontal bar chart,...)
        */
        getChartType: function (chartType) {
            switch (chartType) {
                case "pieF":
                case "pieChart":
                case "pie chart":
                    chartType = "pie chart";
                    break;

                case "lineF":
                case "lineChart":
                case "line chart":
                    chartType = "line chart";
                    break;

                case "funnelF":
                case "funnelChart":
                case "funnel chart":
                    chartType = "funnel chart";
                    break;

                case "barChart":
                case "vBarF":
                case "bar chart":
                    chartType = "bar chart";
                    break;

                case "horizontal":
                case "horizontalBarChart":
                case "hBarF":
                case "horizontal bar chart":
                    chartType = "horizontal bar chart";
                    break;

                case "groupChart":
                case "group by chart":
                    chartType = "group by chart";
                    break;

                case "horizontalGroupChart":
                case "horizontal group by chart":
                    chartType = "horizontal group by chart";
                    break;
            }

            return chartType;
        },

        whiteColor: function (c) {
            c = c.substring(1); // strip #
            var rgb = parseInt(c, 16); // convert rrggbb to decimal
            var r = (rgb >> 16) & 0xff; // extract red
            var g = (rgb >> 8) & 0xff; // extract green
            var b = (rgb >> 0) & 0xff; // extract blue

            var luma = 0.2126 * r + 0.7152 * g + 0.0722 * b; // per ITU-R BT.709

            if (luma < 100) {
                return false;
            }
            return true;
        },
        formatValueNoRounding: function (rawValue) {
            var round = false;
            var decimalPrecision = app.user.getPreference("decimal_precision") || 2;
            decimalPrecision = parseInt(decimalPrecision);
            var numberGroupSeparator = app.user.getPreference("number_grouping_separator") || ",";
            var decimalSeparator = app.user.getPreference("decimal_separator") || ".";
            var toStringOnly = true;

            var res = App.utils.formatNumber(
                rawValue,
                round,
                decimalPrecision,
                numberGroupSeparator,
                decimalSeparator,
                toStringOnly
            );

            //we don't want 0.4999 to show as 0.5 but 0.49
            var decimalSeparatorIdx = res.indexOf(decimalSeparator);
            var resCharLength = res.length;
            if (decimalSeparatorIdx >= 0 && resCharLength > decimalSeparatorIdx + decimalPrecision) {
                res = res.substr(0, decimalSeparatorIdx + decimalPrecision + 1);
            }

            return res;
        },

        /**
         * @return {[type]} [description]
        */
        generateSimpleUID: function () {
            var base = 36;
            var startAt = 2;
            var endAt = 9;
            return Math.random()
                .toString(base)
                .substr(startAt, endAt);
        },

        getFieldQualifiers: function (fieldType) {
            var filter_defs = new Object();
            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "equals",
                value: "Equals"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals_str",
                value: "Does Not Equal"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["encrypt"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "equals",
                value: "Equals"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals_str",
                value: "Does Not Equal"
            };
            qualifiers[qualifiers.length] = {
                name: "contains",
                value: "Contains"
            };
            qualifiers[qualifiers.length] = {
                name: "does_not_contain",
                value: "Does Not Contain"
            };
            qualifiers[qualifiers.length] = {
                name: "starts_with",
                value: "Starts With"
            };
            qualifiers[qualifiers.length] = {
                name: "ends_with",
                value: "Ends With"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["varchar"] = qualifiers;
            filter_defs["char"] = qualifiers;
            filter_defs["text"] = qualifiers;
            filter_defs["email"] = qualifiers;
            filter_defs["yim"] = qualifiers;
            filter_defs["time"] = qualifiers;
            filter_defs["phone"] = qualifiers;
            filter_defs["url"] = qualifiers;

            var qualifiers_name = new Array();
            var is_def = {
                name: "is",
                value: "Is"
            };
            var is_not_def = {
                name: "is_not",
                value: "Is Not"
            };
            var one_of_def = {
                name: "one_of",
                value: "Is One Of"
            };
            var not_one_of_def = {
                name: "not_one_of",
                value: "Is Not One Of"
            };
            qualifiers_name = qualifiers_name.concat(qualifiers);
            qualifiers_name.unshift(not_one_of_def);
            qualifiers_name.unshift(one_of_def);
            qualifiers_name.unshift(is_not_def);
            qualifiers_name.unshift(is_def);
            filter_defs["name"] = qualifiers_name;
            filter_defs["fullname"] = qualifiers_name;
            var qualifiers_name = new Array();
            var is_not_empty_def = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            var is_empty_def = {
                name: "empty",
                value: "Is Empty"
            };
            var reports_to_def = {
                name: "reports_to",
                value: "Reports To"
            };
            qualifiers_name.unshift(reports_to_def);
            qualifiers_name.unshift(is_not_empty_def);
            qualifiers_name.unshift(is_empty_def);
            qualifiers_name.unshift(not_one_of_def);
            qualifiers_name.unshift(one_of_def);
            qualifiers_name.unshift(is_not_def);
            qualifiers_name.unshift(is_def);
            filter_defs["username"] = qualifiers_name;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "on",
                value: "On"
            };
            qualifiers[qualifiers.length] = {
                name: "before",
                value: "Before"
            };
            qualifiers[qualifiers.length] = {
                name: "after",
                value: "After"
            };
            qualifiers[qualifiers.length] = {
                name: "between_dates",
                value: "Is Between"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals_str",
                value: "Not On"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };

            qualifiers[qualifiers.length] = {
                name: "tp_yesterday",
                value: "Yesterday"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_today",
                value: "Today"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_tomorrow",
                value: "Tomorrow"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_n_days",
                value: "Last # Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_n_days",
                value: "Next # Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_7_days",
                value: "Last 7 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_7_days",
                value: "Next 7 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_month",
                value: "Last Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_month",
                value: "This Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_month",
                value: "Next Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_30_days",
                value: "Last 30 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_30_days",
                value: "Next 30 Days"
            };

            qualifiers[qualifiers.length] = {
                name: "tp_last_quarter",
                value: "Last Quarter"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_quarter",
                value: "This Quarter"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_quarter",
                value: "Next Quarter"
            };

            qualifiers[qualifiers.length] = {
                name: "tp_last_year",
                value: "Last Year"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_year",
                value: "This Year"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_year",
                value: "Next Year"
            };

            filter_defs["date"] = qualifiers;
            filter_defs["datetime"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "on",
                value: "On"
            };
            qualifiers[qualifiers.length] = {
                name: "before",
                value: "Before"
            };
            qualifiers[qualifiers.length] = {
                name: "after",
                value: "After"
            };
            qualifiers[qualifiers.length] = {
                name: "between_datetimes",
                value: "Is Between"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals_str",
                value: "Not On"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_yesterday",
                value: "Yesterday"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_today",
                value: "Today"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_tomorrow",
                value: "Tomorrow"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_n_days",
                value: "Last # Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_n_days",
                value: "Next # Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_7_days",
                value: "Last 7 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_7_days",
                value: "Next 7 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_month",
                value: "Last Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_month",
                value: "This Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_month",
                value: "Next Month"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_last_30_days",
                value: "Last 30 Days"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_30_days",
                value: "Next 30 Days"
            };

            qualifiers[qualifiers.length] = {
                name: "tp_last_quarter",
                value: "Last Quarter"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_quarter",
                value: "This Quarter"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_quarter",
                value: "Next Quarter"
            };

            qualifiers[qualifiers.length] = {
                name: "tp_last_year",
                value: "Last Year"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_this_year",
                value: "This Year"
            };
            qualifiers[qualifiers.length] = {
                name: "tp_next_year",
                value: "Next Year"
            };

            filter_defs["datetimecombo"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "equals",
                value: "Equals"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals",
                value: "Does Not Equal"
            };
            qualifiers[qualifiers.length] = {
                name: "less",
                value: "Less Than"
            };
            qualifiers[qualifiers.length] = {
                name: "less_equal",
                value: "Less Than Equal To"
            };
            qualifiers[qualifiers.length] = {
                name: "greater_equal",
                value: "Greater Than Equal To"
            };
            qualifiers[qualifiers.length] = {
                name: "greater",
                value: "Greater Than"
            };
            qualifiers[qualifiers.length] = {
                name: "between",
                value: "Is Between"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["int"] = qualifiers;
            filter_defs["long"] = qualifiers;
            filter_defs["float"] = qualifiers;
            filter_defs["decimal"] = qualifiers;
            filter_defs["currency"] = qualifiers;
            filter_defs["num"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "is",
                value: "Is"
            };
            qualifiers[qualifiers.length] = {
                name: "is_not",
                value: "Is Not"
            };
            qualifiers[qualifiers.length] = {
                name: "one_of",
                value: "Is One Of"
            };
            qualifiers[qualifiers.length] = {
                name: "not_one_of",
                value: "Is Not One Of"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["enum"] = qualifiers;
            filter_defs["radioenum"] = qualifiers;
            filter_defs["parent_type"] = qualifiers;
            filter_defs["timeperiod"] = qualifiers;
            filter_defs["currency_id"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "is",
                value: "Is"
            };
            qualifiers[qualifiers.length] = {
                name: "is_not",
                value: "Is Not"
            };
            qualifiers[qualifiers.length] = {
                name: "one_of",
                value: "Is One Of"
            };
            qualifiers[qualifiers.length] = {
                name: "not_one_of",
                value: "Is Not One Of"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["multienum"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "is",
                value: "Is"
            };
            qualifiers[qualifiers.length] = {
                name: "is_not",
                value: "Is Not"
            };
            qualifiers[qualifiers.length] = {
                name: "one_of",
                value: "Is One Of"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["assigned_user_name"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "is",
                value: "Is"
            };
            qualifiers[qualifiers.length] = {
                name: "is_not",
                value: "Is Not"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["relate"] = qualifiers;
            filter_defs["id"] = qualifiers;

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "equals",
                value: "Equals"
            };
            qualifiers[qualifiers.length] = {
                name: "empty",
                value: "Is Empty"
            };
            qualifiers[qualifiers.length] = {
                name: "not_empty",
                value: "Is Not Empty"
            };
            filter_defs["bool"] = qualifiers;

            var date_group_defs = new Array();
            date_group_defs[date_group_defs.length] = {
                name: "day",
                value: "By Day"
            };
            date_group_defs[date_group_defs.length] = {
                name: "week",
                value: "By Week"
            };
            date_group_defs[date_group_defs.length] = {
                name: "month",
                value: "By Month"
            };
            date_group_defs[date_group_defs.length] = {
                name: "year",
                value: "By Year"
            };
            date_group_defs[date_group_defs.length] = {
                name: "quarter",
                value: "By Quarter"
            };

            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "any",
                value: "Any"
            };
            qualifiers[qualifiers.length] = {
                name: "all",
                value: "At Least"
            };
            qualifiers[qualifiers.length] = {
                name: "exact",
                value: "Exact"
            };
            filter_defs["team_set_id"] = qualifiers;

            // Dropdown for filtering on basis of tag name in the Tags module
            var qualifiers = new Array();
            qualifiers[qualifiers.length] = {
                name: "equals",
                value: "Equals"
            };
            qualifiers[qualifiers.length] = {
                name: "not_equals_str",
                value: "Does Not Equal"
            };
            qualifiers[qualifiers.length] = {
                name: "contains",
                value: "Contains"
            };
            qualifiers[qualifiers.length] = {
                name: "does_not_contain",
                value: "Does Not Contain"
            };
            filter_defs["Tags:name"] = qualifiers;

            filter_defs["file"] = [{
                name: "empty",
                value: "Is Empty"
            },
            {
                name: "not_empty",
                value: "Is Not Empty"
            }
            ];

            return filter_defs[fieldType];
        },

        getFieldDefByKey: function (fieldName, tableKey, reportDefs) {
            var module = reportDefs.full_table_list[tableKey].module;

            var fieldDef = app.metadata.getModule(module).fields[fieldName];

            return fieldDef;
        },

        loadUsers: function () {
            app.api.call("read", app.api.buildURL("wDrillDown/getUsers"), {}, {
                success: function (data) {
                    app.wsystems.wDrillDownReportsChart.users = data;
                },
                error: function () {
                    window.console.log(arguments);
                }
            }, {
                skipMetadataHash: true
            });
        },

        getHash: function (text) {
            if (typeof text === "string") {
                return text.hashCode();
            } else { 
                app.logger.fatal("wDrilldown: Empty hash text given");
            }
        },

        /**
         * 
         * @param {object} field 
         * Ex:  {
         *      dashlet              : "Accounts By Type By Industry",
         *      reportId             : "efc0fedc-7905-11e9-a594-f218983a1c3e",
         *      tableKey             : "self",
         *      fieldName            : "account_type",
         *      pathInReportFilters  : [0],
         * },
         */
        parseFieldUIDObjectGetString: function (fieldArray) {
            var dashlet = fieldArray.dashlet;
            var report = fieldArray.reportId;
            var fieldName = fieldArray.fieldName;//fieldName when save templates
            var tableKey = fieldArray.tableKey;//tableKey when save templates
            var pathInReportFilters = JSON.stringify(fieldArray.pathInReportFilters);

            var fieldUID = dashlet + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                + report + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                + tableKey + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                + fieldName + app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR
                + pathInReportFilters;

            return fieldUID;
        },

        /**
         * 
         * @param {string} field   
         * Ex:  "accounts by type by industry" SEPARATOR "efc0fedc-7905-11e9-a594-f218983a1c3e" SEPARATOR "self"
         * SEPARATOR "account_type" SEPARATOR "[0]"
         */
        parseFieldUIDStringGetObject: function (fieldString) {
            var fieldSplit = fieldString.split(app.wsystems.wDrillDownReportsChart.FILTER_SEPARATOR);

            var dashlet = fieldSplit[0];
            var reportId = fieldSplit[1];
            var tableKey = fieldSplit[2];
            var fieldName = fieldSplit[3];
            var pathInReportFilters = JSON.parse(fieldSplit[4]);

            return {
                dashlet: dashlet,
                reportId: reportId,
                tableKey: tableKey,
                fieldName: fieldName,
                pathInReportFilters: pathInReportFilters,
            };
        },

        /**
         * this._runtimeFilterLeafs will get updated with leafs. 
         * We also generate the path where each leaf is located
         * 
         * Initial call can be: ...getRuntimeFilterLeafsFromFilterDef.apply(this, [filterDefinitions]);
         * 
         * @param {*} filter 
         * @param {*} pathInReportFilters 
         */
        getRuntimeFilterLeafsFromFilterDef: function (filter, pathInReportFilters) {
            var newPath;
            if (typeof filter.operator === "undefined") {
                if (filter.runtime === 1) {
                    filter.pathInReportFilters = pathInReportFilters;
                    if (typeof filter.table_key === "undefined"  && typeof filter.tableKey === "string") { 
                        filter.table_key = filter.tableKey;
                    }
                    if (typeof filter.qualifier_name === "undefined" && typeof filter.qualifier === "string") { 
                        filter.qualifier_name = filter.qualifier;
                    }
                    if (typeof filter.tableKey === "undefined"  && typeof filter.table_key === "string") { 
                        filter.tableKey = filter.table_key;
                    }
                    if (typeof filter.qualifier === "undefined" && typeof filter.qualifier_name === "string") { 
                        filter.qualifier = filter.qualifier_name;
                    }
                    if (typeof filter.fieldName === "undefined" && typeof filter.name === "string") { 
                        filter.fieldName = filter.name;
                    }
                    this._runtimeFilterLeafs.push(filter);
                    return;
                }
            } else {
                var maxIndex = _.max(_.map(_.keys(filter), function (input) {
                    return parseInt(input);
                }));
                var numberOfFields = maxIndex + 1;
                for (var i = 0; i < numberOfFields; i++) {
                    if (Array.isArray(pathInReportFilters)) {
                        newPath = pathInReportFilters.concat(i);
                    } else {
                        newPath = [i];
                    }
                    var subFilter = filter[i];
                    app.wsystems.wDrillDownReportsChart.getRuntimeFilterLeafsFromFilterDef.apply(this, [subFilter, newPath]);
                }
            }
        },
        setTickLength: function (label) {
            var characterLimit = 20;
            if (label.length >= characterLimit) {
                return label.slice(0, label.length).substring(0, characterLimit - 1).trim() + "..";
            }
            return label;
        }
    };

    app.wsystems.wDrillDownReportsChart = _.extend(app.wsystems.wDrillDownReportsChart, chartHelpers);

})(SUGAR.App);
