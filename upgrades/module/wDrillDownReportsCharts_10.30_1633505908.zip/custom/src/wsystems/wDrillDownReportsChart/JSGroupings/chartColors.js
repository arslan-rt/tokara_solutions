/**
 * Adds pastelColor on String object.
 * This method will be responsible to return a color based on input given ONLY for bwc
 *
 * @class chartColors
 */
// eslint-disable-next-line
;  (function chartColors(app) {
    /**
     * Returns a hash code based on given input string
     * @method hashFnv32a
     * @param  {String}    str      String to generate a hash from
     * @param  {Boolean}   asString Convert to 8 digit hex string
     * @param  {String}   seed      8 digit hex string
     * @return {String}   Hash code based on given string
     */
    function hashFnv32a(str, asString, seed) {
        /*jshint bitwise:false */
        var i,
                l,
                // eslint-disable-next-line no-magic-numbers
                hval = seed === undefined ? 0x811c9dc5 : seed;

        for (i = 0, l = str.length; i < l; i++) {
            hval ^= str.charCodeAt(i);
            hval +=
                // eslint-disable-next-line no-magic-numbers
                (hval << 1) +
                // eslint-disable-next-line no-magic-numbers
                (hval << 4) +
                // eslint-disable-next-line no-magic-numbers
                (hval << 7) +
                // eslint-disable-next-line no-magic-numbers
                (hval << 8) +
                // eslint-disable-next-line no-magic-numbers
                (hval << 24);
        }
        if (asString) {
            // Convert to 8 digit hex string
            // eslint-disable-next-line no-magic-numbers
            return ("0000000" + (hval >>> 0).toString(16)).substr(-8);
        }
        return hval >>> 0;
    }

    if (typeof String.prototype.hashCode !== "function") {
        /**
         * Applies hashFnv32a to this string object
         * @method hashCodeHandler
         * @return {String}
         */
        Object.defineProperty(String.prototype, "hashCode", {
            enumerable : false,
            value      : function (obj) {
                return hashFnv32a(this);
            }
        });
    }

    if (typeof String.prototype.pastelColor !== "function") {
        /**
         * Returns a hex color based on string given
         * @method pastelColorHandler
         * @return {String}           hex color
         */
        Object.defineProperty(String.prototype, "pastelColor", {
            enumerable : false,
            value      : function (obj) {
                //we use window.top to make sure we'll have acess to hashCode in bwc frames too
                var hash = window.top.String.prototype.hashCode.apply(this);
                // eslint-disable-next-line no-magic-numbers
                var rHash = Math.abs(hash % 200);
                // eslint-disable-next-line no-magic-numbers
                hash = Math.round(hash / 1000);
                // eslint-disable-next-line no-magic-numbers
                var gHash = Math.abs(hash % 147);
                // eslint-disable-next-line no-magic-numbers
                hash = Math.round(hash / 1000);
                // eslint-disable-next-line no-magic-numbers
                var bHash = Math.abs(hash % 147);

                // eslint-disable-next-line no-magic-numbers
                var r = (rHash + 50).toString(16);
                // eslint-disable-next-line no-magic-numbers
                var g = (gHash + 70).toString(16);
                // eslint-disable-next-line no-magic-numbers
                var b = (bHash + 70).toString(16);

                return "#" + r + g + b;
            }
        });
    }

})(window.top.SUGAR.App);
