// eslint-disable-next-line
;var barChartPlugin = {
    afterDatasetsDraw: function (chart, options) {
        var chartInstance = chart;
        var ctx = chartInstance.ctx;
        ctx.textAlign = "left";
        ctx.font = "12px Open Sans, Helvetica Neue, Arial, sans-serif";
        ctx.fillStyle = "#000000";

        var positionValue = chart.options.plugins.position;
        var approximateValues = chart.options.plugins.approximateValue;
        var isCurrency = chart.options.plugins.numericalChartType === "currency";
        var isDecimal = chart.options.plugins.numericalChartType === "decimal";
        var currencySymbol = App.user.getPreference("currency_symbol");

        chart.data.datasets.forEach(function iterateLegend(dataset, i) {
            var meta = chartInstance.controller.getDatasetMeta(i);
            // eslint-disable-next-line
                meta.data.forEach(function iterateColumns(bar, index) {
                var data = dataset.data[index];
                var dataFormatted = "";
                var labelWidth = "";
                var fontWidth = 12;
                var elementWidth = bar._view.width;
                    
                if (approximateValues === true || positionValue === "total") {
                    // eslint-disable-next-line
                    dataFormatted = sucrose.utility.numberFormatSI(data);
                } else if (isCurrency || isDecimal) {
                    //shows value like 123.49
                    dataFormatted = App.wsystems.wDrillDownReportsChart.formatValueNoRounding(data);
                } else {
                    dataFormatted = data;
                }
                labelWidth = String(dataFormatted).length * fontWidth;

                // eslint-disable-next-line no-magic-numbers
                var elementHeight = bar.height() / 2;
                var fontHeight = 12;
                    
                if (positionValue !== "total") {
                    if (parseFloat(elementHeight) < parseFloat(fontHeight) || parseFloat(elementWidth) < parseFloat(labelWidth)) {
                        return "";
                    }
            
                    var isWhite = App.wsystems.wDrillDownReportsChart.whiteColor(dataset.backgroundColor[index]);
        
                    if (isWhite) {
                        ctx.fillStyle = "#000000";
                    } else {
                        ctx.fillStyle = "#FFFFFF";    
                    }
                }
                    
                var labelPositionX = "";
                var labelPositionY = "";
                    
                if (positionValue === "middle" || positionValue === "1") {
                    // eslint-disable-next-line no-magic-numbers
                    labelPositionX = bar._view.x - labelWidth / 3;
                    // eslint-disable-next-line no-magic-numbers
                    labelPositionY = bar._view.y + (bar.height() / 2);

                } else if (positionValue === "start") {
                    var borderHeight = 4;

                    // eslint-disable-next-line no-magic-numbers
                    labelPositionX = bar._view.x - labelWidth / 3;
                    labelPositionY = bar._view.y + bar.height() - borderHeight;

                } else if (positionValue === "top" || positionValue === "end") {
                    // eslint-disable-next-line no-magic-numbers
                    labelPositionX = bar._view.x - labelWidth / 3;
                    labelPositionY = bar._view.y + fontHeight;
                   
                } else if (positionValue === "total") {
                    ctx.fillStyle = "#000000";  
                    // eslint-disable-next-line no-magic-numbers
                    labelPositionX = bar._view.x - labelWidth / 3;
                    labelPositionY = bar._view.y - fontHeight;
                }
                    
                if (isCurrency === true){
                    dataFormatted = currencySymbol + dataFormatted;
                }

                if (i == 0){
                    ctx.fillText(dataFormatted, labelPositionX, labelPositionY);
                } 
            });
        });
    },
};
