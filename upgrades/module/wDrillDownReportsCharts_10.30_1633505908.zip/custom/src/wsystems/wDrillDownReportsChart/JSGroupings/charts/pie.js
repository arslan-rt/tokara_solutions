//eslint-disable-next-line
; (function pie(app) {
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};
    app.wsystems.wDrillDownReportsChart.charts = app.wsystems.wDrillDownReportsChart.charts || {};
        
    /**
     * 
     * @param {Object} params 
     */
    function loadChart(data, params) {
        var options = {
            responsive          : true,
            maintainAspectRatio : false,
            legend              : {
                display: false
            },
            elements: {
                arc: {
                    backgroundColor : app.wsystems.wDrillDownReportsChart._colorizePieReport.bind(null, false),
                    borderColor     : "white",
                    borderWidth     : 2,
                }
            },
            onClick: function (evt, item) {
                if (_.isEmpty(item)) {
                    return;
                }
                // eslint-disable-next-line no-redeclare
                var item = item[0];
                var datasetIndexSelected = item._index;
                // eslint-disable-next-line camelcase
                var group1_value = item._chart.data.dataValuesRepresented[datasetIndexSelected];
                // eslint-disable-next-line camelcase
                var group1_label = item._chart.data.labels[datasetIndexSelected];

                params.wrapperComponent.trigger("chart:click", {
                    // eslint-disable-next-line camelcase
                    group1_filter_value : group1_value,
                    // eslint-disable-next-line camelcase
                    group1_filter_label : group1_label
                });
            },
            tooltips: {
                mode          : "nearest",
                displayColors : false,
                callbacks     : {
                    label: function(tooltipItem, data){
                        var label = [];
                        var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                        var isCurrency = params.numericalChartType === "currency";
                        var isDecimal = params.numericalChartType === "decimal";
                        var currencySymbol = App.user.getPreference("currency_symbol");
                       
                        //get the concerned dataset
                        var dataset = data.datasets[tooltipItem.datasetIndex];
                        var meta = dataset._meta[Object.keys(dataset._meta)[0]];
                        var total = meta.total;
                        // eslint-disable-next-line no-magic-numbers
                        var percentage = parseFloat((value / total * 100).toFixed(2));

                        if (params.approximate_tooltips === true) {
                            // eslint-disable-next-line no-undef
                            value = sucrose.utility.numberFormatSI(value);
                        } else if (isCurrency || isDecimal) {
                            //shows value like 123.49
                            value = app.wsystems.wDrillDownReportsChart.formatValueNoRounding(value);
                        } 

                        if (isCurrency === true){
                            value = currencySymbol + value;
                        }
                        
                        value += " - " + percentage + "%";
                        label.push(value);

                        return label;
                    },
                    title: function(tooltipItem, data) {
                        if (data.labels[tooltipItem[0].index] === ""){
                            data.labels[tooltipItem[0].index] = "Undefined";
                        }
                        return data.labels[tooltipItem[0].index];
                    }
                }
            },
            hover: {
                mode: "nearest",
            },
            legendCallback: function() {
                var text = [];
                text.push("<ul class=\"" + chart.id + "-legend\">");
                var labels = chart.data.labels;
                for (var i = 0; i < labels.length; i++) {
                    var label = labels[i];
                    var color = app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(label);
                    if (label === ""){
                        label = "Undefined";
                    }
                    text.push("<li class=\"chart_category\" data-index=\"" + i + "\"><i class=\"chart_circle\" style=\"background-color:"
                    + color + "\"/></i><span>" + label + "</span></li>");
                }
                text.push("</ul>");
                return text.join("");
            }
        };
        
        if (params.animations === false) {
            options.animation = options.animation || {};
            options.animation.duration = 0;
            options.responsiveAnimationDuration = 0;
            options.hover.animationDuration = 0;
        }
        
        var ctx = $("#" + params.chartId);

        if (params.show_title) {
            options.title = {
                display  : true,
                text     : params.title,
                position : "top",
            };
        }

        options.plugins = {
            datalabels      : false,
            axisTicksLabels : false
        };

        options.plugins = _.extend({}, options.plugins, {
            labels: {
                render    : "label",
                fontColor : "#000",
                position  : "outside"
            }      
        });

        var chart = new window.Chart(ctx, {
            type    : "pie",
            data    : data,
            options : options,
            plugins : [
                window.chartColorOpacityPlugin,
                window.chartBackgroundColorPlugin,
                window.elementShadingPlugin,
                window.legendLabelsPlugin
            ],
        });
        return chart;
    }

    /**
     * This chart uses one dataset with multiple values
     * @param {*} serverData 
     * @param {*} params 
     */
    function translateData(serverData, params) {
        var translatedData = {
            datasets : [],
            labels   : []
        };
        var serieValues = [];

        var baseAxisValues = _.pluck(serverData.data, "group1_value");
        var baseAxisLabels = _.pluck(serverData.data, "group1_label");
        var baseAxisCounts = _.pluck(serverData.data, "chartColumn");

        //hide empty groups by default
        /*eslint-disable*/
        var baseAxisValuesNew = [];
        var baseAxisLabelsNew = [];
        var baseAxisCountsNew = [];
        for (var countIndex = 0; countIndex < baseAxisCounts.length; countIndex++) {
            if (baseAxisCounts[countIndex] != 0) {
                baseAxisValuesNew.push(baseAxisValues[countIndex]);
                baseAxisLabelsNew.push(baseAxisLabels[countIndex]);
                baseAxisCountsNew.push(baseAxisCounts[countIndex]);
            }
        }
        baseAxisValues = baseAxisValuesNew;
        baseAxisLabels = baseAxisLabelsNew;
        baseAxisCounts = baseAxisCountsNew;

        //sort data based on dashlet configuration
        if (_.isEmpty(params.group1Sort) === false && params.group1Sort !== "default") {
            var sortMask = [];
            if (params.group1Sort == "asc" || params.group1Sort == "desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, baseAxisValues, baseAxisLabels);
            } else if (params.group1Sort == "value-asc" || params.group1Sort == "value-desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, baseAxisCounts, baseAxisLabels);
            }
            var baseAxisValuesNew = [];
            var baseAxisLabelsNew = [];
            var baseAxisCountsNew = [];
            for (var i = 0; i < baseAxisValues.length; i++) {
                baseAxisValuesNew[i] = baseAxisValues[sortMask[i]];
                baseAxisLabelsNew[i] = baseAxisLabels[sortMask[i]];
                baseAxisCountsNew[i] = baseAxisCounts[sortMask[i]];
            }
            baseAxisValues = baseAxisValuesNew;
            baseAxisLabels = baseAxisLabelsNew;
            baseAxisCounts = baseAxisCountsNew;
        }

        /*eslint-enable*/
        _.each(baseAxisValues, function basesAxisValues(baseAxisValue, idx) {
            var newValue = baseAxisCounts[idx];
            serieValues.push(newValue);
        });
        var dataSet = {
            label      : params.reportModule,
            data       : serieValues,
            dataValues : baseAxisValues,
        };
        translatedData.datasets = [dataSet];
        translatedData.labels = baseAxisLabels;
        translatedData.dataValuesRepresented = baseAxisValues;

        return translatedData;
    }

    app.wsystems.wDrillDownReportsChart.charts.pie = {
        loadChart     : loadChart,
        translateData : translateData
    };
})(SUGAR.App);