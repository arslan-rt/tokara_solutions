// eslint-disable-next-line
;var legendLabelsPlugin = {
    afterLayout: function (chart) {
        _.each(chart.legend.legendItems, function iterateLegend(label) {
            if (label.text === "") {
                label.text = "Undefined";
            }
            return label;
        });
    }
};
