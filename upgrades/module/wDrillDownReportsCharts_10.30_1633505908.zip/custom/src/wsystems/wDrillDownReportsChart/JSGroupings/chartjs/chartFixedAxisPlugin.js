/**
 * This plugin sets the vertical bar line and the white background when scroll is enabled. 
 * This way we'll always have the axis show as initially
 * 
 * After drawing the background, we let the scale redraw labels on top
 */
// eslint-disable-next-line
; var chartFixedAxisPlugin = {
    afterDraw: function (chart) {
        if (chart.options.entireChartShown === true) {
            return;
        }

        chart.ctx.save();

        var myScale, secundarAxis, staticAxisWidth, color, lineWidth;
        var chartType = chart.config.type;

        if (chartType === "bar" || chartType === "groupedBar") {
            var leftOffset = 0;
            var canvasLeftOffset = $(chart.canvas).offset().left;
            var wrapperLeftOffset = $(chart.canvas).closest(".chart_container").offset().left;
            if (canvasLeftOffset < wrapperLeftOffset) {
                leftOffset = Math.abs(wrapperLeftOffset) - canvasLeftOffset;
            }        
            myScale = _.find(chart.boxes, function getScale(scale){
                return scale.type === "linearStatic";
            });
            secundarAxis = _.find(chart.boxes, function getSecundarAxis(scale){
                return scale.type === "category";
            });
    
            //background white
            chart.ctx.fillStyle = "#FFFFFF";
            staticAxisWidth = myScale.width;
            //make sure we don't cut half of 0 
            if (leftOffset === 0) {
                chart.ctx.fillRect(leftOffset, 0, staticAxisWidth, myScale._endPixel);
            } else {  
                chart.ctx.fillRect(leftOffset, 0, staticAxisWidth, chart.height);
            }
    
            //draw scaleLabel if is visible
            if (typeof(myScale.options.scaleLabel) !== "undefined" && myScale.options.scaleLabel.display === true) {
                myScale._drawTitle();
            }
            //ticks/labels
            myScale._drawLabels();

            //vertical bar
            //grid lines parameters are optional, so here are some defaults values to use
            color = "rgba(0,0,0,0.25)";
            lineWidth = 1;
            if (Array.isArray(secundarAxis._gridLineItems)) {
                color = secundarAxis._gridLineItems[0].color;
                lineWidth = secundarAxis._gridLineItems[0].width;
            }
        
            var startPixelX = staticAxisWidth;

            chart.ctx.beginPath();
            chart.ctx.lineWidth = lineWidth;
            chart.ctx.strokeStyle = color;
            chart.ctx.moveTo(startPixelX + leftOffset, myScale._startPixel);
            chart.ctx.lineTo(startPixelX + leftOffset, myScale._endPixel);  
            chart.ctx.stroke();

            chart.ctx.restore();
           
        } else {
            myScale = _.find(chart.boxes, function getScale(scale){
                return scale.type === "linearHorizontalStatic";
            });
            secundarAxis = _.find(chart.boxes, function getSecundarAxis(scale){
                return scale.type === "category";
            });
            
            var canvasTopOffset = $(chart.canvas).offset().top;
            var wrapperTopOffset = $(chart.canvas).closest(".chart_container").offset().top;
            var canvasVisibleHeight = $(chart.canvas).closest(".chart_container").height();
            var canvasHeight = $(chart.canvas).height();
            var canvasWidth = $(chart.canvas).width();
            var axisHeight = myScale.height;
            var scrollLocation = canvasHeight - (canvasHeight - canvasVisibleHeight) - axisHeight;

            var yOffset = wrapperTopOffset - canvasTopOffset;
            
            var topOffset = scrollLocation + yOffset;

            //background white
            chart.ctx.fillStyle = "#FFFFFF";
           
            chart.ctx.fillRect(0, topOffset, canvasWidth, chart.height);
    
            //draw scaleLabel if is visible
            if (typeof(myScale.options.scaleLabel) !== "undefined" && myScale.options.scaleLabel.display === true) {
                myScale._drawTitle();
            }
            //ticks/labels
            myScale._drawLabels();

            //horizontal bar
            //grid lines parameters are optional, so here are some defaults values to use
            color = "rgba(0,0,0,0.25)";
            lineWidth = 1;
            
            if (Array.isArray(secundarAxis._gridLineItems)) {
                color = secundarAxis._gridLineItems[0].color;
                lineWidth = secundarAxis._gridLineItems[0].width;
            }
          
            var startBorderX = myScale.margins.left;

            chart.ctx.beginPath();
            chart.ctx.lineWidth = lineWidth;
            chart.ctx.strokeStyle = color;
            chart.ctx.moveTo(startBorderX, scrollLocation + yOffset);
            chart.ctx.lineTo(startBorderX + myScale.width, scrollLocation + yOffset);  
            chart.ctx.stroke();
            chart.ctx.restore();
        }
    }
};