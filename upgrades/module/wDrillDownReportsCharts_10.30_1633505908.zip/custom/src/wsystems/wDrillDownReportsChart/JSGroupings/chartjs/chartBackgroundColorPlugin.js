/**
 * Plugin required in order to have a background color on chart when exporting it
 */
// eslint-disable-next-line
; var chartBackgroundColorPlugin = {
    beforeDraw: function(chart) {
        chart.ctx.save();
        chart.ctx.fillStyle = "white";
        chart.ctx.fillRect(0, 0, chart.width, chart.height);
        chart.ctx.restore();
    }
};
