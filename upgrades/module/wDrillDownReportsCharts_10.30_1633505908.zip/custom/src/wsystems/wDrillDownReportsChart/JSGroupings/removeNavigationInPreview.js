/*
  Removes previous and next icons from Preview (preview-header component).

  This fix is needed because when opening a new preview, firstly it's changed the model on preview (then, collection should be changed and other attrs too)
  This triggeres some other processes which see collection set initially. So new collection is not set on preview even we send it
    when we trigger preview event
  Sugar than checks the model in existing collection. It will not find it neither previously neither as next. Still checking next has a problem.
  Because of this, icons are visible and Next button is available.
*/
// eslint-disable-next-line
; (function removeNavigationInDrillDownPreview(app) {
    var previewHeaderViewExtension = {
        render: function() {
            // custom code
            if (this.layout.meta.isDrilldownPreview) {
                this.layout.hideNextPrevious = true;
            }
            var renderResult = this._super("render", arguments);
            // more custom code
            return renderResult;
        }
    };

    app.events.once("app:start", function extendFunctionalityOnStart() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "view", "preview-header", previewHeaderViewExtension);
    });

})(SUGAR.App);

