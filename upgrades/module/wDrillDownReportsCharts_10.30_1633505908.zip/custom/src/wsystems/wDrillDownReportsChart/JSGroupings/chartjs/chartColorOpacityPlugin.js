/**
 * ChartJS shows the elements transparent by default and opaque on hover, while Sucrose does the opposite
 * This plugin changes that in order to work as Sucrose does.
 */
// eslint-disable-next-line
; var chartColorOpacityPlugin = {
    beforeDatasetDraw: function overrideDefaultHoverColor(chart, easingValue, pluginOptions) {
        for (var datasetIdx = 0; datasetIdx < chart.data.datasets.length; datasetIdx++) {

            var dataLength = chart.controller.getDatasetMeta(datasetIdx).data.length;
            for (var dataIdx = 0; dataIdx < dataLength; dataIdx++) {

                var currentView = chart.controller.getDatasetMeta(datasetIdx).data[dataIdx]._view;

                if (chart.controller.getDatasetMeta(datasetIdx).data[dataIdx].$previousStyle) {
                    // initial functionality was already set in setHoverStyle
                    // then, here we override it
                    var transparentize = function (color) {
                        // eslint-disable-next-line
                        return Color(color).alpha(0.7).rgbString();
                    };
                    currentView.backgroundColor =
                    transparentize(chart.controller.getDatasetMeta(datasetIdx).data[dataIdx].$previousStyle.backgroundColor);
                }

            }

        }
    }
};
