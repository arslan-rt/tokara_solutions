/**
 * Remove events left from record view initialization. Bug observed in sugar 7.8. Still in 7.10
 *
 * @class previewEventsFix
 */
// eslint-disable-next-line
; (function previewEventFix(app) {
    app.events.on("app:init", function appInitPreviewEventFix() {
        var _declareClasses = app.metadata._declareClasses;
        app.overrides = app.overrides || {};

        app.metadata._declareClasses = function declareClassesHandler(data) {
            _declareClasses.call(this, data);

            if (!data._hash) {
                if (typeof app.view.views.BasePreviewView == "undefined") {
                    App.view.declareComponent("view", "preview", "", undefined, false, "base");
                }
                var basePreviewView;
                if (typeof app.view.views.BaseCustomPreviewView != "undefined") {
                    basePreviewView = app.view.views.BaseCustomPreviewView;
                } else if (typeof app.view.views.BaseCustomPreviewView == "undefined") {
                    basePreviewView = app.view.views.BasePreviewView;
                }
                var basePreviewDelegateButtonEvents = basePreviewView.prototype.delegateButtonEvents;

                if (!app.overrides.BasePreviewDelegateButtonEvents) {
                    app.overrides.BasePreviewDelegateButtonEvents =
                        /**
                         * Description
                         * @method delegateButtonEvents
                         * @return
                         */
                        basePreviewView.prototype.delegateButtonEvents = function delegateButtonsHandler() {
                            var activeDrawer = app.drawer.getActive();
                            if (activeDrawer && activeDrawer.type && activeDrawer.type == "drilldown-drawer") {
                                this.context.off("button:save_button:click");
                                this.context.off("button:cancel_button:click");
                                this.layout.off("preview:edit");
                            }

                            basePreviewDelegateButtonEvents.apply(this, arguments);
                        };
                }
            }
        };
    });
})(SUGAR.App);
