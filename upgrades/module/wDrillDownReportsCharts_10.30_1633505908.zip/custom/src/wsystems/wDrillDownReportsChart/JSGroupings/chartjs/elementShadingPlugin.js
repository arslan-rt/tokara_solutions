// eslint-disable-next-line
; (function (app) {
    //simple 32/32 images with a line in the middle
    //defined here in order to have them loaded when needed
    var imgBlack = document.createElement("img");
    imgBlack.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAApSURBVDhPY6AmiIiIeA1lUg5GDSMdjBpGOhg1jHQwahjpYIQYxsDAAABVpyb9sw9pygAAAABJRU5ErkJggg==";
    var imgGray = document.createElement("img");
    imgGray.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAoSURBVDhPYxjU4PDhw/+hTMrBqGGkg1HDSAejhpEORg0jHQxSwxgYAPNgPllaom4VAAAAAElFTkSuQmCC";

    window.elementShadingPlugin = {
        afterDatasetsDraw: function (chart, options) {
            var dataSetIndex, color;

            if (chart.config.type === "line") { 
                for (dataSetIndex = 0; dataSetIndex < chart.data.datasets.length; dataSetIndex++) {
                    chart.getDatasetMeta(dataSetIndex).data.forEach(function getElements(chartElement) {
                        if (chartElement.selected === true) {
                            chartElement._chart.ctx.beginPath();
                            chartElement._chart.ctx.arc(chartElement._model.x, chartElement._model.y, 10, 0, 2 * Math.PI);
                            color = chart.getDatasetMeta(dataSetIndex).dataset._model.backgroundColor;
                            color = color + "4D";//add 25% opacity
                            chartElement._chart.ctx.fillStyle = color;
                            chartElement._chart.ctx.fill();
                            chartElement._chart.ctx.stroke();
                        }
                    });
                }
            } else {
                var img;
                for (dataSetIndex = 0; dataSetIndex < chart.data.datasets.length; dataSetIndex++) {
                    chart.getDatasetMeta(dataSetIndex).data.forEach(function getElements(chartElement, idx) {
                        var meta = chart.getDatasetMeta(dataSetIndex);
                        if (chartElement.selected === true && meta.hidden !== true) {
                            if (app.wsystems.wDrillDownReportsChart.whiteColor(chartElement._model.backgroundColor.trim())) {
                                img = imgBlack;
                            } else {
                                img = imgGray;
                            }
    
                            var pat = chartElement._chart.ctx.createPattern(img, "repeat");
        
                            chartElement._view.backgroundColor = pat;
                                
                            chartElement.draw();
                        }
                    });
                }
            }
        }
    };    
})(SUGAR.App);
