// eslint-disable-next-line
; (function refreshOnPreviewEdit(app) {
    app.events.on("data:sync:complete", function refreshChart(method, collection, options) {
        if (method === "create" || method === "update") {
            var drawer = app.drawer.getActive();
            if (typeof drawer != "undefined" && drawer.name == "drilldown-drawer") {
                app.DrillDownRefreshNeeded = true;
                drawer.updatePanelChartWhenPossible();
            }
        }
    });
})(SUGAR.App);
