// eslint-disable-next-line
;var horizontalBarGroupedChartPlugin = {
    afterDatasetsDraw: function (chart, options) { 
        var chartInstance = chart;
        var ctx = chartInstance.ctx;
        ctx.textAlign = "left";
        ctx.font = "12px Open Sans, Helvetica Neue, Arial, sans-serif";
        ctx.fillStyle = "#000000";

        var positionValue = chart.options.plugins.position;
        var approximateValues = chart.options.plugins.approximateValue;
        var showBarTotal = chart.options.plugins.showBarTotal;
        var stacked = chart.options.plugins.stacked;
        var isCurrency = chart.options.plugins.numericalChartType === "currency";
        var isDecimal = chart.options.plugins.numericalChartType === "decimal";
        var currencySymbol = App.user.getPreference("currency_symbol");
        var totals = [];
        var lastElementWithSomeValue = [];

        //calculate totals of each column
        //store dataset index of last visible value. to be used to show the count
        //above the respective rectangle
        _.each(chart.data.datasets[0].data, function setupTotals() {
            totals.push(0);
        });
        _.each(chart.data.datasets, function getDataSetMeta(d, datasetIdx){
            var meta = d._meta[Object.keys(d._meta)[0]];
            if (meta.hidden !== true){
                _.each(d.data, function getDataElements(element, idx) {
                    if (element.x !== 0) {
                        totals[element.y] += element.x;
                        lastElementWithSomeValue[element.y] = datasetIdx;     
                    }
                });
            }
        });
        
        chart.data.datasets.forEach(function iterateLegend(dataset, i) {
            var meta = chartInstance.controller.getDatasetMeta(i);
            if (meta.hidden !== true){
                // eslint-disable-next-line consistent-return
                meta.data.forEach(function iterateColumns(bar, index) {
                    var data = dataset.data[index];
                    var dataFormatted = "";
                    var labelWidth = "";
                    var fontWidth = 12;

                    if (approximateValues === true) {
                        //eslint-disable-next-line
                        dataFormatted = sucrose.utility.numberFormatSI(data.x);
                    } else if (isCurrency || isDecimal) {
                        //shows value like 123.49
                        dataFormatted = App.wsystems.wDrillDownReportsChart.formatValueNoRounding(data.x);
                    } else {
                        dataFormatted = data.x;
                    }
                    labelWidth = String(dataFormatted).length * fontWidth;

                    var borderWidth = 4;
                    var elementWidth = bar._model.x - bar._model.base - borderWidth;
                    var barWidth = bar._view.x - bar._view.base;
                    var fontHeight = 12;

                    if (showBarTotal === true && stacked === true && positionValue !== "total"){
                        var dataFormattedTT = "";
                        // eslint-disable-next-line no-undef
                        dataFormattedTT = sucrose.utility.numberFormatSI(totals[index]);
                        var labelPositionXTotal = bar._view.x + borderWidth;
                        // eslint-disable-next-line no-magic-numbers
                        var labelPositionYTotal = bar._view.y + fontHeight / 3;
        
                        if (i === lastElementWithSomeValue[index]) {
                            if (isCurrency === true){
                                dataFormattedTT = currencySymbol + dataFormattedTT;
                            }
                            ctx.fillStyle = "#000000";
                            ctx.fillText(dataFormattedTT, labelPositionXTotal, labelPositionYTotal);
                        } 
                    }

                    // eslint-disable-next-line no-magic-numbers
                    var elementHeight = bar._model.height / 2; 

                    if (positionValue !== "total") { 
                        if (parseFloat(elementWidth) < parseFloat(labelWidth) || parseFloat(elementHeight) < parseFloat(fontHeight)) {
                            return "";
                        }
            
                        var isWhite = App.wsystems.wDrillDownReportsChart.whiteColor(bar._view.backgroundColor);
                        if (isWhite) {
                            ctx.fillStyle = "#000000";
                        } else {
                            ctx.fillStyle = "#FFFFFF";    
                        }
                    }

                    var labelPositionX = "";
                    var labelPositionY = "";
                                
                    if (positionValue === "middle" || positionValue === "1") { 
                        // eslint-disable-next-line no-magic-numbers
                        labelPositionX = bar._view.x - barWidth / 2 - labelWidth / 2;
                        // eslint-disable-next-line no-magic-numbers
                        labelPositionY = bar._view.y + fontHeight / 3;
    
                        if (isCurrency === true){
                            dataFormatted = currencySymbol + dataFormatted;
                        }
    
                        if (dataFormatted !== "0"){
                            ctx.fillText(dataFormatted, labelPositionX, labelPositionY);
                        }

                    } else if (positionValue === "start") {
                        labelPositionX = bar._view.x - barWidth + borderWidth;
                        // eslint-disable-next-line no-magic-numbers
                        labelPositionY = bar._view.y + fontHeight / 3;

                        if (isCurrency === true){
                            dataFormatted = currencySymbol + dataFormatted;
                        }
    
                        if (dataFormatted !== 0){
                            ctx.fillText(dataFormatted, labelPositionX, labelPositionY);
                        } 

                    } else if (positionValue === "top" || positionValue === "end") {
                        labelPositionX = bar._view.x - labelWidth;
                        // eslint-disable-next-line no-magic-numbers
                        labelPositionY = bar._view.y + fontHeight / 3;

                        if (isCurrency === true) {
                            dataFormatted = currencySymbol + dataFormatted;
                        }
    
                        if (dataFormatted != 0) {
                            ctx.fillText(dataFormatted, labelPositionX, labelPositionY);
                        }
                        
                    } else if (positionValue === "total") {
                        var dataFormattedT = "";
                        // eslint-disable-next-line
                        dataFormattedT = sucrose.utility.numberFormatSI(totals[index]);

                        labelWidth = String(dataFormattedT).length * fontWidth;
                        
                        labelPositionX = bar._view.x + borderWidth;
                        // eslint-disable-next-line no-magic-numbers
                        labelPositionY = bar._view.y + fontHeight / 3;

                        if (i === lastElementWithSomeValue[index] && stacked === true) {
                            if (isCurrency === true){
                                dataFormattedT = currencySymbol + dataFormattedT;
                            }
                            ctx.fillStyle = "#000000";
                            ctx.fillText(dataFormattedT, labelPositionX, labelPositionY);
                        } 
                    }
                });
            }
        });
    }
};
