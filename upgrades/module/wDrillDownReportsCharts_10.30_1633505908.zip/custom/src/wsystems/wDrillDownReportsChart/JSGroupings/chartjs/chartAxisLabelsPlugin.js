/**
 * Used to have more control over the label of the axes.
 * If used, the property displayCustomScaleLabel should be set to true
 */
// eslint-disable-next-line
; var chartAxisLabelsPlugin = {
    afterDraw: function(chart) {
        var label, xPosition, yPosition;

        //vertical bar charts
        if (chart.options.chart_type == "bar chart" || chart.options.chart_type == "group by chart") {
            if (chart.options.show_x_label) {
                if (chart.options.scales.xAxes[0].scaleLabel.displayCustomScaleLabel) {
                    chart.ctx.save();
                    label = chart.options.scales.xAxes[0].scaleLabel.labelString;
                    xPosition = chart.width / 2 - label.length / 2;
                    yPosition = chart.height - 20;
                    chart.ctx.fillText(label, xPosition, yPosition);
                    chart.ctx.restore();
                }
            }
            if (chart.options.show_y_label) {
                if (chart.options.scales.yAxes[0].scaleLabel.displayCustomScaleLabel) {
                    chart.ctx.save();
                    label = chart.options.scales.yAxes[0].scaleLabel.labelString;
                    xPosition = 10;
                    yPosition = chart.height / 2 - label.length / 2;
                    chart.ctx.translate(xPosition, yPosition);
                    chart.ctx.rotate(-0.5 * Math.PI);
                    chart.ctx.fillText(label, 0, 10);
                    chart.ctx.restore();
                }
            }
        }

        //horizontal bar charts
        if (chart.options.chart_type == "horizontal bar chart" || chart.options.chart_type == "horizontal group by chart") {
            if (chart.options.show_x_label) {
                if (chart.options.scales.xAxes[0].scaleLabel.displayCustomScaleLabel) {
                    chart.ctx.save();
                    label = chart.options.scales.xAxes[0].scaleLabel.labelString;
                    xPosition = chart.width / 2 - label.length / 2;
                    yPosition = chart.height - 20;
                    chart.ctx.fillText(label, xPosition, yPosition);
                    chart.ctx.restore();
                }
            }
            if (chart.options.show_y_label) {
                if (chart.options.scales.yAxes[0].scaleLabel.displayCustomScaleLabel) {
                    chart.ctx.save();
                    label = chart.options.scales.yAxes[0].scaleLabel.labelString;
                    xPosition = 10;
                    yPosition = chart.height / 2 - label.length / 2;
                    chart.ctx.translate(xPosition, yPosition);
                    chart.ctx.rotate(-0.5 * Math.PI);
                    chart.ctx.fillText(label, 0, 10);
                    chart.ctx.restore();
                }
            }
        }
    }
};
