//eslint-disable-next-line
; (function horizontalBar(app) {
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};
    app.wsystems.wDrillDownReportsChart.charts = app.wsystems.wDrillDownReportsChart.charts || {};

    window.Chart.Tooltip.positioners.custom = function getTooltipPosition(elements, eventPosition) {
        return {
            x : eventPosition.x,
            y : eventPosition.y
        };
    };
    /**
     * 
     * @param {*} data 
     * @param {*} params 
     */
    function loadChart(data, params) {
        var chart;
        var options = {
            responsive          : true,
            maintainAspectRatio : false,
            legend              : {
                display: false,
            },
            elements: {
                rectangle: {
                    backgroundColor: app.wsystems.wDrillDownReportsChart._colorizeOneGroupReport.bind(null, false),
                }
            },
            scales: {
                xAxes: [{
                    //type  : "linearHorizontalStatic",
                    ticks: {
                        beginAtZero : true,
                        callback    : function (label, index, values) { 
                            var decimalPrecision = App.user.getPreference("decimal_precision");
                            // eslint-disable-next-line no-undef
                            return sucrose.utility.numberFormatSI(label, decimalPrecision);
                        }
                    },
                }],
                yAxes: [{
                    barThickness : params.barThickness, 
                    gridLines    : { //lines perpedicular on this axis
                        display: false
                    },
                    offset : true,
                    ticks  : {
                        beginAtZero : true,
                        callback    : function (label, index, values) {
                            if (label === "") {
                                label = "Undefined";
                            }
                            label = App.wsystems.wDrillDownReportsChart.setTickLength(label);
                            return label; 
                        }
                    },
                }],
            },
            tooltips: {
                position      : "custom",
                mode          : "nearest",
                displayColors : false,
                callbacks     : {
                    title: function () {
                        //we have no title for this chart
                        return "";
                    },
                    label: function (tooltipItem, data) {
                        var label = [];
                        var valueLabel = "";
                        var isCurrency = params.numericalChartType === "currency";
                        var isDecimal = params.numericalChartType === "decimal";
                        var currencySymbol = App.user.getPreference("currency_symbol");

                        if (tooltipItem.label === "") {
                            tooltipItem.label = "Undefined";
                        }

                        label.push(tooltipItem.label);

                        if (isCurrency === true) {
                            valueLabel += currencySymbol;
                        }

                        if (params.approximate_tooltips === true) {
                            // eslint-disable-next-line no-undef
                            valueLabel += sucrose.utility.numberFormatSI(tooltipItem.value);
                        } else if (isCurrency || isDecimal) {
                            //shows value like 123.49
                            valueLabel += app.wsystems.wDrillDownReportsChart.formatValueNoRounding(tooltipItem.value);
                        } else {
                            valueLabel += tooltipItem.value;
                        }

                        label.push(valueLabel);

                        return label;
                    },
                }
            },
            hover: {
                mode: "nearest",
            },
            onClick: function (evt, item) {
                if (_.isEmpty(item)) {
                    return;
                }
                var groupVal = item[0]._chart.data.datasets[0].dataValues[item[0]._index];
                var groupLabel = item[0]._model.label;
                params.wrapperComponent.trigger("chart:click", {
                    // eslint-disable-next-line camelcase
                    group1_filter_value : groupVal,
                    // eslint-disable-next-line camelcase
                    group1_filter_label : groupLabel
                });

            },
        };

        options.legend = false;

        if (params.animations === false) {
            options.animation = options.animation || {};
            options.animation.duration = 0;
            options.responsiveAnimationDuration = 0;
            options.hover.animationDuration = 0;
        }

        var ctx = $("#" + params.chartId);

        //increase the layout padding in order to fit the total data label
        if (params.showValues === "total") {
            _.each(data.datasets, function getDataSetMeta(d, datasetIdx) {
                var biggestLabel = Math.max.apply(Math, d.data);
                // eslint-disable-next-line no-undef
                var dataFormattedT = sucrose.utility.numberFormatSI(biggestLabel);
                var fontWidth = 12;
                var labelWidth = String(dataFormattedT).length * fontWidth;
                options.layout = {
                    padding: {
                        right: labelWidth
                    }
                };
            });
        }
        
        if (params.show_title) {
            options.title = {
                display  : true,
                text     : params.title,
                position : "top",
            };
        }
        if (params.show_x_label) {
            options.scales.xAxes[0].scaleLabel = {
                display                 : true,
                displayCustomScaleLabel : true,
                labelString             : params.x_axis_label
            };
        }
        if (params.show_y_label) {
            options.scales.yAxes[0].scaleLabel = {
                display                 : true,
                lineHeight              : 0.1,
                displayCustomScaleLabel : false,
                labelString             : params.y_axis_label
            };
        }

        if (params.showValues === "0") {
            options.plugins = _.extend({}, options.plugins, {
                datalabels            : false,
                axisTicksLabels       : false,
                chartAxisLabelsPlugin : false
            });

        } else {
            options.plugins = _.extend({}, options.plugins, {
                chartAxisLabelsPlugin : false,
                datalabels            : false,
                axisTicksLabels       : false,
                position              : params.showValues,
                numericalChartType    : params.numericalChartType,
                approximateValue      : params.approximate_values
            });
        }

        var chartInitOptions = {
            type    : "horizontalBar",
            data    : data,
            options : options,
            plugins : [
                window.chartColorOpacityPlugin,
                window.chartBackgroundColorPlugin,
                // window.chartFixedAxisPlugin,
                window.horizontalBarChartPlugin,
                window.elementShadingPlugin,
            ],
        };
        chart = new window.Chart(ctx, chartInitOptions);
        return chart;
    }

    /**
     * This method will return one dataset. This allows us to have bar labels under each of them - default ChartJS functionality
     * Changing this to a bidimentional data ([{x:0, y: 50}, {x: 1, y:0}, {x: 2, y: 0}, {x:2, y: 100}])
     * means we have a legend but now we don't have bar labels anymore
     * 
     * The legend is useful to hide datasets. Considering we will work with only one dataset for this 
     * chart type, the legend will not be very useful
     * @param {*} serverData 
     * @param {*} options 
     */
    function translateData(serverData, options) {
        var translatedData = {
            datasets : [],
            labels   : []
        };

        //multiple datasets. each of them has only one value
        var baseAxisValues = _.pluck(serverData.data, "group1_value");
        var baseAxisLabels = _.pluck(serverData.data, "group1_label");
        var baseAxisCounts = _.pluck(serverData.data, "chartColumn");

        //sort data based on dashlet configuration
        if (_.isEmpty(options.group1Sort) === false && options.group1Sort !== "default") {
            var sortMask = [];
            if (options.group1Sort == "asc" || options.group1Sort == "desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(options.group1Sort, baseAxisValues, baseAxisLabels);
            } else if (options.group1Sort == "value-asc" || options.group1Sort == "value-desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(options.group1Sort, baseAxisCounts, baseAxisLabels);
            }
            var baseAxisValuesNew = [];
            var baseAxisLabelsNew = [];
            var baseAxisCountsNew = [];
            for (var i = 0; i < baseAxisValues.length; i++) {
                baseAxisValuesNew[i] = baseAxisValues[sortMask[i]];
                baseAxisLabelsNew[i] = baseAxisLabels[sortMask[i]];
                baseAxisCountsNew[i] = baseAxisCounts[sortMask[i]];
            }
            baseAxisValues = baseAxisValuesNew;
            baseAxisLabels = baseAxisLabelsNew;
            baseAxisCounts = baseAxisCountsNew;
        }

        var barColors = [];
        for (var labelsIdx = 0; labelsIdx < baseAxisLabels.length; labelsIdx++) {
            var barColor = app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(baseAxisLabels[labelsIdx]);
            barColors.push(barColor);
        }

        var dataSet = {
            label           : options.module,
            data            : baseAxisCounts,
            dataValues      : baseAxisValues,
            fill            : true,
            backgroundColor : barColors,
            borderColor     : barColors,
            borderWidth     : 1
        };

        translatedData.datasets = [dataSet];
        translatedData.labels = baseAxisLabels;

        return translatedData;
    }

    app.wsystems.wDrillDownReportsChart.charts.horizontalBar = {
        loadChart     : loadChart,
        translateData : translateData
    };
})(SUGAR.App);