// eslint-disable-next-line
;(function resourcesLoader(app) {
    app.wsystems = app.wsystems || {};
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};

    /**
     * Dinamically charge scripts and css files
     * @method loadjscssfile
     * @param  {String}      filename [description]
     * @param  {String}      filetype js/css
     * @return {undefined}
     */
    function loadjscssfile(filename, filetype) {
        var fileref;
        if (filetype === "js") {
            //if filename is a external JavaScript file
            fileref = document.createElement("script");
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", filename);
        } else if (filetype === "css") {
            //if filename is an external CSS file
            fileref = document.createElement("link");
            fileref.setAttribute("rel", "stylesheet");
            fileref.setAttribute("type", "text/css");
            fileref.setAttribute("href", filename);
        }
        if (typeof fileref !== "undefined") $("head").append(fileref);
    }

    app.wsystems.wDrillDownReportsChart.loadjscssfile = loadjscssfile;
    
    /**
     * Load css resources
     */
    app.events.once("app:sync:complete", function loadResources() {
        loadjscssfile("custom/src/wsystems/wDrillDownReportsChart/Assets/css/drawer-style.css", "css");
    });

})(SUGAR.App);
