//eslint-disable-next-line
; (function groupedBar(app) {
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};
    app.wsystems.wDrillDownReportsChart.charts = app.wsystems.wDrillDownReportsChart.charts || {};

    window.Chart.Tooltip.positioners.custom = function getTooltipPosition(elements, eventPosition) {
        return {
            x : eventPosition.x,
            y : eventPosition.y
        };
    };

    /**
    * 
    * @param {*} data 
    * @param {*} params 
    */
    function loadChart(data, params) {
        var chart;
        var options = {
            responsive          : true,
            maintainAspectRatio : false,
            legend              : {
                display: false,
            },
            elements: {
                rectangle: {
                    backgroundColor : app.wsystems.wDrillDownReportsChart._colorizeTwoGroupsReport.bind(null, false),
                    borderWidth     : 1,
                }
            },
            scales: {
                xAxes: [{
                    barThickness : params.barThickness, 
                    gridLines    : { //lines perpedicular on this axis
                        display: false
                    },
                    ticks: {
                        display     : true, //labels on ox
                        beginAtZero : true,
                    },
                    offset: true,
                }],
                yAxes: [{
                    //type   : "linearStatic",
                    offset : false,
                    ticks  : {
                        beginAtZero: true,
                    },
                }],
            },
            layout: {
                padding: {
                    bottom: 30
                }
            },
            tooltips: {
                position      : "custom",
                mode          : "nearest",
                displayColors : false,
                callbacks     : {
                    label: function (tooltipItem, data) {
                        var label = [];
                        var valueLabel = "";
                        var corporation = data.datasets[tooltipItem.datasetIndex].label;
                        var isCurrency = params.numericalChartType === "currency";
                        var isDecimal = params.numericalChartType === "decimal";
                        var currencySymbol = App.user.getPreference("currency_symbol");

                        if (corporation === "") {
                            corporation = "Undefined";
                        }

                        valueLabel += corporation + ": ";

                        if (isCurrency === true) {
                            valueLabel += currencySymbol;
                        }

                        if (params.approximate_tooltips === true) {
                            // eslint-disable-next-line no-undef
                            valueLabel += sucrose.utility.numberFormatSI(tooltipItem.value);
                        } else if (isCurrency || isDecimal) {
                            //shows value like 123.49
                            valueLabel += app.wsystems.wDrillDownReportsChart.formatValueNoRounding(tooltipItem.value);
                        } else {
                            valueLabel += tooltipItem.value;
                        }

                        var index = tooltipItem.index;
                        var currentValue = data.datasets[tooltipItem.datasetIndex].data[index].y;
                        var total = 0;
                        data.datasets.forEach(function calculateTotal(el) {
                            var meta = el._meta[Object.keys(el._meta)[0]];
                            if (meta.hidden !== true) {
                                total = total + el.data[index].y;
                            }
                        });

                        // eslint-disable-next-line no-magic-numbers
                        var percentage = parseFloat((currentValue / total * 100).toFixed(2));
                        valueLabel += " - " + percentage + "%";

                        label.push(valueLabel);

                        return label;
                    }

                }
            },
            hover: {
                mode: "nearest",
            },
            onClick: function (evt, item) {
                if (_.isEmpty(item)) {
                    return;
                }

                chart = item[0]._chart;
                var model = item[0]._model;
                var data = chart.data;
                var activePoint = chart.getElementAtEvent(evt)[0];
                var datasetIndex = activePoint._datasetIndex;
                var dataIndex = activePoint._index;

                var group1Val = data.datasets[datasetIndex].data[dataIndex].group1_value;
                var group1Label = model.label;
                var group2Val = data.datasets[datasetIndex].group2_value;
                var group2Label = data.datasets[datasetIndex].label;

                params.wrapperComponent.trigger("chart:click", {
                    // eslint-disable-next-line camelcase
                    group1_filter_value : group1Val,
                    // eslint-disable-next-line camelcase
                    group1_filter_label : group1Label,
                    // eslint-disable-next-line camelcase
                    group2_filter_value : group2Val,
                    // eslint-disable-next-line camelcase
                    group2_filter_label : group2Label,
                });
            },
            legendCallback: function () {
                var text = [];
                text.push("<ul class=\"" + chart.id + "-legend\">");
                var labels = _.pluck(chart.data.datasets, "label");
                for (var i = 0; i < labels.length; i++) {
                    var label = labels[i];
                    var color = app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(label);
                    if (label === "") {
                        label = "Undefined";
                    }
                    text.push("<li class=\"chart_category\" data-index=\"" + i + "\"><i class=\"chart_circle\" style=\"background-color:"
                        + color + "\" /></i><span>" + label + "</span></li>");
                }
                text.push("</ul>");
                return text.join("");
            }
        };

        if (params.legend) {
            options.legend = params.legend;
        }

        if (params.animations === false) {
            options.animation = options.animation || {};
            options.animation.duration = 0;
            options.responsiveAnimationDuration = 0;
            options.hover.animationDuration = 0;
        }
     
        var ctx = $("#" + params.chartId);

        if (params.show_title) {
            options.title = {
                display  : true,
                text     : params.title,
                position : "top",
            };
            if (params.showValues === "total" || params.showBarTotal === true) {
                options.title.padding = 23;
            }
        } else {
            options.title = {
                display  : true,
                position : "top",
            };
            if (params.showValues === "total" || params.showBarTotal === true) {
                options.title.padding = 23;
            } 
        }

        if (params.show_x_label) {
            options.scales.xAxes[0].scaleLabel = {
                display     : true,
                labelString : params.x_axis_label
            };
        }
        
        if (params.show_y_label) {
            options.scales.yAxes[0].scaleLabel = {
                display                 : true,
                displayCustomScaleLabel : true,
                labelString             : params.y_axis_label
            };
        }

        //rotate ticks
        if (params.rotateTicks === true) {
            options.scales.xAxes[0].ticks = {
                autoSkip    : false,
                maxRotation : 45,
                minRotation : 45,
                callback    : function (label, index, values) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    label = App.wsystems.wDrillDownReportsChart.setTickLength(label);
                    return label;
                }
            };
        }

        //stage ticks
        if (params.staggerTicks === true) {
            options.scales.xAxes[0].ticks = {
                callback: function (label, index, labels) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    label = App.wsystems.wDrillDownReportsChart.setTickLength(label);
                    var hairNumber = 2;
                    if (index % hairNumber == 0) {
                        return [" ", label];
                    } else {
                        return label;
                    }
                }
            };
        }

        //wrap ticks
        if (params.wrapTicks === true) {
            options.scales.xAxes[0].ticks = {
                callback: function (label, index, labels) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    if (/\s/.test(label)) {
                        return label.split(" ");
                    } else {
                        return label;
                    }
                }
            };
        }

        if (params.rotateTicks === false && params.staggerTicks === false && params.wrapTicks === false) {
            options.scales.xAxes[0].ticks = {
                callback: function (label, index, values) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    label = App.wsystems.wDrillDownReportsChart.setTickLength(label);
                    return label;
                }
            };
        }

        if (params.stacked) {
            options.scales.xAxes[0].stacked = true;
            options.scales.yAxes[0].stacked = true;
        }

        if (params.showValues === "0") {
            options.plugins = _.extend({}, options.plugins, {
                datalabels      : false,
                axisTicksLabels : false,
                showBarTotal    : params.showBarTotal,
                stacked         : params.stacked,
                position        : params.showValues,
            });
        } else {
            options.plugins = _.extend({}, options.plugins, {
                datalabels         : false,
                axisTicksLabels    : false,
                position           : params.showValues,
                numericalChartType : params.numericalChartType,
                approximateValue   : params.approximate_values,
                showBarTotal       : params.showBarTotal,
                stacked            : params.stacked
            });
        }

        var chartInitOptions = {
            type    : "bar",
            data    : data,
            options : options,
            plugins : [
                window.chartColorOpacityPlugin,
                window.chartBackgroundColorPlugin,
                window.chartAxisLabelsPlugin,
                // window.chartFixedAxisPlugin,
                window.groupedBarChartPlugin,
                window.elementShadingPlugin,
                window.legendLabelsPlugin
            ],
        };
        chart = new window.Chart(ctx, chartInitOptions);
        return chart;
    }

    /**
     *  Uses multiple datasets. Each dataset has multiple values
            Mapping:
            - group1 : dataset -> data[] (each of these are shown on base axis.
                the labels are given to result object explicitly)
            - group2 : dataset (dataset.label)
     * @param {*} serverData 
     * @param {*} params 
     */
    function translateData(serverData, params) {
        var translatedData = {
            datasets : [],
            labels   : []
        };
        var sortMask = [];
        var firstGroupValuesNew = [];
        var firstGroupLabelsNew = [];
        var firstGroupsAllCountNew = [];
        var secondGroupLabelsNew = [];
        var secondGroupValuesNew = [];
        var secondGroupAllCountNew = [];

        /*eslint-disable*/
        //parse server data to generate lists
        var firstGroupValues = _.unique(_.pluck(serverData.data, "group1_value"));
        var firstGroupLabels = _.unique(_.pluck(serverData.data, "group1_label"));
        var firstGroupsAllCount = [];//sum of each entire category
        _.each(firstGroupValues, function (v) {
            var sum = 0;
            _.each(serverData.data, function (d) {
                if (d.group1_value == v)
                    sum += d.chartColumn;
            });
            firstGroupsAllCount.push(sum);
        });
        var secondGroupLabels = serverData.properties.sort;//default sort (made on server side)
        var secondGroupValues = [];
        _.each(secondGroupLabels, function (label) {
            var element = _.find(serverData.data, function (d) {
                return d.group2_label === label;
            });
            secondGroupValues.push(element.group2_value);
        });
        var secondGroupAllCount = [];//sum of each value (from secondGroupValues) for each category
        _.each(secondGroupValues, function (val) {
            var sum = 0;
            _.each(serverData.data, function (d) {
                if (d.group2_value === val) {
                    sum += d.chartColumn;
                }
            });
            secondGroupAllCount.push(sum);
        });

        //sort data based on dashlet configuration
        if (_.isEmpty(params.group1Sort) === false && params.group1Sort !== "default") { //sort base axis
            sortMask = [];
            if (params.group1Sort == "asc" || params.group1Sort == "desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, firstGroupLabels, firstGroupLabels);
            } else if (params.group1Sort == "value-asc" || params.group1Sort == "value-desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, firstGroupsAllCount, firstGroupLabels);
            }
            firstGroupLabelsNew = [];
            firstGroupValuesNew = [];
            firstGroupsAllCountNew = [];
            for (var i = 0; i < firstGroupLabels.length; i++) {
                firstGroupLabelsNew[i] = firstGroupLabels[sortMask[i]];
                firstGroupValuesNew[i] = firstGroupValues[sortMask[i]];
                firstGroupsAllCountNew[i] = firstGroupsAllCount[sortMask[i]];
            }
            firstGroupLabels = firstGroupLabelsNew;
            firstGroupValues = firstGroupValuesNew;
            firstGroupsAllCount = firstGroupsAllCountNew;
        }
        if (_.isEmpty(params.group2Sort) === false && params.group2Sort !== "default") { //sort values in a group
            sortMask = [];
            if (params.group2Sort == "asc" || params.group2Sort == "desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group2Sort, secondGroupLabels, secondGroupLabels);
            } else if (params.group2Sort == "value-asc" || params.group2Sort == "value-desc") {
                sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group2Sort, secondGroupAllCount, secondGroupLabels);
            }
            secondGroupLabelsNew = [];
            secondGroupValuesNew = [];
            secondGroupAllCountNew = [];
            for (var i = 0; i < secondGroupLabels.length; i++) {
                secondGroupLabelsNew[i] = secondGroupLabels[sortMask[i]];
                secondGroupValuesNew[i] = secondGroupValues[sortMask[i]];
                secondGroupAllCountNew[i] = secondGroupAllCount[sortMask[i]];
            }
            secondGroupLabels = secondGroupLabelsNew;
            secondGroupValues = secondGroupValuesNew;
            secondGroupAllCount = secondGroupAllCountNew;
        }

        var datasets = [];
        _.each(secondGroupValues, function createTheDatasetScheleton(secondGroupValue, secondGroupIndex) {
            var prototypeValues = _.map(firstGroupValues, function (v, vidx) {
                var newValue;
                if (params.chartType == "horizontal group by chart") {
                    newValue = {
                        group1_value: v,
                        x: 0,
                        y: vidx
                    };
                } else {
                    newValue = {
                        group1_value: v,
                        x: vidx,
                        y: 0
                    };
                }
                return newValue;
            });

            var group2Label = secondGroupLabels[secondGroupIndex];
            var hexColor = app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(group2Label);
            datasets.push({
                label: group2Label,
                group2_value: secondGroupValue,
                data: prototypeValues,
            });
        });

        _.each(serverData.data, function wearTheScheleton(d) {
            var localDataserie = _.find(datasets, function (dsr) {
                return d.group2_value === dsr.group2_value;
            });
            if (localDataserie) {
                var valueInThisSerie = _.find(localDataserie.data, function (vals) {
                    return vals.group1_value === d.group1_value;
                });
                if (valueInThisSerie) {//set value (non empty group)
                    var chartType = app.wsystems.wDrillDownReportsChart.getChartType(params.chart_type);
                    if (chartType == "horizontal group by chart") {
                        valueInThisSerie.x = valueInThisSerie.x + d.chartColumn;
                    } else {
                        valueInThisSerie.y = valueInThisSerie.y + d.chartColumn;
                    }
                }
            }
        });
        translatedData.datasets = datasets;
        translatedData.labels = firstGroupLabels;//shown on the base axis

        return translatedData;
    }

    app.wsystems.wDrillDownReportsChart.charts.groupedBar = {
        loadChart: loadChart,
        translateData: translateData
    };
})(SUGAR.App);