//eslint-disable-next-line
; (function line(app) {
    app.wsystems.wDrillDownReportsChart = app.wsystems.wDrillDownReportsChart || {};
    app.wsystems.wDrillDownReportsChart.charts = app.wsystems.wDrillDownReportsChart.charts || {};
        
    /**
     * 
     * @param {Object} params 
     */
    function loadChart(data, params) {
        var options = {
            responsive          : true,
            maintainAspectRatio : false,
            legend              : {
                display: false
            },
            scales: {
                xAxes: [{
                    display  : true,
                    position : "bottom",
                   
                    ticks: {
                        display: true
                    }
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                    }
                }],
            },
            elements: {
                line: {
                    borderColor     : app.wsystems.wDrillDownReportsChart._colorizeLineReport.bind(null, false),
                    backgroundColor : app.wsystems.wDrillDownReportsChart._colorizeLineReport.bind(null, false),
                    fill            : false,
                    borderWidth     : 2,
                }
            },
            tooltips: {
                mode          : "nearest",
                displayColors : false,
                callbacks     : {
                    label: function(tooltipObj, data){
                        if (params.approximate_tooltips === true) {
                            // eslint-disable-next-line no-undef
                            return sucrose.utility.numberFormatSI(tooltipObj.value);
                        } else {
                            return tooltipObj.value;
                        }
                    },
                    title: function(tooltipItem, data) {
                        if (data.labels[tooltipItem[0].index] === ""){
                            data.labels[tooltipItem[0].index] = "Undefined";
                        }
                        return data.labels[tooltipItem[0].index];
                    }
                }
            },
            hover: {
                mode: "nearest",
            },

            /*eslint-disable*/
            onClick: function (evt, item) {
                if (_.isEmpty(item)) {
                    return;
                }
                chart = item[0]._chart;
                var elementClicked = chart.getElementAtEvent(evt);
                var datasetIndex = elementClicked[0]._datasetIndex;
                var dataIndex = elementClicked[0]._index;
                if (chart.config.groupType == "simple") {
                    var baseAxisValue = chart.data.baseAxisValues[dataIndex];
                    var baseAxisLabel = chart.data.labels[dataIndex];
                    params.wrapperComponent.trigger("chart:click", {
                        group1_filter_value : baseAxisValue,
                        group1_filter_label : baseAxisLabel
                    });
                } else {
                    var categoryValue = chart.data.datasets[datasetIndex].categoryValue;
                    var categoryLabel = chart.data.datasets[datasetIndex].label;
                    var baseAxisValue = chart.data.baseAxisValues[dataIndex];
                    var baseAxisLabel = chart.data.labels[dataIndex];
                    params.wrapperComponent.trigger("chart:click", {
                        group1_filter_value : categoryValue,
                        group1_filter_label : categoryLabel,
                        group2_filter_value : baseAxisValue,
                        group2_filter_label : baseAxisLabel,
                    });
                }
            },
            legendCallback: function(chart) {
                var text = [];
                var labels;
                text.push("<ul class=\"" + chart.id + "-legend\">");
                if (params.groupType == "simple") {
                    labels = chart.data.labels;
                } else {
                    labels = _.pluck(chart.data.datasets, "label");
                }
                for (var i = 0; i < labels.length; i++) {
                    var label = labels[i];
                    var color = app.wsystems.wDrillDownReportsChart._getColorBasedOnValue(label);
                    if (label === ""){
                        label = "Undefined";
                    }
                    text.push("<li class=\"chart_category\" data-index=\"" + i + "\"><i class=\"chart_circle\" style=\"background-color:"
                    + color + "\"/></i><span>" + label + "</span></li>");
                }
                text.push("</ul>");
                return text.join("");
            }
        };

        if (params.animations === false) {
            options.animation = options.animation || {};
            options.animation.duration = 0;
            options.responsiveAnimationDuration = 0;
            options.hover.animationDuration = 0;
        }

        
        var ctx = $("#" + params.chartId);

        if (params.show_title) {
            options.title = {
                display  : true,
                text     : params.title,
                position : "top",
            };
        }
        if (params.show_x_label) {
            options.scales.xAxes[0].scaleLabel = {
                display     : true,
                labelString : params.x_axis_label
            };
        }
        if (params.show_y_label) {
            options.scales.yAxes[0].scaleLabel = {
                display     : true,
                labelString : params.y_axis_label
            };
        }
       
        //stage ticks
        if (params.staggerTicks === true){
            options.scales.xAxes[0].ticks = {
                autoSkip: false,
                maxRotation : 0,
                minRotation : 0,
                callback: function (label, index, labels) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    var hairNumber = 2;
                    if (label.length > 3){
                        label = label.slice(0, 5) + "..";
                        if (index % hairNumber == 0) {
                            return [" ", label];
                        } else {
                            return label;
                        } 
                    }
                }
            };
        }

         //rotate ticks
         if (params.rotateTicks === true){
            options.scales.xAxes[0].ticks = {
                autoSkip    : false,
                maxRotation : 45,
                minRotation: 45,
                callback: function (label, index, values) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    return label; 
                }
            };
         }
        
        //wrap ticks
        if (params.wrapTicks === true) {
            options.scales.xAxes[0].ticks = {
                callback: function (label, index, labels) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    return label;
                }
            };
        }
        
        if (params.rotateTicks === false && params.staggerTicks === false && params.wrapTicks === false) {
            options.scales.xAxes[0].ticks = {
                callback: function (label, index, values) {
                    if (label === "") {
                        label = "Undefined";
                    }
                    return label; 
                }
            };
        }

        options.plugins = {
            datalabels      : false,
            axisTicksLabels : false
        };

        var chart = new window.Chart(ctx, {
            type      : "line",
            data      : data,
            options   : options,
            groupType : params.groupType,
            plugins   : [
                window.chartColorOpacityPlugin, 
                window.chartBackgroundColorPlugin,
                window.elementShadingPlugin,
                window.legendLabelsPlugin
            ],
        });
        return chart;
    }

    /**
     *  reports with one group   : base axis labels are on group1 for this use case
         - one dataset and multiple values -
        reports with 2 groups    : this chart will show multiple datasets.
                                base axis labels are on group2
         - multiple datasets with multiple values -
     * @param {*} serverData 
     * @param {*} params 
     */
   
    function translateData(serverData, params) {
        var translatedData = {
            datasets : [],
            labels   : []
        };

        if (params.groupType == "simple") {
            var baseAxisValues = _.pluck(serverData.data, "group1_value");
            var baseAxisLabels = _.pluck(serverData.data, "group1_label");
            var baseAxisCounts = _.pluck(serverData.data, "chartColumn");

            //hide empty groups by default
            var baseAxisValuesNew = [];
            var baseAxisLabelsNew = [];
            var baseAxisCountsNew = [];
            for (var countIndex = 0; countIndex < baseAxisCounts.length; countIndex++) {
                if (baseAxisCounts[countIndex] != 0) {
                    baseAxisValuesNew.push(baseAxisValues[countIndex]);
                    baseAxisLabelsNew.push(baseAxisLabels[countIndex]);
                    baseAxisCountsNew.push(baseAxisCounts[countIndex]);
                }
            }
            baseAxisValues = baseAxisValuesNew;
            baseAxisLabels = baseAxisLabelsNew;
            baseAxisCounts = baseAxisCountsNew;

            //sort data based on dashlet configuration
            if (_.isEmpty(params.group1Sort) === false && params.group1Sort !== "default") {
                var sortMask = [];
                if (params.group1Sort == "asc" || params.group1Sort == "desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, baseAxisValues, baseAxisLabels);
                } else if (params.group1Sort == "value-asc" || params.group1Sort == "value-desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(params.group1Sort, baseAxisCounts, baseAxisLabels);
                }
                var baseAxisValuesNew = [];
                var baseAxisLabelsNew = [];
                var baseAxisCountsNew = [];
                for (var i = 0; i < baseAxisValues.length; i++) {
                    baseAxisValuesNew[i] = baseAxisValues[sortMask[i]];
                    baseAxisLabelsNew[i] = baseAxisLabels[sortMask[i]];
                    baseAxisCountsNew[i] = baseAxisCounts[sortMask[i]];
                }
                baseAxisValues = baseAxisValuesNew;
                baseAxisLabels = baseAxisLabelsNew;
                baseAxisCounts = baseAxisCountsNew;
            }

            var dataset = {
                label : _.isEmpty(params.x_axis_label) ? params.reportModule : params.x_axis_label,
                data  : baseAxisCounts,
                fill: false,
                dataValues: baseAxisValues,
            };
            translatedData.datasets = [dataset];
            translatedData.labels = baseAxisLabels;
            translatedData.baseAxisValues = baseAxisValues;
        } else {
            //parse server data to generate lists
            var categoriesKeys = _.pluck(serverData.data, "group1_value");
            categoriesKeys = _.uniq(categoriesKeys);
            var categoriesLabels = _.pluck(serverData.data, "group1_label");
            categoriesLabels = _.uniq(categoriesLabels);
            var baseAxisLabels = serverData.properties.sort;//default sort (made on server side)
            baseAxisLabels = _.uniq(baseAxisLabels);
            var baseAxisKeys = [];
            _.each(baseAxisLabels, function(label) {
                var element = _.find(serverData.data, function(d) {
                    return d.group2_label === label;
                });
                baseAxisKeys.push(element.group2_value);
            });
            var categoriesCounts = [];//sum of each entire category
            _.each(categoriesKeys, function(v) {
                var sum = 0;
                _.each(serverData.data, function(d) {
                    if (d.group1_value == v)
                        sum += d.chartColumn;
                });
                categoriesCounts.push(sum);
            });

            var baseAxisAllCount = [];//sum of each value (from base axis) for each category
            _.each(baseAxisKeys, function(val) {
                var sum = 0;
                _.each(serverData.data, function(d) {
                    if (d.group2_value === val) {
                        sum += d.chartColumn;
                    }
                });
                baseAxisAllCount.push(sum);
            });

            //hide empty groups by default
            var categoriesKeysNew = [];
            var categoriesLabelsNew = [];
            var categoriesCountsNew = [];
            for (var countIndex = 0; countIndex < categoriesCounts.length; countIndex++) {
                if (categoriesCounts[countIndex] != 0) {
                    categoriesKeysNew.push(categoriesKeys[countIndex]);
                    categoriesLabelsNew.push(categoriesLabels[countIndex]);
                    categoriesCountsNew.push(categoriesCounts[countIndex]);
                }
            }
            categoriesKeys = categoriesKeysNew;
            categoriesLabels = categoriesLabelsNew;
            categoriesCounts = categoriesCountsNew;

            var baseAxisSort = params.group1Sort;
            var legendSort = params.group2Sort;
                        
            //sort data based on dashlet configuration
            if (_.isEmpty(baseAxisSort) === false && baseAxisSort !== "default") { //sort base axis
                var sortMask = [];
                if (baseAxisSort == "asc" || baseAxisSort == "desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(baseAxisSort, baseAxisLabels, baseAxisLabels);
                } else if (baseAxisSort == "value-asc" || baseAxisSort == "value-desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(baseAxisSort, baseAxisAllCount, baseAxisLabels);
                }
                var baseAxisLabelsNew = [];
                var baseAxisKeysNew = [];
                var baseAxisAllCountNew = [];
                for (var i = 0; i < baseAxisLabels.length; i++) {
                    baseAxisLabelsNew[i] = baseAxisLabels[sortMask[i]];
                    baseAxisKeysNew[i] = baseAxisKeys[sortMask[i]];
                    baseAxisAllCountNew[i] = baseAxisAllCount[sortMask[i]];
                }
                baseAxisLabels = baseAxisLabelsNew;
                baseAxisKeys = baseAxisKeysNew;
                baseAxisAllCount = baseAxisAllCountNew;
            }
            if (_.isEmpty(legendSort) === false && legendSort !== "default") { //sort values in a group
                var sortMask = [];
                if (legendSort == "asc" || legendSort == "desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(legendSort, categoriesLabels, categoriesLabels);
                } else if (legendSort == "value-asc" || legendSort == "value-desc") {
                    sortMask = app.wsystems.wDrillDownReportsChart.getSortMask(legendSort, categoriesCounts, categoriesLabels);
                }
                var categoriesLabelsNew = [];
                var categoriesKeysNew = [];
                var categoriesCountsNew = [];
                for (var i = 0; i < categoriesLabels.length; i++) {
                    categoriesLabelsNew[i] = categoriesLabels[sortMask[i]];
                    categoriesKeysNew[i] = categoriesKeys[sortMask[i]];
                    categoriesCountsNew[i] = categoriesCounts[sortMask[i]];
                }
                categoriesLabels = categoriesLabelsNew;
                categoriesKeys = categoriesKeysNew;
                categoriesCounts = categoriesCountsNew;
            }

            var datasets = [];
            _.each(categoriesLabels, function generateDatasets(categoryLabel, categoryLabelIdx) {
                var categoryKey = categoriesKeys[categoryLabelIdx];
                var dataset = {
                    label         : categoryLabel,
                    data          : [],
                    categoryValue : categoryKey,
                };
                _.each(baseAxisLabels, function generateScheletonData(baseAxisLabel, baseAxisLabelIdx) {
                    dataset.data.push(0);
                });
                _.each(serverData.data, function wearTheScheleton(d) {
                    var idxOfThisValue = baseAxisKeys.indexOf(d.group2_value);
                    if (idxOfThisValue >= 0 && d.group1_value === categoryKey) {
                        dataset.data[idxOfThisValue] += d.chartColumn;
                    }
                });
                datasets.push(dataset);
            });
            translatedData.datasets = datasets;
            translatedData.labels = baseAxisLabels;
            translatedData.baseAxisValues = baseAxisKeys;
        }
        return translatedData;

    }
    /*eslint-enable*/

    app.wsystems.wDrillDownReportsChart.charts.line = {
        loadChart     : loadChart,
        translateData : translateData
    };
})(SUGAR.App);