// eslint-disable-next-line
; (function processFiltersOnDashboardDuplicate(app) {
    var dashboardFabViewExtension = {
        duplicateClicked: function (evt) {
            //add param to identify the Duplicate action and process filters further
            this.model.set("sourceDashboard", this.model.get("id"), { silent: true });

            //needed to send the param to API
            SUGAR.App.metadata.getModule("Dashboards").fields["sourceDashboard"] = { name: "sourceDashboard" };
            var initResult = this._super("duplicateClicked", arguments);
            delete SUGAR.App.metadata.getModule("Dashboards").fields.sourceDashboard;

            return initResult;
        },

        /**
         * Sugar 10.2 function
         */
        _successWhileSave: function (change, model) { 
            if (this.disposed) {
                return;
            }
            this.model.unset("sourceDashboard", { silent: true });
            delete this.model.changed.sourceDashboard;

            var initResult = this._super("_successWhileSave", arguments);
            return initResult; //eslint-disable-line consistent-return
        },

        /**
         * Sugar 10.2 function
         */
        _errorWhileSave: function () { 
            if (this.disposed) {
                return;
            }
            this.model.unset("sourceDashboard", { silent: true });
            delete this.model.changed.sourceDashboard;
            
            var initResult = this._super("_errorWhileSave", arguments);
            return initResult; //eslint-disable-line consistent-return
        },

        /**
         * Sugar 10.3 function
         */
        handleSuccessfulSave: function (change, model) {
            if (this.disposed) {
                return;
            }
            this.model.unset("sourceDashboard", { silent: true });
            delete this.model.changed.sourceDashboard;

            var initResult = this._super("handleSuccessfulSave", arguments);
            return initResult; //eslint-disable-line consistent-return
        },

        /**
         * Sugar 10.3 function
         */
        handleFailedSave: function () { 
            if (this.disposed) {
                return;
            }
            this.model.unset("sourceDashboard", { silent: true });
            delete this.model.changed.sourceDashboard;
            
            var initResult = this._super("handleFailedSave", arguments);
            return initResult; //eslint-disable-line consistent-return
        }
    };

    /**
     * Code for Sugar 10.2
     */
    app.events.once("app:sync:complete", function drilldownDashboardDuplicate() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", "Dashboards", "view", "dashboard-headerpane", dashboardFabViewExtension);
    });

    /**
     * Code for Sugar 10.3
     */
    app.events.once("app:start", function drilldownDashboardDuplicate() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "view", "dashboard-fab", dashboardFabViewExtension);
    });

})(SUGAR.App);
