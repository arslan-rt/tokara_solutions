/**
 * Fixes force refresh action
 *
 * @class dashletRefresh
 */
// eslint-disable-next-line
; (function dashletRefresh(app) {
    var dashletLayoutExtension = {
        reloadDashlet: function(options) {
            var drilldownView = this.getComponent("w-saved-reports-chart");
            var reloadResult;

            if (typeof drilldownView == "undefined") {
                reloadResult = this._super("reloadDashlet", arguments);
            } else {
                options.forceRefresh = true;

                drilldownView.reportData.set("chartData", {}, { silent: true });

                //this follow action will call component.loadData(options)
                reloadResult = this._super("reloadDashlet", [options]);
            }
            return reloadResult;
        }
    };

    app.events.once("app:start", function drilldownDashletRefresh() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "layout", "dashlet", dashletLayoutExtension);
        //solution for 10.2+
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "layout", "dashlet-grid-wrapper", dashletLayoutExtension);
    });

})(SUGAR.App);
