// eslint-disable-next-line
; (function refreshOnMerge(app) {
    app.events.on("drilldown:update", function refreshChart(method, collection, options) {
        var drillDownDrawer = app.drawer.getComponent("drilldown-drawer");
        if (typeof drillDownDrawer != "undefined") {
            drillDownDrawer.updatePanelChartWhenPossible();
            drillDownDrawer.updateLists();
        }
    });
})(SUGAR.App);
