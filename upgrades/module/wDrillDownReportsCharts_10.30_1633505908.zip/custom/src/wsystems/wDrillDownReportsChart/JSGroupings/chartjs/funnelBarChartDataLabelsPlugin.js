/**
 * ChartJS shows the elements transparent by default and opaque on hover, while Sucrose does the opposite
 * This plugin changes that in order to work as Sucrose does.
 */
// eslint-disable-next-line
;var funnelBarChartPlugin = {
    afterDatasetsDraw: function (chart, options) {
        var chartInstance = chart;
        var ctx = chartInstance.ctx;
        ctx.textAlign = "left";
        ctx.font = "12px Open Sans, Helvetica Neue, Arial, sans-serif";
        ctx.fillStyle = "#000000";

        var approximateValues = chart.options.plugins.approximateValue;
        var isCurrency = chart.options.plugins.numericalChartType === "currency";
        var isDecimal = chart.options.plugins.numericalChartType === "decimal";
        var currencySymbol = App.user.getPreference("currency_symbol");
                
        chart.data.datasets.forEach(function iterateLegend(dataset, i) {
            var meta = chartInstance.controller.getDatasetMeta(i);
            // eslint-disable-next-line consistent-return
            meta.data.forEach(function iterateColumns(bar, index) {
                var data = dataset.data[bar._index];
                var corners = bar._cornersCache;
                var bottomLeftCornerIndex = 0;
                var topLeftCornerIndex = 1;
                var yAxisIndex = 1;
                var bottomYPos = corners[bottomLeftCornerIndex][yAxisIndex];
                var topYPos = corners[topLeftCornerIndex][yAxisIndex] ;
                        
                var elementHeight = bottomYPos - topYPos;
                var fontHeight = 12;
                        
                if (parseFloat(elementHeight) < parseFloat(fontHeight)) {
                    return "";
                }

                var isWhite = App.wsystems.wDrillDownReportsChart.whiteColor(dataset.backgroundColor[bar._index]);
                        
                if (isWhite) {
                    ctx.fillStyle = "#000000";
                } else {
                    ctx.fillStyle = "#FFFFFF";    
                }

                var labelWidth = "";
                var fontWidth = 12;
                        
                if (approximateValues === true) {
                    //eslint-disable-next-line
                    data = sucrose.utility.numberFormatSI(data);
                    labelWidth = data.length * fontWidth;
                } else if (isCurrency || isDecimal) {
                    //shows value like 123.49
                    data = App.wsystems.wDrillDownReportsChart.formatValueNoRounding(data);
                    labelWidth = data.length * fontWidth;
                }
                        
                // eslint-disable-next-line no-magic-numbers
                var labelPositionX = bar._view.x - labelWidth / 3;
                // eslint-disable-next-line no-magic-numbers
                var labelPositionY = bottomYPos - (bottomYPos - topYPos) / 2 + fontHeight / 2; 

                if (isCurrency === true){
                    data = currencySymbol + data;
                }

                if (i == 0){
                    ctx.fillText(data, labelPositionX, labelPositionY);
                } 
            });
        });
    }
};
