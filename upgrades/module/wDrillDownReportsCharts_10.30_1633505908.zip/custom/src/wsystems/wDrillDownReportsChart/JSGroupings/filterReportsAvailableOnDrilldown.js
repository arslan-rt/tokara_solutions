// eslint-disable-next-line
; (function filterReportsAvailableOnDrilldown(app) {
    var relateFieldExtension = {
        _createSearchCollection: function() {
            var initResult = this._super("_createSearchCollection", arguments);
            if (this.view.name === "w-saved-reports-chart") {
                var waitForANewRequest = app.config.requiredElapsed || 500; // eslint-disable-line
                var endpoint = _.debounce(function debouncedDrilldownReportEndPoint(method, model, options, callbacks) {
                    var url = app.api.buildURL("Reports", "drilldown", {}, options.params);
                    return app.api.call("read", url, {}, callbacks);
                }, waitForANewRequest);
                this.searchCollection.setOption("endpoint", _.bind(endpoint, this));
            }
            return initResult;
        },

        openSelectDrawer: function() {
            try {
                if (this.view.name === "w-saved-reports-chart") {
                    app.controller.context.set("wSavedReportChart", true);
                } else {
                    app.controller.context.set("wSavedReportChart", false);
                }
            } catch (e) {
                window.console.log("Problem while handle drilldown reports list");
            }

            var initRes = this._super("openSelectDrawer", arguments);
            return initRes;
        }
    };

    var selectionListViewExtension = {
        initialize: function(options) {
            var initResult = this._super("initialize", arguments);

            if (app.controller.context.get("wSavedReportChart")) {
                var waitForANewRequest = app.config.requiredElapsed || 500; // eslint-disable-line
                var endpoint = _.debounce(function debouncedDrilldownReportEndPoint(method, model, options, callbacks) {
                    var url = app.api.buildURL("Reports", "drilldown", {}, options.params);
                    return app.api.call("read", url, {}, callbacks);
                }, waitForANewRequest);
                this.collection.setOption("endpoint", _.bind(endpoint, this));
            }

            return initResult;
        }
    };

    app.events.once("app:start", function wDrillDownReportsChartExtension() {
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "field", "relate", relateFieldExtension);
        app.wsystems.wDrillDownReportsChart.extendComponent("base", null, "view", "selection-list", selectionListViewExtension);
    });

})(SUGAR.App);
