/**
 * Loads users into an accessible location
 *
 * @class loadUsers
 */
// eslint-disable-next-line
; (function loadUsers(app) {
    app.events.on("app:sync:complete", function registerLoadUsers() {
        app.wsystems.wDrillDownReportsChart.loadUsers();
    });

})(SUGAR.App);
