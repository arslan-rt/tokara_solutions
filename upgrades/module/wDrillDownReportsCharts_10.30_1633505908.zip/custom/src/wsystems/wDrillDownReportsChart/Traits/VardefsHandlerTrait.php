<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Traits;

use BeanFactory;
use DBManagerFactory;
use Doctrine\DBAL\DBALException;
use Doctrine\DBAL\Query\QueryException;
use DynamicField;
use Exception;
use MetaDataFileInterface;
use MetaDataFiles;
use ParserLabel;
use ReflectionException;
use RepairAndClear;
use StudioModule;
use StudioModuleFactory;
use SugarApiExceptionNotFound;
use SugarAutoLoader;
use Sugarcrm\Sugarcrm\Security\InputValidation\Exception\ViolationException;
use SugarException;
use VardefManager;

/**
 * *** VardefsHandlerTrait ***
 *
 * This trait manipulates fields metadata.
 *
 * @package SamplePackage
 * @author Vali Bratulescu
 * @version 1.0.7
 * @since SugarCRM 8.0
 * @since PHP 7.1
 */
trait VardefsHandlerTrait
{
    /**
     * Creates/updates vardef extension file for a specific field.
     * This method uses Sugar's default pattern for vardef files: "sugarfield_<field_name>.php"
     * In order to have vardefs put in a custom file, @see vardefCustomFileWrite method.
     * In order to remove this file, @see vardefFileDelete method.
     *
     * <code>
     *
     * $this->vardefFileWrite("Accounts", [
     *      "vname" => "LBL_TEST_LABEL",
     *      "name"  => "name",
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $meta
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFileWrite(string $module, array $meta): void
    {
        list($df, $obj, $field) = $this->vardefPrepare($module, $meta);

        $df->writeVardefExtension($obj, $field, $meta);
    }

    /**
     * Creates/updates vardef extension files for multiple fields at once.
     *
     * <code>
     *
     * $this->vardefFileWriteMulti("Accounts", [
     *     [
     *         "vname" => "LBL_TEST_LABEL",
     *         "name"  => "name",
     *     ],
     *     [
     *         "vname" => "LBL_SIC_CODE",
     *         "name"  => "sic_code",
     *     ],
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $fieldDefs
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFileWriteMulti(string $module, array $fieldDefs): void
    {
        foreach ($fieldDefs as $meta) {
            $this->vardefFileWrite($module, $meta);
        }
    }

    /**
     * Removes standard vardef file for a specific module and field.
     * For example, the standard vardef file path for Accounts module and sic_code field whould be:
     *
     * "custom/Extension/modules/Accounts/sugarfield_sic_code.php".
     *
     * @param string $module
     * @param string $fieldName
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFileDelete(string $module, string $fieldName): void
    {
        $meta = [
            "name" => $fieldName,
        ];

        list($df, $obj, $field) = $this->vardefPrepare($module, $meta);

        $df->removeVardefExtension($field);
    }

    /**
     * Removes standard vardef files for multiple fields at once.
     *
     * <code>
     *
     * $this->vardefFileDeleteMulti("Accounts", [
     *     "sic_code", "industry", "description"
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $fieldNames
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFileDeleteMulti(string $module, array $fieldNames = []): void
    {
        foreach ($fieldNames as $fieldName) {
            $this->vardefFileDelete($module, $fieldName);
        }
    }

    /**
     * Creates/updates vardef extension file for a specific field.
     * This method allows putting vardefs metadata in custom file,
     * named as the package whose functionality it is part of.
     * In order to remove this file, @see vardefCustomFileDelete method.
     *
     * <code>
     *
     * $this->vardefCustomFileWrite("Opportunities", [
     *      "convertToBase" => true,
     *      "name"          => "amount",
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $meta
     * @param bool $append True to append output to the file, false to rewrite the file
     *
     * @return void
     */
    public function vardefCustomFileWrite(string $module, array $meta, bool $append = true): void
    {
        $name = $meta["name"];

        $file = $this->vardefFileNameBuild($module);

        $output = "";

        if ($append === true) {
            $output = \sugar_file_get_contents($file) ?? "";
        }

        if (empty(trim($output))) {
            $output = "<?php";
        }

        $output .= "\r\n";

        foreach ($meta as $property => $value) {
            $output .= override_value_to_string_recursive(
                [
                    BeanFactory::getObjectName($module),
                    "fields",
                    $name,
                    $property,
                ],
                "dictionary",
                $value
            );
        }

        AutoLoaderHelper::fileAddContent($file, $output);
    }

    /**
     * Removes `<package_name>_vardef.php` vardef file for a specific module.
     * For example, the custom vardef file path for Accounts module would be:
     *
     * "custom/Extension/modules/Accounts/SamplePackage_vardef.php".
     *
     * @see vardefFileNameBuild
     *
     * @param string $module
     *
     * @return void
     */
    public function vardefCustomFileDelete(string $module): void
    {
        $file = $this->vardefFileNameBuild($module);

        AutoLoaderHelper::fileDelete($file);
    }

    /**
     * Removes `<package_name>_vardef.php` vardef files multiple modules at once.
     *
     * @param array $modules
     *
     * @return void
     */
    public function vardefCustomFileDeleteMulti(array $modules = []): void
    {
        foreach ($modules as $module) {
            $this->vardefCustomFileDelete($module);
        }
    }

    /**
     * Creates a new field programatically by adding it into the fields_meta_data table.
     *
     * <code>
     *
     * $this->vardefFieldCreate("Accounts",  [
     *     "name"   => "filter_test_c",
     *     "label"  => "LBL_FILTER",
     *     "type"   => "filter",
     *     "dbType" => "text",
     *     "module" => "Contacts",
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $meta
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFieldCreate(string $module, array $meta): void
    {
        $name = $meta["name"];

        if (empty(trim($name))) {
            throw new SugarException("Fail to create vardef for field {$name} on {$module}. Field name is empty.");
        }

        $this->vardefRefresh($module);

        list($df, $obj, $field) = $this->vardefPrepare($module, $meta);

        if ($df->fieldExists($meta["name"], $meta["type"])) {
            throw new SugarException(
                "Fail to create vardef for field {$name}. Field already found in fields_meta_data for module {$module}."
            );
        }

        $field->save($df);

        $this->vardefRefresh($module);
    }

    /**
     * Creates multiple fields programatically at once.
     *
     * @param string $module
     * @param array $fieldDefs
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFieldCreateMulti(string $module, array $fieldDefs): void
    {
        foreach ($fieldDefs as $meta) {
            $this->vardefFieldCreate($module, $meta);
        }
    }

    /**
     * Updates field metadata.
     * It searches the field in the fields_meta_data table and update its meta accordingly.
     * In order to do the same for non-custom fields, it is recommended to use `vardefFileWrite` method,
     * as these fields are not stored in the database but in vardef files.
     *
     * <code>
     *
     * $this->vardefFieldCreate("Accounts",  [
     *     "name"        => "filter_test_c",
     *     "type"        => "filter",
     *     "moduleField" => "Contacts",
     * ]);
     *
     * </code>
     *
     * @param string $module
     * @param array $meta
     *
     * @return void
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFieldUpdate(string $module, array $meta): void
    {
        $name = $meta["name"];

        if (empty(trim($name))) {
            throw new SugarException("Fail to create vardef for field {$name} on {$module}. Field name is empty.");
        }

        $this->vardefRefresh($module);

        list($df, $obj, $field) = $this->vardefPrepare($module, $meta);

        if ($df->fieldExists($meta["name"], $meta["type"]) === false) {
            throw new SugarException(
                "Fail to create vardef for field {$name}. Field not found in fields_meta_data for module {$module}."
            );
        }

        $field->save($df);

        $this->vardefRefresh($module);
    }

    /**
     * Retrieves field definition.
     *
     * @param string $module
     * @param string $fieldName
     *
     * @return null|array
     */
    public function vardefMetaGet(string $module, string $fieldName): ?array
    {
        $meta = BeanFactory::newBean($module)->getFieldDefinition($fieldName);

        if (\is_array($meta)) {
            return $meta;
        }

        return null;
    }

    /**
     * Runs quick repair and rebuild.
     *
     * Available actions:
     *
     * [
     *     'repairDatabase'
     *     'rebuildExtensions'
     *     'clearTpls'
     *     'clearJsFiles'
     *     'clearDashlets'
     *     'clearThemeCache'
     *     'clearJsLangFiles'
     *     'rebuildAuditTables'
     *     'clearSearchCache'
     *     'clearAdditionalCaches'
     *     'repairMetadataAPICache'
     *     'clearPDFFontCache'
     *     'resetForecasting'
     *     'repairConfigs'
     *     'clearAll'
     * ]
     *
     * @param array $modules List of modules to repair and rebuild vardefs for
     * @param array|null $actions List of actions to be executed
     *                            By default, `clearAll` action will be used, namely, all actions will be executed
     * @param bool $autoExecute True to automatically execute potential queries generated by the QRR process
     * @param bool $showOutput True to show QRR output
     * @param string $metadataSection Name of the metadata section to be repaired
     *                                Blank value means that all sections will be repaired
     *
     * @return void
     *
     * @throws SugarApiExceptionNotFound
     * @throws ReflectionException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefRepairAndRebuild(
        array $modules,
        array $actions = null,
        bool $autoExecute = true,
        bool $showOutput = false,
        string $metadataSection = ""
    ): void {

        $qrr = new RepairAndClear();

        if (empty($actions)) {
            $actions = [
                "clearAll",
            ];
        }

        $qrr->repairAndClearAll($actions, $modules, $autoExecute, $showOutput, $metadataSection);

        foreach ($modules as $module) {
            $this->vardefRefresh($module);
        }
    }

    /**
     * Creates a new field programatically by adding it into the main table or custom table for a specific module,
     * according to the field definition.
     *
     * In order to know which table a field should be added in, the logic below looks if the `source` attribute
     * has the `custom_fields` value.
     * This is the flag that indicates if a field must be inserted into the main or custom table.
     *
     * <code>
     *
     * $fieldDefs = [
     *     "demo_relate_field_id"= [
     *         "name"   => "demo_relate_field_id",
     *         "type"   => "id",
     *         "source" => "custom_fields",
     *     ],
     *     "demo_relate_field_id_test"= [
     *         "name"   => "demo_relate_field_id_test",
     *         "type"   => "id",
     *     ],
     * ];
     *
     * $this->vardefFieldMetaCommitToDb("Accounts", $fieldDefs);
     *
     * </code>
     *
     * @param string $module
     * @param array $fieldDefs
     *
     * @return void
     *
     * @throws ReflectionException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     * @throws SugarException
     */
    public function vardefFieldMetaCommitToDb(string $module, array $fieldDefs): void
    {
        $this->vardefRefresh($module);

        $bean = BeanFactory::newBean($module);

        if (empty($fieldDefs)) {
            throw new SugarException("Fail to commit field vardefs to db for module {$module}. Field defs are empty.");
        }

        $db = DBManagerFactory::getInstance();

        $mainTableFieldDefs   = [];
        $customTableFieldDefs = [];

        foreach ($fieldDefs as $fieldName => $fieldDef) {
            $name = trim($fieldName);

            if (empty(trim($name))) {
                throw new SugarException("Fail to create vardef for field {$name} on {$module}. Field name is empty.");
            }

            if (empty($GLOBALS["dictionary"][$bean->object_name]["fields"][$name]) === false) {
                throw new SugarException("Fail to create vardef for field {$name} on {$module}. Field already exists.");
            }

            if ($fieldDef["source"] === "custom_fields") {
                /**
                 * Remove source for custom fields because in order to create the `ALTER TABLE` query,
                 * the database manager is going to skip those fields whose `source` attribute is other than `db`.
                 *
                 * Sugar uses the same approach in `DynamicField` class.
                 *
                 * @see DBManager::repairTableColumns
                 * @see DynamicField::repairCustomFields
                 * @see DynamicField::getFieldDefinitions
                 */
                unset($fieldDef["source"]);

                $customTableFieldDefs[$name] = $fieldDef;
            } else if ($fieldDef["source"] !== "non-db") {
                $mainTableFieldDefs[$name] = $fieldDef;
            }
        }

        if (empty($mainTableFieldDefs) === false) {
            $db->repairTableParams($bean->getTableName(), $mainTableFieldDefs, [], true);
        }

        if (empty($customTableFieldDefs) === false) {
            $df = new DynamicFieldWrapper($module);
            $df->setup($bean);
            $df->createCustomTable(true);

            $db->repairTableParams($bean->get_custom_table_name(), $customTableFieldDefs, [], true);
        }

        $this->vardefRefresh($module);
    }

    /**
     * Checks if a specific field exists on module.
     *
     * @param string $module
     * @param string $fieldName
     *
     * @return bool
     *
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFieldExists(string $module, string $fieldName): bool
    {
        $df = new DynamicFieldWrapper($module);

        $df->setup(BeanFactory::newBean($module));

        return $df->fieldExists($fieldName);
    }

    /**
     * Deletes field from fields_meta_data table.
     *
     * @param string $module
     * @param string $fieldName
     *
     * @return bool True if the field has been deleted
     *
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    public function vardefFieldDelete(string $module, string $fieldName): bool
    {
        $df = new DynamicFieldWrapper($module);

        $df->setup(BeanFactory::newBean($module));
        $df->deleteField($fieldName);

        return !$this->vardefFieldExists($module, $fieldName);
    }

    /**
     * Removes fields from all Studio layouts.
     *
     * @param string $module
     * @param array $fields
     *
     * @return void
     */
    public function vardefFieldsRemoveFromLayouts(string $module, array $fields): void
    {
        /** @var StudioModule $studioModule */
        $studioModule = StudioModuleFactory::getStudioModule($module);

        /** @var array $viewSources */
        $viewSources = $studioModule->getViewMetadataSources();

        /**
         * List of Module Builder metadata locations
         *
         * ['base', 'custom', 'working', 'history']
         */
        $mbMetaLocations = [
            MB_BASEMETADATALOCATION,
            MB_CUSTOMMETADATALOCATION,
            MB_WORKINGMETADATALOCATION,
            MB_HISTORYMETADATALOCATION,
        ];

        foreach ($fields as $field) {
            $studioModule->removeFieldFromLayouts($field);

            /**
             * The goal here is to ensure that each metadata file that is going to be modified
             * after plucking a specific field from them will not be cached
             * so to always use the already updated version of that file.
             */
            if (\function_exists("opcache_invalidate") === true) {
                foreach ($viewSources as $def) {
                    foreach ($mbMetaLocations as $type) {
                        /** @var MetaDataFileInterface $file */
                        $file = MetaDataFiles::getFile($def["type"], $module, [
                            "client"   => "base",
                            "location" => $type,
                        ]);

                        $filePath = MetaDataFiles::getFilePath($file);

                        if (\sugar_is_file($filePath) === true) {
                            \opcache_invalidate($filePath);
                        }
                    }
                }
            }
        }
    }

    /**
     * Creates labels programatically.
     *
     * <code>
     *
     * $this->vardefLabelsAdd("Accounts", [
     *     "LBL_SAMPLE_SIC_CODE" => "Sic Code",
     *     "LBL_PROTOTYPER"      => "Prototyper"
     * ], "en_us");
     *
     * --------------------
     *
     * $this->vardefLabelsAdd("Accounts", [
     *     "LBL_SAMPLE_SIC_CODE" => "Sic Code",
     *     "LBL_PROTOTYPER"      => "Prototyper"
     * ], "en_us", "include/language");
     *
     * </code>
     *
     * @param string $module
     * @param array $labels
     * @param string $language
     * @param null|string $basepath
     *
     * @return bool
     *
     * @throws ViolationException
     */
    public function vardefLabelsAdd(string $module, array $labels, string $language, ?string $basepath = null): bool
    {
        return ParserLabel::addLabels($language, $labels, $module, $basepath);
    }

    /**
     * Removes labels programatically.
     *
     * <code>
     *
     * $this->vardefLabelsRemove("Accounts", [
     *     "LBL_SAMPLE_SIC_CODE" => "Sic Code",
     *     "LBL_PROTOTYPER"      => "Prototyper"
     * ], "en_us");
     *
     * --------------------
     *
     * $this->vardefLabelsRemove("Accounts", [
     *     "LBL_SAMPLE_SIC_CODE" => "Sic Code",
     *     "LBL_PROTOTYPER"      => "Prototyper"
     * ], "en_us", "include/language");
     *
     * </code>
     *
     * @param string $module
     * @param array $labelsMapping
     * @param string $language
     * @param null|string $basepath
     *
     * @return array
     *
     * @throws ViolationException
     */
    public function vardefLabelsRemove(
        string $module,
        array $labelsMapping,
        string $language,
        ?string $basepath = null
    ): array{

        $result = [];

        foreach ($labelsMapping as $vname => $labelValue) {
            $result[] = [
                "vname"      => $vname,
                "labelValue" => $labelValue,
                "removed"    => ParserLabel::removeLabel($language, $vname, $labelValue, $module, $basepath),
            ];
        }

        return $result;
    }

    /**
     * Refreshes the given module vardefs.
     *
     * @access protected
     *
     * @param string $module
     *
     * @return void
     *
     * @throws ReflectionException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    protected function vardefRefresh(string $module): void
    {
        $object = BeanFactory::getObjectName($module);

        VardefManager::loadVardef($module, $object, true);
    }

    /**
     * Prepares dynamic field, module object and template field.
     *
     * @access protected
     *
     * @param string $module
     * @param array $meta
     *
     * @return array
     *
     * @throws SugarException
     * @throws Exception
     * @throws QueryException
     * @throws DBALException
     */
    protected function vardefPrepare(string $module, array $meta): array
    {
        $name = $meta["name"];

        if (empty(trim($name))) {
            throw new SugarException("Fail to write vardef file. Field name not found.");
        }

        $meta["name"] = $name;

        $meta = \array_merge($this->vardefMetaGet($module, $name) ?? [], $meta);

        SugarAutoLoader::load("modules/DynamicFields/FieldCases.php");

        $df = new DynamicFieldWrapper($module);

        $mod = BeanFactory::newBean($module);
        $obj = BeanFactory::getObjectName($module);

        $df->setup($mod);

        $field = \get_widget($meta["type"]);
        $field->populateFromRow($meta);

        return [
            $df, $obj, $field,
        ];
    }

    /**
     * @access protected
     *
     * @param string $module
     *
     * @return string
     */
    protected function vardefFileNameBuild(string $module): string
    {
        $df = new DynamicFieldWrapper($module);

        $namespaceParts = explode("\\", __NAMESPACE__);

        foreach ($namespaceParts as $key => $part) {
            if ($part === "wsystems") {
                $packageName = $namespaceParts[$key + 1];

                return "{$df->base_path}/{$packageName}_vardef.php";
            }
        }

        return "";
    }
}

/**
 * Extend DynamicField class in order to make the `writeVardefExtension` method public.
 */
class DynamicFieldWrapper extends DynamicField
{
    /**
     * @inheritdoc
     */
    public function writeVardefExtension($bean_name, $field, $def_override)
    {
        return parent::writeVardefExtension($bean_name, $field, $def_override);
    }

    /**
     * @inheritdoc
     */
    public function removeVardefExtension($field)
    {
        return parent::removeVardefExtension($field);
    }
}

\class_alias(\SugarAutoLoader::class, "AutoLoaderWrapper");

class AutoLoaderHelper extends \AutoLoaderWrapper
{
    /**
     * @inheritdoc
     */
    public static function fileAddContent($filename, $data)
    {
        return parent::put($filename, $data);
    }

    /**
     * @inheritdoc
     */
    public static function fileDelete($filename)
    {
        parent::unlink($filename);
    }

}
