<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs;

use RunnableSchedulerJob;
use SchedulersJob;

class RemoveOutdatedDrilldownCacheJob implements RunnableSchedulerJob
{
    /**
     * @var SchedulersJob
     */
    protected $job;

    /**
     * @param SchedulersJob $job
     *
     * @return void
     */
    public function setJob(SchedulersJob $job): void
    {
        $this->job = $job;
    }

    /**
     * @param mixed $data
     *
     * @return bool
     */
    public function run($data): bool
    {
        global $db, $sugar_config;
        $conn = $db->getConnection();

        try {
            $sql = "delete from wdrilldown_report_charts where DATE(date_created) != DATE(CURDATE())";
            if ((array_key_exists('db_manager', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_manager'] == "SqlsrvManager")
                || (array_key_exists('db_type', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_type'] == 'mssql')) {
                $sql = "delete from wdrilldown_report_charts where CAST(date_created AS DATE) != CAST(GETDATE() AS DATE)";
            }
            $conn->executeQuery($sql);
        } catch (\Throwable $e) {
            $this->job->name .= " [ERROR: " . $e->getMessage() . "]";
            $this->job->message = $e->getMessage() . "\n" . $e->getTraceAsString();
        }

        return true;
    }
}
