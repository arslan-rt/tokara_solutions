<?php

namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Jobs;

use RunnableSchedulerJob;
use SchedulersJob;

class ClearDrilldownCacheJob implements RunnableSchedulerJob
{
    /**
     * @var SchedulersJob
     */
    protected $job;

    /**
     * @param SchedulersJob $job
     *
     * @return void
     */
    public function setJob(SchedulersJob $job): void
    {
        $this->job = $job;
    }

    /**
     * @param mixed $data
     *
     * @return bool
     */
    public function run($data): bool
    {
        global $db;
        try {
            $sql = <<<SQL
DELETE
FROM
    wdrilldown_report_charts;
SQL;
            $db->query($sql);
            return true;
        } catch (\Throwable $e) {
            $this->job->name .= " [ERROR: " . $e->getMessage() . "]";
            $this->job->message = $e->getMessage() . "\n" . $e->getTraceAsString();
        }

        return true;
    }
}
