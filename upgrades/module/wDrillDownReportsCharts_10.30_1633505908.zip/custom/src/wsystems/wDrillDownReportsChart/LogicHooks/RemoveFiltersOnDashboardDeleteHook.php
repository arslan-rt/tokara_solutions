<?php

use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class RemoveFiltersOnDashboardDeleteHook
{
    public function deleteFilters($bean, $event, $arguments)
    {
        $metadata = $bean->metadata;
        if (is_string($bean->metadata)) {
            $metadata = json_decode($metadata, true);
        }
        $dashletIds = FilterUtils::getWChartDashletIds($metadata);
        foreach ($dashletIds as $idx => $dashletId) {
            FilterUtils::removeFiltersOfDashletId($dashletId);
        }
        FilterUtils::removeDashboardFilters($bean->id);
        FilterUtils::removeDashboardFilterTemplate($bean->id);
    }

}
