<?php
use Doctrine\DBAL\Portability\Statement as Statement;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\Utils as Utils;

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class DashboardsAppendRuntimesHook
{
    /**
     * Add filter groups, qualifiers and values to Dashboard GET request
     */
    public function before_respond($event, $response)
    {
        global $service;

        $request = $service->getRequest();
        $path    = $request->path;
        $route   = $request->route;

        if (
            ($request->method === "GET" || $request->method === "PUT")
            && count($path) === 2
            && $path[0] === "Dashboards"
            && empty($path[1]) === false
            && count($route["pathVars"]) === 2
            && $route["pathVars"][0] === "module"
            && $route["pathVars"][1] === "record"
        ) {

            $body = $response->getBody();

            if (is_string($body["id"])) {
                $body["dashboardRuntimeTemplates"] = $this->geDashboardTemplates($body["id"]);

                /**
                 * @var array
                 */
                $dashboardRuntimeTemplates = $body["dashboardRuntimeTemplates"];
                $body["dashboardFilters"]  = $this->getDashboardFilters($body["id"], $dashboardRuntimeTemplates);

                //this solution assures we have the latest changes of templates returned in the api
                $response->setHeader("Cache-Control", "no-store");
            } else {
                $GLOBALS["log"]->fatal("wDrilldown: Empty dashboard id. Could not getTemplate and dashboard filters for user "
                    . $GLOBALS["current_user"]->id);
            }
            $response->setContent($body);
        }
    }

    protected function geDashboardTemplates(string $dashboardId): array
    {
        $dashboardTemplates     = [];
        $dashboardTemplatesInDb = FilterUtils::getDashboardTemplatesFromDb($dashboardId);

        //remove templates who's dashlets doesn't exist anymore
        //don't delete them from db. first save will do
        $dashboardBean                = BeanFactory::retrieveBean("Dashboards", $dashboardId);
        $metadata                     = json_decode($dashboardBean->metadata, true);
        $dashlets                     = Utils::getwChartDashlets($metadata);
        $dashletIdsVisibleOnDashboard = array_column($dashlets, "dashletId");

        foreach ($dashboardTemplatesInDb as $templatIdx => $template) {
            $comunDashlets = array_intersect($template["dashlets"], $dashletIdsVisibleOnDashboard);
            if (count($comunDashlets) >= 1) {
                $dashboardTemplates[] = $template;
            }
        }

        //remove fields on templates which are not valid anymore
        for ($i = 0; $i < count($dashboardTemplates); $i++) {
            $dashboardTemplates[$i]["fields"] = $this->filterValidFields($dashboardTemplates[$i]["fields"], $dashboardId);
        }

        //remove templates with no fields (that's required)
        $dashboardTemplatesTemp = [];
        foreach ($dashboardTemplates as $templateIdx => $template) {
            if (count($template["fields"]) >= 1) {
                $dashboardTemplatesTemp[] = $template;
            }
        }
        $dashboardTemplates = $dashboardTemplatesTemp;

        return $dashboardTemplates;
    }

    protected function filterValidFields(array $fields, $dashboardId): array
    {
        $result = [];

        $dashboardBean                = BeanFactory::retrieveBean("Dashboards", $dashboardId);
        $metadata                     = json_decode($dashboardBean->metadata, true);
        $dashlets                     = Utils::getwChartDashlets($metadata);
        $dashletIdsVisibleOnDashboard = array_column($dashlets, "dashletId");

        foreach ($fields as $fieldIdx => $field) {
            // dashlet is not on dashboard anymore
            if (in_array($field["dashlet"], $dashletIdsVisibleOnDashboard) === false) {
                continue;
            }

            // report does not exist anymore
            $qb = DBManagerFactory::getConnection()->createQueryBuilder();

            $qb->select("id");
            $qb->from("saved_reports");
            $qb->where($qb->expr()->eq("id", ":id"));
            $qb->andWhere($qb->expr()->eq("deleted", ":deleted"));

            $qb->setParameter(":id", $field["reportId"]);
            $qb->setParameter(":deleted", 0);

            $dbResult = $qb->execute();

            if ($dbResult instanceof Statement === true) {
                $dbResult = $dbResult->fetch();
                if (is_array($dbResult) === false || is_string($dbResult["id"]) === false) {
                    continue;
                }
            } else {
                continue;
            }

            // field is not runtime anymore (or doesn't exist at all)
            $fieldName           = $field["fieldName"];
            $pathInReportFilters = $field["pathInReportFilters"];

            $chartReport = BeanFactory::getBean("Reports", $field['reportId'], array("encode" => false));
            $reportClass = SugarAutoLoader::customClass("Report");
            if ($reportClass == "Report") {
                $reporter = new Report($chartReport->content);
            }
            if ($reportClass == "CustomReport") {
                $reporter = new CustomReport($chartReport->content);
            }
            $filtersInDb = $reporter->report_def['filters_def']['Filter_1'];

            $runtimeFilterIsStillThere = $this->checkRuntimeFieldExists($filtersInDb, $fieldName, $pathInReportFilters);
            if ($runtimeFilterIsStillThere === false) {
                continue;
            }

            $result[] = $field;
        }

        return $result;
    }

    protected function checkRuntimeFieldExists(&$filterDef, $fieldName, $pathInReportFilters)
    {
        if (empty($pathInReportFilters)) {
            return $filterDef["name"] === $fieldName && $filterDef["runtime"] === 1;
        } else {
            $idx = array_shift($pathInReportFilters);
            do {
                return $this->checkRuntimeFieldExists($filterDef[$idx], $fieldName, $pathInReportFilters);
            } while ($idx = array_shift($pathInReportFilters));
        }
    }

    protected function getDashboardFilters(string $dashboardId, array $templates): array
    {
        global $timedate;
        $dashboardFilters     = [];
        $dashboardFiltersInDb = FilterUtils::getFilterFromDb(
            "wdrilldown_report_filters_dashboards",
            [
                "dashboardId" => $dashboardId,
                "userId"      => $GLOBALS["current_user"]->id,
            ]
        );

        if (is_array($dashboardFiltersInDb)) {
            $dashboardFiltersInDb = @json_decode($dashboardFiltersInDb["filters"], true);
        }

        if (is_array($dashboardFiltersInDb) === false) {
            return [];
        }

        //remove filters with the template deleted
        foreach ($dashboardFiltersInDb as $filterIdx => $filter) {
            $templateFound = false;
            foreach ($templates as $templatIdx => $template) {
                if ($filter["templateId"] === $template["templateId"]) {
                    $templateFound = true;
                }
            }
            if ($templateFound) {
                $dashboardFilters[] = $filter;
            }
        }

        return $dashboardFilters;
    }

}
