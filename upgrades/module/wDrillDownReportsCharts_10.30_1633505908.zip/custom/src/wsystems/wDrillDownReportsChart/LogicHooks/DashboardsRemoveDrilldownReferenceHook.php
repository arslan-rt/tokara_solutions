<?php

use Doctrine\DBAL\Portability\Statement as Statement;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class DashboardsRemoveDrilldownReferenceHook
{
    /**
     * Remove reference about runtime filter
     */
    public function before_api_call($event, $arguments)
    {
        $request = $arguments["request"];
        $path    = $request->path;

        if (
            $request->method !== "PUT"
            || count($path) !== 2
            || $path[0] !== "Dashboards"
            || is_string($path[1]) === false
        ) {
            return;
        }

        $dashboardId = $path[1];
        if (is_string($dashboardId) === false) {
            return;
        }
        $currentMetadata = FilterUtils::getDashboardMetadata($dashboardId);

        $requestMetadata = $request->args["metadata"];
        if (md5(serialize($currentMetadata)) === md5(serialize($requestMetadata))) {
            return;
        }

        if (is_array($currentMetadata) === false || is_array($requestMetadata) === false) {
            return;
        }

        //remove custom filters when the dashlet is deleted
        $previousWChartDashletIds = FilterUtils::getWChartDashletIds($currentMetadata);
        $wChartDashletIds         = FilterUtils::getWChartDashletIds($requestMetadata);
        foreach ($previousWChartDashletIds as $previouswChartDashletId) {
            if (in_array($previouswChartDashletId, $wChartDashletIds) === false) {
                $dashletIdIsShared = $this->checkDashletIdBeingUsedInMultipleDashooards($previouswChartDashletId);
                if ($dashletIdIsShared === false) {
                    FilterUtils::removeFiltersOfDashletId($previouswChartDashletId);
                }
            }
        }

        //remove custom filters saved on a dashlet if the user changed the report
        $previousDashlets = FilterUtils::getWChartDashlets($currentMetadata);
        $currentDashlets  = FilterUtils::getWChartDashlets($requestMetadata);
        foreach ($previousDashlets as $previousIdx => $previousDashlet) {
            foreach ($currentDashlets as $currentIdx => $currentDashlet) {
                if ($previousIdx === $currentIdx && $previousDashlet["saved_report_id"] !== $currentDashlet["saved_report_id"]) {
                    FilterUtils::removeFiltersOfDashletId($previousDashlet["dashletId"]);
                }
            }
        }
    }

    public function checkDashletIdBeingUsedInMultipleDashooards(string $dashletId): bool
    {
        $data = [];

        $qb = DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("count(id) as count");
        $qb->from("dashboards");
        $qb->where($qb->expr()->like("metadata", ":dashletId"));

        $qb->setParameter(":dashletId", "%{$dashletId}%");

        $result = $qb->execute();

        if ($result instanceof Statement === true) {
            $result = $result->fetch();
        }

        if (is_array($result) && isset($result["count"])) {
            return $result["count"] > 1;
        }

        return false;
    }
}
