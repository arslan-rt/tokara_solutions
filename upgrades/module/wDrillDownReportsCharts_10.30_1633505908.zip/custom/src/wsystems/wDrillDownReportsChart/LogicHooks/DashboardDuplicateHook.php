<?php

use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils\FilterUtils as FilterUtils;

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

class DashboardDuplicateHook
{
    /**
     * before_api_call
     */
    public function generateNewDashletIds($event, $arguments)
    {
        global $service;

        $duplicateDashboardRequest = $this->isDuplicateRoute($service);
        if ($duplicateDashboardRequest === false) {
            return;
        }
        $request = $service->getRequest();
        $args    = $request->getArgs();

        $dashletIdsChanged = [];
        foreach ($args["metadata"]["dashlets"] as &$dashlet) {
            if (
                isset($dashlet["view"]) && isset($dashlet["view"]["type"])
                && $dashlet["view"]["type"] === "w-saved-reports-chart"
                && isset($dashlet["view"]["dashletId"])
            ) {
                //the pointer will set a new dashletId on each dashlet
                $oldDashletId                 = $dashlet["view"]["dashletId"];
                $newDashletId                 = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();
                $dashlet["view"]["dashletId"] = $newDashletId;

                $dashletIdsChanged[$oldDashletId] = $newDashletId;

                $dashletHasRuntimeFilters = $this->dashletHasRuntimeFilters($oldDashletId);
                if ($dashletHasRuntimeFilters === true) {
                    $this->copyDashletFilters($oldDashletId, $newDashletId);
                }
            }
        }
        $args["dashletIdsChanged"] = $dashletIdsChanged;
        $arguments["request"]->setArgs($args);
    }

    /**
     * before_respond
     */
    public function createNewTemplate($event, $response)
    {
        global $service;

        $duplicateDashboardRequest = $this->isDuplicateRoute($service);
        if ($duplicateDashboardRequest === false) {
            return;
        }

        $request = $service->getRequest();
        $args    = $request->args;

        $dashboardHasRuntimeFilters = false;
        if (is_string($args["sourceDashboard"])) {
            $dashboardHasRuntimeFilters = $this->dashboardHasRuntimeFilters($args["sourceDashboard"]);
        }

        if ($dashboardHasRuntimeFilters === true) {

            $body = $response->getBody();

            if (is_string($args["sourceDashboard"]) && is_string($body["id"])) {
                $templates = FilterUtils::getDashboardTemplatesFromDb($args["sourceDashboard"]);

                $templates = json_encode($templates);

                if (isset($args["dashletIdsChanged"])) {
                    $templates = $this->replaceDashletIds($templates, $args["dashletIdsChanged"]);
                }
                $this->insertTemplates($templates, $body["id"]);
                $this->copyDashboardFilters($args["sourceDashboard"], $body["id"]);
            } else {
                $GLOBALS["log"]->fatal("wDrilldown: Empty sourceDashboard or id. Could not copyTemplate for user "
                    . $GLOBALS["current_user"]->id . ". request params: " . var_export($args, true));
            }
        }
    }

    /**
     * DashletIds need to be updated for the dashboard processing to validate the filter
     * as being on this particular dashboard
     */
    protected function replaceDashletIds($templates, $dashletIdsChanged)
    {
        foreach ($dashletIdsChanged as $oldDashletId => $newDashletId) {
            $templates = str_replace($oldDashletId, $newDashletId, $templates);
        }
        return $templates;
    }

    protected function insertTemplates(string $templates, string $dashboardId): void
    {
        global $timedate;

        $params = [
            "id"             => Sugarcrm\Sugarcrm\Util\Uuid::uuid1(),
            "dashboard_id"   => $dashboardId,
            "templates"      => $templates,
            "date_generated" => $timedate->nowDb(),
        ];
        FilterUtils::insertDashboardTemplatesInDb($params);
    }

    /**
     * Copy runtime filters set on a dashlet to another one
     */
    protected function copyDashletFilters(string $oldDashletId, string $newDashletId)
    {
        global $dictionary, $timedate;

        $db    = \DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_dashlets";

        $fieldDefs = $dictionary[$table]["fields"];

        $filterInDb = FilterUtils::getFilterFromDb($table, [
            "dashletId" => $oldDashletId,
            "userId"    => $GLOBALS["current_user"]->id,
        ]);

        $filterInDb["id"]             = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();
        $filterInDb["dashlet_id"]     = $newDashletId;
        $filterInDb["date_generated"] = $timedate->nowDb();

        $inserted = $db->insertParams($table, $fieldDefs, $filterInDb);

        return $inserted;
    }

    protected function copyDashboardFilters(string $sourceDasboardId, string $newDashboardId)
    {
        global $dictionary, $timedate;

        $db    = \DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_dashboards";

        $fieldDefs = $dictionary[$table]["fields"];

        $filterInDb = FilterUtils::getFilterFromDb($table, [
            "dashboardId" => $sourceDasboardId,
            "userId"      => $GLOBALS["current_user"]->id,
        ]);

        $filterInDb["id"]             = Sugarcrm\Sugarcrm\Util\Uuid::uuid1();
        $filterInDb["dashboard_id"]   = $newDashboardId;
        $filterInDb["date_generated"] = $timedate->nowDb();

        $inserted = $db->insertParams($table, $fieldDefs, $filterInDb);

        return $inserted;
    }

    protected function dashletHasRuntimeFilters($dashletId)
    {
        $table = "wdrilldown_report_filters_dashlets";

        $filterInDb = FilterUtils::getFilterFromDb($table, [
            "dashletId" => $dashletId,
            "userId"    => $GLOBALS["current_user"]->id,
        ]);

        return isset($filterInDb["filters"]);
    }

    protected function dashboardHasRuntimeFilters($dashletId)
    {
        $table = "wdrilldown_report_filters_dashboards";

        $filterInDb = FilterUtils::getFilterFromDb($table, [
            "dashboardId" => $dashletId,
            "userId"      => $GLOBALS["current_user"]->id,
        ]);

        return isset($filterInDb["filters"]);
    }

    protected function isDuplicateRoute($service): bool
    {
        $request = $service->getRequest();
        $path    = $request->path;
        $route   = $request->route;

        if (
            $request->method === "POST"
            && count($path) === 1
            && $path[0] === "Dashboards"
            && count($route["pathVars"]) === 1
            && $route["pathVars"][0] === "module"
        ) {
            return true;
        }

        return false;
    }
}
