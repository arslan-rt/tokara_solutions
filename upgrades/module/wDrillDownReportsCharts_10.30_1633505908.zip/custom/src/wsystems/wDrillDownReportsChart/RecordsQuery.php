<?php
namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart;

class RecordsQuery
{
    protected $report_def          = array();
    protected $full_table_list     = array();
    protected $full_bean_list      = array();
    protected $all_fields          = array();
    protected $module              = '';
    protected $groupType           = 'simple'; //simple/group
    protected $baseTable           = '';
    public $displayColumns         = array();
    protected $fieldsAddedToSelect = array();

    protected $query         = '';
    protected $from          = '';
    protected $select_fields = array();
    protected $joins         = array();
    protected $where         = array();
    protected $groupBy       = array();
    protected $orderBy       = array(); //summary uses a string to store this
    protected $offset        = 0;
    protected $limit         = 100;
    public $paginate         = true;

    private $dbType           = "mysql";
    private $isNullFunctional = "ifnull"; // mysql uses ifnull while mssql uses isnull
    private $roundTruncate    = "truncate"; // mysql uses truncate while mssql uses round
    private function trimDb($contentToTrim)
    {
        $trim = "trim(" . $contentToTrim . ")"; //mysql
        if ($this->dbType === "mssql") {
            $trim = "ltrim(rtrim(" . $contentToTrim . "))";
        }
        return $trim;
    }
    /*
    tableKey => sql
    we need it when display columns show a currency from a table not loaded yet in join statement.
    this table might be added just when we handle related tables so we'll store the sql here
     */
    protected $currencysJoinLeftToAdd = array();

    /*
    Used to hold keys for groupings.
    For simple chart types this array wil only contain a value. For grouped ones will contain two values.
     */
    protected $filters = array();
    /*
    Used to create select, group by and order by statements for Fiscals and Quarters grouping types
     */
    protected $layout_manager = null;
    /*
    Used to create unique join table aliases
     */
    protected $jtCount = 0;
    /*
    Versatile variable. Contains navigation keys from a target to self. We use it to build joins
     */
    protected $tableKeyNavigation = array();
    /*
    If groupType is 'group', we expect we make groupings on two fields
    For 'simple' type we only have one group by
     */
    protected $groupNumbers = 1;

    public function __construct($reporter, $groupType, $filters = array(), $offset = 0, $recordsPerPage = 100)
    {
        global $dictionary, $sugar_config;

        if ((array_key_exists('db_manager', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_manager'] == "SqlsrvManager")
            || (array_key_exists('db_type', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_type'] == 'mssql')) {
            $this->dbType           = "mssql";
            $this->isNullFunctional = 'isnull';
            $this->roundTruncate    = "round";
        }

        $this->report_def      = $reporter->report_def;
        $this->full_table_list = $this->report_def['full_table_list'];

        $this->full_bean_list = $reporter->full_bean_list;
        $this->module         = $this->report_def['module'];
        $this->groupType      = $groupType;
        $this->filters        = $filters;

        $this->baseBean  = \BeanFactory::newBean($this->module);
        $this->baseTable = $dictionary[$this->baseBean->object_name]['table'];

        $this->initializeTableListAliases();
        $this->full_table_list['self']['params']['join_table_alias'] = $this->baseTable;

        $this->groupNumbers = $this->getNumberOfGroupsWeAreSelectingFrom();

        $this->_load_all_fields();

        include_once 'include/generic/LayoutManager.php';
        $this->layout_manager                      = new \LayoutManager();
        $this->layout_manager->default_widget_name = 'ReportField';
        $this->layout_manager->setAttributePtr('reporter', $reporter);

        $this->offset = $offset;
        if ($recordsPerPage == -1) {
            $this->paginate = false;
        } else {
            $this->limit = $recordsPerPage;
        }

        $this->initialLimit  = $this->limit;
        $this->initialOffset = $this->offset;

        //add missing type on report groupings
        for ($i = 0; $i < count($this->report_def['group_defs']); $i++) {
            $groupDef                                   = $this->report_def['group_defs'][$i];
            $this->report_def['group_defs'][$i]["type"] = $this->all_fields[$groupDef['table_key'] . ":" . $groupDef["name"]]["type"];
        }
    }

    /*
    Entry point for api
    @return array
     */
    public function getData($args)
    {
        global $log;

        $db = \DBManagerFactory::getInstance('reports');

        $this->parseRequest($args);
        $this->generateQuery($args);

        $log->debug($this->query);

        $dbRes  = $db->query($this->query);
        $result = array();
        while ($row = $db->fetchByAssoc($dbRes)) {
            $result[] = $row;
        }

        return $result;
    }

    /*
    Parses report in order to extract field names, from statement, joins, wheres,...
    All of these are put in properties on this object
     */
    public function parseRequest($args)
    {
        $this->createFrom();
        $this->addGroupingRelations();
        $this->setBasicSelect();
        $this->setWhere();
        if (!empty($args['link']) && isset($args["reportDefinitionOnly"]) === false) {
            $this->appendCurrentRecordFilterDefinition($args);
        }
        $this->addDefaultFilters($args);
        $this->addSecurity();
        $this->addSelectColumnJoinsThatWereNotAddedYet();

        foreach ($this->currencysJoinLeftToAdd as $tableKey => $sqlJoinSubStatement) {
            $this->joins[]                                     = $sqlJoinSubStatement;
            $this->full_table_list[$tableKey]['tableJoinMade'] = true;
        }

        $this->addOrderByStatement($args);
        $this->addPagination();
    }

    /*
    Creates query for chart rendering
     */
    public function generateQuery($args)
    {
        $select_fields = "SELECT distinct ";
        for ($i = 0; $i < count($this->select_fields); $i++) {
            if ($i >= 1) {
                $select_fields .= ", ";
            }
            $select_fields .= $this->select_fields[$i] . " ";
        }
        $groupBy = "";
        if (count($this->groupBy) > 0) {
            $groupBy = "GROUP BY ";
            for ($i = 0; $i < count($this->groupBy); $i++) {
                if ($i >= 1) {
                    $groupBy .= ", ";
                }
                $groupBy .= $this->groupBy[$i] . " ";
            }
        }
        $joins = "";
        for ($i = 0; $i < count($this->joins); $i++) {
            $joins .= $this->joins[$i] . " ";
        }
        $where = "";
        if (count($this->where) > 0) {
            $where = "WHERE ";
            for ($i = 0; $i < count($this->where); $i++) {
                if ($i >= 1) {
                    $where .= " AND ";
                }
                $where .= $this->where[$i] . " ";
            }
        }
        $orderBy = "";
        if (count($this->orderBy) > 0) {
            $orderBy = "ORDER BY ";
            for ($i = 0; $i < count($this->orderBy); $i++) {
                if ($i >= 1) {
                    $orderBy .= ", ";
                }
                $orderBy .= $this->orderBy[$i] . " ";
            }
        }

        $query = "";
        $query .= $select_fields;
        $query .= $this->from;
        $query .= $joins;
        $query .= $where;
        $query .= $groupBy;

        if ($this->paginate) {
            $query .= $orderBy;
            if ($this->dbType === 'mysql') {
                $query .= "LIMIT " . $this->initialOffset . ", " . $this->limit;
            } else {
                $query .= "offset " . $this->initialOffset . " rows fetch next " . $this->limit . " rows only";
            }
        }

        $this->query = $query;
    }

    protected function addSecurity()
    {
        global $current_user, $mod_strings, $log;

        if (!is_admin($current_user)) {
            $where_clause = "";
            // add team security
            $focus   = $this->baseBean;
            $options = array(
                // notify visibility strategies we are running from reports
                'report_query'    => true,
                'where_condition' => true,
            );
            $focus->addVisibilityWhere($where_clause, $options);

            // add visibility permissions based on role
            $list_action = \ACLAction::getUserAccessLevel($current_user->id, $this->baseBean->module_dir, 'list', $type = 'module');
            $view_action = \ACLAction::getUserAccessLevel($current_user->id, $this->baseBean->module_dir, 'view', $type = 'module');

            if ($list_action == ACL_ALLOW_NONE || $view_action == ACL_ALLOW_NONE) {
                $log->fatal("You are not able to access this report due to permissions restrictions.");
                die("You are not able to access this report due to permissions restrictions.");
            }
            $aclVisibility = new \ACLVisibility($this->baseBean);
            $aclVisibility->setOptions(array('action' => 'view'));
            $aclVisibility->addVisibilityWhere($where_clause);
            $aclVisibility->setOptions(array('action' => 'list'));
            $aclVisibility->addVisibilityWhere($where_clause);
            if (trim($where_clause) != "") {
                $this->where[] = $where_clause;
            }
        }
    }

    protected function createFrom()
    {
        $db = \DBManagerFactory::getInstance('reports');

        $this->from = "\nFROM " . $this->baseBean->table_name . "\n";

        if ($db->tableExists($this->baseBean->table_name . '_cstm')) {
            $this->from .= "\nLEFT JOIN {$this->baseBean->table_name}_cstm on {$this->baseBean->table_name}_cstm.id_c = {$this->baseBean->table_name}.id \n";
        }

        $tp_count = 1;
        foreach ($this->report_def["group_defs"] as $idx => $groupDef) {
            if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                $tableKey   = $groupDef['table_key'];
                $fieldName  = $groupDef['name'];
                $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                $fieldName  = $tableAlias . "." . $fieldName;

                $this->from .= " INNER JOIN timeperiods tp" . $tp_count . " ON (" . $fieldName .
                    " >= tp" . $tp_count . ".start_date AND " . $fieldName . " <= tp" . $tp_count . ".end_date" .
                    " AND tp" . $tp_count . ".type = 'Quarter' AND tp" . $tp_count . ".deleted = 0)\n";
                $tp_count++;
            }
        }
    }

    protected function setBasicSelect()
    {
        global $log;

        $this->displayColumns = $this->report_def['display_columns'];

        // summation report types don't have display_columns
        if (count($this->displayColumns) == 0) {
            // this module list view always made problems. solution was to hard code fields used for it
            if ($this->module == "Trackers") {
                $this->displayColumns = array(
                    array(
                        'name'      => 'action',
                        'label'     => 'Action',
                        'table_key' => 'self',
                    ),
                    array(
                        'name'      => 'module_name',
                        'label'     => 'Module',
                        'table_key' => 'self',
                    ),
                    array(
                        'name'      => 'item_id',
                        'label'     => 'Item Id',
                        'table_key' => 'self',
                    ),
                    array(
                        'name'      => 'item_summary',
                        'label'     => 'Item Summary',
                        'table_key' => 'self',
                    ),
                    array(
                        'name'      => 'date_modified',
                        'label'     => 'Date Modified',
                        'table_key' => 'self',
                    ),
                    array(
                        'name'      => 'user_id',
                        'label'     => 'User Id',
                        'table_key' => 'self',
                    ),
                );
            } else {
                $this->displayColumns = $this->getFieldListFromListView($this->module);
            }
        }

        for ($i = 0; $i < count($this->displayColumns); $i++) {
            $fieldToSelect = $this->displayColumns[$i];
            $tableKey      = $fieldToSelect['table_key'];
            $fieldName     = $fieldToSelect['name'];
            $fieldType     = $this->all_fields[$tableKey . ":" . $fieldName]['type'];

            // There are cases when user will set a relate from a foreign table on display columns
            // By the moment we set select fields, the join is not made so here is a good moment to
            // make joins in the correct order
            if ($fieldToSelect['table_key'] != 'self') {
                if (!array_key_exists('tableJoinMade', $this->full_table_list[$fieldToSelect['table_key']]) || $this->full_table_list[$fieldToSelect['table_key']]['tableJoinMade'] != true) {
                    $this->tableKeyNavigation = array();
                    $this->createTableKeyNavigation($tableKey);
                    $this->addJoins();
                }
            }
            $fieldKey = $tableKey . ":" . $fieldName;

            if (in_array($fieldKey, $this->fieldsAddedToSelect)) {
                continue;
            } else {
                array_push($this->fieldsAddedToSelect, $fieldKey);
            }

            if ($fieldType == 'relate') {
                //add id_name field to select
                $nameFieldDef = $this->all_fields[$tableKey . ":" . $fieldName];
                $relateModule = $nameFieldDef['ext2'];
                $relateId     = $nameFieldDef['id_name'];
                $tableAlias   = $this->all_fields[$tableKey . ":" . $relateId]['table_alias'];
                $idFieldDb    = "{$tableAlias}.{$relateId}";
                $fieldAlias   = "{$tableAlias}_{$fieldToSelect['name']}";

                $this->select_fields[] = "{$idFieldDb} as {$fieldAlias}";

                //add label to select. This implies a new join also
                $idFieldDef        = $this->all_fields[$tableKey . ":" . $relateId];
                $sourceRealTable   = $idFieldDef['table_alias'];
                $relatedTableAlias = $this->addJoinForRelateField($sourceRealTable, $relateId, $relateModule);
                $relateName        = $idFieldDef['name'];
                $tableAlias        = $this->all_fields[$tableKey . ":" . $relateName]['table_alias'];

                $relateBean = \BeanFactory::newBean($relateModule);
                if ($relateBean->field_defs['name']['source'] == 'non-db') {
                    $sourceFieldsDb = array("{$this->isNullFunctional}({$relatedTableAlias}.first_name, '')", "{$this->isNullFunctional}({$relatedTableAlias}.last_name, '')");
                } else {
                    $sourceFieldsDb = array("{$this->isNullFunctional}({$relatedTableAlias}.name, '')");
                }
                $fieldAlias    = "{$tableAlias}_{$fieldToSelect['name']}_label";
                $fieldDbRawSql = "concat('', ";
                $fieldDbRawSql .= implode(", ' ', ", $sourceFieldsDb);
                $fieldDbRawSql .= ")";
                $fieldDbRawSql = $this->trimDb($fieldDbRawSql);

                $this->select_fields[] = "{$fieldDbRawSql} as {$fieldAlias}";
            } elseif ($fieldType == 'date' || $fieldType == 'datetime' || $fieldType == 'datetimecombo') {
                $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

                $fieldDb    = "{$table}.{$fieldName}";
                $fieldAlias = "{$table}_{$fieldName}";

                $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";
            } elseif ($fieldType == 'currency') {
                $currencyFieldDef = $this->all_fields[$tableKey . ":" . $fieldName];
                $fieldName        = $fieldToSelect['name'];
                $tableAlias       = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
                $fieldAlias       = "{$tableAlias}_{$fieldName}";
                $fieldDb          = "{$tableAlias}.{$fieldName}";

                $currencyTableAlias = $this->all_fields[$tableKey . ":currency_id"]['table_alias'];
                $currencyFieldAlias = "{$currencyTableAlias}_currency_id";
                $currencyFieldDb    = "{$currencyTableAlias}.currency_id";

                $currencyTableKey = $tableKey . ":currency_id";

                //There are default currency fields set for a speciffic currency (see rev_line_itmes - cost_usdollar).
                //These will be saved in currency set in their definition even currency_id on record is something else. On render are shown both preset currency and record's currency
                if (array_key_exists('currency_id', $currencyFieldDef) && !empty($currencyFieldDef['currency_id'])) {
                    $currencyIdPredefined = $currencyFieldDef['currency_id'];
                    $currenciesJoin       = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdPredefined}'";
                } elseif (array_key_exists('is_base_currency', $currencyFieldDef) && $currencyFieldDef['is_base_currency'] == true) {
                    if ($GLOBALS['current_user']->getPreference('currency_show_preferred')) {
                        $userCurrency         = \SugarCurrency::getUserLocaleCurrency();
                        $currencyIdPredefined = $userCurrency->id;
                    } else {
                        $currencyIdPredefined = \SugarCurrency::getBaseCurrency()->id;
                    }
                    $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdPredefined}'";
                } else {
                    $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}.currency_id={$currencyTableAlias}_currencies.id
AND {$currencyTableAlias}_currencies.deleted=0";
                }

                if ($this->full_table_list[$currencyTableKey]['tableJoinMade']) {
                    $this->joins[] = $currenciesJoin;
                } else {
                    $this->currencysJoinLeftToAdd[$tableKey] = $currenciesJoin;
                }

                $this->select_fields[] = "{$this->isNullFunctional}({$currencyTableAlias}_currencies.symbol, '$') as {$fieldAlias}_currency_symbol";
                $this->select_fields[] = "{$this->roundTruncate}({$this->isNullFunctional}({$fieldDb}, 0), 2) as {$fieldAlias}";
            } elseif ($fieldType == 'fullname') {
                $firstNameKey = $tableKey . ":first_name";
                $lastNameKey  = $tableKey . ":first_name";
                if (array_key_exists($firstNameKey, $this->all_fields) && array_key_exists($lastNameKey, $this->all_fields)) {
                    $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

                    $fieldDb    = "{$table}.{$fieldName}";
                    $fieldAlias = "{$table}_{$fieldName}";

                    $fieldAliasTempStr     = "concat({$this->isNullFunctional}({$table}.first_name, ' '), ' ', {$this->isNullFunctional}({$table}.last_name, ''))";
                    $fieldAliasTempStr     = $this->trimDb($fieldAliasTempStr);
                    $fieldAliasTempStr     = $fieldAliasTempStr . " as {$fieldAlias}";
                    $this->select_fields[] = $fieldAliasTempStr;
                }
                // add id
                $fieldDb    = "{$table}.id";
                $fieldAlias = "{$table}_{$fieldName}_id";

                $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";
            } elseif ($fieldType == 'name') {
                $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

                $fieldDb    = "{$table}.{$fieldName}";
                $fieldAlias = "{$table}_{$fieldName}";

                $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";

                // add id
                $fieldDb    = "{$table}.id";
                $fieldAlias = "{$table}_{$fieldName}_id";

                $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";
            } else {
                $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

                $fieldDb    = "{$table}.{$fieldName}";
                $fieldAlias = "{$table}_{$fieldName}";

                $fieldDef            = $this->all_fields[$tableKey . ":" . $fieldName];
                $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);

                $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, {$defaultNotNullValue}) as {$fieldAlias}";
            }
        }
    }

    // sqlserver does not accept '' for a decimal column
    // so we need to make sure we give the correct value depending on field type
    protected function getDefaultNotNullValue($fieldDef)
    {
        $db = \DBManagerFactory::getInstance('reports');

        $fieldType         = $db->getFieldType($fieldDef);
        $isTextType        = false;
        $dbIsTextTypeCheck = $db->isTextType($fieldType);
        $textTypes         = array("varchar", "enum", "multienum", "html", "longhtml", "char", "blob", "url", "encrypt", "file");
        if (in_array($fieldType, $textTypes) || $dbIsTextTypeCheck) {
            $isTextType = true;
        }
        if ($isTextType || $this->dbType === 'mysql') {
            $defaultNotNullValue = "''";
        } else {
            $defaultNotNullValue = 0;
        }
        return $defaultNotNullValue;
    }

    /*
    Returns a list of fields to be shown on drawer.
    We don't show fields which are not stored in base tabels and neither calculated fields.
     */
    protected function getFieldListFromListView($module)
    {
        $viewdefs     = array();
        $metaDataFile = \SugarAutoLoader::existingCustomOne("modules/{$module}/clients/base/views/list/list.php");
        include_once $metaDataFile;
        $fieldsOnListView     = $viewdefs[$module]['base']['view']['list']['panels'][0]['fields'];
        $fieldNamesOnListView = array();
        if (is_array($fieldsOnListView)) {
            foreach ($fieldsOnListView as $field) {
                $fieldNamesOnListView[] = $field['name'];
            }
        }

        $fieldsToDisplay = array();
        $bean            = \BeanFactory::newBean($module);

        foreach ($bean->field_defs as $fieldDef) {
            if (in_array($fieldDef['name'], $fieldNamesOnListView)) {
                if (!array_key_exists('source', $fieldDef) && (!array_key_exists('calculated', $fieldDef) || (array_key_exists('calculated', $fieldDef) && $fieldDef['calculated'] === false))) {
                    $fieldsToDisplay[] = array(
                        'name'      => $fieldDef['name'],
                        'label'     => translate($fieldDef['vname'], $module),
                        'table_key' => 'self',
                    );
                }
            }
        }
        return $fieldsToDisplay;
    }

    /*
    Reports can be created on a module, grouped on other modules BUT contain fields in Display columns from other modules also
    Select method adds all fields to query and here we make sure all required joins were made
     */
    protected function addSelectColumnJoinsThatWereNotAddedYet()
    {
        foreach ($this->displayColumns as $idx => $displayColumn) {
            $fieldTableKey = $displayColumn['table_key'];
            if ($fieldTableKey != 'self' && !$this->full_table_list[$fieldTableKey]['tableJoinMade']) {
                $this->tableKeyNavigation = array();
                $this->createTableKeyNavigation($fieldTableKey);

                $this->addJoins();
            }
        }
    }

    protected function appendCurrentRecordFilterDefinition(&$args)
    {
        $tableListToAdd = $this->getTableListAddin($args);

        foreach ($tableListToAdd as $key => $val) {
            // $report_info['full_table_list'][$key] = $val;
            if (!array_key_exists($key, $this->full_table_list)) {
                $this->full_table_list[$key] = $val;
            }

            if (!array_key_exists($key, $this->full_bean_list)) {
                $this->full_bean_list[$key] = \BeanFactory::newBean($val['module']);
            }

            if (!array_key_exists('params', $this->full_table_list[$key]) || !array_key_exists('join_table_alias', $this->full_table_list[$key]['params'])
                || empty($this->full_table_list[$key]['params']['join_table_alias'])) {
                $this->addAliasForASpecificKey($key);
            }
        }

        $this->report_def['filters_def'] = $this->getFilterDefsWithAddin($args);

        $this->all_fields = [];
        $this->_load_all_fields();
    }

    /*
    Used to add to full_table_list for relate to current record functionality. new filter has to relate to full_Table_list
     */
    protected function getTableListAddin($args)
    {
        $report_info = &$this->report_def;
        $ret         = array();

        global $dictionary;

        $beanName = \BeanFactory::getObjectName($args['module']);

        $bean = \BeanFactory::getBean($args['module']);
        $bean->load_relationship($args['link']);
        $targetModule   = $bean->{$args['link']}->getRelatedModuleName();
        $targetBeanName = \BeanFactory::getObjectName($targetModule);

        $relName = $dictionary[$beanName]['fields'][$args['link']]['relationship'];

        //lets reverse lookup the target link field
        $targetLinkField = null;
        if ($dictionary[$targetBeanName]['fields']) {
            foreach ($dictionary[$targetBeanName]['fields'] as $fieldName => $field) {
                if (isset($field['type']) && $field['type'] == 'link'
                    && isset($field['relationship']) && $field['relationship'] == $relName) {
                    $targetLinkField = $field;
                }
            }
        }

        if ($targetLinkField == null) {
            return array();
        } //no filtering

        $targetLinkFieldName = $targetLinkField['name'];

        $tmpBean = \BeanFactory::getBean($targetModule);

        $tmpBean->load_relationship($targetLinkFieldName);

        $tmpLink = $tmpBean->$targetLinkFieldName;

        $keyName = $targetModule . ':' . $targetLinkFieldName;

        $ret[$keyName] = array();

        $ret[$keyName]['name']                          = $targetModule . ' > ' . $beanName;
        $ret[$keyName]['parent']                        = 'self';
        $ret[$keyName]['link_def']                      = array();
        $ret[$keyName]['link_def']['name']              = $targetLinkFieldName;
        $ret[$keyName]['link_def']['relationship_name'] = $relName;
        $ret[$keyName]['link_def']['bean_is_lhs']       = (bool) ($tmpLink->_get_bean_position());
        $ret[$keyName]['link_def']['link_type']         = $tmpLink->getType();
        $ret[$keyName]['link_def']['label']             = $beanName;
        $ret[$keyName]['link_def']['module']            = $args['module'];
        $ret[$keyName]['link_def']['table_key']         = $keyName;

        // dependents is set in javascript. will keep this commented for an eventual fix needed
        // $ret[$keyName]['dependents'] = array('Filter.1_table_filter_row_1', 'Filter.1_table_filter_row_1');

        $ret[$keyName]['module'] = $args['module'];
        $ret[$keyName]['label']  = $beanName;

        return $ret;
    }

    /*
    Returns filters already set plus a new one that filters the result for current record
     */
    public function getFilterDefsWithAddin(&$args)
    {
        $report_info = &$this->report_def;
        $ret         = array();

        global $dictionary;

        $beanName = \BeanFactory::getObjectName($args['module']);

        $bean    = \BeanFactory::getBean($args['module']);
        $loadRes = $bean->load_relationship($args['link']);
        if (!$loadRes) {
            return $report_info['filters_def'];
        }
        $targetModule   = $bean->{$args['link']}->getRelatedModuleName();
        $targetBeanName = \BeanFactory::getObjectName($targetModule);

        $relName = $dictionary[$beanName]['fields'][$args['link']]['relationship'];

        //lets reverse lookup the target link field
        $targetLinkField = null;
        if ($dictionary[$targetBeanName]['fields']) {
            foreach ($dictionary[$targetBeanName]['fields'] as $fieldName => $field) {
                if (isset($field['type']) && $field['type'] == 'link'
                    && isset($field['relationship']) && $field['relationship'] == $relName) {
                    $targetLinkField = $field;
                }
            }
        }

        if ($targetLinkField == null) {
            return array();
        } //no filtering

        $targetLinkFieldName = $targetLinkField['name'];

        //custom filter key!
        $ret['Filter_1']             = array();
        $ret['Filter_1']['operator'] = 'AND';

        $tableKey                            = $targetModule . ':' . $targetLinkFieldName;
        $ret['Filter_1'][0]                  = array();
        $ret['Filter_1'][0]['name']          = $this->full_table_list[$tableKey]['params']['join_table_alias'] . '.id';
        $ret['Filter_1'][0]['table_key']     = $tableKey;
        $ret['Filter_1'][0]['qualifierName'] = 'is';
        $ret['Filter_1'][0]['input_name0']   = $args['record_id'];
        $ret['Filter_1'][0]['input_name1']   = $args['record_name'];

        $preset_filters = $report_info['filters_def'];
        if (!array_key_exists('Filter_1', $preset_filters)) {
            $preset_filters = $preset_filters["Filter_1"];
        }

        if (isset($args["customFilter"])) {
            $preset_filters = $args["customFilter"];
        }

        if (!empty($preset_filters)) {
            $ret['Filter_1'][1] = $preset_filters;

            $args["customFilter"] = $ret["Filter_1"];
        }

        return $ret;
    }

    protected function setWhere()
    {
        $db       = \DBManagerFactory::getInstance('reports');
        $tp_count = 1;
        for ($i = 0; $i < count($this->filters); $i++) {
            $groupValue = $db->quote($this->filters[$i]);
            $groupDef   = $this->report_def['group_defs'][$i];

            $fieldType = $groupDef['type'];
            $fieldName = $groupDef['name'];
            $tableKey  = $groupDef['table_key'];
            //for relate fields we filter on id_name
            if ($fieldType == "relate") {
                $relateField = $this->getFieldDefs($tableKey, $fieldName);
                $fieldName   = $relateField['id_name'];
            }
            $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
            $fieldAlias = "{$tableAlias}.{$fieldName}";

            //on date type fields (including fiscal year, quarters, months, ..)we have to format the filter value as the one in use in where statement
            if ($fieldType == 'date' || $fieldType == 'datetime' || $fieldType == 'datetimecombo') {

                if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                    $groupDef["timeperiods_count"] = $tp_count;
                    $tp_count                      = $tp_count + 1;
                }
                $this->layout_manager->defs['context'] = 'GroupBy';
                //widgetQuery uses $groupDef['column_function'] to create the formula
                $alteredGroupDef         = $groupDef;
                $alteredGroupDef['name'] = $fieldAlias;
                $fieldDbFormated         = $this->layout_manager->widgetQuery($alteredGroupDef);

                $fieldAlias = $fieldDbFormated;
            }

            if ($fieldType == 'currency') {
                //in Sugar9+, if fieldtype is currency, groupValue is an array containing both amount and currency id
                if (is_array($groupValue) && array_key_exists("amount", $groupValue) === true) {
                    $amount             = $groupValue['amount'];
                    $currencyId         = $groupValue['currency_id'];
                    $currencyTableAlias = $this->all_fields[$tableKey . ":currency_id"]['table_alias'];
                    $currencyField      = "{$currencyTableAlias}.currency_id";

                    if (empty($amount) || intval($amount) === '0') {
                        $this->where[] = "{$fieldAlias} is null or {$fieldAlias} = 0";
                    } else {
                        $this->where[] = "({$fieldAlias} = {$amount}) AND ({$currencyField} = '{$currencyId}')";
                    }
                } else {
                    $amount = $groupValue;
                    if (empty($amount) || intval($amount) === '0') {
                        $this->where[] = "{$fieldAlias} is null or {$fieldAlias} = 0";
                    } else {
                        $this->where[] = "({$fieldAlias} = {$amount})";
                    }
                }
            } else {
                if ($fieldType == "date" || $fieldType == "datetime" || $fieldType == "datetimecombo") {
                    //we need this case for fields like datetimecombo which can not understand an empty string as a date
                    if (empty($groupValue)) {
                        $where = "{$fieldAlias} is null";
                    } else {
                        $where = "{$fieldAlias} = '{$groupValue}'";
                    }
                    $this->where[] = "(" . $where . ")";
                } else {
                    $where = "{$fieldAlias} = '{$groupValue}'";
                    if (empty($groupValue)) {
                        $where .= " OR {$fieldAlias} is null";
                    }
                    $this->where[] = "(" . $where . ")";
                }
            }
        }
    }

    /**
     * @param $args Array Optionally it might contain "customFilter" given from UI
     */
    protected function addDefaultFilters($args)
    {
        $this->layout_manager->setAttribute('context', 'Filter');
        $filters      = $this->report_def['filters_def'];
        $where_clause = "";

        if (isset($args["customFilter"])) {
            $filters["Filter_1"] = $args["customFilter"];
        }

        if (isset($filters['Filter_1'])) {
            $this->filtersIterateAddJoins($filters['Filter_1']);
        }
        $this->filtersIterate($filters['Filter_1'], $where_clause);
        if (trim($where_clause) != "") {
            $this->where[] = $where_clause;
        }

        $baseTableAlias = $this->all_fields["self:id"]['real_table'];
        $this->where[]  = "{$baseTableAlias}.deleted = 0";
    }

    /*
    Recursevely iterate throw filters and add needed join statements
     */
    protected function filtersIterateAddJoins($filters)
    {
        for ($i = 0; $i < count($filters) - 1; $i++) {
            $current_filter = $filters[$i];
            if (isset($current_filter['operator'])) {
                $this->filtersIterateAddJoins($current_filter);
            } else {
                $tableKey = $current_filter['table_key'];
                if (!$this->full_table_list[$tableKey]['tableJoinMade']) {
                    $this->tableKeyNavigation = array();
                    $this->createTableKeyNavigation($tableKey);
                    $this->addJoins();
                }
            }
        }
    }

    /*
    Recursevely iterate throw fitlers and create the where statement
     */
    protected function filtersIterate($filters, &$where_clause)
    {
        $where_clause .= '(';
        $operator       = $filters['operator'];
        $isSubCondition = 0;
        if (count($filters) < 2) { // We only have an operator and an empty Filter Box.
            $where_clause .= "1=1";
        }
        for ($i = 0; $i < count($filters) - 1; $i++) {
            $current_filter = $filters[$i];
            if (isset($current_filter['operator'])) {
                $where_clause .= "(";
                $isSubCondition = 1;
                $this->filtersIterate($current_filter, $where_clause);
            } else {
                if (strpos($current_filter['name'], ".") === false) { //current_filter name comes with table alias prepended
                    $currentFilterName = $current_filter['name'];
                } else {
                    $currentFilterName = substr($current_filter['name'], strpos($current_filter['name'], ".") + 1, strlen($current_filter['name']));
                }
                $current_filter["name"] = $currentFilterName;

                if (empty($current_filter["qualifier_name"])) {
                    $current_filter["qualifier_name"] = $current_filter["qualifierName"];
                }

                $current_filter['table_alias'] = $this->all_fields[$current_filter['table_key'] . ":" . $current_filter['name']]['table_alias'];
                $current_filter['column_key']  = $current_filter['table_key'] . ":" . $current_filter['name'];
                $current_filter['type']        = $this->all_fields[$current_filter['table_key'] . ":" . $current_filter['name']]['type'];

                //widgetQuery will need DateTime objects to generate the filter
                //problem observed whith a queryFilterBetween_Dates filter and applies to others as well
                if (!empty($current_filter['type']) && ($current_filter['type'] == 'datetimecombo' || $current_filter['type'] == 'datetime')) {
                    if (!empty($current_filter['input_name0'])) {
                        try {
                            $current_filter['input_name0'] = new \SugarDateTime($current_filter['input_name0']);
                        } catch (\Exception $e) {
                            //do nothing
                        }
                    }
                    if (!empty($current_filter['input_name1'])) {
                        try {
                            $current_filter['input_name1'] = new \SugarDateTime($current_filter['input_name1']);
                        } catch (\Exception $e) {
                            //do nothing
                        }
                    }
                }

                if ($current_filter['type'] == 'relate') {
                    $fieldDef                     = $this->getFieldDefs($current_filter['table_key'], $current_filter['name']);
                    $idName                       = $fieldDef['id_name'];
                    $current_filter['name']       = $idName;
                    $current_filter['column_key'] = $current_filter['table_key'] . ":" . $idName;
                    $current_filter['type']       = 'id';
                }

                $select_piece = "(" . $this->layout_manager->widgetQuery($current_filter) . ")";
                $where_clause .= $select_piece;
            }
            if ($isSubCondition == 1) {
                $where_clause .= ")";
                // reset the subCondition
                $isSubCondition = 0;
            }
            if ($i != count($filters) - 2) {
                $where_clause .= " $operator ";
            }
        }
        $where_clause .= ')';
    }

    /*
    Add join to get record label

    @params $sourceRealTable
    @params $sourceIdName field name of id_name
    @params $relateModule
    @return $relateTableName
     */
    protected function addJoinForRelateField($sourceRealTable, $sourceIdName, $relateModule)
    {
        $relatedBean       = \BeanFactory::newBean($relateModule);
        $relatedTableName  = $relatedBean->table_name;
        $relatedTableAlias = $relatedTableName . "_" . $sourceIdName;

        $joinStatement = " LEFT JOIN {$relatedTableName} {$relatedTableAlias} on {$sourceRealTable}.{$sourceIdName} = {$relatedTableAlias}.id";
        $this->joins[] = $joinStatement;

        return $relatedTableAlias;
    }

    /*
    Calculates and returns number of groups of the report
    @return int
     */
    protected function getNumberOfGroupsWeAreSelectingFrom()
    {
        global $log;
        $interestingGroups = 0;

        if ($this->groupType == 'simple') {
            if (count($this->report_def['group_defs']) >= 1) {
                $interestingGroups = 1;
            } else {
                $log->debug('For this type of chart you have to define at least one Group By field.');
            }
        } elseif ($this->groupType == 'group') {
            if (count($this->report_def['group_defs']) >= 2) {
                $interestingGroups = 2;
            } else {
                $log->debug('For this type of chart you have to define at least two Group By fields.');
            }
        }

        return $interestingGroups;
    }

    protected function addGroupingRelations()
    {
        $groupDefs = $this->report_def['group_defs'];

        for ($i = 0; $i < $this->groupNumbers; $i++) {
            $groupDef = $this->report_def['group_defs'][$i];
            $tableKey = $groupDef['table_key'];

            $fieldDef = $this->getFieldDefs($tableKey, $groupDef['name']);
            if ($tableKey == 'self') {
                if ($groupDef['type'] == 'relate') {
                    $relateIdName = $fieldDef['id_name'];
                    $baseTable    = $this->all_fields[$tableKey . ":" . $relateIdName]['real_table'];
                    $fieldDb      = "{$baseTable}.{$relateIdName}";
                } elseif ($groupDef['type'] == 'date' || $groupDef['type'] == 'datetime' || $groupDef['type'] == 'datetimecombo') {
                    $fieldName = $groupDef['name'];
                    $baseTable = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];

                    $this->layout_manager->defs['context'] = 'GroupBy';
                    //widgetQuery uses $groupDef['column_function'] to create the formula
                    $groupDef['name'] = $baseTable . "." . $groupDef['name'];
                    $fieldDb          = $this->layout_manager->widgetQuery($groupDef);
                }
            } else {
                $tableKey = $groupDef['table_key'];

                if (!$this->full_table_list[$tableKey]['tableJoinMade']) {
                    $this->tableKeyNavigation = array();
                    $this->createTableKeyNavigation($tableKey);
                    $this->addJoins();
                }

                $fieldKey = $tableKey . ":" . $fieldDef['name'];
                if (!in_array($fieldKey, $this->fieldsAddedToSelect)) {
                    $this->addRelationToSelect($groupDef, $fieldDef);
                    array_push($this->fieldsAddedToSelect, $fieldKey);
                }
            }
        }
    }
    /*
    Retrieves field definition
    @params $table_key string
    @params $fieldName string
    @return $fieldDef array
     */
    protected function getFieldDefs($tableKey, $fieldName)
    {
        global $dictionary;

        $objectName = $this->full_bean_list[$tableKey]->object_name;
        $fieldDef   = $dictionary[$objectName]['fields'][$fieldName];

        return $fieldDef;
    }

    /*
    Creates joins for relate group entry and adds it to Select
    We have to add it to select also because $this->setSelect can not add it. SugarQuery expects fields given to be in the baseTable and relate types are not
    @params $groupDef Entry from report definition (report_def ['groupdef'])
     */
    protected function addRelationToSelect($groupDef, $fieldDef)
    {
        $tableKey    = $groupDef['table_key'];
        $fieldDefBak = $fieldDef;

        if ($fieldDef['type'] == 'relate') {
            $relateId = $fieldDef['id_name'];
            $fieldDef = $this->full_bean_list[$tableKey]->field_defs[$relateId];
        }

        $fieldName  = $fieldDef['name'];
        $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
        $fieldAlias = "{$tableAlias}_{$groupDef['name']}";
        $fieldDb    = "{$tableAlias}.{$fieldName}";

        if ($groupDef['type'] == 'date' || $groupDef['type'] == 'datetime' || $groupDef['type'] == 'datetimecombo') {
            $this->layout_manager->defs['context'] = 'GroupBy';
            //widgetQuery uses $groupDef['column_function'] to create the formula
            $groupDef['name'] = $tableAlias . "." . $groupDef['name'];
            $fieldDb          = $this->layout_manager->widgetQuery($groupDef);
        }

        $this->select_fields[] = "{$fieldDb} as {$fieldAlias}";

        // for label we have to make another join with target module
        if ($groupDef['type'] == 'relate') {
            $relateModule = $fieldDefBak['ext2'];

            //related field is not on all_fields so we have to find out his real table
            $fieldNameDef = $this->getRelatedFieldNameFromTarget($fieldDefBak);

            $idFieldDef        = $this->all_fields[$tableKey . ":" . $relateId];
            $sourceRealTable   = $idFieldDef['table_alias'];
            $relatedTableAlias = $this->addJoinForRelateField($sourceRealTable, $relateId, $relateModule);

            $fieldDb    = "{$relatedTableAlias}.name";
            $relateBean = \BeanFactory::newBean($relateModule);
            if ($relateBean->field_defs['name']['source'] == 'non-db') {
                $sourceFieldsDb = array("{$relatedTableAlias}.first_name", "{$relatedTableAlias}.last_name");
            } else {
                $sourceFieldsDb = array("{$relatedTableAlias}.name");
            }
            $fieldAlias  = "{$tableAlias}_{$groupDef['name']}_label";
            $fieldRawSql = "concat('', ";
            $fieldRawSql .= implode(", ' ', ", $sourceFieldsDb);
            $fieldRawSql .= ")";
            $fieldRawSql = $this->trimDb($fieldRawSql);
            $fieldRawSql = $fieldRawSql . " as {$fieldAlias}";

            //here we add the label of relate field. the id is added outside this if block
            $this->select_fields[] = $fieldRawSql;
        } elseif ($groupDef['type'] == 'name') {
            $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

            $fieldDb    = "{$table}.{$fieldName}";
            $fieldAlias = "{$table}_{$fieldName}";

            $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";

            // add id
            $fieldDb    = "{$table}.id";
            $fieldAlias = "{$table}_{$fieldName}_id";

            $this->select_fields[] = "{$this->isNullFunctional}({$fieldDb}, '') as {$fieldAlias}";
        }
    }

    /*
    Used to find real table of a relate field name (target record)

    @params $fieldNameDef Field definition in source record (where relate field is defined)
    @return $targetFieldDef array containing module and real table of the relate field
     */
    protected function getRelatedFieldNameFromTarget($sourceFieldNameDef)
    {
        $relateBean     = \BeanFactory::newBean($sourceFieldNameDef['ext2']);
        $targetFieldDef = $relateBean->field_defs['name'];

        $targetFieldDef['module']     = $relateBean->object_name;
        $targetFieldDef['real_table'] = $relateBean->table_name;

        return $targetFieldDef;
    }

    /*
    Gets key given and creates $this->tableKeyNavigation array containing all cronology up to base (exclusively)
    @params $groupTableKey
     */
    protected function createTableKeyNavigation($groupTableKey)
    {
        if (empty($groupTableKey)) {
            return;
        }

        if (array_key_exists('parent', $this->full_table_list[$groupTableKey])) {
            $this->tableKeyNavigation[] = $groupTableKey;
            $this->createTableKeyNavigation($this->full_table_list[$groupTableKey]['parent']);
        }
    }

    /*
    Extracts group function, field name and table list key fom given numericalChartValue
    @params $numericalChartValue String
    @returns array group function, field name and table list key
     */
    protected function parseNumericalChartColumn($numericalChartValue)
    {
        global $log;
        $result = false;

        $numericalChartComponents = explode(":", $numericalChartValue);
        if (count($numericalChartComponents) <= 1) {
            $log->fatal("Could not parse Data Series - numerical_chart_column: " . var_export($numericalChartComponents, true));
            return $result;
        }

        if (end($numericalChartComponents) == "count") { // count funciton on this group
            $groupFunction      = array_pop($numericalChartComponents);
            $fieldName          = "id";
            $tableListKeyColumn = implode(":", $numericalChartComponents);
        } else { // we have a group function
            $groupFunction      = array_pop($numericalChartComponents);
            $fieldName          = array_pop($numericalChartComponents);
            $tableListKeyColumn = implode(":", $numericalChartComponents);
        }

        return array($groupFunction, $fieldName, $tableListKeyColumn);
    }

    /*
    Gives aliases to all table keys entries. One for the join table and one for the base relate table
     */
    protected function initializeTableListAliases()
    {

        //add aliases for each table key (database table)
        foreach ($this->full_table_list as $tableKey => $tableDef) {
            $params = array();
            if (array_key_exists('link_def', $tableDef)) {
                $params = $tableDef['link_def'];
            }

            if (!isset($params['join_table_alias'])) {
                $params['join_table_alias'] = "jt" . $this->jtCount;
            }

            if (!isset($params['join_table_link_alias'])) {
                $params['join_table_link_alias'] = "jtl" . $this->jtCount;
            }
            $this->full_table_list[$tableKey]['params'] = $params;

            $this->jtCount++;
        }
    }

    protected function addAliasForASpecificKey($tableKey)
    {
        $tableDef = $this->full_table_list[$tableKey];
        $params   = array();
        if (array_key_exists('link_def', $tableDef)) {
            $params = $tableDef['link_def'];
        }

        if (!isset($params['join_table_alias'])) {
            $params['join_table_alias'] = "jt" . $this->jtCount;
        }

        if (!isset($params['join_table_link_alias'])) {
            $params['join_table_link_alias'] = "jtl" . $this->jtCount;
        }
        $this->full_table_list[$tableKey]['params'] = $params;

        $this->jtCount++;
    }

    /*
    Browse throw $this->tableKeyNavigation list and adds joins for each navigation key
     */
    protected function addJoins()
    {
        global $log;
        $joinMade = false;

        for ($i = count($this->tableKeyNavigation) - 1; $i >= 0; $i--) {
            $tableKey                = $this->tableKeyNavigation[$i];
            $tableDef                = $this->full_table_list[$tableKey];
            $relationship_name       = $tableDef['link_def']['relationship_name'];
            $link_name               = $tableDef['link_def']['name'];
            $params                  = $tableDef['params'];
            $params['includeCustom'] = true;

            if ($link_name != '') {
                if (isset($tableDef['parent'])) {
                    $parentKey = $tableDef['parent'];
                    $parentDef = $this->full_table_list[$parentKey];

                    if (isset($tableDef['optional']) && $tableDef['optional'] == 1) {
                        $params['join_type'] = 'LEFT JOIN ';
                    }

                    if (!isset($params['bean_is_lhs']) || $params['bean_is_lhs'] != 1) {
                        $params['right_join_table_alias']      = $this->full_table_list[$parentKey]['params']['join_table_alias'];
                        $params['right_join_table_link_alias'] = $this->full_table_list[$parentKey]['params']['join_table_link_alias'];
                    }
                    $params['left_join_table_alias']      = $this->full_table_list[$parentKey]['params']['join_table_alias'];
                    $params['left_join_table_link_alias'] = $this->full_table_list[$parentKey]['params']['join_table_link_alias'];

                    $load = $this->full_bean_list[$parentKey]->load_relationship($link_name);

                    $join = $this->full_bean_list[$parentKey]->$link_name->getJoin($params);

                    if ($this->full_bean_list[$tableKey]->hasCustomFields()) {
                        $join .= "LEFT JOIN " . $this->full_bean_list[$tableKey]->table_name . "_cstm " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . "_cstm
							ON " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . ".id = " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . "_cstm.id_c";
                    }
                    //fix for 3+ levels on relations used
                    if (!array_key_exists('tableJoinMade', $this->full_table_list[$tableKey]) || $this->full_table_list[$tableKey]['tableJoinMade'] != true) {
                        $this->joins[]                                     = $join;
                        $this->full_table_list[$tableKey]['tableJoinMade'] = true;
                        $joinMade                                          = true;
                    }
                }
            } else {
                $log->fatal("Unable to load link. Rel name: " . $relationship_name);
            }
        }

        $tableKey                                          = $this->tableKeyNavigation[0];
        $this->full_table_list[$tableKey]['tableJoinMade'] = $joinMade;
    }

    /*
    Populates $this->all_fields with field definitions.
    We also include real table source and Module names
    Format used is TABLE_KEY . ':' . FIELD_NAME
     */
    protected function _load_all_fields()
    {
        $tmp = array();
        foreach ($this->full_table_list as $table_key => $table_data) {
            if (!isset($table_data['module'])) {
                continue;
            }

            if (!isset($tmp[$table_data['module']])) {
                $tmp[$table_data['module']] = array();
            }

            if (!isset($this->full_bean_list[$table_key])) {
                continue;
            }

            $bean = $this->full_bean_list[$table_key];

            foreach ($bean->field_defs as $field_def) {
                $tmp[$table_data['module']][$field_def['name']] = 0;
                $field_def['real_table']                        = $this->full_bean_list[$table_key]->table_name;
                $field_def['table_alias']                       = $this->full_table_list[$table_key]['params']['join_table_alias'];
                if (!empty($field_def['source']) && ($field_def['source'] == 'custom_fields' || ($field_def['source'] == 'non-db'
                    && !empty($field_def['ext2']) && !empty($field_def['id']))) && !empty($field_def['real_table'])
                ) {
                    $field_def['real_table'] .= '_cstm';
                    $field_def['table_alias'] .= '_cstm';
                }
                if ($field_def['type'] == 'relate' && !empty($field_def['ext2'])) {
                    $joinFocus                    = \BeanFactory::getBean($field_def['ext2']);
                    $field_def['secondary_table'] = $joinFocus->table_name;
                    if (isset($table_data['link_def']) && isset($table_data['link_def']['module']) && isset($table_data['module'])
                        && $table_data['link_def']['module'] == $table_data['module']) {
                        $tmp[$table_data['module']][$field_def['name']]++;
                    }
                }
                $field_def['module']       = empty($field_def['module']) ? $bean->module_name : $field_def['module'];
                $field_def['rep_rel_name'] = $field_def['name'] . '_' . $tmp[$table_data['module']][$field_def['name']];

                $this->all_fields[$table_key . ':' . $field_def['name']] = $field_def;
            }
        }
    }

    /*
    Returns an array with 'meta' -  fields metadata
    'collection' - array with data to show in each cell ('key', ['label'] ,['id']). For relate and name types we add 'label' and 'id'
     */
    public function formatData($data)
    {
        global $timedate, $current_user, $app_list_strings;
        $res = array(
            'meta'       => array('panel' => array('fields' => array())),
            'collection' => array(),
        );
        $fieldListOrder = array();

        foreach ($this->displayColumns as $displayColumn) {
            $field = array(
                'name'      => $displayColumn['name'],
                'label'     => $displayColumn['label'],
                'table_key' => $displayColumn['table_key'],
            );

            $fieldDef = $this->all_fields[$displayColumn['table_key'] . ":" . $displayColumn['name']];

            $field['module']                  = $fieldDef['module'];
            $field['type']                    = $fieldDef['type'];
            $res['meta']['panel']['fields'][] = $field;

            $fieldToDisplay               = array();
            $fieldToDisplay['identifier'] = $fieldDef['table_alias'] . "_" . $displayColumn['name'];
            $fieldToDisplay['definition'] = $fieldDef;
            $fieldListOrder[]             = $fieldToDisplay;
        }

        // 'relate' fields need both id and label values. We store them in follow format: table-field_name and table-field_name_label
        // For 'name' fields we look on field name for his label and on FIELDNAME_id for record id
        $idx = 0;
        if (is_array($data)) {
            foreach ($data as $d) {
                $fields = array();
                foreach ($fieldListOrder as $fieldToDisplay) {
                    $fieldName       = $fieldToDisplay['identifier'];
                    $fieldDefinition = $fieldToDisplay['definition'];

                    $fieldToAdd = array("label" => $d[$fieldName]);

                    if ($fieldDefinition['type'] == 'name' || $fieldDefinition['type'] == 'fullname') {
                        $fieldToAdd['label'] = $d[$fieldName];
                        $fieldToAdd['id']    = '';
                        if (array_key_exists($fieldName . "_id", $d)) {
                            $fieldToAdd['id'] = $d[$fieldName . "_id"];
                        }
                    } elseif ($fieldDefinition['type'] == 'relate') {
                        $fieldToAdd['id'] = $d[$fieldName];
                        if (array_key_exists($fieldName . "_label", $d)) {
                            $fieldToAdd['label'] = $d[$fieldName . "_label"];
                        }
                    } elseif ($fieldDefinition['type'] == 'date') {
                        $dbDate = $timedate->fromDb($d[$fieldName]);
                        if ($dbDate !== false) {
                            $fieldToAdd['label'] = $timedate->asUserType($dbDate, 'date', $current_user);
                        }
                    } elseif ($fieldDefinition['type'] == 'datetime' || $fieldDefinition['type'] == 'datetimecombo') {
                        $dbDateTime = $timedate->fromDb($d[$fieldName]);
                        if ($dbDateTime !== false) {
                            $fieldToAdd['label'] = $timedate->asUserType($dbDateTime, 'datetime', $current_user);
                        }
                    } elseif ($fieldDefinition['type'] == 'currency') {
                        $symbol = $d[$fieldName . "_currency_symbol"];
                        $value  = $d[$fieldName];

                        if (strpos($fieldName, '_usdoll') !== false) {
                            // convert base to user preferred if set in user prefs
                            if ($current_user->getPreference('currency_show_preferred')) {
                                $userCurrency = \SugarCurrency::getUserLocaleCurrency();
                                $value        = \SugarCurrency::convertWithRate($value, 1.0, $userCurrency->conversion_rate);
                            }
                        }

                        $fieldToAdd['label'] = $symbol . $this->formatNumber($value);
                    } elseif ($fieldDefinition['type'] == "integer" || $fieldDefinition['type'] == "decimal" || $fieldDefinition['type'] == "float") {
                        $value               = $d[$fieldName];
                        $fieldToAdd['label'] = $this->formatNumber($value);
                    } elseif ($fieldDefinition['type'] == 'enum') {
                        $value               = $d[$fieldName];
                        $options             = $fieldDefinition['options'];
                        $dropdown            = $app_list_strings[$options];
                        $label               = $dropdown[$value];
                        $fieldToAdd['label'] = $label;
                    } elseif ($fieldDefinition['type'] == 'multienum') {
                        $options  = $fieldDefinition['options'];
                        $dropdown = $app_list_strings[$options];

                        $value = $d[$fieldName];
                        preg_match_all("/\^(.*?)\^/", $value, $enumValuesMatches);
                        if (count($enumValuesMatches) >= 2) {
                            $label       = "";
                            $valuesFound = $enumValuesMatches[1];
                            if (count($valuesFound) >= 1) {
                                foreach ($valuesFound as $enumValueFound) {
                                    $label .= $dropdown[$enumValueFound] . ", ";
                                }
                            }
                            $label = rtrim($label, ", ");
                        }
                        $fieldToAdd['label'] = $label;
                    } elseif ($fieldDefinition['type'] == 'umultirelate') {
                        $value       = json_decode($d[$fieldName]);
                        $display_arr = array();

                        foreach ($value as $key => $item) {
                            $display_arr[] = $item->name;
                        }
                        $fieldToAdd['label'] = implode(",", $display_arr);
                    }

                    if ($fieldToAdd["label"] == "[]") {
                        $fieldToAdd["label"] = "";
                    }

                    $fields[] = $fieldToAdd;
                }

                $newRow['fields']    = $fields;
                $newRow['row_index'] = $this->initialOffset + $idx++;
                $res['collection'][] = $newRow;
            }
        }

        return $res;
    }

    public function formatNumber($number, $decimals = null, $decimal_point = null, $thousands_sep = null)
    {
        global $locale;
        if (is_null($decimals)) {
            $decimals = $locale->getPrecision();
        }
        $seps          = get_number_seperators();
        $thousands_sep = $seps[0];
        $decimal_point = $seps[1];
        return number_format($number, $decimals, $decimal_point, $thousands_sep);
    }

    protected function addOrderByStatement($args)
    {
        if (array_key_exists('orderBy', $args)) {
            $orderBy   = $args['orderBy'];
            $tableKey  = $orderBy['table_key'];
            $fieldName = $orderBy['fieldname'];
            $fieldDef  = $this->getFieldDefs($tableKey, $fieldName);

            if ($fieldDef['type'] == 'relate') {
                $fieldName = $fieldDef['id_name'];
            }

            if ($tableKey == 'self') {
                $table = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
            } else {
                $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
            }
            $fieldDb = $table . "." . $fieldName;

            if ($fieldDef['type'] == 'fullname' && array_key_exists('source', $fieldDef) && $fieldDef['source'] == 'non-db') { //Leads use this field type
                $fieldDb = $table . "_full_name"; //that's the alias we use to agregate first name and last name
            }

            $this->orderBy[] = $fieldDb . " " . strtoupper($orderBy['direction']);
        } else {
            $table   = $this->all_fields["self:date_modified"]['real_table'];
            $fieldDb = $table . ".date_modified";

            //we sort by date_modified in this case because if not, joins made will put edited record on some other page
            $this->orderBy[] = $fieldDb . " DESC";
        }
    }

    protected function addPagination()
    {
        $recordsPerPagePlus1 = $this->limit + 1;
        $this->offset        = $this->offset;
        $this->limit         = $recordsPerPagePlus1;
    }

    public function getBaseTable()
    {
        return $this->baseTable;
    }
    public function setFieldsToSelect($fieldsToSelect)
    {
        $this->select_fields = $fieldsToSelect;
    }
    public function getQuery()
    {
        return $this->query;
    }
    public function getDbType()
    {
        return $this->dbType;
    }
}
