<?php
namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils;

class Utils
{
    public static function getwChartDashlets(array $metadata): array
    {
        if (is_array($metadata) === false) {
            return [];
        }

        $dashlets = [];
        if (isset($metadata["dashlets"])) {
            foreach ($metadata["dashlets"] as $dashlet) {
                if (
                    is_array($dashlet) && is_array($dashlet["view"])
                    && isset($dashlet["view"]["type"]) && $dashlet["view"]["type"] === "w-saved-reports-chart"
                    && empty($dashlet["view"]["saved_report_id"]) === false
                ) {
                    $dashlets[] = $dashlet["view"];
                }
            }
        } else {
            //bwc dashboards
            foreach ($metadata["components"] as $component) {
                foreach ($component["rows"] as $rows) {
                    foreach ($rows as $row) {
                        if (
                            is_array($row) && is_array($row["view"])
                            && isset($row["view"]["type"]) && $row["view"]["type"] === "w-saved-reports-chart"
                            && empty($row["view"]["saved_report_id"]) === false
                        ) {
                            $dashlets[] = $row["view"];
                        }
                    }
                }
            }
        }
        return $dashlets;
    }

}
