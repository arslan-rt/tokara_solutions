<?php
namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Utils;

use Doctrine\DBAL\Portability\Statement as Statement;

class FilterUtils
{
    /**
     * Return if dashlet/dashboard given has any filter set
     * @param Array $params
     *  $params[dashletId] string
     *  $params[dashboardId] string
     *  $params[userId] string
     *
     * @return Bool
     */
    public static function filterExistsInDb(string $table, array $params): bool
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("COUNT(*) AS record_count");
        $qb->from($table);

        // $qb->andWhere($qb->expr()->eq("1", "1"));
        if (isset($params["dashletId"])) {
            $qb->andWhere($qb->expr()->eq("dashlet_id", ":dashlet_id"));
            $qb->setParameter(":dashlet_id", $params["dashletId"]);
        }
        if (isset($params["dashboardId"])) {
            $qb->andWhere($qb->expr()->eq("dashboard_id", ":dashboard_id"));
            $qb->setParameter(":dashboard_id", $params["dashboardId"]);
        }
        if (isset($params["userId"])) {
            $qb->andWhere($qb->expr()->eq("user_id", ":user_id"));
            $qb->setParameter(":user_id", $params["userId"]);
        }

        $result = $qb->execute();

        if ($result instanceof Statement === true) {
            $result = $result->fetch();
        }

        if (is_array($result) === true && $result["record_count"] > 0) {
            return true;
        }

        return false;
    }

    /**
     * Returns dashlet/dashboard filter
     * @param Array $params
     *  $params[dashletId] string
     *  $params[dashboardId] string
     *  $params[userId] string
     *
     * @return Array
     */
    public static function getFilterFromDb(string $table, array $params): array
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("*");
        $qb->from($table);

        if (isset($params["dashletId"])) {
            $qb->andWhere($qb->expr()->eq("dashlet_id", ":dashlet_id"));
            $qb->setParameter(":dashlet_id", $params["dashletId"]);
        }
        if (isset($params["dashboardId"])) {
            $qb->andWhere($qb->expr()->eq("dashboard_id", ":dashboard_id"));
            $qb->setParameter(":dashboard_id", $params["dashboardId"]);
        }
        if (isset($params["userId"])) {
            $qb->andWhere($qb->expr()->eq("user_id", ":user_id"));
            $qb->setParameter(":user_id", $params["userId"]);
        }

        $result = $qb->execute();

        if ($result instanceof Statement === true) {
            $result = $result->fetch();
        }

        if (is_array($result) === true) {
            return $result;
        }

        return [];
    }

    public static function getDashboardTemplatesFromDb(string $dashboardId): array
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("templates");
        $qb->from("wdrilldown_report_filters_templates");
        $qb->where($qb->expr()->eq("dashboard_id", ":dashboard_id"));

        $qb->setParameter(":dashboard_id", $dashboardId);

        $dbResult = $qb->execute();

        if ($dbResult instanceof Statement === true) {
            $dbResult = $dbResult->fetch();
        }

        if (is_array($dbResult) && isset($dbResult["templates"])) {
            $templates = json_decode($dbResult["templates"], true);
            return $templates;
        }

        return [];
    }

    /**
     * Eg:
     * $patch = [
     *      "reportId":"efc0fedc-7905-11e9-a594-f218983a1c3e",
     *      "pathInReportFilters":[
     *         0
     *      ],
     *      "fieldName":"account_type",
     *      "qualifier_name":"is",  //required
     *      "qualifier":"is",
     *      "tableKey":"self",
     *      "input_name0":[         ////required
     *          "Customer"
     *      ],
     *      "input_name1": [        //required depending on qualifier
     *          "Customer2"
     *      ]
     * $this->applyFilterPatch($patch, $patch["pathInReportFilters"], $reporter->report_def['filters_def']['Filter_1']);
     */
    public static function applyFilterPatch($patch, $path, &$filterDef)
    {
        if (is_null($path)) {
            return;
        }
        if (count($path) === 1) {
            $filterDef[$path[0]]["qualifier_name"] = $patch["qualifier"];
            $filterDef[$path[0]]["input_name0"]    = $patch["input_name0"];
            if (isset($patch["input_name1"])) {
                $filterDef[$path[0]]["input_name1"] = $patch["input_name1"];
            }
        } else {
            $currentIdx = array_shift($path);
            self::applyFilterPatch($patch, $path, $filterDef[$currentIdx]);
        }
    }

    public static function insertDashboardTemplatesInDb(array $dataToSave): bool
    {
        global $dictionary;

        $db    = \DBManagerFactory::getInstance();
        $table = "wdrilldown_report_filters_templates";

        $fieldDefs = $dictionary[$table]["fields"];

        $inserted = $db->insertParams($table, $fieldDefs, $dataToSave);

        return $inserted;
    }

    public static function getDashboardMetadata(string $dashboardId): array
    {
        $data = [];

        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->select("metadata");
        $qb->from("dashboards");
        $qb->where($qb->expr()->eq("id", ":dashboard_id"));

        $qb->setParameter(":dashboard_id", $dashboardId);

        $result = $qb->execute();

        if ($result instanceof Statement === true) {
            $result = $result->fetch();
        }

        if (is_array($result) && isset($result["metadata"])) {
            $data = json_decode($result["metadata"], true);
        }

        return $data;
    }

    public static function removeFiltersOfDashletId(string $dashletIdToRemove): void
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->delete("wdrilldown_report_filters_dashlets");
        $qb->where("dashlet_id = :dashlet_id");
        $qb->andWhere("user_id = :user_id");
        $qb->setParameter(":dashlet_id", $dashletIdToRemove);
        $qb->setParameter(":user_id", $GLOBALS["current_user"]->id);
        $qb->execute();
    }

    public static function removeDashboardFilters(string $dashboardIdToRemove): void
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->delete("wdrilldown_report_filters_dashboards");
        $qb->where("dashboard_id = :dashboard_id");
        $qb->andWhere("user_id = :user_id");
        $qb->setParameter(":dashboard_id", $dashboardIdToRemove);
        $qb->setParameter(":user_id", $GLOBALS["current_user"]->id);
        $qb->execute();
    }

    public static function removeDashboardFilterTemplate(string $dashboardIdToRemove): void
    {
        $qb = \DBManagerFactory::getConnection()->createQueryBuilder();

        $qb->delete("wdrilldown_report_filters_templates");
        $qb->where("dashboard_id = :dashboard_id");
        $qb->setParameter(":dashboard_id", $dashboardIdToRemove);
        $qb->execute();
    }

    public static function getWChartDashletIds(array $metadata): array
    {
        $dashletIds = [];
        foreach ($metadata["dashlets"] as $dashlet) {
            if (
                is_array($dashlet) && is_array($dashlet["view"])
                && isset($dashlet["view"]["type"])
                && $dashlet["view"]["type"] === "w-saved-reports-chart"
                && is_string($dashlet["view"]["dashletId"])
            ) {
                $dashletIds[] = $dashlet["view"]["dashletId"];
            }
        }

        return $dashletIds;
    }

    public static function getWChartDashlets(array $metadata): array
    {
        $dashlets = [];
        foreach ($metadata["dashlets"] as $dashlet) {
            if (
                is_array($dashlet) && is_array($dashlet["view"])
                && isset($dashlet["view"]["type"])
                && $dashlet["view"]["type"] === "w-saved-reports-chart"
                && is_string($dashlet["view"]["dashletId"])
            ) {
                $dashlets[] = $dashlet["view"];
            }
        }

        return $dashlets;
    }

}
