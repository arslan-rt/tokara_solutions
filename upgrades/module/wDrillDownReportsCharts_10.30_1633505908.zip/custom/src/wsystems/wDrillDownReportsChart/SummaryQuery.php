<?php
namespace Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart;

use BeanFactory;
use stdClass;
use Sugarcrm\Sugarcrm\custom\wsystems\wDrillDownReportsChart\Traits\VardefsHandlerTrait;

include_once 'include/generic/LayoutManager.php';

class SummaryQuery
{
    use VardefsHandlerTrait;
    protected $report_def      = array();
    protected $full_table_list = array();
    protected $full_bean_list  = array();
    protected $all_fields      = array();
    protected $module          = '';
    protected $groupType       = 'simple'; //simple/group
    protected $baseTable       = '';
    protected $isTotalQuery    = false;

    //mysql has ifnull while mssql has isnull
    private $isNullFunction = "ifnull";
    private $dbType         = "mysql";

    protected $query         = '';
    protected $from          = '';
    protected $select_fields = array();
    protected $joins         = array();
    protected $where         = array();
    protected $groupBy       = array();
    protected $orderBy       = '';

    // Used to create select, group by and order by statements for Fiscals and Quarters grouping types
    protected $layout_manager = null;
    // Used to create unique join table aliases
    protected $jtCount = 0;
    // Versatile variable. Used for building joins
    protected $tableKeyNavigation = array();
    // If groupType is 'group', we expect we make groupings on two fields
    //For 'simple' type we only have one group by
    protected $groupNumbers = 1;

    public function __construct($reporter, $groupType)
    {
        global $dictionary, $sugar_config;

        if ((array_key_exists('db_manager', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_manager'] == "SqlsrvManager")
            || (array_key_exists('db_type', $sugar_config['dbconfig']) && $sugar_config['dbconfig']['db_type'] == 'mssql')
        ) {
            $this->dbType         = "mssql";
            $this->isNullFunction = 'isnull';
        }

        $this->report_def      = $reporter->report_def;
        $this->full_table_list = $this->report_def['full_table_list'];

        $this->full_bean_list = $reporter->full_bean_list;
        $this->module         = $this->report_def['module'];
        $this->groupType      = $groupType;

        $this->baseBean  = \BeanFactory::newBean($this->module);
        $this->baseTable = $dictionary[$this->baseBean->object_name]['table'];

        $this->initializeTableListAliases();
        $this->full_table_list['self']['params']['join_table_alias'] = $this->baseTable;

        $this->groupNumbers = $this->getNumberOfGroupsWeAreSelectingFrom();

        $this->_load_all_fields();

        $this->layout_manager                      = new \LayoutManager();
        $this->layout_manager->default_widget_name = 'ReportField';
        $this->layout_manager->setAttributePtr('reporter', $reporter);

        //add missing type on report groupings
        for ($i = 0; $i < count($this->report_def['group_defs']); $i++) {
            $groupDef                                   = $this->report_def['group_defs'][$i];
            $this->report_def['group_defs'][$i]["type"] = $this->all_fields[$groupDef['table_key'] . ":" . $groupDef["name"]]["type"];
        }
    }

    private function trimDb($contentToTrim)
    {
        $trim = "trim(" . $contentToTrim . ")"; //mysql
        if ($this->dbType === "mssql") {
            $trim = "ltrim(rtrim(" . $contentToTrim . "))";
        }

        return $trim;
    }

    /*
    Entry point for api
    @return array
     */
    public function getData(&$args)
    {
        global $log;
        $db              = \DBManagerFactory::getInstance('reports');
        $result          = array();
        $fieldExistsFlag = $this->validateFieldsInReport($args);
        if ($fieldExistsFlag["fieldExists"] === false) {
            $args["error"] = $fieldExistsFlag["fieldName"];
            return $result;
        }

        $this->parseRequest($args);
        $this->generateQuery($args);

        $log->debug($this->query);

        $dbRes = $db->query($this->query);
        while ($row = $db->fetchByAssoc($dbRes)) {
            $result[] = $row;
        }

        return $result;
    }

    /**
     * Check fields existence in vardefs
     * @param array $args
     * @return array
     */

    public function validateFieldsInReport($args)
    {
        global $relationships;
        $beanReport    = BeanFactory::getBean("Reports", $args["reportId"]);
        $reportContent = json_decode($beanReport->content);
        foreach ($reportContent->filters_def as $filter => $filterContent) {
            foreach ($filterContent as $filterDef) {
                if ($filterDef instanceof stdClass) {
                    $moduleName = $reportContent->module;
                    $fieldName  = $filterDef->name;
                    if ($filterDef->table_key !== "self") {
                        $moduleRelationships = explode(":", $filterDef->table_key);
                        unset($moduleRelationships[0]);
                        foreach ($moduleRelationships as $relationship) {
                            $relatedMeta = $this->vardefMetaGet($moduleName, $relationship);
                            if (empty($relatedMeta) && empty($relationships[$relationship]) === false) {
                                $relationshipDef = $relationships[$relationship];
                                $moduleName      = $this->setModuleNameByRelatedMeta($relationshipDef, $moduleName);
                            } else {
                                if (empty($relatedMeta["module"]) && empty($relatedMeta["relationship"]) === false) {
                                    if (empty($relationships[$relatedMeta["relationship"]]) === false) {
                                        $relationshipDef = $relationships[$relatedMeta["relationship"]];
                                        $moduleName      = $this->setModuleNameByRelatedMeta($relationshipDef, $moduleName);
                                    }
                                } else {
                                    $moduleName = $relatedMeta["module"];
                                }
                            }
                        }
                    }
                    $fieldDefInFilter = $this->vardefMetaGet($moduleName, $fieldName);
                    if (empty($fieldDefInFilter)) {
                        return [
                            "fieldExists" => false,
                            "fieldName"   => $filterDef->name,
                        ];
                    }
                }
            }
        }

        return [
            "fieldExists" => true,
        ];
    }

    protected function setModuleNameByRelatedMeta($relationshipDef, $oldModuleName)
    {
        $moduleName = "";
        if ($relationshipDef["lhs_module"] !== $oldModuleName) {
            $moduleName = $relationshipDef["lhs_module"];
        } else {
            $moduleName = $relationshipDef["rhs_module"];
        }

        return $moduleName;
    }

    /*
    Parses report in order to extract field names, from statement, joins, wheres,...
    All of these are put in properties on this object
     */
    protected function parseRequest($args)
    {
        $this->createFrom();
        $this->setBasicSelect();
        $this->addDataSeriesColumn();
        $this->setGroupings();
        $this->createOrderBy();
        $this->addJoinsOnDisplayColumnFieldsFromOtherModules();
        $this->addTimePeriods();

        if (!empty($args['link']) && isset($args["reportDefinitionOnly"]) === false) {
            $this->appendCurrentRecordFilterDefinition($args);
        }

        $this->addDefaultFilters($args);

        $this->addSecurity();
    }

    /*
    Creates query for chart rendering
     */
    public function generateQuery($args)
    {
        $query         = "";
        $select_fields = "SELECT ";
        for ($i = 0; $i < count($this->select_fields); $i++) {
            if ($i >= 1) {
                $select_fields .= ", ";
            }
            $select_fields .= $this->select_fields[$i] . " ";
        }
        $groupBy = "";
        if (count($this->groupBy) > 0) {
            $groupBy = "GROUP BY ";
            for ($i = 0; $i < count($this->groupBy); $i++) {
                if ($i >= 1) {
                    $groupBy .= ", ";
                }
                $groupBy .= $this->groupBy[$i] . " ";
            }
        }
        $joins = "";
        for ($i = 0; $i < count($this->joins); $i++) {
            $joins .= $this->joins[$i] . " ";
        }
        $where = "";
        if (count($this->where) > 0) {
            $where = "WHERE ";
            for ($i = 0; $i < count($this->where); $i++) {
                if ($i >= 1) {
                    $where .= " AND ";
                }
                $where .= $this->where[$i] . " ";
            }
        }

        $query .= $select_fields;
        $query .= $this->from;
        $query .= $joins;
        $query .= $where;
        $query .= $groupBy;
        $query .= $this->orderBy;

        $this->query = $query;
    }

    /*
    In summation with details users can set display columns from related modules.
    This mean joins are made for each different module. So here we need to add them manually because if not we'll not have the same charts
     */
    public function addJoinsOnDisplayColumnFieldsFromOtherModules()
    {
        if (array_key_exists('display_columns', $this->report_def)) {
            $displayColumns = $this->report_def['display_columns'];
            foreach ($displayColumns as $displayColumn) {
                if ($displayColumn['table_key'] != 'self') {
                    if (!array_key_exists('tableJoinMade', $this->full_table_list[$displayColumn['table_key']]) || $this->full_table_list[$displayColumn['table_key']]['tableJoinMade'] != true) {
                        $this->tableKeyNavigation = array();
                        $this->createTableKeyNavigation($displayColumn['table_key']);
                        $this->addJoins();
                    }
                }
            }
        }
    }

    public function addTimePeriods()
    {
        $tp_count = 1;
        foreach ($this->report_def["group_defs"] as $idx => $groupDef) {
            if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                $tableKey   = $groupDef['table_key'];
                $fieldName  = $groupDef['name'];
                $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];

                $fieldName = $tableAlias . "." . $fieldName;

                $this->joins[] = " INNER JOIN timeperiods tp" . $tp_count . " ON (" . $fieldName .
                    " >= tp" . $tp_count . ".start_date AND " . $fieldName . " <= tp" . $tp_count . ".end_date" .
                    " AND tp" . $tp_count . ".type = 'Quarter' AND tp" . $tp_count . ".deleted = 0)\n";
                $tp_count++;
            }
        }
    }

    /*
    Needed on total calculation. In this use case we'll not make group bys where we add the joins.
    So we will meke them here.
     */
    public function addJoinsOnSummaryColumnFieldsFromOtherModules()
    {
        if (array_key_exists('summary_columns', $this->report_def)) {
            $displayColumns = $this->report_def['summary_columns'];

            foreach ($displayColumns as $displayColumn) {
                if ($displayColumn['table_key'] != 'self') {
                    $a = $this->full_table_list[$displayColumn['table_key']];
                    if (!array_key_exists('tableJoinMade', $this->full_table_list[$displayColumn['table_key']]) || $this->full_table_list[$displayColumn['table_key']]['tableJoinMade'] != true) {
                        $this->tableKeyNavigation = array();
                        $this->createTableKeyNavigation($displayColumn['table_key']);
                        $this->addJoins();
                    }
                }
            }
        }
    }

    /**
     * Adds security like in Reports.php on the base module only
     */
    protected function addSecurity()
    {
        global $current_user, $mod_strings, $log;

        if (!is_admin($current_user)) {
            $where_clause = "";
            // add team security
            $focus   = $this->baseBean;
            $options = array(
                // notify visibility strategies we are running from reports
                'report_query'    => true,
                'where_condition' => true,
            );
            $focus->addVisibilityWhere($where_clause, $options);

            // add visibility permissions based on role
            $list_action = \ACLAction::getUserAccessLevel($current_user->id, $this->baseBean->module_dir, 'list', $type = 'module');
            $view_action = \ACLAction::getUserAccessLevel($current_user->id, $this->baseBean->module_dir, 'view', $type = 'module');

            if ($list_action == ACL_ALLOW_NONE || $view_action == ACL_ALLOW_NONE) {
                $log->fatal("You are not able to access this report due to permissions restrictions.");
                die("You are not able to access this report due to permissions restrictions.");
            }
            $aclVisibility = new \ACLVisibility($this->baseBean);
            $aclVisibility->setOptions(array('action' => 'view'));
            $aclVisibility->addVisibilityWhere($where_clause);
            $aclVisibility->setOptions(array('action' => 'list'));
            $aclVisibility->addVisibilityWhere($where_clause);
            if (trim($where_clause) != "") {
                $this->where[] = $where_clause;
            }
        }
    }

    protected function createFrom()
    {
        $db = \DBManagerFactory::getInstance('reports');

        $this->from = "\nFROM " . $this->baseBean->table_name . "\n";

        if ($db->tableExists($this->baseBean->table_name . '_cstm')) {
            $this->from .= "\nLEFT JOIN {$this->baseBean->table_name}_cstm on {$this->baseBean->table_name}_cstm.id_c = {$this->baseBean->table_name}.id \n";
        }
    }

    /*
    Adds to Select only fields in the base record cause just these fields are available without additional joins
     */
    protected function setBasicSelect()
    {
        global $log;

        $tp_count = 1;
        for ($i = 0; $i < $this->groupNumbers; $i++) {
            $groupDef = $this->report_def['group_defs'][$i];
            $tableKey = $groupDef['table_key'];
            if ($tableKey == "self") {
                if ($groupDef['type'] == 'relate') {
                    //add id_name field to select
                    $nameFieldDef          = $this->all_fields[$tableKey . ":" . $groupDef['name']];
                    $relateModule          = $nameFieldDef['ext2'];
                    $relateId              = $nameFieldDef['id_name'];
                    $tableAlias            = $this->all_fields[$tableKey . ":" . $relateId]['real_table'];
                    $idFieldDb             = "{$tableAlias}.{$relateId}";
                    $fieldAlias            = "{$tableAlias}_{$groupDef['name']}";
                    $this->select_fields[] = "{$this->isNullFunction}({$idFieldDb}, '') as {$fieldAlias}";

                    //add label to select. This implies a new join also
                    $idFieldDef        = $this->all_fields[$tableKey . ":" . $relateId];
                    $sourceRealTable   = $idFieldDef['table_alias'];
                    $relatedTableAlias = $this->addJoinForRelateField($sourceRealTable, $relateId, $relateModule);
                    $relateName        = $idFieldDef['name'];
                    $tableAlias        = $this->all_fields[$tableKey . ":" . $relateName]['real_table'];

                    $relateBean = \BeanFactory::newBean($relateModule);
                    if ($relateBean->field_defs['name']['source'] == 'non-db') {
                        $sourceFieldsDb = array("{$this->isNullFunction}({$relatedTableAlias}.first_name, '')", "{$this->isNullFunction}({$relatedTableAlias}.last_name, '')");
                    } else {
                        $sourceFieldsDb = array("{$this->isNullFunction}({$relatedTableAlias}.name, '')");
                    }
                    $fieldAlias  = "{$tableAlias}_{$groupDef['name']}_label";
                    $fieldRawSql = "trim(concat('', ";
                    $fieldRawSql .= implode(", ' ', ", $sourceFieldsDb);
                    $fieldRawSql .= "))";

                    $fieldRawTemp = $this->trimDb($fieldRawSql);
                    $fieldRawSql  = $fieldRawTemp . " as {$fieldAlias}";

                    $this->select_fields[] = $fieldRawSql;
                    if ($this->dbType == "mssql") {
                        $this->groupBy[] = "{$relatedTableAlias}.name"; //mssql can't work without this. see setGroupings
                    }
                } elseif ($groupDef['type'] == 'date' || $groupDef['type'] == 'datetime' || $groupDef['type'] == 'datetimecombo') {
                    $fieldName  = $groupDef['name'];
                    $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    $fieldAlias = "{$tableAlias}_{$fieldName}";
                    //unique aliases has to be used to parse them correctly
                    if (array_key_exists('column_function', $groupDef) && !empty($groupDef['column_function'])) {
                        $fieldAlias .= "_" . $groupDef['column_function'];
                    }
                    if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                        $groupDef["timeperiods_count"] = $tp_count;
                        $tp_count                      = $tp_count + 1;
                    }
                    $this->layout_manager->defs['context'] = 'GroupBy';
                    //widgetQuery uses $groupDef['column_function'] to create the formula
                    $groupDef['name'] = $tableAlias . "." . $groupDef['name'];
                    $fieldDb          = $this->layout_manager->widgetQuery($groupDef);

                    $this->select_fields[] = "{$this->isNullFunction}({$fieldDb}, '') as {$fieldAlias}";
                } elseif ($groupDef['type'] == 'currency') {
                    $fieldName             = $groupDef['name'];
                    $tableAlias            = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    $fieldAlias            = "{$tableAlias}_{$fieldName}";
                    $fieldDb               = "{$tableAlias}.{$fieldName}";
                    $this->select_fields[] = "{$this->isNullFunction}({$fieldDb}, 0) as {$fieldAlias}";
                    $currencyFieldDef      = $this->all_fields[$tableKey . ":" . $fieldName];

                    if (array_key_exists('currency_id', $currencyFieldDef) && !empty($currencyFieldDef['currency_id'])) {
                        $currencyTableAlias    = $this->all_fields[$tableKey . ":currency_id"]['real_table'];
                        $currencyFieldAlias    = "{$currencyTableAlias}_currency_id";
                        $currencyIdPredefined  = $currencyFieldDef['currency_id'];
                        $this->select_fields[] = "'{$currencyIdPredefined}' as {$currencyFieldAlias}";
                    } elseif (array_key_exists('is_base_currency', $currencyFieldDef) && $currencyFieldDef['is_base_currency'] == true) {
                        if ($GLOBALS['current_user']->getPreference('currency_show_preferred')) {
                            $userCurrency         = \SugarCurrency::getUserLocaleCurrency();
                            $currencyIdPredefined = $userCurrency->id;
                        } else {
                            $currencyIdPredefined = \SugarCurrency::getBaseCurrency()->id;
                        }
                        $currencyTableAlias    = $this->all_fields[$tableKey . ":currency_id"]['real_table'];
                        $currencyFieldAlias    = "{$currencyTableAlias}_currency_id";
                        $this->select_fields[] = "'{$currencyIdPredefined}' as {$currencyFieldAlias}";
                    } else {
                        $currencyTableAlias    = $this->all_fields[$tableKey . ":currency_id"]['real_table'];
                        $currencyFieldAlias    = "{$currencyTableAlias}_currency_id";
                        $currencyFieldDb       = "{$currencyTableAlias}.currency_id";
                        $this->select_fields[] = "{$this->isNullFunction}({$currencyFieldDb}, 0) as {$currencyFieldAlias}";
                    }
                } else {
                    $fieldName = $groupDef['name'];
                    $baseTable = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];

                    $fieldDb    = "{$baseTable}.{$fieldName}";
                    $fieldAlias = "{$baseTable}_{$fieldName}";

                    $fieldDef            = $this->all_fields[$tableKey . ":" . $fieldName];
                    $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);

                    $this->select_fields[] = "{$this->isNullFunction}({$fieldDb}, {$defaultNotNullValue}) as {$fieldAlias}";
                }
            }
        }
        //this record count is usefull on funnel charts and manual sort by set on summation reports
        if (!$this->isTotalQuery) {
            $baseTable             = $this->all_fields[$tableKey . ":id"]['table_alias'];
            $fieldDb               = "{$baseTable}.id";
            $fieldAlias            = "records_count";
            $this->select_fields[] = "count({$fieldDb}) as {$fieldAlias}";
        }
    }

    /**
     * Functionality like in dashablelist dashlet.
     * For 'link' setting - a link type in context bean, we'll append that relation on query by adding joins and corresponding filters (if any)
     * @method appendCurrentRecordFilterDefinition
     * @param  Array   $args
     * @return NULL           Changes are made directly on $this and parsed afterwards
     */
    protected function appendCurrentRecordFilterDefinition(&$args)
    {
        $tableListToAdd = $this->getTableListAddinDefinition($args);
        foreach ($tableListToAdd as $key => $val) {
            if (!array_key_exists($key, $this->full_table_list)) {
                $this->full_table_list[$key] = $val;
            }

            if (!array_key_exists($key, $this->full_bean_list)) {
                $this->full_bean_list[$key] = \BeanFactory::newBean($val['module']);
            }

            if (
                !array_key_exists('params', $this->full_table_list[$key]) || !array_key_exists('join_table_alias', $this->full_table_list[$key]['params'])
                || empty($this->full_table_list[$key]['params']['join_table_alias'])
            ) {
                $this->addAliasForASpecificKey($key);
            }
        }

        $this->report_def['filters_def'] = $this->getFilterDefsWithAddin($args);

        $this->all_fields = [];
        $this->_load_all_fields();
    }

    /*
    Used to add to full_table_list for relate to current record functionality.
    The new filter added on getFilterDefsWithAddin will need full_table_list
     */
    protected function getTableListAddinDefinition($args)
    {
        $ret = array();

        global $dictionary;

        $beanName = \BeanFactory::getObjectName($args['module']);

        $bean = \BeanFactory::getBean($args['module']);
        $bean->load_relationship($args['link']);
        $targetModule   = $bean->{$args['link']}->getRelatedModuleName();
        $targetBeanName = \BeanFactory::getObjectName($targetModule);

        $relName = $dictionary[$beanName]['fields'][$args['link']]['relationship'];

        //lets reverse lookup the target link field
        $targetLinkField = null;
        if ($dictionary[$targetBeanName]['fields']) {
            foreach ($dictionary[$targetBeanName]['fields'] as $fieldName => $field) {
                if (
                    isset($field['type']) && $field['type'] == 'link'
                    && isset($field['relationship']) && $field['relationship'] == $relName
                ) {
                    $targetLinkField = $field;
                }
            }
        }

        if ($targetLinkField == null) {
            return array();
        } //no filtering

        $targetLinkFieldName = $targetLinkField['name'];

        $tmpBean = \BeanFactory::getBean($targetModule);

        $tmpBean->load_relationship($targetLinkFieldName);

        $tmpLink = $tmpBean->$targetLinkFieldName;

        $keyName = $targetModule . ':' . $targetLinkFieldName;

        $ret[$keyName] = array();

        $ret[$keyName]['name']                          = $targetModule . ' > ' . $beanName;
        $ret[$keyName]['parent']                        = 'self';
        $ret[$keyName]['link_def']                      = array();
        $ret[$keyName]['link_def']['name']              = $targetLinkFieldName;
        $ret[$keyName]['link_def']['relationship_name'] = $relName;
        $ret[$keyName]['link_def']['bean_is_lhs']       = (bool) ($tmpLink->_get_bean_position());
        $ret[$keyName]['link_def']['link_type']         = $tmpLink->getType();
        $ret[$keyName]['link_def']['label']             = $beanName;
        $ret[$keyName]['link_def']['module']            = $args['module'];
        $ret[$keyName]['link_def']['table_key']         = $keyName;

        // dependents is set in javascript. will keep this commented for an eventual fix needed
        // $ret[$keyName]['dependents'] = array('Filter.1_table_filter_row_1', 'Filter.1_table_filter_row_1');

        $ret[$keyName]['module'] = $args['module'];
        $ret[$keyName]['label']  = $beanName;

        return $ret;
    }

    /*
    Returns existing filters plus a new one that filters the result for current record
     */
    public function getFilterDefsWithAddin(&$args)
    {
        $report_info = &$this->report_def;
        $ret         = array();

        global $dictionary;

        $beanName = \BeanFactory::getObjectName($args['module']);

        $bean    = \BeanFactory::getBean($args['module']);
        $loadRes = $bean->load_relationship($args['link']);
        if (!$loadRes) {
            return $report_info['filters_def'];
        }
        $targetModule   = $bean->{$args['link']}->getRelatedModuleName();
        $targetBeanName = \BeanFactory::getObjectName($targetModule);

        $relName = $dictionary[$beanName]['fields'][$args['link']]['relationship'];

        //lets reverse lookup the target link field
        $targetLinkField = null;
        if ($dictionary[$targetBeanName]['fields']) {
            foreach ($dictionary[$targetBeanName]['fields'] as $fieldName => $field) {
                if (
                    isset($field['type']) && $field['type'] == 'link'
                    && isset($field['relationship']) && $field['relationship'] == $relName
                ) {
                    $targetLinkField = $field;
                }
            }
        }

        if ($targetLinkField == null) {
            return array();
        } //no filtering

        $targetLinkFieldName = $targetLinkField['name'];

        //custom filter key!
        $ret['Filter_1']             = array();
        $ret['Filter_1']['operator'] = 'AND';

        $tableKey                            = $targetModule . ':' . $targetLinkFieldName;
        $ret['Filter_1'][0]                  = array();
        $ret['Filter_1'][0]['name']          = $this->full_table_list[$tableKey]['params']['join_table_alias'] . '.id';
        $ret['Filter_1'][0]['table_key']     = $tableKey;
        $ret['Filter_1'][0]['qualifierName'] = 'is';
        $ret['Filter_1'][0]['input_name0']   = $args['record_id'];
        $ret['Filter_1'][0]['input_name1']   = $args['record_name'];

        $preset_filters = $report_info['filters_def'];
        if (!array_key_exists('Filter_1', $preset_filters)) {
            $preset_filters = $preset_filters["Filter_1"];
        }

        if (isset($args["customFilter"])) {
            $preset_filters = $args["customFilter"];
        }

        if (!empty($preset_filters)) {
            $ret['Filter_1'][1] = $preset_filters;
        }
        $args["customFilter"] = $ret["Filter_1"];

        return $ret;
    }

    /**
     * @param $args Array Optionally it might contain "customFilter" given from UI
     */
    protected function addDefaultFilters($args)
    {
        $this->layout_manager->setAttribute('context', 'Filter');
        $filters = $this->report_def['filters_def'];

        if (isset($args["customFilter"])) {
            $filters["Filter_1"] = $args["customFilter"];
        }

        //Sugar keeps all filtes in Filter_1
        if (isset($filters['Filter_1'])) {
            $where_clause = "";
            $this->filtersIterateAddJoins($filters['Filter_1']);
            $this->filtersIterate($filters['Filter_1'], $where_clause);

            if (trim($where_clause) != "") {
                $this->where[] = $where_clause;
            }
        }
        $baseTableAlias = $this->all_fields["self:id"]['real_table'];
        $this->where[]  = "{$baseTableAlias}.deleted = 0";
    }

    /*
    Recursevely iterate throw filters and add needed join statements
     */
    protected function filtersIterateAddJoins($filters)
    {
        for ($i = 0; $i < count($filters) - 1; $i++) {
            $current_filter = $filters[$i];
            if (isset($current_filter['operator'])) {
                $this->filtersIterateAddJoins($current_filter);
            } else {
                $tableKey = $current_filter['table_key'];
                if (!$this->full_table_list[$tableKey]['tableJoinMade']) {
                    $this->tableKeyNavigation = array();
                    $this->createTableKeyNavigation($tableKey);
                    if (count($this->tableKeyNavigation) > 0) {
                        $this->addJoins();
                    }
                }
            }
        }
    }

    /*
    Recursevely iterate throw filters and create the where statement
     */
    protected function filtersIterate($filters, &$where_clause)
    {
        //$where_arr = array();
        $where_clause .= '(';
        $operator       = $filters['operator'];
        $isSubCondition = 0;
        if (count($filters) < 2) {
            // We only have an operator and an empty Filter Box.
            $where_clause .= "1=1";
        }

        for ($i = 0; $i < count($filters) - 1; $i++) {
            $current_filter = $filters[$i];
            if (isset($current_filter['operator'])) {
                $where_clause .= "(";
                $isSubCondition = 1;
                $this->filtersIterate($current_filter, $where_clause);
            } else {
                if (strpos($current_filter['name'], ".") === false) { //current_filter name comes with table alias prepended
                    $currentFilterName = $current_filter['name'];
                } else {
                    $currentFilterName = substr($current_filter['name'], strpos($current_filter['name'], ".") + 1, strlen($current_filter['name']));
                }
                $current_filter["name"] = $currentFilterName;

                if (empty($current_filter["qualifier_name"])) {
                    $current_filter["qualifier_name"] = $current_filter["qualifierName"];
                }

                $current_filter['type']        = $this->all_fields[$current_filter['table_key'] . ":" . $current_filter['name']]['type'];
                $current_filter['table_alias'] = $this->all_fields[$current_filter['table_key'] . ":" . $current_filter['name']]['table_alias'];
                $current_filter['column_key']  = $current_filter['table_key'] . ":" . $current_filter['name'];

                //widgetQuery will need DateTime objects to generate the filter
                //problem observed whith a queryFilterBetween_Dates filter and applies to others as well
                if (!empty($current_filter['type']) && ($current_filter['type'] == 'datetimecombo' || $current_filter['type'] == 'datetime')) {
                    if (!empty($current_filter['input_name0'])) {
                        try {
                            $current_filter['input_name0'] = new \SugarDateTime($current_filter['input_name0']);
                        } catch (\Exception $e) {
                            //do nothing
                        }
                    }
                    if (!empty($current_filter['input_name1'])) {
                        try {
                            $current_filter['input_name1'] = new \SugarDateTime($current_filter['input_name1']);
                        } catch (\Exception $e) {
                            //do nothing
                        }
                    }
                }

                if ($current_filter['type'] == 'relate') {
                    $fieldDef                     = $this->getFieldDefs($current_filter['table_key'], $current_filter['name']);
                    $idName                       = $fieldDef['id_name'];
                    $current_filter['name']       = $idName;
                    $current_filter['column_key'] = $current_filter['table_key'] . ":" . $idName;
                    $current_filter['type']       = 'id';
                }

                $select_piece = "(" . $this->layout_manager->widgetQuery($current_filter) . ")";
                $where_clause .= $select_piece;
            }
            if ($isSubCondition == 1) {
                $where_clause .= ")";
                // reset the subCondition
                $isSubCondition = 0;
            }
            if ($i != count($filters) - 2) {
                $where_clause .= " {$operator} ";
            }
        }
        $where_clause .= ')';
    }

    /*
    Add join to get record label

    @params $sourceRealTable
    @params $sourceIdName field name of id_name
    @params $relateModule
    @return $relateTableName
     */
    protected function addJoinForRelateField($sourceRealTable, $sourceIdName, $relateModule)
    {
        $relatedBean       = \BeanFactory::newBean($relateModule);
        $relatedTableName  = $relatedBean->table_name;
        $relatedTableAlias = $relatedTableName . "_" . $sourceIdName;

        $joinStatement = " LEFT JOIN {$relatedTableName} {$relatedTableAlias} on {$sourceRealTable}.{$sourceIdName} = {$relatedTableAlias}.id";
        $this->joins[] = $joinStatement;

        return $relatedTableAlias;
    }

    /*
    Calculates and returns number of groups of the report
    @return int
     */
    protected function getNumberOfGroupsWeAreSelectingFrom()
    {
        global $log;
        $interestingGroups = 0;

        if ($this->groupType == 'simple') {
            if (count($this->report_def['group_defs']) >= 1) {
                $interestingGroups = 1;
            } else {
                $log->debug('For this type of chart you have to define at least one Group By field.');
            }
        } elseif ($this->groupType == 'group') {
            if (count($this->report_def['group_defs']) >= 2) {
                $interestingGroups = 2;
            } else {
                $log->debug('For this type of chart you have to define at least two Group By fields.');
            }
        }

        return $interestingGroups;
    }

    /*
    Modifies the Group By object property of Query object
     */
    protected function setGroupings()
    {
        $groupDefs = $this->report_def['group_defs'];
        $tp_count  = 1;
        for ($i = 0; $i < $this->groupNumbers; $i++) {
            $groupDef = $this->report_def['group_defs'][$i];
            $tableKey = $groupDef['table_key'];
            $fieldDef = $this->getFieldDefs($tableKey, $groupDef['name']);
            if ($tableKey == 'self') {
                if ($groupDef['type'] == 'relate') {
                    $relateIdName = $fieldDef['id_name'];
                    $baseTable    = $this->all_fields[$tableKey . ":" . $relateIdName]['real_table'];
                    $fieldDb      = "{$baseTable}.{$relateIdName}";

                    $this->groupBy[] = "{$this->isNullFunction}({$fieldDb}, '')";
                    //mssql needs the label to be on group by too. that's made on setBasicSelect
                } elseif ($groupDef['type'] == 'date' || $groupDef['type'] == 'datetime' || $groupDef['type'] == 'datetimecombo') {
                    $fieldName = $groupDef['name'];
                    $baseTable = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                        $groupDef["timeperiods_count"] = $tp_count;
                        $tp_count                      = $tp_count + 1;
                    }
                    $this->layout_manager->defs['context'] = 'GroupBy';
                    //widgetQuery uses $groupDef['column_function'] to create the formula
                    $groupDef['name'] = $baseTable . "." . $groupDef['name'];
                    $fieldDb          = $this->layout_manager->widgetQuery($groupDef);

                    $this->groupBy[] = "{$this->isNullFunction}({$fieldDb}, '')";
                } elseif ($groupDef['type'] == 'currency') {
                    $this->groupBy[] = "{$this->isNullFunction}({$groupDef['name']}, 0)";

                    $baseTable       = $this->all_fields[$tableKey . ":" . "currency_id"]['real_table'];
                    $fieldDb         = "{$baseTable}.currency_id";
                    $this->groupBy[] = "{$this->isNullFunction}({$fieldDb}, 0)";
                } else {
                    $fieldName = $groupDef['name'];
                    $baseTable = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    $fieldDb   = "{$baseTable}.{$fieldName}";

                    $fieldDef            = $this->all_fields[$tableKey . ":" . $fieldName];
                    $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);

                    $this->groupBy[] = "{$this->isNullFunction}({$fieldDb}, {$defaultNotNullValue})";
                }
            } else {
                $tableKey = $groupDef['table_key'];
                if (!array_key_exists('tableJoinMade', $this->full_table_list[$tableKey]) || $this->full_table_list[$tableKey]['tableJoinMade'] != true) {
                    $this->tableKeyNavigation = array();
                    $this->createTableKeyNavigation($tableKey);
                    $this->addJoins();
                }

                if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                    $groupDef["timeperiods_count"] = $tp_count;
                    $tp_count                      = $tp_count + 1;
                }

                $this->addRelationToGroupByAndToSelect($groupDef, $fieldDef);
            }
        }
    }

    // sqlserver does not accept '' for a decimal column
    // so we need to make sure we give the correct value depending on field type
    protected function getDefaultNotNullValue($fieldDef)
    {
        $db = \DBManagerFactory::getInstance('reports');

        $fieldType         = $db->getFieldType($fieldDef);
        $isTextType        = false;
        $dbIsTextTypeCheck = $db->isTextType($fieldType);
        $textTypes         = array("varchar", "enum", "multienum", "html", "longhtml", "char", "blob", "url", "encrypt", "file");
        if (in_array($fieldType, $textTypes) || $dbIsTextTypeCheck) {
            $isTextType = true;
        }
        if ($isTextType || $this->dbType === 'mysql') {
            $defaultNotNullValue = "''";
        } else {
            $defaultNotNullValue = 0;
        }

        return $defaultNotNullValue;
    }

    /*
    Retrieves field definition
    @params $table_key string
    @params $fieldName string
    @return $fieldDef array
     */
    protected function getFieldDefs($tableKey, $fieldName)
    {
        global $dictionary;

        $objectName = $this->full_bean_list[$tableKey]->object_name;
        $fieldDef   = $dictionary[$objectName]['fields'][$fieldName];

        return $fieldDef;
    }

    /*
    Creates joins for relate group entry, adds it to Group By and to Select
    We have to add it to select also because $this->setSelect can not add it. SugarQuery expects fields given to be in the baseTable and relate types are not

    For relate fields we also add the new join to take relate's name

    @params $groupDef Entry from report definition (report_def ['groupdef'])
     */
    protected function addRelationToGroupByAndToSelect($groupDef, $fieldDef)
    {
        $tableKey    = $groupDef['table_key'];
        $fieldDefBak = $fieldDef;

        if ($fieldDef['type'] == 'relate') {
            $relateId = $fieldDef['id_name'];
            $fieldDef = $this->full_bean_list[$tableKey]->field_defs[$relateId];
        }

        $fieldName  = $fieldDef['name'];
        $tableAlias = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
        $fieldAlias = "{$tableAlias}_{$groupDef['name']}";
        $fieldDb    = "{$tableAlias}.{$fieldName}";

        if ($groupDef['type'] == 'date' || $groupDef['type'] == 'datetime' || $groupDef['type'] == 'datetimecombo') {
            $this->layout_manager->defs['context'] = 'GroupBy';
            //widgetQuery uses $groupDef['column_function'] to create the formula
            $groupDef['name'] = $tableAlias . "." . $groupDef['name'];

            $fieldDb = $this->layout_manager->widgetQuery($groupDef);

            if (array_key_exists('column_function', $groupDef) && !empty($groupDef['column_function'])) {
                $fieldAlias .= "_" . $groupDef['column_function'];
            }
        }

        if ($groupDef['type'] == 'currency') {
            $this->select_fields[] = "{$this->isNullFunction}({$fieldDb}, 0) as {$fieldAlias}";
            $this->groupBy[]       = $fieldAlias;

            $currencyTableAlias    = $this->all_fields[$tableKey . ":currency_id"]['table_alias'];
            $currencyFieldAlias    = "{$currencyTableAlias}_currency_id";
            $currencyFieldDb       = "{$currencyTableAlias}.currency_id";
            $this->select_fields[] = "{$this->isNullFunction}({$currencyFieldDb}, 0) as {$currencyFieldAlias}";

            // default sugar charts has a problem when grouping by currencies: multiple identical amount values are grouped together even if they reffer different currencies
            // follow grouping fixes that
            $this->groupBy[] = $currencyFieldDb;
        } else {
            $fieldDef            = $this->all_fields[$tableKey . ":" . $fieldName];
            $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);

            $this->groupBy[]       = "{$this->isNullFunction}({$fieldDb}, {$defaultNotNullValue})";
            $this->select_fields[] = "{$this->isNullFunction}({$fieldDb}, {$defaultNotNullValue}) as {$fieldAlias}";
        }

        // for label we have to make another join with target module
        if ($groupDef['type'] == 'relate') {
            $relateModule = $fieldDefBak['ext2'];

            //related field is not on all_fields so we have to find out his real table
            $fieldNameDef      = $this->getRelatedFieldNameFromTarget($fieldDefBak);
            $idFieldDef        = $this->all_fields[$tableKey . ":" . $relateId];
            $sourceRealTable   = $idFieldDef['table_alias'];
            $relatedTableAlias = $this->addJoinForRelateField($sourceRealTable, $relateId, $relateModule);

            $fieldDb    = "{$relatedTableAlias}.name";
            $relateBean = \BeanFactory::newBean($relateModule);
            if ($relateBean->field_defs['name']['source'] == 'non-db') {
                $sourceFieldsDb = array("{$relatedTableAlias}.first_name", "{$relatedTableAlias}.last_name");
            } else {
                $sourceFieldsDb = array("{$relatedTableAlias}.name");
            }
            $fieldAlias  = "{$tableAlias}_{$groupDef['name']}_label";
            $fieldRawSql = "trim(concat('', ";
            $fieldRawSql .= implode(", ' ', ", $sourceFieldsDb);
            $fieldRawSql .= ")) as {$fieldAlias}";

            //here we add the label of relate field. the id is added outside this if block
            $this->select_fields[] = "{$fieldRawSql}";
        }
    }

    /*
    Used to find real table of a relate field name (target record)

    @params $fieldNameDef Field definition in source record (where relate field is defined)
    @return $targetFieldDef array containing module and real table of the relate field
     */
    protected function getRelatedFieldNameFromTarget($sourceFieldNameDef)
    {
        $relateBean     = \BeanFactory::newBean($sourceFieldNameDef['ext2']);
        $targetFieldDef = $relateBean->field_defs['name'];

        $targetFieldDef['module']     = $relateBean->object_name;
        $targetFieldDef['real_table'] = $relateBean->table_name;

        return $targetFieldDef;
    }

    /*
    Gets key given and creates $this->tableKeyNavigation array containing all cronology up to base (exclusively)
    @params $groupTableKey
     */
    protected function createTableKeyNavigation($groupTableKey)
    {
        if (empty($groupTableKey)) {
            return;
        }
        if (array_key_exists('parent', $this->full_table_list[$groupTableKey])) {
            $this->tableKeyNavigation[] = $groupTableKey;
            $this->createTableKeyNavigation($this->full_table_list[$groupTableKey]['parent']);
        }
    }

    /**
     * Retrieves the rate of the current user currency symbol.
     * If the `currency_show_preferred` option is not checked on the user profile,
     * we're going to use the base currency rate.
     *
     * @return void
     */
    protected function getUserCurrencyRate()
    {
        global $current_user;

        $showPreferred = $current_user->getPreference("currency_show_preferred");
        $currencyId    = "";

        if ($showPreferred === true) {
            $currencyId = \Currency::getCurrentCurrency();
        } else {
            $currencyId = \SugarCurrency::getBaseCurrency()->id;
        }

        $currencyBean = \BeanFactory::retrieveBean("Currencies", $currencyId);

        return $currencyBean->conversion_rate;
    }

    /*
    Data series column is the field used for counting. It is stored in report_def -> numerical_chart_column
    This method adds it to the select and if a join has to be made it does that too
    Note 1: If counting column is of currency type we calculate values in user's currency directly on query. This way the final
    count value will represent a valid value in user's currency.
     */
    protected function addDataSeriesColumn()
    {
        $numericalParse = $this->parseNumericalChartColumn($this->report_def["numerical_chart_column"]);
        if (is_bool($numericalParse) && $numericalParse === false) {
            return;
        } else {
            list($groupFunction, $fieldName, $fieldType, $tableListKeyColumn) = $numericalParse;
        }

        if ($tableListKeyColumn == "self") {
            //add to select
            $baseTableAlias = $this->all_fields[$tableListKeyColumn . ":" . $fieldName]['real_table'];
            if ($groupFunction == "count") {
                $this->select_fields[] = "count(distinct {$baseTableAlias}.id) as count";
            } else {
                if ($fieldType == 'currency') {
                    $currencyFieldDef   = $this->all_fields[$tableListKeyColumn . ":" . $fieldName];
                    $currencyTableAlias = $this->all_fields[$tableListKeyColumn . ":currency_id"]['real_table'];
                    $currencyFieldAlias = "{$currencyTableAlias}_currency_id";
                    $currencyFieldDb    = "{$currencyTableAlias}.currency_id";

                    //There are default currency fields set for a speciffic currency (see rev_line_itmes - cost_usdollar).
                    //These will be saved in currency set in their definition even currency_id on record is something else. On render are shown both preset currency and record's currency
                    if (array_key_exists('currency_id', $currencyFieldDef) && !empty($currencyFieldDef['currency_id'])) {
                        $currencyIdConfigured = $currencyFieldDef['currency_id'];
                        $currenciesJoin       = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdConfigured}'";
                    } elseif (array_key_exists('is_base_currency', $currencyFieldDef) && $currencyFieldDef['is_base_currency'] == true) {
                        if ($GLOBALS['current_user']->getPreference('currency_show_preferred')) {
                            $userCurrency         = \SugarCurrency::getUserLocaleCurrency();
                            $currencyIdPredefined = $userCurrency->id;
                        } else {
                            $currencyIdPredefined = \SugarCurrency::getBaseCurrency()->id;
                        }
                        $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdPredefined}'";
                    } else {
                        $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}.currency_id={$currencyTableAlias}_currencies.id
                        AND {$currencyTableAlias}_currencies.deleted=0";
                    }

                    $currencyRate = $this->getUserCurrencyRate();

                    $this->joins[]         = $currenciesJoin;
                    $this->select_fields[] = "{$groupFunction}({$this->isNullFunction}({$baseTableAlias}.{$fieldName}, 0) "
                        . "/{$this->isNullFunction}({$currencyTableAlias}_currencies.conversion_rate, 1) * {$currencyRate}) as {$groupFunction}";
                } else {
                    $this->select_fields[] = "{$groupFunction}( {$baseTableAlias}.{$fieldName}) as {$groupFunction}";
                }
            }
        } else {
            //adds the right entries to select and adds necessary joins on query
            if (!$this->full_table_list[$tableListKeyColumn]['tableJoinMade']) {
                $this->tableKeyNavigation = array();
                $this->createTableKeyNavigation($tableListKeyColumn);
                $this->addJoins();
            }

            $tableAlias = $this->all_fields[$tableListKeyColumn . ":" . $fieldName]['table_alias'];

            //add to select
            if ($groupFunction == "count") {
                $this->select_fields[] = "count(distinct {$tableAlias}.id) as count";
            } else {
                if ($fieldType == 'currency') {
                    $currencyFieldDef   = $this->all_fields[$tableListKeyColumn . ":" . $fieldName];
                    $currencyTableAlias = $this->all_fields[$tableListKeyColumn . ":currency_id"]['table_alias'];
                    $currencyFieldAlias = "{$currencyTableAlias}_currency_id";
                    $currencyFieldDb    = "{$currencyTableAlias}.currency_id";

                    //There are default currency fields set for a speciffic currency (see rev_line_itmes - cost_usdollar).
                    //These will be saved in currency set in their definition even currency_id on record is something else. On render are shown both preset currency and record's currency
                    if (array_key_exists('currency_id', $currencyFieldDef) && !empty($currencyFieldDef['currency_id'])) {
                        $currencyIdConfigured = $currencyFieldDef['currency_id'];
                        $currenciesJoin       = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdConfigured}'";
                    } elseif (array_key_exists('is_base_currency', $currencyFieldDef) && $currencyFieldDef['is_base_currency'] == true) {
                        if ($GLOBALS['current_user']->getPreference('currency_show_preferred')) {
                            $userCurrency         = \SugarCurrency::getUserLocaleCurrency();
                            $currencyIdPredefined = $userCurrency->id;
                        } else {
                            $currencyIdPredefined = \SugarCurrency::getBaseCurrency()->id;
                        }
                        $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}_currencies.id = '{$currencyIdPredefined}'";
                    } else {
                        $currenciesJoin = "LEFT JOIN currencies {$currencyTableAlias}_currencies ON {$currencyTableAlias}.currency_id={$currencyTableAlias}_currencies.id
                        AND {$currencyTableAlias}_currencies.deleted=0";
                    }

                    $currencyRate = $this->getUserCurrencyRate();

                    $this->joins[]         = $currenciesJoin;
                    $this->select_fields[] = "{$groupFunction}({$this->isNullFunction}({$tableAlias}.{$fieldName}, 0) "
                        . "/{$this->isNullFunction}({$currencyTableAlias}_currencies.conversion_rate, 1) * {$currencyRate}) as {$groupFunction}";
                } else {
                    $this->select_fields[] = "{$groupFunction}( {$tableAlias}.{$fieldName}) as {$groupFunction}";
                }
            }
        }
    }

    /*
    Extracts group function, field name and table list key fom given numericalChartValue
    @params $numericalChartValue String
    @returns array group function, field name, $field type and table list key
     */
    protected function parseNumericalChartColumn($numericalChartValue)
    {
        global $log;
        $result = false;

        $numericalChartComponents = explode(":", $numericalChartValue);
        if (count($numericalChartComponents) <= 1) {
            $log->fatal("Could not parse Data Series - numerical_chart_column: " . var_export($numericalChartComponents, true));

            return $result;
        }

        if (end($numericalChartComponents) == "count") {
            // count funciton on this group
            $groupFunction      = array_pop($numericalChartComponents);
            $fieldName          = "id";
            $tableListKeyColumn = implode(":", $numericalChartComponents);
            $fieldType          = 'unusefull id';
        } else {
            // we have a group function
            $groupFunction      = array_pop($numericalChartComponents);
            $fieldName          = array_pop($numericalChartComponents);
            $tableListKeyColumn = implode(":", $numericalChartComponents);
            $fieldType          = $this->all_fields[$tableListKeyColumn . ":" . $fieldName]['type'];
        }

        return array($groupFunction, $fieldName, $fieldType, $tableListKeyColumn);
    }

    /*
    Gives aliases to all table keys entries. One for the join table and one for the base relate table
    We are gonna use this to all_fields mapping so that we know where is found each field

    Note self table alias is base table name
     */
    protected function initializeTableListAliases()
    {

        //add aliases for each table key (database table)
        foreach ($this->full_table_list as $tableKey => $tableDef) {
            $params = array();
            if (array_key_exists('link_def', $tableDef)) {
                $params = $tableDef['link_def'];
            }

            if (!isset($params['join_table_alias'])) {
                $params['join_table_alias'] = "jt" . $this->jtCount;
            }

            if (!isset($params['join_table_link_alias'])) {
                $params['join_table_link_alias'] = "jtl" . $this->jtCount;
            }
            $this->full_table_list[$tableKey]['params'] = $params;

            $this->jtCount++;
        }
    }

    protected function addAliasForASpecificKey($tableKey)
    {
        $tableDef = $this->full_table_list[$tableKey];
        $params   = array();
        if (array_key_exists('link_def', $tableDef)) {
            $params = $tableDef['link_def'];
        }

        if (!isset($params['join_table_alias'])) {
            $params['join_table_alias'] = "jt" . $this->jtCount;
        }

        if (!isset($params['join_table_link_alias'])) {
            $params['join_table_link_alias'] = "jtl" . $this->jtCount;
        }
        $this->full_table_list[$tableKey]['params'] = $params;

        $this->jtCount++;
    }

    /*
    Browse throw $this->tableKeyNavigation list and adds joins for each navigation key
     */
    protected function addJoins()
    {
        global $log, $current_user, $dictionary, $objectList, $beanList;

        for ($i = count($this->tableKeyNavigation) - 1; $i >= 0; $i--) {
            $tableKey                = $this->tableKeyNavigation[$i];
            $tableDef                = $this->full_table_list[$tableKey];
            $linkDef                 = $tableDef['link_def'];
            $relationship_name       = $linkDef['relationship_name'];
            $link_name               = $linkDef['name'];
            $params                  = $tableDef['params'];
            $params['includeCustom'] = true;

            if (empty($link_name)) {
                $log->info("Unable to load link on SummaryQuery. Table def: " . var_export($tableDef, true));
            } else {
                if (isset($tableDef['parent'])) {
                    $parentKey = $tableDef['parent'];
                    $parentDef = $this->full_table_list[$parentKey];

                    if (isset($tableDef['optional']) && $tableDef['optional'] == 1) {
                        $params['join_type'] = 'LEFT JOIN';
                        //$params['joinType'] = 'LEFT JOIN';
                    }

                    if (!isset($linkDef['bean_is_lhs']) || $linkDef['bean_is_lhs'] != 1) {
                        $params['right_join_table_alias']      = $this->full_table_list[$parentKey]['params']['join_table_alias'];
                        $params['right_join_table_link_alias'] = $this->full_table_list[$parentKey]['params']['join_table_link_alias'];
                    } else {
                        $params['left_join_table_alias']      = $this->full_table_list[$parentKey]['params']['join_table_alias'];
                        $params['left_join_table_link_alias'] = $this->full_table_list[$parentKey]['params']['join_table_link_alias'];
                    }

                    $load = $this->full_bean_list[$parentKey]->load_relationship($link_name);
                    if (!$load) {
                        $log->fatal("Unable to load link {$link_name} on SummaryQuery. Table def: " . var_export($tableDef, true));
                        die("error");
                    }

                    $link = $this->full_bean_list[$parentKey]->{$link_name};
                    $join = $link->getJoin($params);

                    $joinModuleKey = $tableKey;

                    //add Team visibility filter to joined table, only if that module has teams security (it has the field team_set_id)
                    if (!$current_user->is_admin) {
                        $fullTableListModule = $this->full_table_list[$joinModuleKey]["module"];
                        $object              = $objectList[$fullTableListModule];
                        if (empty($object)) {
                            $object = $beanList[$fullTableListModule];
                        }
                        \VardefManager::loadVarDef($fullTableListModule, $object);

                        if (
                            is_array($dictionary[$object])
                            && array_key_exists("visibility", $dictionary[$object])
                            && array_key_exists("TeamSecurity", $dictionary[$object]["visibility"])
                        ) {
                            $join .= " AND ";
                            if (isset($linkDef['bean_is_lhs']) && $linkDef['bean_is_lhs'] === true) {
                                $join .= $params['left_join_table_alias'];
                            } else {
                                $join .= $params['join_table_alias'];
                            }

                            $currentUserId = $current_user->id;
                            $join .= ".team_set_id IN (SELECT tst.team_set_id "
                                . "FROM team_sets_teams tst "
                                . "INNER JOIN team_memberships team_membershipsl ON tst.team_id = team_membershipsl.team_id "
                                . "AND team_membershipsl.user_id = '{$currentUserId}' "
                                . "AND team_membershipsl.deleted = 0)";
                        }
                    }

                    if ($this->full_bean_list[$tableKey]->hasCustomFields()) {
                        $join .= "LEFT JOIN " . $this->full_bean_list[$tableKey]->table_name . "_cstm " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . "_cstm
							ON " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . ".id = " . $this->full_table_list[$tableKey]['params']['join_table_alias'] . "_cstm.id_c";
                    }
                    //fix for 3+ levels on relations used
                    if (!array_key_exists('tableJoinMade', $this->full_table_list[$tableKey]) || $this->full_table_list[$tableKey]['tableJoinMade'] != true) {
                        $this->joins[]                                     = $join;
                        $this->full_table_list[$tableKey]['tableJoinMade'] = true;
                    }
                }
            }
        }

        $tableKey                                          = $this->tableKeyNavigation[0];
        $this->full_table_list[$tableKey]['tableJoinMade'] = true;
    }

    /*
    Populates $this->all_fields with field definitions. That includes real table source
     */
    protected function _load_all_fields()
    {
        $tmp = array();
        foreach ($this->full_table_list as $table_key => $table_data) {
            if (!isset($table_data['module'])) {
                continue;
            }

            if (!isset($tmp[$table_data['module']])) {
                $tmp[$table_data['module']] = array();
            }

            if (!isset($this->full_bean_list[$table_key])) {
                continue;
            }

            foreach ($this->full_bean_list[$table_key]->field_defs as $field_def) {
                $tmp[$table_data['module']][$field_def['name']] = 0;
                $field_def['module']                            = $this->full_table_list[$table_key]['bean_label'];
                $field_def['real_table']                        = $this->full_bean_list[$table_key]->table_name;
                $field_def['table_alias']                       = $this->full_table_list[$table_key]['params']['join_table_alias'];
                if (
                    !empty($field_def['source']) && ($field_def['source'] == 'custom_fields' || ($field_def['source'] == 'non-db'
                        && !empty($field_def['ext2']) && !empty($field_def['id']))) && !empty($field_def['real_table'])
                ) {
                    $field_def['real_table'] .= '_cstm';
                    $field_def['table_alias'] .= '_cstm';
                }
                if ($field_def['type'] == 'relate' && !empty($field_def['ext2'])) {
                    $joinFocus                    = \BeanFactory::getBean($field_def['ext2']);
                    $field_def['secondary_table'] = $joinFocus->table_name;
                    if (
                        isset($table_data['link_def']) && isset($table_data['link_def']['module']) && isset($table_data['module'])
                        && $table_data['link_def']['module'] == $table_data['module']
                    ) {
                        $tmp[$table_data['module']][$field_def['name']]++;
                    }
                }
                $field_def['rep_rel_name'] = $field_def['name'] . '_' . $tmp[$table_data['module']][$field_def['name']];

                $this->all_fields[$table_key . ':' . $field_def['name']] = $field_def;
            }
        }
    }

    /*
    If user sets order by then we apply that. Else we'll apply some implicit sort depending on report groups

    Enum fields need to be sorted as in studio

    @return string ORDER BY statement
     */
    protected function createOrderBy()
    {
        global $app_list_strings;
        $db = \DBManagerFactory::getInstance('reports');

        //summary reports can be sorted by a summary column from UI
        if (array_key_exists('summary_order_by', $this->report_def)) {
            $fieldToSortOn = $this->report_def['summary_order_by'][0];
            if ($fieldToSortOn['name'] == 'count') {
                $orderByPart = " ORDER BY records_count ";
            } else {
                $tableKey  = $fieldToSortOn['table_key'];
                $fieldName = $fieldToSortOn['name'];
                //if column selected is used as a group function it might have
                //some more calculations and will have an alias (like in currencies)
                if (array_key_exists('group_function', $fieldToSortOn)) {
                    $groupFunction = strtoupper($fieldToSortOn['group_function']);
                    //check if this group function returned or table_field syntax is used
                    $groupFunctionIsUsed = false;
                    foreach ($this->select_fields as $sf) {
                        $fieldToCheck = " " . strtolower($sf);
                        if (strpos(strtolower($groupFunction), $fieldToCheck) > -1) {
                            $groupFunctionIsUsed = true;
                        }
                    }
                    if ($groupFunctionIsUsed) {
                        $fieldName = $groupFunction;
                    }
                }
                if ($tableKey == 'self') {
                    $table = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                } else {
                    $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
                }

                $fieldDef = $this->all_fields[$tableKey . ":" . $fieldName];
                if ($fieldDef['type'] == 'enum') {
                    $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);
                    $orderByPart         = " ORDER BY {$this->isNullFunction}({$table}.{$fieldName}, {$defaultNotNullValue}) ";
                } else {
                    $orderByPart = " ORDER BY {$table}.{$fieldName} ";
                }
            }

            if ($fieldToSortOn['sort_dir'] == 'd') {
                $orderByPart .= "desc";
            } else {
                $orderByPart .= "asc";
            }
        } else {
            //implicit sort

            $fieldsToSortOn      = $this->report_def['group_defs'];
            $fieldsToSortOnCount = $this->groupNumbers;
            $orderByPart         = "";
            $tp_count            = 1;
            for ($i = 0; $i < $fieldsToSortOnCount; $i++) {
                $groupDef  = $fieldsToSortOn[$i];
                $tableKey  = $groupDef['table_key'];
                $fieldName = $groupDef['name'];
                $fieldDef  = $this->all_fields[$tableKey . ":" . $fieldName];

                if ($fieldDef['type'] == 'enum') {
                    $options  = $fieldDef['options'];
                    $dropdown = $app_list_strings[$options];
                    if (
                        is_null($dropdown)
                        && is_null($options)
                        && isset($fieldDef["function"])
                        && function_exists($fieldDef["function"])
                    ) {
                        $dropdown = \getOptionsFromVardef([
                            "function_bean" => null,
                            "function"      => $fieldDef["function"],
                        ]);
                    }

                    if ($tableKey == 'self') {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    } else {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
                    }
                    $fieldDb = "{$this->isNullFunction}({$table}.{$fieldName}, '')";

                    $orderStatement = $db->orderByEnum($fieldDb, $dropdown, 'ASC'); //third parameter should be direction. we ommit it here because orderByRaw adds it
                    $orderByPart .= $orderStatement . ",";
                } elseif ($fieldDef['type'] == 'date' || $fieldDef['type'] == 'datetime' || $fieldDef['type'] == 'datecombo' || $fieldDef['type'] == 'datetimecombo') {
                    if ($tableKey == 'self') {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    } else {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
                    }
                    if (!empty($groupDef["qualifier"]) && $groupDef["qualifier"] == "fiscalQuarter") {
                        $groupDef["timeperiods_count"] = $tp_count;
                        $tp_count                      = $tp_count + 1;
                    }
                    $this->layout_manager->defs['context'] = 'GroupBy'; //we use the same expresion as in gorup by to have them both in group by and in order by
                    //also if we would use OrderBy it adds direction somewhere inside and that creates problems
                    $fieldDef['name'] = $table . "." . $fieldName;
                    $fieldDb          = $this->layout_manager->widgetQuery($groupDef);

                    $orderStatement = "{$this->isNullFunction}(" . $fieldDb . ", '') ASC";
                    $orderByPart .= $orderStatement . ",";
                } elseif ($fieldDef['type'] == 'relate') {
                    $relateId = $fieldDef['id_name'];

                    if ($tableKey == 'self') {
                        $table = $this->all_fields[$tableKey . ":" . $relateId]['real_table'];
                    } else {
                        $table = $this->all_fields[$tableKey . ":" . $relateId]['table_alias'];
                    }
                    $fieldDb = "{$this->isNullFunction}({$table}.{$relateId}, 0)";

                    $orderStatement = $fieldDb . " ASC";
                    $orderByPart .= $orderStatement . ",";
                } else {
                    //includes ($fieldDef['type'] == 'name')
                    if ($tableKey == 'self') {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['real_table'];
                    } else {
                        $table = $this->all_fields[$tableKey . ":" . $fieldName]['table_alias'];
                    }
                    $fieldDef            = $this->all_fields[$tableKey . ":" . $fieldName];
                    $defaultNotNullValue = $this->getDefaultNotNullValue($fieldDef);

                    $fieldDb = "{$this->isNullFunction}({$table}.{$fieldName}, {$defaultNotNullValue})";

                    $orderStatement = $fieldDb . " ASC";
                    $orderByPart .= $orderStatement . ",";
                }
            }

            $orderByPart = rtrim($orderByPart, ',');
            if (!empty($orderByPart)) {
                $orderByPart = " ORDER BY " . $orderByPart;
            }
        } //end else implicit sort

        $this->orderBy = $orderByPart;
    }

    /*
    Formats raw sql data in a way so that we can use it on chart
     */
    public function formatData($data)
    {
        global $timedate, $current_user, $app_list_strings;
        $result = array();

        $group1Defs              = $this->report_def['group_defs'][0];
        $group1DbFieldValueAlias = $this->getGroupAlias($group1Defs);
        $group1TableKey          = $group1Defs["table_key"];
        $group1FieldName         = $group1Defs["name"];
        $group1Key               = $group1TableKey . ":" . $group1FieldName;
        $group1FieldDef          = $this->all_fields[$group1Key];

        $group2Defs = array();
        if ($this->groupNumbers == 2) {
            $group2Defs              = $this->report_def['group_defs'][1];
            $group2DbFieldValueAlias = $this->getGroupAlias($group2Defs);
            $group2TableKey          = $group2Defs["table_key"];
            $group2FieldName         = $group2Defs["name"];
            $group2Key               = $group2TableKey . ":" . $group2FieldName;
            $group2FieldDef          = $this->all_fields[$group2Key];
        }

        $numericalConfigured = $this->getNumericalColumn($this->report_def);
        $numericalColumn     = $numericalConfigured[0];
        $numericalType       = $numericalConfigured[1];

        if ($group1FieldDef['type'] == 'enum' || ($this->groupNumbers == 2 && $group2FieldDef['type'] == 'enum')) {
            $data = $this->moveNonExistingEnumValuesAndCounts($data, $numericalType);
        }

        $this->layout_manager->setAttribute('context', 'List'); // we'll need this to format labels
        if (is_array($data)) {
            //start building the formatted data
            foreach ($data as $row) {
                $formattedRow = array();

                if ($group1Defs['type'] == 'relate') {
                    //widgetDisplay would format this field as a link.
                    //still we need to have each value (id, name) separated in order to parse it further
                    $formattedRow['group1_value'] = $row[$group1DbFieldValueAlias];
                    $labelAlias                   = $group1DbFieldValueAlias . "_label";
                    $formattedRow['group1_label'] = $row[$labelAlias];
                } else {
                    $fields = array();
                    foreach ($row as $key => $value) {
                        //if value is null or not set, then change to empty string.  This prevents array index errors while processing
                        $fields[strtoupper($key)] = is_null($value) ? '' : $value;
                    }
                    $displayColumn               = $group1Defs;
                    $displayColumn['varname']    = $group1DbFieldValueAlias;
                    $displayColumn['fields']     = $fields;
                    $displayColumn['column_key'] = $group1Defs['table_key'] . ":" . $group1Defs['name'];
                    $display                     = $this->layout_manager->widgetDisplay($displayColumn);

                    $formattedRow['group1_value'] = $row[$group1DbFieldValueAlias];
                    $formattedRow['group1_label'] = empty($display) ? $formattedRow['group1_value'] : $display;

                    //in case of dropdown value update set the needed label
                    $fieldDef = $this->all_fields[$group1TableKey . ":" . $group1FieldName];
                    if ($fieldDef['type'] == 'enum') {
                        $optionsListName    = $fieldDef['options'];
                        $optionsOfThisField = $app_list_strings[$optionsListName];

                        if (array_key_exists($formattedRow['group1_label'], $optionsOfThisField)) {
                            $formattedRow['group1_label'] = $optionsOfThisField[$formattedRow['group1_label']];
                        }
                    }
                }
                //custom fields
                if ($formattedRow["group1_value"] == "[]") {
                    $formattedRow["group1_label"] = "";
                }

                if (!empty($group2Defs)) {
                    if ($group2Defs['type'] == 'relate') {
                        //widgetDisplay would format this field as a link.
                        //still we need to have each value (id, name) separated in order to parse it further
                        $formattedRow['group2_value'] = $row[$group2DbFieldValueAlias];
                        $labelAlias                   = $group2DbFieldValueAlias . "_label";
                        $formattedRow['group2_label'] = $row[$labelAlias];
                    } else {
                        $displayColumn               = $group2Defs;
                        $displayColumn['varname']    = $group2DbFieldValueAlias;
                        $displayColumn['fields']     = $fields;
                        $displayColumn['column_key'] = $group2Defs['table_key'] . ":" . $group2Defs['name'];
                        $display                     = $this->layout_manager->widgetDisplay($displayColumn);

                        $formattedRow['group2_value'] = $row[$group2DbFieldValueAlias];
                        $formattedRow['group2_label'] = empty($display) ? $formattedRow['group2_value'] : $display;

                        //in case of dropdown value update set the needed label
                        $fieldDef = $this->all_fields[$group2TableKey . ":" . $group2FieldName];
                        if ($fieldDef['type'] == 'enum') {
                            $optionsListName = $fieldDef['options'];

                            $optionsOfThisField = $app_list_strings[$optionsListName];
                            if (array_key_exists($formattedRow['group2_label'], $optionsOfThisField)) {
                                $formattedRow['group2_label'] = $optionsOfThisField[$formattedRow['group2_label']];
                            }
                        }
                    }
                    //custom fields
                    if ($formattedRow["group2_value"] == "[]") {
                        $formattedRow["group2_label"] = "";
                    }
                }

                if ($numericalType == "currency" || $numericalType == "decimal") {
                    $formattedRow['chartColumn'] = floatval($row[$numericalColumn]);
                } else {
                    $formattedRow['chartColumn'] = intval($row[$numericalColumn]);
                }
                $formattedRow['recordsCount'] = intval($row['records_count']);

                $result[] = $formattedRow;
            }
        }

        return $result;
    }

    public function hideEmptyGroups($data)
    {
        $res = array();
        foreach ($data as $idx => $row) {
            if ((float) $row["chartColumn"] !== (float) 0) {
                $res[] = $row;
            }
        }

        return $res;
    }

    /**
     * Remove enum values that were deleted
     * This method will implicitly update the numerical value to the "" (undefined) option
     */
    private function moveNonExistingEnumValuesAndCounts($data, $numericalType)
    {
        global $app_list_strings;
        $res = array();

        if ((is_array($data) || is_object($data)) && count($data) > 0) {
            //format the string counts to correct number value in order to make the eventual addition correct
            foreach ($data as &$row) {
                if ($numericalType == "currency" || $numericalType == "decimal") {
                    $row['count'] = floatval($row["count"]);
                } else {
                    $row['count'] = intval($row["count"]);
                }
                $row['records_count'] = intval($row["records_count"]);
            }

            unset($row); // pointer fix for php 7
        }

        if ($this->groupNumbers == 1) {
            //number of records in a specific group
            $emptyRecordCountsToAdd = 0;
            //report count in speciffic group
            $emptyCountsToAdd        = 0;
            $group1Defs              = $this->report_def['group_defs'][0];
            $group1DbFieldValueAlias = $this->getGroupAlias($group1Defs);
            $group1TableKey          = $group1Defs["table_key"];
            $group1FieldName         = $group1Defs["name"];
            $group1Key               = $group1TableKey . ":" . $group1FieldName;
            $group1FieldDef          = $this->all_fields[$group1Key];
            $optionsListName         = $group1FieldDef['options'];
            $optionsOfThisField      = $app_list_strings[$optionsListName];

            if ($group1FieldDef["type"] == "enum") {
                $optionsListName    = $group1FieldDef['options'];
                $optionsOfThisField = $app_list_strings[$optionsListName];
                if (
                    is_null($optionsOfThisField)
                    && isset($group1FieldDef["function"])
                    && function_exists($group1FieldDef["function"])
                ) {
                    $optionsOfThisField = \getOptionsFromVardef([
                        "function_bean" => null,
                        "function"      => $group1FieldDef["function"],
                    ]);
                }
                if ((is_array($data) || is_object($data)) && count($data) > 0) {
                    foreach ($data as $row) {
                        if (
                            !array_key_exists($row[$group1DbFieldValueAlias], $optionsOfThisField)
                            || empty($row[$group1DbFieldValueAlias])
                        ) {
                            $row[$group1DbFieldValueAlias] = "";
                        }
                        $res[] = $row;
                    }
                }
            }

            //merge duplicate values
            $newRes = array();
            foreach ($res as $row) {
                $newRowExists = false;
                foreach ($newRes as &$newRow) {
                    if ($row[$group1DbFieldValueAlias] == $newRow[$group1DbFieldValueAlias]) {
                        $newRowExists = true;
                        $newRow["records_count"] += $row["records_count"];
                        $newRow["count"] += $row["count"];
                    }
                }
                unset($newRow);
                if (!$newRowExists) {
                    $newRes[] = $row;
                }
            }
            $res = $newRes;
        } else if ($this->groupNumbers == 2) {
            //number of records in a specific group2. Each group2 value has it's own count
            $emptyRecordCountsToAdd = array();
            //report count in speciffic group2. Each group2 value has it's own count
            $emptyCountsToAdd        = array();
            $group1Defs              = $this->report_def['group_defs'][0];
            $group1DbFieldValueAlias = $this->getGroupAlias($group1Defs);
            $group1TableKey          = $group1Defs["table_key"];
            $group1FieldName         = $group1Defs["name"];
            $group1Key               = $group1TableKey . ":" . $group1FieldName;
            $group1FieldDef          = $this->all_fields[$group1Key];
            //number of records in a specific group2. Each group2 value has it's own count
            $emptyRecordCountsToAdd2 = array();
            //report count in speciffic group2. Each group2 value has it's own count
            $emptyCountsToAdd2       = array();
            $group2Defs              = $this->report_def['group_defs'][1];
            $group2DbFieldValueAlias = $this->getGroupAlias($group2Defs);
            $group2TableKey          = $group2Defs["table_key"];
            $group2FieldName         = $group2Defs["name"];
            $group2Key               = $group2TableKey . ":" . $group2FieldName;
            $group2FieldDef          = $this->all_fields[$group2Key];

            if ($group1FieldDef["type"] == "enum") {
                $optionsListName    = $group1FieldDef['options'];
                $optionsOfThisField = $app_list_strings[$optionsListName];
                if (
                    is_null($optionsOfThisField)
                    && isset($group1FieldDef["function"])
                    && function_exists($group1FieldDef["function"])
                ) {
                    $optionsOfThisField = \getOptionsFromVardef([
                        "function_bean" => null,
                        "function"      => $group1FieldDef["function"],
                    ]);
                }

                foreach ($data as $row) {
                    if (
                        !array_key_exists($row[$group1DbFieldValueAlias], $optionsOfThisField)
                        || empty($row[$group1DbFieldValueAlias])
                    ) {
                        $row[$group1DbFieldValueAlias] = "";
                    }
                    $res[] = $row;
                }
                $data = $res;
            }

            if ($group2FieldDef["type"] == "enum") {
                $res                = array();
                $optionsListName    = $group2FieldDef['options'];
                $optionsOfThisField = $app_list_strings[$optionsListName];
                if (
                    is_null($optionsOfThisField)
                    && isset($group2FieldDef["function"])
                    && function_exists($group2FieldDef["function"])
                ) {
                    $optionsOfThisField = \getOptionsFromVardef([
                        "function_bean" => null,
                        "function"      => $group2FieldDef["function"],
                    ]);
                }
                foreach ($data as $row) {
                    $newRow = $row;
                    if (
                        !array_key_exists($row[$group2DbFieldValueAlias], $optionsOfThisField)
                        || empty($row[$group2DbFieldValueAlias])
                    ) {
                        $newRow[$group2DbFieldValueAlias] = "";
                    }
                    $res[] = $newRow;
                }
            }

            //merge duplicate values
            $newRes = array();
            foreach ($res as $row) {
                $newRowExists = false;
                foreach ($newRes as &$newRow) {
                    if (
                        $row[$group1DbFieldValueAlias] == $newRow[$group1DbFieldValueAlias]
                        && $row[$group2DbFieldValueAlias] == $newRow[$group2DbFieldValueAlias]
                    ) {
                        $newRowExists = true;
                        $newRow["records_count"] += $row["records_count"];
                        $newRow["count"] += $row["count"];
                    }
                }
                unset($newRow);
                if (!$newRowExists) {
                    $newRes[] = $row;
                }
            }
            $res = $newRes;
        }

        return $res;
    }

    /*
    Based on group definition given, returns the alias used in query
     */
    public function getGroupAlias($groupDef)
    {
        $tableKey    = $groupDef['table_key'];
        $fieldName   = $groupDef['name'];
        $fieldDef    = $this->all_fields[$tableKey . ":" . $fieldName];
        $resultAlias = $fieldDef['table_alias'] . "_" . $fieldDef['name'];

        // these types are not shown on group defs. so we add them here
        if (in_array($fieldDef['type'], array('date', 'datetime', 'datetimecombo'))) {
            $groupDef['type'] = $fieldDef['type'];
        }

        //for relate types we store the id on {table}_{studio field name}
        //and the label on {table}_{studio field name}_label
        if ($groupDef['type'] == 'relate') {
            $resultAlias = $fieldDef['table_alias'] . "_" . $fieldDef['name'];
        }

        // reports can be made on Year/Month/... so columne_function will be added on field name
        // this way we can distinquish between different grouping based on the same column
        if (array_key_exists('column_function', $groupDef) && !empty($groupDef['column_function'])) {
            $resultAlias .= "_" . $groupDef['column_function'];
        }

        return $resultAlias;
    }

    /*
    Return the key where is stored the count for elements
    Sugar allows user to manually set this field in a Report step
    @param report_def array Report definitions
    @return Array An array with 2 values:
    - numerical field name
    - numerical field type
     */
    public function getNumericalColumn($report_def)
    {
        $numericalParse                                                 = $this->parseNumericalChartColumn($report_def["numerical_chart_column"]);
        list($chartColumn, $fieldName, $fieldType, $tableListKeyColumn) = $numericalParse;

        $numericalChartFieldType = $this->all_fields[$tableListKeyColumn . ":" . $fieldName]['type'];

        $result = array($chartColumn, 'number');

        if ($numericalChartFieldType == 'currency') {
            $result[1] = "currency";
        }
        if ($numericalChartFieldType == 'float' || $numericalChartFieldType == 'decimal') {
            $result[1] = "decimal";
        }

        return $result;
    }

    /*
    A new query is needed because we can not base counting on data received.
    Count can be made on relates and we don't want duplicates be counted.
    Counting this way means we'll not select unneeded 'id' fields and another additional parse

    Also format the total according to his meaning (integer value or currency)

    @param $args arguments used on summary query too
    @return $total string formatted
     */
    public function getTotal($args)
    {
        global $current_user, $sugar_config;
        $db = \DBManagerFactory::getInstance('reports');

        $this->isTotalQuery = true;
        $fieldExistsFlag    = $this->validateFieldsInReport($args);
        if ($fieldExistsFlag["fieldExists"] === false) {

            return [];
        }
        //parse the report
        $this->createFrom();
        //there are times when a select is made on an agregated column (or sum, count..)
        //mssql will expect the field be on Group by too but we can not add it because it might mess the count
        //$this->setBasicSelect();
        $this->addDataSeriesColumn();
        $this->addJoinsOnDisplayColumnFieldsFromOtherModules();
        $this->addJoinsOnSummaryColumnFieldsFromOtherModules();
        $this->addTimePeriods();

        if (!empty($args['link']) && isset($args["reportDefinitionOnly"]) === false) {
            $this->appendCurrentRecordFilterDefinition($args);
        }
        $this->addDefaultFilters($args);
        $this->addSecurity();

        //create a query
        $this->createQueryForTotal($args);

        //parse response and return it
        $dbRes    = $db->query($this->query);
        $totalRow = $db->fetchByAssoc($dbRes);

        $numericalParse = $this->parseNumericalChartColumn($this->report_def["numerical_chart_column"]);
        if (is_bool($numericalParse) && $numericalParse === false) {
            return;
        } else {
            list($groupFunction, $fieldName, $fieldType, $tableListKeyColumn) = $numericalParse;
        }

        if (is_array($totalRow) && array_key_exists($groupFunction, $totalRow)) {
            $total = $totalRow[$groupFunction];
        } else {
            $total = 0;
        }

        $approximationMade = false;
        if ($args['approximateTotal']) {
            if ($total >= 1000 && $total < 1000000000) {
                $approximationMade = true;
                $total             = ($total / 1000);
                $symbolAproximated = "K";
            } elseif ($total >= 1000000000 && $total < 1000000000000) {
                $approximationMade = true;
                $total             = ($total / 1000);
                $symbolAproximated = "M";
            }
        }

        if ($fieldType == 'currency') {
            //$total = \SugarCurrency::formatAmountUserLocale($total, $sugar_config['currency']);
            $amount = $total;

            if ($fieldType == 'currency' && strpos($this->report_def["numerical_chart_column"], '_usdoll') !== false) {
                // convert base to user preferred if set in user prefs
                if ($current_user->getPreference('currency_show_preferred')) {
                    $userCurrency = \SugarCurrency::getUserLocaleCurrency();
                    $amount       = \SugarCurrency::convertWithRate($amount, 1.0, $userCurrency->conversion_rate);
                }
            }
            //commmented this because of Opportunities Won By Lead Source where we can not remove ,
            //break the number so that it's not rounded inside formatAmount
            //$amount = (string) $amount;
            //$explodedAmount = explode(".", $amount);
            //$amount = $explodedAmount[0];
            $userCurrency = $current_user->getPreference('currency');
            if (is_object($userCurrency) && false == empty($userCurrency->id)) {
                $currencyId = $userCurrency->id;
            } else {
                if (true == is_string($userCurrency) && false == empty($userCurrency)) {
                    $currencyId = $userCurrency;
                } else {
                    $currencyId = $sugar_config['currency'];
                }
            }

            if ($args['approximateTotal']) {
                $decimalPrecision = 0;
            } else {
                $decimalPrecision = 2;
            }
            $decimalSeparator        = '.';
            $numberGroupingSeparator = ',';
            $showSymbol              = true;
            $total                   = \SugarCurrency::formatAmount($amount, $currencyId, $decimalPrecision, $decimalSeparator, $numberGroupingSeparator, $showSymbol);
            if ($approximationMade) {
                $total .= $symbolAproximated;
            }
        } else {
            $user_dec_sep     = $current_user->getPreference('dec_sep');
            $dec_sep          = (empty($user_dec_sep) ? $sugar_config['default_decimal_seperator'] : $user_dec_sep);
            $user_num_grp_sep = $current_user->getPreference('num_grp_sep');
            $num_grp_sep      = (empty($user_num_grp_sep) ? $sugar_config['default_number_grouping_seperator'] : $user_num_grp_sep);
            // $precision = $sugar_config['default_currency_significant_digits'];
            $precision = 0;

            $total = number_format($total, $precision, $dec_sep, $num_grp_sep);
            if ($approximationMade) {
                $total .= $symbolAproximated;
            }
        }

        return $total;
    }

    public function createQueryForTotal($args)
    {
        $query         = "";
        $select_fields = "SELECT ";
        for ($i = 0; $i < count($this->select_fields); $i++) {
            if ($i >= 1) {
                $select_fields .= ", ";
            }
            $select_fields .= $this->select_fields[$i] . " ";
        }
        $joins = "";
        for ($i = 0; $i < count($this->joins); $i++) {
            $joins .= $this->joins[$i] . " ";
        }
        $where = "WHERE ";
        for ($i = 0; $i < count($this->where); $i++) {
            if ($i >= 1) {
                $where .= " AND ";
            }
            $where .= $this->where[$i] . " ";
        }

        $query .= $select_fields;
        $query .= $this->from;
        $query .= $joins;
        $query .= $where;
        $query .= $this->orderBy;

        $this->query = $query;
    }

    public function getModule()
    {
        return $this->module;
    }

    /**
     * Sugar 7.10
     * In Sugar, chart sort is only made for grouped reports. It is based on report mysql(group bys)
     * and also programatically based on groups and series.
     * The code sort is made based on last field used for grouping.
     *     If it's a date type (all kind of date/datetime types), it will firstly make DateTime object and then sort on them.
     *     If it's something else, it's sorted alphabetically with asort
     *     If there are multiple groups, each group is sorted in the way explaned, then, keys are extracted from each group
     *      - this will be the sort used in chart. Update Sugar 8: this sort is now composed from Labels and not Values
     * Empty strings/Nulls/Undefineds are shown with label "Undefined" and their position is:
     *     In legend they are sorted as they come from sql selection
     *     In chart elements, are sorted as the last element for a serie/group (see sucroseReports->processReportData)
     * So far could not find a report with one grouping showing different in custom vs default sugar's.
     * So following implementation focuses on reports with 2 groups
     *
     * @method getSugarSort
     * @param  Array                  $data Formatted data
     * @param  Array                  $args          [description]
     * @return Array                  A list of labels that will be used by the chart engine to sort data
     */
    public function getSugarSort($data, $args)
    {
        $res                              = array();
        $chartType                        = $args['dashletChartType'];
        $chartsTypesThatWorkWithTwoGroups = array("group by chart", "horizontal group by chart", "line chart");

        if (count($this->report_def["group_defs"]) >= 2 && in_array($chartType, $chartsTypesThatWorkWithTwoGroups)) {
            $sortBy = "group2_label";
        } else {
            $sortBy = "group1_label";
        }

        $groups = array();
        if ($sortBy == "group2_label") {
            //arrange each group values alphabetically or by date time
            //split groups
            $fieldToSortOnIsDateType = $this->fieldToSortIsDateType($sortBy);

            $groupBy     = "group1_value";
            $groupByKeys = array();
            foreach ($data as $d) {
                if (!in_array($d[$groupBy], $groupByKeys)) {
                    $groupByKeys[] = $d[$groupBy];
                }
            }

            $tempGroups = array();
            foreach ($groupByKeys as $groupByKey) {
                $tempGroups[$groupByKey] = array();
                foreach ($data as $d) {
                    if ($d[$groupBy] == $groupByKey) {
                        $tempGroups[$groupByKey][] = $d;
                    }
                }
            }

            /*
            Found an use case where report was made on two DateTime fields.
            For that case, we had to add "&& !$fieldToSortOnIsDateType" in order to not change Undefined's position in categories list
             */
            if ((count($groupByKeys) >= 2 && $groupByKeys[0] == "") && !$fieldToSortOnIsDateType) {
                $firstGroupKey               = $groupByKeys[0];
                $secondGroupKey              = $groupByKeys[1];
                $aux                         = $tempGroups[$firstArrayKey];
                $tempGroups[$firstArrayKey]  = $tempGroups[$secondGroupKey];
                $tempGroups[$secondGroupKey] = $aux;
            }

            //arrange each group
            foreach ($tempGroups as $groupByKey => $groupData) {
                if ($fieldToSortOnIsDateType) {
                    $groupArranged = $this->sortDateGroup($groupData, $sortBy);
                } else {
                    $groupArranged = $this->sortGroup($groupData, $sortBy);
                }
                $groups = array_merge($groups, $groupArranged);
            }
        }

        //extract all sortBy values and get uniques
        $res = $this->extractSortFromGroups($groups, $sortBy);

        return $res;
    }

    protected function fieldToSortIsDateType($sortingGroup)
    {
        if ($sortingGroup == "group1_value") {
            $groupNumber = 0; //first group
        } else {
            $groupNumber = 1; //second group
        }
        $fieldToSortOnIsDateType = false;
        $fieldName               = $this->report_def["group_defs"][$groupNumber]["name"];
        $tableKey                = $this->report_def["group_defs"][$groupNumber]["table_key"];
        $fieldType               = $this->all_fields["{$tableKey}:{$fieldName}"]["type"];
        $dateTypes               = array('date', 'datetime', 'datetimecombo');
        if (in_array($fieldType, $dateTypes)) {
            $fieldToSortOnIsDateType = true;
        }

        return $fieldToSortOnIsDateType;
    }

    protected function sortGroup($groupData, $sortBy)
    {
        foreach ($groupData as $gd) {
            if ($gd[$sortBy] == "") {
                $gd[$sortBy] = "zzzzzzzz";
            }
        }

        for ($i = 0; $i < count($groupData) - 1; $i++) {
            for ($j = $i + 1; $j < count($groupData) - 1; $j++) {
                $iter1 = strtolower($groupData[$i][$sortBy]);
                $iter2 = strtolower($groupData[$j][$sortBy]);
                if ($iter1 > $iter2) {
                    $aux           = $groupData[$i];
                    $groupData[$i] = $groupData[$j];
                    $groupData[$j] = $aux;
                }
            }
        }

        return $groupData;
    }

    protected function sortDateGroup($groupData, $sortBy)
    {
        for ($i = 0; $i < count($groupData); $i++) {
            if ($groupData[$i][$sortBy] == "") {
                // showed as undefined
                $groupData[$i][$sortBy] = "2100-01-01 00:00:00";
            }
        }

        for ($i = 0; $i < count($groupData) - 1; $i++) {
            for ($j = $i + 1; $j < count($groupData) - 1; $j++) {
                $iter1 = new \DateTime($groupData[$i][$sortBy]);
                $iter2 = new \DateTime($groupData[$j][$sortBy]);
                if ($iter1 > $iter2) {
                    $aux           = $groupData[$i];
                    $groupData[$i] = $groupData[$j];
                    $groupData[$j] = $aux;
                }
            }
        }

        for ($i = 0; $i < count($groupData); $i++) {
            if ($groupData[$i][$sortBy] == "2100-01-01 00:00:00") {
                // showed as undefined
                $groupData[$i][$sortBy] = "";
            }
        }

        return $groupData;
    }

    protected function extractSortFromGroups($groups, $sortBy)
    {
        $res = array();
        foreach ($groups as $groupData) {
            if (!in_array($groupData[$sortBy], $res)) {
                $res[] = $groupData[$sortBy];
            }
        }

        return $res;
    }
}
