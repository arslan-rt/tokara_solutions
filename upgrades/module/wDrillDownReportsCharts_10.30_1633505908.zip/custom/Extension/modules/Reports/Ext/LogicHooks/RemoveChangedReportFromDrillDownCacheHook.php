<?php

$hook_array['before_save'][] = array(
    1,
    'Hook description',
    'custom/modules/Reports/RemoveChangedReportFromDrillDownCacheHook.php',
    'RemoveChangedReportFromDrillDownCacheHook',
    'afterSaveHandler',
);
