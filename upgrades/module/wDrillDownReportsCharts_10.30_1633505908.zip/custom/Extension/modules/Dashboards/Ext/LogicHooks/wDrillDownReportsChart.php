<?php
$hook_array['after_delete'][] = array(
    1,
    'before_api_call',
    'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/RemoveFiltersOnDashboardDeleteHook.php',
    'RemoveFiltersOnDashboardDeleteHook',
    'deleteFilters',
);
