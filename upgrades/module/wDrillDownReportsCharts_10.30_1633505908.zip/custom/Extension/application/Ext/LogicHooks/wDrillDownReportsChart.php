<?php
$hook_array['before_api_call'][] = array(
    1,
    'before_api_call',
    'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsRemoveDrilldownReferenceHook.php',
    'DashboardsRemoveDrilldownReferenceHook',
    'before_api_call',
);
$hook_array['before_api_call'][] = array(
    2,
    'before_api_call',
    'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardDuplicateHook.php',
    'DashboardDuplicateHook',
    'generateNewDashletIds',
);

$hook_array['before_respond'][] = array(
    1,
    'before_respond_hook',
    'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardsAppendRuntimesHook.php',
    'DashboardsAppendRuntimesHook',
    'before_respond',
);

$hook_array['before_respond'][] = array(
    2,
    'before_respond_hook',
    'custom/src/wsystems/wDrillDownReportsChart/LogicHooks/DashboardDuplicateHook.php',
    'DashboardDuplicateHook',
    'createNewTemplate',
);
