<?php
//Loop through the groupings to find grouping file you want to append to
foreach ($js_groupings as $key => $groupings) {
    foreach ($groupings as $file => $target) {
        //if the target grouping is found
        if ($target == "include/javascript/sugar_grp7.min.js") {
            //append the custom JavaScript file
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/resourcesLoader.js"] = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/plugins/component.extend.js"] = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartColors.js"]                       = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/dashletRefresh.js"]                    = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/removeNavigationInPreview.js"]         = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/previewEventsFix.js"]                  = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnPreviewEdit.js"]              = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/refreshOnMerge.js"]                    = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/filterReportsAvailableOnDrilldown.js"] = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/Chart.bundle.js"]               = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chart.funnel.js"]               = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartColorOpacityPlugin.js"]    = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartBackgroundColorPlugin.js"] = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisTicksLabelsPlugin.js"] = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartAxisLabelsPlugin.js"]      = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/chartFixedAxisPlugin.js"]       = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/elementShadingPlugin.js"]       = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/legendLabelsPlugin.js"]         = "include/javascript/sugar_grp7.min.js";

            //dataLabelsPlugins
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/barChartDataLabelsPlugin.js"]                  = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/groupedBarChartDataLabelsPlugin.js"]           = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarChartDataLabelsPlugin.js"]        = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/horizontalBarGroupedChartDataLabelsPlugin.js"] = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/funnelBarChartDataLabelsPlugin.js"]            = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/chartjs/pieChartDataLabelsPlugin.js"]                  = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/bar.js"]                  = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/groupedBar.js"]           = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBar.js"]        = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/horizontalBarGrouped.js"] = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/pie.js"]                  = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/funnel.js"]               = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/charts/line.js"]                 = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/utils.js"] = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadUsers.js"] = "include/javascript/sugar_grp7.min.js";

            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/loadDashboardFilter.js"]                = "include/javascript/sugar_grp7.min.js";
            $js_groupings[$key]["custom/src/wsystems/wDrillDownReportsChart/JSGroupings/processFiltersOnDashboardDuplicate.js"] = "include/javascript/sugar_grp7.min.js";

        }

        break;
    }
}
