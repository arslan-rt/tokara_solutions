<?php

class RemoveChangedReportFromDrillDownCacheHook
{
    public function afterSaveHandler($bean, $event, $arguments)
    {
        global $db;
        $db->query("delete from wdrilldown_report_charts where report_id='{$bean->id}'");
    }
}
