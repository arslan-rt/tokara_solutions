<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['wMaps'] = 'wMaps';
$beanFiles['wMaps'] = 'modules/wMaps/wMaps.php';
$moduleList[] = 'wMaps';
$beanList['wMaps_wMapsLocations'] = 'wMaps_wMapsLocations';
$beanFiles['wMaps_wMapsLocations'] = 'modules/wMaps_wMapsLocations/wMaps_wMapsLocations.php';
$moduleList[] = 'wMaps_wMapsLocations';

?>