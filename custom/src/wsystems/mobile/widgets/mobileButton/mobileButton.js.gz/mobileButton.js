/*eslint-disable*/
class MobileButton {
    constructor(config, container, buttonId, buttonsNumber) {
        this.checked = config.checked;
        this.config = config;
        this.container = container;
        this.buttonId = buttonId;
        this.buttonKey = "mobileButton" + this.config.name + buttonsNumber;
        this.buttonNumber = buttonsNumber;

        if (this.config.horizontalButton) {
            this.buttonKey = this.buttonKey + "horizontal";
        }

        this.createButtonHtml();
        this.createButton();
    }

    createButtonHtml() {
        var iconHTML = `<i class="${this.config.icon}" style="font-size:20px;flex-shrink:0"></i>`;

        if (this.config.encodedIcon) {
            iconHTML = `<img src="${this.config.encodedIcon}">`;
        }

        var labelColor = this.config.labelColor ? this.config.labelColor : "#f5f5f5";

        var labelCss = `
        <div style="color: ${labelColor};position: absolute;top: 12px;left: -1247px;background-color: ${
            this.config.backgroundColor
        };border-radius: 20px;padding: 3px 8px;" class="mobileButtonInfoLabel${this.buttonKey}">
            ${this.config.label}
        </div>`;

        if (this.config.horizontalButton) {
            labelCss = `
            <div style="color: #f5f5f5;" class="mobileButtonInfoLabel${this.buttonKey}">
                ${this.config.label}
            </div>`;
        }

        this.buttonHtml =
            `
            <style>
            .masterButtonInput${this.config.manager.id}:checked ~ .${this.buttonKey} {
              background-color: ${this.config.backgroundColor};
              color: ${this.config.color};
              opacity: 1;
            }
            </style>
                <div class="mobileButton ${this.buttonKey}" id="${this.buttonId}" style="font-weight:900;z-index:-${
                this.buttonNumber
            };display:flex;justify-content:center;align-items:center;">
            ` +
            iconHTML +
            labelCss +
            `
        </div>
            `;
    }

    createButton() {
        this.container.append(this.buttonHtml);

        this.mobileButtonInfoLabel = $(".mobileButtonInfoLabel" + this.buttonKey);
        this.mobileButton = $("#" + this.buttonId);

        this.mobileButton.on("click", this.action.bind(this));
    }

    action() {
        try {
            if (this.masterWidgetCreated) {
                this.config.manager.hideWidget();
                this.config.masterButton.showWidget();
            } else if (this.config.callback && this.config.manager.masterButton.attr("checked")) {
                if (this.config.loadingScreenSettings) {
                    this.config.manager.showLoadingScreen(this.config.loadingScreenSettings);
                }
                if (this.config.horizontalButton) {
                    this.checked = !this.checked;
                    var opacity = this.checked ? 1 : 0.5;

                    this.mobileButton.css("opacity", opacity);
                } else {
                    this.config.manager.currentButtonConfig = this.config;
                }

                this.config.callback(this.config.manager);
                if (!this.config.horizontalButton) {
                    if (this.config.majorButton) {
                        this.masterWidgetCreated = true;
                    } else {
                        this.config.manager.goToMainWidget();
                    }
                }
            }
        } catch (err) {
            var buttonsManager = SUGAR.customizationTools.mobileButtonsManager;
            buttonsManager.goToMainWidget();
            buttonsManager.hideLoadingScreen();

            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: err.message,
                autoClose: true
            });
        }
    }

    show() {
        this.mobileButtonInfoLabel.show();
        this.masterButtonPressed(true);
    }

    hide() {
        this.mobileButtonInfoLabel.hide();
    }

    masterButtonPressed(checked) {
        if (checked) {
            this.animateButton();
        } else {
            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(0em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-0em)`);
            }
        }

        var transitionSpeed = 500;
        var timeoutTreshold = 200;
        var targetOpacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
        var elementTarget = this.config.horizontalButton ? this.mobileButton : this.mobileButtonInfoLabel;

        elementTarget.css("opacity", "0");

        if (checked && this.canShow()) {
            elementTarget.animate({
                    opacity: targetOpacity
                },
                transitionSpeed
            );
        }

        if (!this.config.horizontalButton) {
            elementTarget.css("left", "-9999px");
            setTimeout(
                function positionLabels() {
                    var distanceFromIcon = 5;
                    var currentWidth = distanceFromIcon + elementTarget.width();
                    elementTarget.css("left", "-" + currentWidth + "px");
                }.bind(this),
                timeoutTreshold
            );
        }
    }

    animateButton() {
        if (this.canShow()) {
            var opacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
            this.mobileButton.css("opacity", opacity);

            var finalPosition = this.config.manager.getFinalPosition(this);

            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(-${finalPosition.transform}em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-${finalPosition.transform}em)`);
            }

            this.mobileButton.css("transition-delay", finalPosition.delay + "s");
        } else {
            this.mobileButton.css("opacity", "0");
        }
    }

    canShow() {
        var canShow = true;

        if (this.config.showCondition) {
            canShow = this.config.showCondition();
        }
        this.test = canShow;
        return canShow;
    }

    destroy() {}
}