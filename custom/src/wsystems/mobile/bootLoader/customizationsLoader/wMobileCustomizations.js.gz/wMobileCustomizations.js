
(function(app){
    SUGAR.mobile = {
        widgets: {},
        views: {},
        fields: {},
        layouts: {},
        dashlets: {},
        extensions: {},
        styles: {},
    };
    app.mobile = {
        widgets: {},
        views: {},
        fields: {},
        layouts: {},
        dashlets: {},
        styles: {},
    };
   SUGAR.mobile.views["user-profiles"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["user-profiles"]["controller"] = /**
 * Class Description
 *
 * @class user-profiles
 */
({
    headerConfig: {
        title    : "User Profiles", // title that is going to be displayed on the header when the view is on screen
        back     : true, // show the back button in the header of the view
        mainMenu : false // show the main menu button in the header of the view
    },

    events() {
        return {
            "click #addProfile": "createUserProfile" // we can register events here
        };
    },

    render(options) {
        let _result = this._super("render", arguments);

        this._initProperties();
        this._loadProfiles();

        return _result;
    },
    
    createUserProfile(ev, profileId, profileData) {
        var profileElement = app.view.createView({
            name    : app.mobile.views.MobileUserprofileView,
            model   : this.model,
            context : this.context,
            manager : this,
        });

        if (typeof profileId === "string") {
            profileElement.fillProfile(profileId, profileData);
        }

        profileElement.render();

        this.$el.find(this.USER_PROFILES_CONTAINER).append(profileElement.$el);
    },

    updateProfileData(profileId, profileData) {
        this._profiles[profileId] = profileData;

        window.localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(this._profiles));
    },

    chooseProfile(profileId) {
        _.each(this._profiles, function createProfile(profileData, profId){
            this._profiles[profId].inUse = false;
        }, this);

        this._profiles[profileId].inUse = true;

        window.localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(this._profiles));

        const settings = {
            loginUrl  : this._profiles[profileId].url,
            loginName : this._profiles[profileId].user,
        };

        app.loginManager.applyLoginSettings(app.loginManager.setTempSetting(settings));

        app.loginManager.verifyLoginSettings((errorCode, error) => {
            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSO_NOT_SUPPORTED
            ) {
                app.error.handleExternalLoginNotAvailable();
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSL_NOT_SUPPORTED
            ) {
                app.alert.show("invalid_login_settings", {
                    level     : "error",
                    messages  : app.lang.get("ERR_MOBILE_HTTPS_CONNECTION_FAILED_LOGIN"),
                    autoClose : true,
                });
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSL_AVAILABLE
            ) {
                
                app.alert.show("invalid_login_settings", {
                    level     : "error",
                    messages  : app.lang.get("ERR_MOBILE_HTTP_CONNECTION_FAILED_LOGIN"),
                    autoClose : true,
                });
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.OTHER_HTTP_ERROR
            ) {
                app.error.handleHttpError(error);
            }

            this.trigger("settings:submit");
            this.layout._header.onBackClicked();
        });

    },

    _loadProfiles() {
        _.each(this._profiles, function createProfile(profileData, profileId){
            this.createUserProfile(false, profileId, profileData);
        }, this);
    },

    _initProperties() {
        this._profiles = {};
        this.USER_PROFILES_CONTAINER = "#profilesContainer";
        this.LOCAL_STORAGE_KEY = "wsysUserProfiles";

        let _profiles = window.localStorage.getItem(this.LOCAL_STORAGE_KEY);

        if (typeof _profiles === "string") {
            this._profiles = JSON.parse(_profiles);
        }

        let _loginTmpSettings = app.loginManager.getTempSetting();
        let _hasConfig = false;

        _.each(this._profiles, function searchProfile(profileData){
            if (profileData.url === _loginTmpSettings.loginUrl) {
                _hasConfig = true;
            }
        });

        if (_hasConfig == false) {
            this.updateProfileData(app.utils.generateUUID(), {
                url   : _loginTmpSettings.loginUrl,
                user  : _loginTmpSettings.loginName,
                inUse : true
            });
        }
    },
});
;
    SUGAR.mobile.views["user-profiles"]["templates"]["user-profiles"] = "<a id=\"addProfile\" class=\"btn\" style=\"float: right;\"><i class=\"fas fa-plus\" style=\"color: #6b7479;\"><\/i>&nbsp; Add\n    Profile<\/a>\n<div id=\"profilesContainer\">\n<\/div>";   SUGAR.mobile.views["user-profile"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["user-profile"]["controller"] = /**
 * Class Description
 *
 * @class user-profiles
 */
({
    events() {
        return {
            "click #chooseProfile" : "chooseUserProfile", // we can register events here
            "change #urlInput"     : "urlChanged",
            "change #userInput"    : "userChanged"
        };
    },

    initialize(options) {
        let _initResult = this._super("initialize", arguments);

        this._initProperties();

        return _initResult;
    },
    
    chooseUserProfile(ev) {
        this._manager.chooseProfile(this._id);
    },

    userChanged(ev) {
        this._user = ev.currentTarget.value;

        this._manager.updateProfileData(this._id, {
            user : this._user,
            url  : this._url
        });
    },
    
    urlChanged(ev) {
        this._url = ev.currentTarget.value;

        this._manager.updateProfileData(this._id, {
            user : this._user,
            url  : this._url
        });
    },

    fillProfile(profileId, profileData) {
        this._url = profileData.url;
        this._user = profileData.user;
        this._canChoose = !profileData.inUse;
        this._id = profileId;
    },

    _initProperties() {
        this._manager = this.options.manager;
        this._canChoose = true;
        this._url = "";
        this._user = "";
        this._id = app.utils.generateUUID();
    },
});
;
    SUGAR.mobile.views["user-profile"]["templates"]["user-profile"] = "<div id=\"userProfileView\">\n    <div class=\"field\" field-name=\"url\" field-type=\"url\" style=\"margin-left: 5px;margin-top: 10px;\">\n        <div class=\"field__controls\">\n            <label class=\"field__label settings__control_label_url\">Server URL<\/label>\n            <span class=\"input-wrapper\">\n                <input id=\"urlInput\" type=\"url\" class=\"login_settings_server_url\"\n                    placeholder=\"your-wMobileForSugarCRM-instance.com\" value=\"{{_url}}\" autocapitalize=\"off\"\n                    autocorrect=\"off\" autocomplete=\"off\">\n                <i class=\"icondefault icon icon-remove clear-button\"><\/i>\n            <\/span>\n        <\/div>\n        <div class=\"field__controls\">\n            <label class=\"field__label settings__control_label_url\">User<\/label>\n            <span class=\"input-wrapper\">\n                <input id=\"userInput\" type=\"text\" class=\"login_settings_server_url\" placeholder=\"username\"\n                    value=\"{{_user}}\" autocapitalize=\"off\" autocorrect=\"off\" autocomplete=\"off\">\n                <i class=\"icondefault icon icon-remove clear-button\"><\/i>\n            <\/span>\n        <\/div>\n    <\/div>\n    {{#if _canChoose}}\n        <a id=\"chooseProfile\" class=\"btn\" style=\"float: right;color: green;\"><i class=\"fas fa-check\"\n                style=\"color: green;\"><\/i>&nbsp; Use\n            Profile<\/a>\n    {{else}}\n        <a id=\"chooseProfile\" class=\"btn\" style=\"float: right;color: green;\">In Use...<\/a>\n    {{\/if}}\n<\/div>";   SUGAR.mobile.views["uMaps-route-collection"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["uMaps-route-collection"]["controller"] = ({
    uMapsRouteCollectionView : true,
    loadingScreenTimer       : 500,
    allowedModules           : ["Accounts", "Contacts", "Leads", "Opportunities"],
    headerConfig             : {
        title    : "wMaps Route Collection",
        back     : true,
        mainMenu : true
    },
    extendsFrom: {
        baseType : "inner-list",
        module   : ""
    },

    events() {
        return {
            "click article": "onItemElementClick"
        };
    },

    render: function () {
        var renderResult = this._super("render", arguments);

        this.populateListView();

        return renderResult;
    },

    populateListView: function () {
        _.each(
            app.mobile.directionsRouteCollection.models,
            function removeModel(model) {
                this.collection.remove(model);
            }.bind(this)
        );

        var recordsToDisplay = app.mobile.directionsRouteCollection.models;

        _.each(
            recordsToDisplay,
            function getAttributes(model) {
                this.collection.add(model);
                this.$el
                    .find("[data-id=\"" + model.attributes.id + "\"]")
                    .append(
                        `
                        <div id="removeFromRouteButtons" style="width:30%;height: 5em;margin-top:-4em;float:right;"><i class="fas fa-minus-circle" style="float: right;font-size:  26px;color:#f44336;margin-top:0.75em; pointer-events:none;"></i></div>`
                    );
                this.$el.find(".fields").css("pointer-events", "none");
            }.bind(this)
        );
    },

    onItemElementClick: function (e) {
        if (e.target && e.target.id.indexOf("removeFromRouteButtons") > -1) {
            e.stopPropagation();
            var userResponse = confirm("Are you sure you want to remove this record from the route?");

            if (userResponse === true) {
                this.collection.remove(this.collection.get(e.currentTarget.getAttribute("data-id")));
                app.mobile.directionsRouteCollection.remove(
                    app.mobile.directionsRouteCollection.get(e.currentTarget.getAttribute("data-id"))
                );

                app.controller.trigger("wMaps-collection-route-changed");

                if (this.collection.length <= 0) {
                    app.controller.goUp();
                    app.alert.show("wMaps-mobile-error", {
                        level     : "warning",
                        messages  : "Your route is now empty.",
                        autoClose : true
                    });
                }
            }
        } else {
            this._super("onItemElementClick", arguments);
        }
    },

    getMobileButtonsManager: function () {
        return SUGAR.customizationTools.mobileButtonsManager;
    }
});;   SUGAR.mobile.views["add-checkbox-view-on-inner-list"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["add-checkbox-view-on-inner-list"]["templates"]["add-checkbox-view-on-inner-list"] = "<style>\n  .left-menu {\n    width: 50px;\n    background-color: #f3f5f6; \n    display: inline-block; \n    position: absolute; \n    left: 0px; \n    top: 0px; \n    height: 100%;\n    -webkit-transition: width 12s, height 4s; \/* For Safari 3.1 to 6.0 *\/\n    transition: width 12s, height 4s;\n  }\n\n.boxes {\n  margin: auto;\n  padding: 50px;\n  background: #484848;\n}\n\n.fix-element-in-middle {\n  position: absolute;\n  left: 25%;\n  top: 30%;\n}\n\n.element-detector-input { display: none }\n.element-detector-label {}\n\ninput[class=\"element-detector-input\"]:checked ~ div {\n  padding-left: 45px;\n}\n\ninput[class=\"element-detector-input\"]:checked ~ label {\n  -webkit-transition:all 0.1s linear;\n  -moz-transition:all 0.1s linear;\n  -o-transition:all 0.1s linear;\n  -ms-transition:all 0.1s linear;\n  transition:all 0.1s linear;\n  display: block !important;\n  width: 50px;\n  margin-left: 0px;\n}\ninput[class=\"element-detector-input\"] ~ label {\n  \/* we have to keep unset display when the checkbox is hidden\n  to be able to get the slow show effect *\/\n  display: unset; \n  margin-left: -50px;\n}\n\ninput[class=\"element-detector-input\"] ~ div {\n  padding-left: 0px;\n}\n\n.element-hide {\n  display: none;\n}\n<\/style>\n\n<input type=\"checkbox\" attrfordetection=\"checkbox\" class=\"element-detector-input\"><\/input>\n<label class=\"left-menu element-detector-label\">\n  <i style=\"color: #2b79c8;position: absolute;left: 50%;top: 50%;-webkit-transform: translate(-50%, -50%);transform: translate(-50%, -50%);background-color: transparent;\/* border-radius: 10px; *\/font-size: 1.30em;\"\n    class=\"fas fa-check\" aria-hidden=\"true\"><\/i>\n<\/label>";   SUGAR.mobile.views["saved-report-list-summary-row"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["saved-report-list-summary-row"]["templates"]["saved-report-list-summary-row"] = "<table id=\"{{rowsTableId}}\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class='reportDataChildtablelistView row-report wReportTable'>  \n    {{#if headerFields}}\n        <tbody>\n            <tr>\n                <td>\n                    <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"reportDataChildtablelistView\">\n                        <tbody class=\"rowsContainer\">\n                            <tr class='group-line headerContainer' style=\"height:30px\">          \n        \n                            <\/tr>\n                        <\/tbody>\n                    <\/table>\n                <\/td>\n            <\/tr>\n        <\/tbody>\n    {{\/if}}\n<\/table>\n";
    SUGAR.mobile.views["saved-report-list-summary-row"]["controller"] = /* global app */

({
    headerFields   : null,
    normalizedRows : [],
    reportModuleLC : "",

    initialize: function (options) {
        this._super("initialize", arguments);

        this.rowsTableId = _.uniqueId();
        this.normalizedRows = [];
        this.reportModuleLC = this.options.dashletParent.serverResults.keyPrefix;
        this.headerFields = this.options.dashletParent.serverResults.fields;
    },

    render: function () {
        this._super("render", arguments);
        this.parseCollectionData();
    },

    orderRows: function (event) { },

    parseCollectionData: function (orderParam) {
        var cKeys = Object.keys(this.collection);
        var rowsContainerEl = this.$el.find(".rowsContainer");
        var darkMode = $("body").hasClass("theme-dark") === true;

        // iterate through all the cells html and append them into the table
        for (var i = 0; i < cKeys.length; i++) {
            if (cKeys[i] !== "wIsData" && cKeys[i] !== "header") {
                var currentRowData = this.collection[cKeys[i]];
                var htmlContent = "<tr class='group-line-cells'>";
                var maxCellWidth = 100;
                var cellWidth =
                    maxCellWidth / Object.keys(currentRowData).length;

                _.each(currentRowData, function createHtml(
                    cellContent,
                    cellKey
                ) {
                    if (cellKey !== "wIsData" && cellKey !== "header") {
                        var oddComparision = 2;
                        var bgColor =
                            i % oddComparision === 0 ? "#f6f6f6" : "#fff";

                        if (darkMode === true) {
                            if (i % oddComparision === 0) {
                                bgColor = "#575757";
                            } else {
                                bgColor = "#2b2d2e";
                            }
                        }

                        htmlContent =
                            htmlContent +
                            "<td class='row-column' style='text-indent:5px; height:25px; width:" +
                            cellWidth +
                            "%; text-align:left; background-color:" +
                            bgColor +
                            "; border-width:1px; border-bottom-style:solid; border-top-style:solid; border-color:#e9e9e9;'>" +
                            cellContent +
                            "</td>";
                    }
                });

                htmlContent = htmlContent + "</tr>";

                rowsContainerEl.append(htmlContent);
            }
        }
        var self = this;
        _.each(this.headerFields, function createHeader(headerData) {
            var backgroundColor = "#fff";
            var textColor = "#666";

            if (darkMode === true) {
                backgroundColor = "#2b2d2e";
                textColor = "#fff";
            }

            var headerHtml =
                "<th class=\"row-column\" style=\"text-align:left; border-width:1px; border-style:solid; background-color:" + backgroundColor + ";border-color: #e9e9e9\">\
                    <a class=\"rowHeader\" data-html=\"true\" style=\"margin-left: 5px; border-style: none;color:" + textColor + ";font-size: 13px;font-weight: bolder;\" tabindex=\"-1\">\
                    " +
                headerData.label +
                "</a>\
                </th>";

            self.$el.find(".headerContainer").append(headerHtml);
        });
    }
});;   SUGAR.mobile.views["saved-report-list-summary-details"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["saved-report-list-summary-details"]["templates"]["saved-report-list-summary-details"] = "{{!--\n\/*\n * Your installation or use of this SugarCRM file is subject to the applicable\n * terms available at\n * http:\/\/support.sugarcrm.com\/06_Customer_Center\/10_Master_Subscription_Agreements\/.\n * If you do not agree to all of the applicable terms or do not have the\n * authority to bind the entity as an authorized representative, then do not\n * install or use this SugarCRM file.\n *\n * Copyright (C) SugarCRM Inc. All rights reserved.\n *\/\n--}}\n\n\n\n{{#if ServerResults}}\n    {{#if ServerResults.collection}}\n            <table class=\"table table-striped dataTable\">\n                <thead>\n                    <tr>\n                        {{#each ServerResults.fields}}\n                            <th{{#if name}} data-fieldname=\"{{name}}\"{{\/if}} data-orderby=\"{{orderBy}}\">\n                                <span>{{label}}<\/span>\n                            <\/th>\n                        {{\/each}}\n                    <\/tr>\n                <\/thead>\n                <tbody>\n                    {{#each ServerResults.collection}}\n                        <tr class=\"single\">\n                            {{#each rows}}\n                                <td>\n                                    <span class=\"list\">\n                                        <div class=\"ellipsis_inline\" data-placement=\"bottom\" title=\"{{text}}\" >\n                                            {{{html}}}\n                                        <\/div>\n                                    <\/span>\n                                <\/td>\n                            {{\/each}}\n                        <\/tr>\n                    {{\/each}}\n                <\/tbody>\n            <\/table>\n    {{else}}\n        <div class=\"block-footer\">\n            {{str \"LBL_NO_DATA_AVAILABLE\"}}\n        <\/div>\n    {{\/if}}\n{{\/if}}\n\n";
    SUGAR.mobile.views["saved-report-list-summary-details"]["controller"] = ({
    initialize: function (options) {
        this._super("initialize", arguments);
    },

    render: function () {
        this.ServerResults = this.options.dashletParent.serverResults;
        this._super("render", arguments);
        this.fixBwcLinks();
    },

    fixBwcLinks: function () {
        this.$el
            .find("a[href*=\"module=\"]")
            .each(function goThroughElements(i, elem) {
                // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
            });
    }
});;   SUGAR.mobile.views["uMaps-mobile"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["uMaps-mobile"]["templates"]["uMaps-mobile"] = "<div id='uMapsRoutesContainer'><\/div>\n<div id='uMapsContainer' style='width: 100vw; height: 100vh;'><\/div>";
    SUGAR.mobile.views["uMaps-mobile"]["controller"] = ({
    template     : "uMaps-mobile",
    headerConfig : {
        title    : "wMaps",
        back     : true,
        mainMenu : true
    },
    uMapsView: true,

    createPushpin: function (map, recordData) {
        var latLon = new Microsoft.Maps.Location(recordData.latitude, recordData.longitude);

        var pushpinTitle = recordData.name;
        var pushpin = new Microsoft.Maps.Pushpin(latLon, {
            title    : pushpinTitle,
            subtitle : pushpinTitle,
            color    : recordData.color
        });
        pushpin.title = pushpinTitle;
        pushpin.subtitle = pushpinTitle;

        var pindesc = "";
        if (recordData.street) pindesc += recordData.street;
        if (recordData.city) pindesc += "," + recordData.city;
        if (recordData.state) pindesc += "," + recordData.state;
        if (recordData.postalcode) pindesc += " " + recordData.postalcode;
        if (recordData.country) pindesc += " " + recordData.country;
        if (pindesc.length > 5) pindesc = "Address: " + pindesc;

        pushpin.description = pindesc;
        pushpin.module = recordData.module;
        pushpin.recordId = recordData.id;
        
        map.entities.push(pushpin);

        Microsoft.Maps.Events.addHandler(pushpin, "click", this.displayInfobox.bind(this));
    },

    generateInfoBoxHtml: function(pin) {
        var infoboxHTML =
            "<div id=\"infoboxText\" style=\"z-index:9;border-radius: 3px;background-color:#313030;opacity:0.8; color:white;border-style:solid;border-width:medium; border-color:#313030; opacity:0.8; min-height:100px;width:240px;\"><div style=\"min-height:20px;word-wrap: break-word;\"><div style=\"display:inline; width:90%;\"><a style=\"color:#00E2FF\" id=\"title_link\" record_id=\"" +
            pin.tag +
            "\">" +
            pin.title +
            "</a><span style=\"float:right; margin-right:5%;\"><a id=\"street_view_link\" pin_latitude=\"" +
            pin.geometry.bounds[0] +
            "\" pin_longitude=\"" +
            pin.geometry.bounds[1] +
            "\"><i class=\"fas fa-map-pin fa-2x\"></i></a></span></div></div><div style=\"word-wrap: break-word; top:110px;\">" +
            pin.description +
            "</div><div class=\"infobox-stalk\" style=\"width: 33px; height: 38px; overflow: hidden; position: absolute; z-index: 1; left: 20px; top: 100px;\"></div></div></div>";
        return infoboxHTML;
    },

    hideInfoBox: function(e) {
        this.pinInfobox.setOptions({
            visible: false
        });
    },

    displayInfobox: function(e) {
        if (e.targetType == "pushpin") {
            var pin = e.target;
            this.pinInfobox.setLocation(pin.getLocation());

            var infoboxHTML = this.generateInfoBoxHtml(pin);

            this.pinInfobox.setHtmlContent(infoboxHTML);

            //calculate infobox position
            var map_control_div = this.$el.find("#uMapsContainer")[0];
            var map_ctrl = this.mapCtrl;
            window.map_control_on_record = map_ctrl;
            var map_center = window.map_control_on_record.getCenter();
            var point_position = pin.getLocation();
            var offset_latitude = 0;
            var offset_longitude = 0;
            if (map_center.latitude >= point_position.latitude) {
                offset_latitude = 15;
            } else {
                offset_latitude = -120;
            }

            if (map_center.longitude >= point_position.longitude) {
                offset_longitude = -15;
            } else {
                offset_longitude = -230;
            }
            
            this.pinInfobox.setOptions({
                offset  : new Microsoft.Maps.Point(offset_longitude, offset_latitude),
                visible : true
            });

            this.pinInfobox.setMap(window.map_control_on_record);

            $("#infoboxText")
                .parent()
                .parent()
                .parent()
                .css("z-index", "0");

            setTimeout(function() {
                $("#title_link").on("click", function(evt) {
                    App.controller.navigate(`${pin.module}/${pin.recordId}`);
                });
            }, 0);

            setTimeout(function() {
                $("#street_view_link").on(
                    "click",
                    function(evt) {
                        var pin_latitude = $(evt.currentTarget).attr("pin_latitude");
                        var pin_longitude = $(evt.currentTarget).attr("pin_longitude");
                        var map_ctrl = window.map_control_on_record;
                        var self = this;

                        setTimeout(function() {
                            self.hideInfoBox();
                            map_ctrl.setView({
                                center: new Microsoft.Maps.Location(pin_latitude, pin_longitude)
                            });
                            map_ctrl.setView({ zoom: 18 });
                            map_ctrl.setView({
                                mapTypeId: Microsoft.Maps.MapTypeId.streetside
                            });
                            map_ctrl.setView({
                                mapTypeId         : Microsoft.Maps.MapTypeId.streetside,
                                streetsideOptions : {
                                    showCurrentAddress : false,
                                    onErrorLoading     : function() {
                                        message = app.lang.get("WMAPS_LABEL_ALERT18");
                                        app.alert.show("StreetSideNotAvailableOnView", {
                                            level     : "warning",
                                            messages  : message,
                                            autoClose : true
                                        });
                                    },
                                    onSuccessLoading: function() {
                                        if ($("#directionsClose").length > 0) {
                                            $("#directionsClose").css("z-index", 0);
                                            $("#infoboxText").hide();
                                        }
                                        $(".streetsideExit").on("click", function() {
                                            if ($("#directionsClose").length > 0) {
                                                $("#directionsClose").css("z-index", 999);
                                            }
                                            if ($(".ms-composite").children().length > 0) {
                                                $(".ms-composite")
                                                    .children()
                                                    .css("z-index", 0);
                                            }
                                        });
                                    }
                                }
                            });
                        }.bind(this), 800);
                    }.bind(this)
                );
            }.bind(this), 0);
        }
    },

    createWaypoint: function (directionsManager, recordData) {
        var waypoint = new Microsoft.Maps.Directions.Waypoint({
            address  : recordData.name,
            location : new Microsoft.Maps.Location(recordData.latitude, recordData.longitude)
        });

        directionsManager.addWaypoint(waypoint);
    },

    getZoom: function (locations) {
        var maxLat = -85,
                minLat = 85,
                maxAngle = 360,
                halfAngle = 180,
                medAngle = 256,
                decrease = 2,
                maxLon = -180,
                minLon = 180,
                zoom1 = 0,
                zoom2 = 0,
                i;

        // If we have a locations array, the we ned to get the MBR
        if (locations) {
            // A list of location objects, we need to get MBR
            for (i = 0; i < locations.length; i++) {
                if (locations[i].latitude > maxLat) {
                    maxLat = locations[i].latitude;
                }
                if (locations[i].latitude < minLat) {
                    minLat = locations[i].latitude;
                }
                if (locations[i].longitude > maxLon) {
                    maxLon = locations[i].longitude;
                }
                if (locations[i].longitude < minLon) {
                    minLon = locations[i].longitude;
                }
            }
        }

        //get the center of the map
        var center = {};
        center.latitude = (maxLat + minLat) / decrease;
        center.longitude = (maxLon + minLon) / decrease;

        var params = {
            mapWidth  : screen.width, // Width of your map div in pixels
            mapHeight : screen.height, // Height of your map div in pixels
            buffer    : 50 // How many pixels to add as a buffer
        };

        //Determine the best zoom level based on the map scale and bounding coordinate information
        if (maxLon != minLon && maxLat != minLat) {
            //best zoom level based on map width
            zoom1 =
                Math.log(maxAngle / medAngle * (params.mapWidth - decrease * params.buffer) / (maxLon - minLon)) /
                Math.log(decrease);
            //best zoom level based on map height
            zoom2 =
                Math.log(halfAngle / medAngle * (params.mapHeight - decrease * params.buffer) / (maxLat - minLat)) /
                Math.log(decrease);
        }
        //use the most zoomed out of the two zoom levels
        var optimZoom = zoom1 < zoom2 ? zoom1 : zoom2;

        return { zoom: optimZoom, center: center };
    },

    generateMap: function (collection, computeDirections, fromRecord) {
        this.pinInfobox = new Microsoft.Maps.Infobox(new Microsoft.Maps.Location(0, 0), {
            description     : "description",
            showCloseButton : false,
            showPointer     : false,
            offset          : new Microsoft.Maps.Point(-26, 2)
        });

        Microsoft.Maps.Events.addHandler(this.pinInfobox, "mouseleave", this.hideInfoBox.bind(this));
        
        var mapInitialLatitude = app.user.currentLocationLat;
        var mapInitialLongitude = app.user.currentLocationLng;

        if ((fromRecord || app.cameFromRecordFiltering) && collection && collection[0]) {
            mapInitialLatitude = collection[0].latitude;
            mapInitialLongitude = collection[0].longitude;
        }

        var zoomAndCenter = this.getZoom(collection);
        var directionsManager = false;

        if (zoomAndCenter.zoom === 0) {
            zoomAndCenter.zoom = 10;
        }

        if (zoomAndCenter.center) {
            var map = new Microsoft.Maps.Map(document.getElementById("uMapsContainer"), {
                credentials : "AuIEmeKGjvNV037yKiYGV0B3cxqNmx6FWnode0Hj8tjQPjK1zJP-7GAESccoCDUA",
                center      : zoomAndCenter.center,
                zoom        : zoomAndCenter.zoom
            });
            this.mapCtrl = map;
            Microsoft.Maps.Events.addHandler(map, "click", this.hideInfoBox.bind(this));

            if (!fromRecord && !app.cameFromRecordFiltering) {
                if (computeDirections) {
                    directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);
                    // Set Route Mode to driving
                    directionsManager.setRequestOptions({ routeMode: Microsoft.Maps.Directions.RouteMode.driving });

                    this.createWaypoint(directionsManager, {
                        name      : app.user.get("full_name"),
                        latitude  : mapInitialLatitude,
                        longitude : mapInitialLongitude,
                        color     : "rgb(38,135,27)"
                    });
                } else {
                    this.createPushpin(map, {
                        name      : app.user.get("full_name"),
                        latitude  : mapInitialLatitude,
                        longitude : mapInitialLongitude,
                        color     : "rgb(38,135,27)"
                    });
                }
            }

            _.each(
                collection,
                function addPushpins(recordData) {
                    recordData.color = "rgb(0,66,121)";
                    if (directionsManager) {
                        this.createWaypoint(directionsManager, recordData);
                    } else {
                        this.createPushpin(map, recordData);
                    }
                },
                this
            );

            if (directionsManager) {
                // Set the element in which the itinerary will be rendered
                directionsManager.setRenderOptions({
                    itineraryContainer: document.getElementById("uMapsRoutesContainer")
                });
                directionsManager.calculateDirections();

                this.$el.find("#uMapsRoutesContainer").hide();
            }
        }

        delete app.cameFromRecordFiltering;
    }
});
;   SUGAR.mobile.views["saved-report-list-rows-columns"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["saved-report-list-rows-columns"]["templates"]["saved-report-list-rows-columns"] = "{{!--\n\/*\n * Your installation or use of this SugarCRM file is subject to the applicable\n * terms available at\n * http:\/\/support.sugarcrm.com\/06_Customer_Center\/10_Master_Subscription_Agreements\/.\n * If you do not agree to all of the applicable terms or do not have the\n * authority to bind the entity as an authorized representative, then do not\n * install or use this SugarCRM file.\n *\n * Copyright (C) SugarCRM Inc. All rights reserved.\n *\/\n--}}\n\n\n\n{{#if ServerResults}}\n\t{{#if ServerResults.collection}}\n        <table class=\"table table-striped dataTable\">\n            <thead>\n                <tr>\n                    {{#each ServerResults.fields}}\n                        <th{{#if name}} data-fieldname=\"{{name}}\"{{\/if}} data-orderby=\"{{orderBy}}\" data-tablekey=\"{{table_key}}\" {{#eq name ..\/sortName}}{{#eq ..\/table_key ..\/..\/sortTableKey}}data-sortdirection=\"{{..\/..\/..\/sortDir}}\"{{\/eq}}{{\/eq}} class=\"sorting{{#eq name ..\/sortName}}{{#eq ..\/table_key ..\/..\/sortTableKey}}{{#eq ..\/..\/..\/..\/sortDir \"a\"}}_asc{{\/eq}}{{#eq ..\/..\/..\/..\/sortDir \"d\"}}_desc{{\/eq}}{{\/eq}}{{\/eq}}\">\n                            <span>{{label}}<\/span>\n                        <\/th>\n                    {{\/each}}\n                <\/tr>\n            <\/thead>\n            <tbody>\n                {{#each ServerResults.collection}}\n                    <tr class=\"single\">\n\t                   \t\t{{#each rows}}\n\t                   \t\t\t<td>\n\t                   \t\t\t\t<span class=\"list\">\n\t                   \t\t\t\t\t<div class=\"ellipsis_inline\" data-placement=\"bottom\" title=\"{{text}}\" >\n\t\t\t\t\t\t\t\t\t    \t{{{html}}}\n\t\t\t\t\t\t\t\t\t    <\/div>\n\t                   \t\t\t\t<\/span>\n\t                   \t\t\t<\/td>\n\t                   \t\t{{\/each}}\n                    <\/tr>\n                {{\/each}}\n            <\/tbody>\n        <\/table>\n\t{{else}}\n        <div class=\"block-footer\">\n            {{str \"LBL_NO_DATA_AVAILABLE\"}}\n        <\/div>\n\t{{\/if}}\n{{\/if}}\n";
    SUGAR.mobile.views["saved-report-list-rows-columns"]["controller"] = ({
    initialize: function (options) {
        this._super("initialize", arguments);

        options = options || {};
        options.dashletParent = options.dashletParent || {};

        if (_.isObject(options.dashletParent.sort)) {
            this.sortName = options.dashletParent.sort.name;
            this.sortTableKey = options.dashletParent.sort.table_key;
            this.sortDir = options.dashletParent.sort.sort_dir;
        }
    },

    render: function () {
        this.ServerResults = this.options.dashletParent.serverResults;
        this._super("render", arguments);

        this.fixBwcLinks();
    },

    fixBwcLinks: function () {
        this.$el
            .find("a[href*=\"module=\"]")
            .each(function goThroughElements(i, elem) {
                // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
            });
    }
});;   SUGAR.mobile.views["saved-report-list-summary-header"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["saved-report-list-summary-header"]["controller"] = /* global app, _ */

({
    events: {
        "click #expandColapseButton": "expandColapseButtonClicked"
    },

    initialize: function (options) {
        this._super("initialize", arguments);

        this.header = options.title;
        this.parent = options.parent;
        this.cUUID = app.utils.generateUUID();
        this.headerIndex = options.headerIndex;
        this.showSummary = options.showSummary;
        this.tableToCollapseId = _.uniqueId();
        this.childTableVisible = true;
        this.dashletParent = options.dashletParent;

        var spacesOffset = 10;
        var spacesLeft = 5;
        this.spaces = this.headerIndex * spacesOffset - spacesLeft;

        this.darkMode = $("body").hasClass("theme-dark") === true;
    },

    render: function () {
        this._super("render", arguments);
        this.getHeader();
        var headerHtml =
            "<div data-html=\"true\" style=\"float:left; margin-left: 5px;\">" +
            this.header +
            "</div>";

        this.$el.find("." + this.tableToCollapseId).append(headerHtml);
    },

    expandColapseButtonClicked: function (event) {
        var childTable = this.$el.find("#" + event.currentTarget.name);
        if (childTable.data("visible") === false) {
            event.currentTarget.children[0].src =
                "themes/default/images/basic_search.gif?v=NDZq21b7_V0TWvcCY4J40";
            childTable.data("visible", true);
            childTable.show();
        } else {
            childTable.hide();
            childTable.data("visible", false);
            event.currentTarget.children[0].src =
                "themes/default/images/advanced_search.gif?v=NDZq21b7_V0TWvcCY4J40";
        }
    },

    getHeader: function () {
        if (
            typeof this.collection == "undefined" ||
            this.showSummary !== true
        ) {
            return;
        }

        if (this.collectionIsHeader()) {
            for (var group in this.collection) {
                if (group !== "header") {
                    var subGroupView = app.view.createView({
                        name          : "saved-report-list-summary-header",
                        model         : this.model,
                        context       : this.context,
                        collection    : this.collection[group],
                        headerIndex   : this.headerIndex + 1,
                        showSummary   : this.showSummary,
                        title         : this.collection[group]["header"],
                        dashletParent : this.dashletParent
                    });

                    subGroupView.render();

                    this.$el
                        .find("table#" + this.cUUID)
                        .find("td.group-data:first")
                        .append(subGroupView.$el.find("table:first"));
                }
            }
        } else {
            var headerRow = app.view.createView({
                name          : "saved-report-list-summary-row",
                model         : this.model,
                context       : this.context,
                collection    : this.collection,
                dashletParent : this.dashletParent
            });

            headerRow.render();

            this.$el
                .find("table#" + this.cUUID)
                .find("td.group-data:first")
                .append(headerRow.$el.find("table:first"));
        }
    },

    collectionIsHeader: function () {
        return !this.collection.wIsData;
    }
});;
    SUGAR.mobile.views["saved-report-list-summary-header"]["templates"]["saved-report-list-summary-header"] = "<table id='{{cUUID}}' width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class='reportGroupViewTable wReportTable'>\n    <tbody>\n        <tr>\n            <td>\n                <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"reportGroupNByTable\">\n                    <tbody>\n                        <tr height=\"20\">\n                            <th align=\"left\" class=\"reportGroup1ByTableEvenListRowS1 {{tableToCollapseId}}\"\n                                valign=\"middle\" nowrap=\"\"\n                                style=\"{{#eq darkMode false}}background-color: #f6f6f6;{{\/eq}}border-style:solid;border-color:#e9e9e9; height:30px; border-width: 1px;border-bottom-style: none;\">\n                                <span id=\"img_combo_summary_div_0\" style=\"float:left; margin-left:{{spaces}}px;\">\n                                    <a id=\"expandColapseButton\" name=\"{{tableToCollapseId}}\">\n                                        {{#if showSummary}}\n                                            <img width=\"8\" height=\"8\" border=\"0\" absmiddle=\"\" alt=\"Show\"\n                                                src=\"themes\/default\/images\/basic_search.gif?v=NDZq21b7_V0TWvcCY4J40w\">\n                                        {{else}}\n                                            <img width=\"8\" height=\"8\" border=\"0\" absmiddle=\"\" alt=\"Show\"\n                                                src=\"themes\/default\/images\/advanced_search.gif?v=NDZq21b7_V0TWvcCY4J40\">\n                                        {{\/if}}\n                                    <\/a>\n                                <\/span>\n                            <\/th>\n                        <\/tr>\n                    <\/tbody>\n                <\/table>\n            <\/td>\n        <\/tr>\n        <tr class='group-line' id=\"{{tableToCollapseId}}\">\n            <td class='group-data'>\n\n            <\/td>\n        <\/tr>\n    <\/tbody>\n<\/table>";   SUGAR.mobile.views["saved-report-list-grand-total"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.views["saved-report-list-grand-total"]["controller"] = /* global app */

({
    reportModuleLC: "",

    initialize: function (options) {
        this._super("initialize", arguments);

        this.reportModuleLC = this.options.dashletParent.serverResults.keyPrefix;
        this.minTableWidth = options.minTableWidth;
        var grandTotalData = this.options.dashletParent.serverResults.grandTotal;

        this.columns = grandTotalData.columnNames;
        this.values = grandTotalData.columnValues;
        this.darkMode = $("body").hasClass("theme-dark") === true;
    },

    render: function () {
        this._super("render", arguments);
    }
});;
    SUGAR.mobile.views["saved-report-list-grand-total"]["templates"]["saved-report-list-grand-total"] = "<table style=\"min-width:{{minTableWidth}}\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"\n    class=\"wReportsDashletGrandTotalHead\">\n    <thead>\n        <tr style=\"width: 100%;\">\n            <th class=\"row-column\" style=\"text-align:left;border-width:1px;border-style:solid;border-color:#e9e9e9;{{#eq darkMode false}}background-color: #f6f6f6;{{\/eq}}\n\">\n                <a class=\"rowHeader\"\n                    name=\"view-saved-report-list-grand-total-view369-<no-id>\/Home\/bean:Home\/e9a0ecf6-c971-11e6-bc95-000c29eb6790\/coll:Home-0\"\n                    style=\"border-style: none;border-color:#e9e9e9; color:#666;font-size: 13px;font-weight: bolder;\"\n                    tabindex=\"-1\">\n                    {{str 'LBL_WRD_GRAND_TOTAL'}}\n                <\/a>\n            <\/th>\n        <\/tr>\n    <\/thead>\n<\/table>\n<table style=\"min-width:{{minTableWidth}}\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"\n    class='reportDataChildtablelistView row-report wReportTable'>\n    <tbody>\n        <tr>\n            {{#each columns}}\n                <th class='row-column'\n                    style=\"text-align:left; border-width:1px; border-style:solid; border-color:#e9e9e9;\">\n                    <a class=\"rowHeader\" name=\"{{this}}\"\n                        style=\"border-style: none;border-color:#e9e9e9; color:#666;font-size: 13px;font-weight: bolder;\"\n                        tabindex=\"-1\">\n                        {{this}}\n                    <\/a>\n                <\/th>\n            {{\/each}}\n        <\/tr>\n        <tr>\n            {{#each values}}\n                <td class='row-column'\n                    style=\"text-align:left; border-width:1px; border-color:#e9e9e9; border-style:solid\">\n                    {{this}}\n                <\/td>\n            {{\/each}}\n        <\/tr>\n    <\/tbody>\n<\/table>";   SUGAR.mobile.widgets["mobileButtonsManager"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.widgets["mobileButtonsManager"]["controller"] = /*eslint-disable*/
class MobileButtonsManager {
    constructor(containerHtml, masterButtonHtml) {
        this.masterButtons = {};
        this.masterButtonsConfig = {};

        this.createContainer(containerHtml);
        this.initialize();
    }

    initialize() {
        app.on("app:orientation:changed", this.handleDeviceOrientationChanged.bind(this));
        if (!app.controller.navigationExtended) {
            app.controller.navigationExtended = true;
            var navFunction = app.controller.navigate;
            var buttonsManager = this;

            app.controller.navigate = function (url, options) {
                navFunction.call(app.controller, url, options);

                buttonsManager.handleViewChange();
            };
        }

        document.getElementById("nomad").appendChild(document.getElementById("customizationsLoadingScreen"));
    }

    createContainer(containerHtml) {
        $("#nomad").append(containerHtml);
        this.container = $("#mobileButtonsContainer");
        this.mobileButtonsOverlay = $("#mobileButtonsOverlay");
        this.mobileButtonsLoadingScreen = $("#customizationsLoadingScreen");
        this.loadingScreenLabel = $("#customizationsLoadingScreenLabel");
        this.mobileButtonsOverlay.on("click", this.closeMasterButtons.bind(this));
        this.mobileButtonsOverlay.on("touchmove", this.closeMasterButtons.bind(this));

        this.initContainerPosition();
    }

    getInitialContainerPosition() {
        var containerSize = 100;
        var containerXPos = window.innerWidth - containerSize;
        var containerYPos = window.innerHeight - containerSize;

        var initialContainerPosition = "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)";

        return initialContainerPosition;
    }

    initContainerPosition() {
        this.container.css("transform", this.getInitialContainerPosition());
    }

    closeMasterButtons() {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                masterButton.closeWidget();
            }.bind(this)
        );
        this.hideOverlay();
    }

    hideOverlay() {
        this.mobileButtonsOverlay.hide();
    }

    dragStart(e) {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                if (e.target === masterButton.dragItemLabel || e.target.id === masterButton.dragItemIcon.id) {
                    this.active = true;
                }
            }.bind(this)
        );
    }

    dragEnd(e) {
        var transitionActivated = false;

        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                var container = masterButton.manager.container;
                var containerPosition = container.position();
                var masterButtonPosition = masterButton.masterButtonLabel.position();
                if (
                    !transitionActivated &&
                    container &&
                    this.active &&
                    (containerPosition.left + masterButtonPosition.left < 0 ||
                        containerPosition.left + masterButtonPosition.left + masterButton.masterButtonLabel.width() >
                        window.innerWidth ||
                        containerPosition.top + masterButtonPosition.top < 0 ||
                        containerPosition.top + masterButtonPosition.top + masterButton.masterButtonLabel.height() >
                        window.innerHeight)
                ) {
                    transitionActivated = true;
                    var transitionSpeed = 100;
                    var containerSize = 100;
                    var wiggleWidth = 20;
                    var containerXPos = window.innerWidth - containerSize;
                    var containerYPos = window.innerHeight - containerSize;

                    container.animate({
                            transform: "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)"
                        },
                        transitionSpeed,
                        function wiggle() {
                            container.animate({
                                    transform: "translate3d(" +
                                        (containerXPos - wiggleWidth) +
                                        "px, " +
                                        containerYPos +
                                        "px, 0px)"
                                },
                                transitionSpeed,
                                function wiggleBack() {
                                    container.animate({
                                            transform: "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)"
                                        },
                                        transitionSpeed
                                    );
                                }
                            );
                        }
                    );
                }
            }.bind(this)
        );

        this.active = false;
    }

    drag(e) {
        if (this.active) {
            e.preventDefault();
            var currentX = 0;
            var currentY = 0;

            if (e.type === "touchmove") {
                currentX = e.touches[0].clientX;
                currentY = e.touches[0].clientY;
            } else {
                currentX = e.clientX;
                currentY = e.clientY;
            }

            _.each(
                this.masterButtons,
                function goThroughMasterButtons(masterButton) {
                    if (masterButton.masterButton.attr("checked")) {
                        masterButton.masterButton.prop("checked", false);
                        masterButton.notifyButtons(false);
                    }
                }.bind(this)
            );

            this.setTranslate(currentX, currentY);
        }
    }

    setTranslate(xPos, yPos) {
        var buttonRadius = 50;

        xPos = xPos - buttonRadius;
        yPos = yPos - buttonRadius;
        this.container.css("transform", "translate3d(" + xPos + "px, " + yPos + "px, 0)");
    }

    setEnabledHorizontalButtonsData(data) {
        return this.masterButtons.mainButton.setEnabledHorizontalButtonsData(data);
    }

    getEnabledHorizontalButtonsData() {
        return this.masterButtons.mainButton.getEnabledHorizontalButtonsData();
    }

    enableHorizontalButtons() {
        return this.masterButtons.mainButton.enableHorizontalButtons();
    }

    disableHorizontalButtons() {
        return this.masterButtons.mainButton.disableHorizontalButtons();
    }

    registerMobileButtons(newButtons) {
        _.each(
            newButtons,
            function registerButtons(buttonConfig) {
                this.masterButtonsConfig[app.utils.generateUUID()] = buttonConfig;
            },
            this
        );
    }

    createMasterButtons() {
        if (Object.keys(this.masterButtonsConfig).length > 0) {
            $("#mobileButtonsContainer").show();
            this.initContainerPosition();
            var mainButtonId = "mainButton";
            var mainButtonConfig = {
                isMainButton: true,
                masterButton: true,
                name: "d",
                label: "Forth Button",
                icon: "fab fa-wikipedia-w",
                color: "white",
                backgroundColor: "rgb(0,66,121)",
                children: this.masterButtonsConfig
            };

            this.createMasterButton(mainButtonConfig, mainButtonId, true);
            this.wrapperContainer = document.querySelector("#nomad");

            this.wrapperContainer.addEventListener("touchstart", this.dragStart.bind(this), false);
            this.wrapperContainer.addEventListener("touchend", this.dragEnd.bind(this), false);
            this.wrapperContainer.addEventListener("touchmove", this.drag.bind(this), false);

            this.wrapperContainer.addEventListener("mousedown", this.dragStart.bind(this), false);
            this.wrapperContainer.addEventListener("mouseup", this.dragEnd.bind(this), false);
            this.wrapperContainer.addEventListener("mousemove", this.drag.bind(this), false);
        } else {
            $("#mobileButtonsContainer").hide();
        }
    }

    createMasterButton(masterButtonConfig, buttonId, mainButton) {
        this.masterButtons[buttonId] = new SUGAR.mobile.widgets.mobileMasterButton.controller(
            masterButtonConfig,
            buttonId,
            this
        );

        return this.masterButtons[buttonId];
    }

    goToMainWidget() {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                masterButton.hideWidget();
            }.bind(this)
        );

        if (this.masterButtons.mainButton) {
            this.masterButtons.mainButton.showWidget();
            this.masterButtons.mainButton.closeWidget();
        }
    }

    destroyExistingButtons() {
        this.container.empty();
        this.masterButtonsConfig = {};
        _.each(this.masterButtons, function destroyMasterButton(masterButton) {
            masterButton.destroy();
        });
        delete this.masterButtons;
        this.masterButtons = {};
    }

    cleanButtons() {
        var duplicatedIds = [];
        _.each(
            this.buttonsConfig,
            function getDuplicatedButtons(buttonConfig, buttonId) {
                _.each(
                    this.buttonsConfig,
                    function checkDuplicatedButtons(dupeButtonConfig, dupeButtonId) {
                        if (
                            dupeButtonConfig.name == buttonConfig.name &&
                            dupeButtonConfig.icon == buttonConfig.icon &&
                            dupeButtonConfig.color == buttonConfig.color &&
                            dupeButtonConfig.backgroundColor == buttonConfig.backgroundColor &&
                            dupeButtonConfig.label == buttonConfig.label &&
                            buttonId !== dupeButtonId &&
                            duplicatedIds.indexOf(dupeButtonId) < 0 &&
                            duplicatedIds.indexOf(buttonId) < 0
                        ) {
                            duplicatedIds.push(dupeButtonId);
                        }
                    },
                    this
                );
            },
            this
        );

        for (var idIndex = 0; idIndex < duplicatedIds.length; idIndex++) {
            delete this.buttonsConfig[duplicatedIds[idIndex]];
        }
    }

    hideLoadingScreen(hideTimer) {
        if (hideTimer) {
            setTimeout(
                function hideLoadingScreenWidget() {
                    this.mobileButtonsLoadingScreen.css("display", "none");

                    if (app.rebrandingManager) {
                        app.rebrandingManager.handleLoadingScreen(false);
                    }
                }.bind(this),
                hideTimer
            );
        } else {
            this.mobileButtonsLoadingScreen.css("display", "none");

            if (app.rebrandingManager) {
                app.rebrandingManager.handleLoadingScreen(false);
            }
        }
    }

    handleLoadingScreen(loadingScreenSettings) {
        var loadingScreenMessage = loadingScreenSettings.message ? loadingScreenSettings.message : "Loading ...";
        this.loadingScreenLabel.text(loadingScreenMessage);

        var loadingScreenOpacity = loadingScreenSettings.opacity ? loadingScreenSettings.opacity : 0.85;
        this.mobileButtonsLoadingScreen.css("opacity", loadingScreenOpacity);

        this.showLoadingScreen();

        if (loadingScreenSettings.autoHide) {
            setTimeout(
                function hideLoadingScreenWidget() {
                    this.hideLoadingScreen();
                }.bind(this),
                loadingScreenSettings.hideTimer
            );
        }
    }

    showLoadingScreen() {
        if (app.rebrandingManager) {
            app.rebrandingManager.handleLoadingScreen(true);
        }
        this.mobileButtonsLoadingScreen.css("display", "flex");
    }

    handleDeviceOrientationChanged() {
        this.initContainerPosition();
    }

    handleViewChange() {
        this.destroyExistingButtons();
        app.controller.trigger("mobile-context-changed", this);
        this.cleanButtons();
        this.createMasterButtons();

        if (app.rebrandingManager) {
            app.rebrandingManager.handleViewChange(App.controller.getScreenContext());
        }
    }
};
    SUGAR.mobile.widgets["mobileButtonsManager"]["templates"]["mobileButtonsContainer"] = "<div style=\"position:absolute;width:100%;height:100%;z-index:9000;display:none;\" id=\"mobileButtonsOverlay\"><\/div>\n<div id=\"mobileButtonsContainer\" style=\"position:absolute;z-index:9999;height:100px;width:100px;\"><\/div>\n<link rel=\"stylesheet\" href=\"https:\/\/use.fontawesome.com\/releases\/v5.4.1\/css\/all.css\" integrity=\"sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz\" crossorigin=\"anonymous\">\n<style>\nbody {\n--l: 4em;\n}\n\n.masterButton {\ndisplay: none;\n}\n\n.masterButton + label {\ncursor: pointer;\nposition: absolute;\nright: 1em; bottom: 1em;\nbackground-color: tomato;\nheight: var(--l); width: var(--l);\nborder-radius: 50%;\nz-index: 2;\n}\n\n.masterButton:checked + label:before { transform: rotatez(-45deg); }\n\n.masterButton:checked + label:after { transform: rotatez(-45deg); }\n\n.mobileButton {\ncursor: pointer;\nposition: absolute;\nright: 1em; bottom: 1em;\npadding: 1em;\nwidth: 1em; height: 1em;\nborder-radius: 50%;\nopacity: 0;\nz-index: 1;\ntransform: rotateZ(90deg);\nfont-size: 1em;\ncolor: #fff;\ntransition-property: all;\ntransition-duration: .35s;\ntransition-timing-function: cubic-bezier(0.175, 0.885, 0.32, 1.275);\n}\n\n.masterButton:checked ~ .mobileButton {\nopacity: 1;\n}\n\n.masterButton:checked ~.mobileButton:hover {\nopacity: .9;\n}\n<\/style>";   SUGAR.mobile.widgets["mobileButton"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.widgets["mobileButton"]["controller"] = /*eslint-disable*/
class MobileButton {
    constructor(config, container, buttonId, buttonsNumber) {
        this.checked = config.checked;
        this.config = config;
        this.container = container;
        this.buttonId = buttonId;
        this.buttonKey = "mobileButton" + this.config.name + buttonsNumber;
        this.buttonNumber = buttonsNumber;

        if (this.config.horizontalButton) {
            this.buttonKey = this.buttonKey + "horizontal";
        }

        this.createButtonHtml();
        this.createButton();
    }

    createButtonHtml() {
        var iconHTML = `<i class="${this.config.icon}" style="font-size:20px;flex-shrink:0"></i>`;

        if (this.config.encodedIcon) {
            iconHTML = `<img src="${this.config.encodedIcon}">`;
        }

        var labelColor = this.config.labelColor ? this.config.labelColor : "#f5f5f5";

        var labelCss = `
        <div style="color: ${labelColor};position: absolute;top: 12px;left: -1247px;background-color: ${
            this.config.backgroundColor
        };border-radius: 20px;padding: 3px 8px;" class="mobileButtonInfoLabel${this.buttonKey}">
            ${this.config.label}
        </div>`;

        if (this.config.horizontalButton) {
            labelCss = `
            <div style="color: #f5f5f5;" class="mobileButtonInfoLabel${this.buttonKey}">
                ${this.config.label}
            </div>`;
        }

        this.buttonHtml =
            `
            <style>
            .masterButtonInput${this.config.manager.id}:checked ~ .${this.buttonKey} {
              background-color: ${this.config.backgroundColor};
              color: ${this.config.color};
              opacity: 1;
            }
            </style>
                <div class="mobileButton ${this.buttonKey}" id="${this.buttonId}" style="font-weight:900;z-index:-${
                this.buttonNumber
            };display:flex;justify-content:center;align-items:center;">
            ` +
            iconHTML +
            labelCss +
            `
        </div>
            `;
    }

    createButton() {
        this.container.append(this.buttonHtml);

        this.mobileButtonInfoLabel = $(".mobileButtonInfoLabel" + this.buttonKey);
        this.mobileButton = $("#" + this.buttonId);

        this.mobileButton.on("click", this.action.bind(this));
    }

    action() {
        try {
            if (this.masterWidgetCreated) {
                this.config.manager.hideWidget();
                this.config.masterButton.showWidget();
            } else if (this.config.callback && this.config.manager.masterButton.attr("checked")) {
                if (this.config.loadingScreenSettings) {
                    this.config.manager.showLoadingScreen(this.config.loadingScreenSettings);
                }
                if (this.config.horizontalButton) {
                    this.checked = !this.checked;
                    var opacity = this.checked ? 1 : 0.5;

                    this.mobileButton.css("opacity", opacity);
                } else {
                    this.config.manager.currentButtonConfig = this.config;
                }

                this.config.callback(this.config.manager);
                if (!this.config.horizontalButton) {
                    if (this.config.majorButton) {
                        this.masterWidgetCreated = true;
                    } else {
                        this.config.manager.goToMainWidget();
                    }
                }
            }
        } catch (err) {
            var buttonsManager = SUGAR.customizationTools.mobileButtonsManager;
            buttonsManager.goToMainWidget();
            buttonsManager.hideLoadingScreen();

            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: err.message,
                autoClose: true
            });
        }
    }

    show() {
        this.mobileButtonInfoLabel.show();
        this.masterButtonPressed(true);
    }

    hide() {
        this.mobileButtonInfoLabel.hide();
    }

    masterButtonPressed(checked) {
        if (checked) {
            this.animateButton();
        } else {
            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(0em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-0em)`);
            }
        }

        var transitionSpeed = 500;
        var timeoutTreshold = 200;
        var targetOpacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
        var elementTarget = this.config.horizontalButton ? this.mobileButton : this.mobileButtonInfoLabel;

        elementTarget.css("opacity", "0");

        if (checked && this.canShow()) {
            elementTarget.animate({
                    opacity: targetOpacity
                },
                transitionSpeed
            );
        }

        if (!this.config.horizontalButton) {
            elementTarget.css("left", "-9999px");
            setTimeout(
                function positionLabels() {
                    var distanceFromIcon = 5;
                    var currentWidth = distanceFromIcon + elementTarget.width();
                    elementTarget.css("left", "-" + currentWidth + "px");
                }.bind(this),
                timeoutTreshold
            );
        }
    }

    animateButton() {
        if (this.canShow()) {
            var opacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
            this.mobileButton.css("opacity", opacity);

            var finalPosition = this.config.manager.getFinalPosition(this);

            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(-${finalPosition.transform}em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-${finalPosition.transform}em)`);
            }

            this.mobileButton.css("transition-delay", finalPosition.delay + "s");
        } else {
            this.mobileButton.css("opacity", "0");
        }
    }

    canShow() {
        var canShow = true;

        if (this.config.showCondition) {
            canShow = this.config.showCondition();
        }
        this.test = canShow;
        return canShow;
    }

    destroy() {}
};   SUGAR.mobile.widgets["mobileMasterButton"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.widgets["mobileMasterButton"]["templates"]["mobileMasterButton"] = "<input id=\"masterButton\" class=\"masterButton masterButtonInputPlaceHolder\" type=\"checkbox\" \/>\n<label id=\"masterButtonLabel\" class=\"masterButtonLabelPlaceHolder\" style=\"box-shadow: 0 3px 5px -1px rgba(0,0,0,.2), 0 6px 10px 0 rgba(0,0,0,.14), 0 1px 18px 0 rgba(0,0,0,.12);\">\n    <div id=\"masterButtonIcon\" class=\"masterButtonIcon masterButtonIconPlaceHolder\" style=\"font-size:  25px\"><\/div>\n<\/label>";
    SUGAR.mobile.widgets["mobileMasterButton"]["templates"]["wSystemsLogo"] = "<img class=\"masterButtonIconLogo\" id=\"masterButtonIcon\" src=\"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAABCFBMVEVHcEz\/\/\/\/\/\/\/\/\/\/\/\/8\/Pz8\/Pz\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/5+fn\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/MzMzOzs7MzMzh4eHLy8vz8\/PMzMz\/\/\/\/MzMz\/\/\/\/Ly8v6+vrPz8\/+\/v7X19fT09Pb29vv7+\/h4eHq6url5eX29vby8vKCN9xWAAAASHRSTlMA9wUfCwMI\/WHGAvvM5cAU9CcQGQ6fduDRQO1M8q7wuFy8Reo3cy1kXrOVOwGaaiol16hvHFGG24t+M6OCWNWPVvRNseGd4bc0fC53AAAF10lEQVR42u1a2VriShBmkwAhrAZQdgQVgYiIqON69soXxVFR3\/9NDnGSQEhXNwlMcpO6pdJVdG1\/\/92BgC+++OKLL7744ou3EvLW+vCo4aH53dagOBp7Zj4fa2YgFfbMvJTkAUqnHpnPHSU5ABBa3piPllM8AEDmyBPz\/UOxAt9y5UkJ5jrFX+ahnvbAfKJX5zX7xR9eVH5H0MxD0IsEOKzqfx9AjLrfdx\/PDPNQGrqffZPKwn7mznX72Sq3sA8D1wOwl1wyD\/dZt8PfEJbtu14BkUJt2T5UIy6n30PQZF9ouzx5Rc5kH277rtoPV83mIekuCBrWV+wH3UWB2dSKfejuemt\/f89b+3DiJgoZNi32i4du5n\/dYh9uXcR+6arV\/r2L54Bd0Wqf6xAUG7FlaVy0DsfmWXlqUjh+LLezuR029r7irA4k8wRNc6JwfPDgsn7bW\/Jhr2ZW4CtCUjwO0\/vpTidotc8Tp2CMoAm1ai9h7GWToMCdFaioulEjfBQnfjIuAUkEyShYiajA1SkHu70i4Qv+mKw8Ia4PmY7uQbZI1oijHmSTJP1Ujqzdq5HXrz3q8RTJCtBFopDukrR5bApF6sj6BnK7CJIVuGtiJoZIBYBvwDzGHOKB3rfTSUSBjG1iGVsbMG\/ZSIwXk+saUYAbArxuk5fDNyCwM0DX17bgxwGiULMO13yTqMnHKEVbDmJb0NPaWpXl4lICICVDaxvpOLb+idaOYliaHKxmwV2FnK8StXGiMS5qpR6+xDSuVjoAua1BKU91AI0xFLTZeoIpnJkGbFSkr4OOLjTGeuhaGUSBO2IOFoubBDnmkfWDZW0ipTAX60vnrOwZosQEQmHsSxC1NO8Ao1LUjcTqmY0E+w9oGmr9+FDANCbGKhcVRjHRzu\/Yt3Cu1fcIUzASPB9nbxKO4NAYN7UYP2Jpwut0SwFrFqN1+JBzYHTbfAnTGH2nyc7wb+T3THkdEHsqsFrNBFMQvlMs9M\/LE7KHa50GQzfY+vfacbq3T+1Wf\/7x\/EkO0ZqEDIY6jEGOAhdIzf9i5C9Z\/nLShRdjNAmMHEKBS6alboAsz4i\/Xq97lLmlx5gCXOAkEPlPlpV34tdr34q09xkTKYECl8uxugHK65Tw22BnXQciXXQiaWiqjE0kXppngKz8JJRBxca1zBHHKGQcuPw73wBZJpVB3QYniKOOQYIBXJ5+KqoHb\/agoOU6A0Udl0MWcHlXHVA+HNfgmqgDBy5fz6oDrxsyIjk0xl0tkg1sIk1fFFlWLM34wObFUAFFHRr4Hd9jGjNiFo7scWJ9NupAgcunGoPVZhy8sMvrM1EHDlzUNFRmNk4jRLlDwekFC7i8ydZmXLBPrZdYZzAUuDzN01B5mTobAwu5Yp2RsuhE+lBWm7HogJbF6BIAjeILibQ0fP4inCns0YtNGuqgApfpq2JuxvGcE4JTwhzQxxpKl6itwNSMC07sU2L80GeA0\/lEWoYEgjNiHKXEjANmmzKRlpvxjcObAZQu0XnGaJcykRbN2HYXNOgSNMbVKAO4qK3AyMKk4wcSKOrQRxsOXGbKohk7v5rAUcc1C7h8PhvN+MD5Cw0mXdJHgcu8FejNuLrBBf0xx6BLcODyJmvNGGPG1wOnKF2iY\/wC3go0SHC2yeUQhS4Zso7SH1oWPmz23AGdSBLrKP0lfyAUrq0HB10WXYKekaYv3824u+ETBRT81jS2J4cCo5mahfymN+T4Uf2Kdcfw+fKJXM\/Zkg7HAKe4i+9vwJ1vfO05LrEosXPMxbcZlLbwRkLiqZQYhRR8mvHSFm5+000GXRK4wwrhazsPBfcEBvGOEcNTYTtvJPpShk6XBMLkUsxIW3qlE+pUUEoMfaABUOls7Y1G6LHEoL7DA4uPpbttvhEJF+L7HEqXqHnQEi8XEJLbjxe2\/UIi145NxG4zbpJl3isULndORvVUsytOYu3f80QoEYpGTGLZ5LlCNJQI+OKLL7744osvvjiT\/wFqVhC31sfrswAAAABJRU5ErkJggg==\" style=\"width:  38px;\">";
    SUGAR.mobile.widgets["mobileMasterButton"]["controller"] = /*eslint-disable*/
class MobileMasterButton {
    constructor(masterButtonConfig, id, manager) {
        this.manager = manager;
        this.id = id;
        this.config = masterButtonConfig;
        this.html = SUGAR.mobile.widgets.mobileMasterButton.templates.mobileMasterButton;

        this.buttons = {};
        this.buttonsConfig = {};
        this.buttonHeight = 3.2;
        this.buttonDelay = 0.0;
        this.initialHeight = 1.5;

        this.createMasterButton();
        this.createNewButtons();
    }

    createMasterButton() {
        this.manager.container.append(this.html);

        $(".masterButtonInputPlaceHolder")
            .addClass("masterButtonInput" + this.id)
            .removeClass("masterButtonInputPlaceHolder");
        $(".masterButtonLabelPlaceHolder")
            .addClass("masterButtonLabel" + this.id)
            .removeClass("masterButtonLabelPlaceHolder");
        $(".masterButtonIconPlaceHolder")
            .addClass("masterButtonIcon" + this.id)
            .removeClass("masterButtonIconPlaceHolder");

        this.masterButton = $(".masterButtonInput" + this.id);
        this.masterButtonLabel = $(".masterButtonLabel" + this.id);
        this.masterButtonIcon = $(".masterButtonIcon" + this.id);

        this.masterButtonIcon.addClass(this.config.icon);
        this.masterButtonIcon.css("color", this.config.color);
        this.masterButtonLabel.css("background-color", this.config.backgroundColor);

        if (this.config.isMainButton) {
            this.masterButtonLabel.empty();
            this.masterButtonLabel.append(SUGAR.mobile.widgets.mobileMasterButton.templates.wSystemsLogo);
            this.masterButtonIcon = $(".masterButtonIconLogo");

            if (SUGAR.rebrandedLogo) {
                $(".masterButtonIconLogo").attr("src", SUGAR.rebrandedLogo);

            }

            if (SUGAR.rebrandedLogoSize) {
                $(".masterButtonIconLogo").css("width", SUGAR.rebrandedLogoSize);
            }

            if (SUGAR.rebrandedLogoMarginRight) {
                $(".masterButtonIconLogo").css("margin-right", SUGAR.rebrandedLogoMarginLeft);
            }

            if (SUGAR.rebrandedLogoMarginLeft) {
                $(".masterButtonIconLogo").css("margin-left", SUGAR.rebrandedLogoMarginLeft);
            }

            if (SUGAR.rebrandedLogoBackground) {
                $("#masterButtonLabel").css("background-color", SUGAR.rebrandedLogoBackground);
            }
        }

        var newIconWidth = this.masterButtonIcon.width();
        var newIconHeight = this.masterButtonIcon.height();

        if (newIconHeight === 0) {
            newIconHeight = newIconWidth;
        }

        this.masterButtonIcon.css("margin-left", this.masterButtonLabel.width() / 2 - newIconWidth / 2 + "px");
        this.masterButtonIcon.css("margin-top", this.masterButtonLabel.height() / 2 - newIconHeight / 2 + "px");

        this.masterButtonIcon.on("click", function triggerChange() {
            var nextCheckedValue = !this.masterButton.prop('checked');
            this.masterButton.prop('checked', nextCheckedValue);

            this.showPressedFeedback();
            if (!nextCheckedValue) {
                if (this.config.isMainButton) {
                    this.manager.hideOverlay();
                } else {
                    this.hideWidget();

                    this.config.mainButton.showWidget();
                }
            }

            this.notifyButtons(nextCheckedValue);
        }.bind(this));

        this.dragItem = document.querySelector("#mobileButtonsContainer");
        this.dragItemLabel = document.querySelector("#masterButtonLabel");
        this.dragItemIcon = document.querySelector("#masterButtonIcon");
        this.active = false;
    }

    createNewButtons() {
        _.each(this.config.children, this.createButton, this);
    }

    createButton(buttonConfig, buttonId) {
        var buttonsNumber = 1;
        _.each(this.buttons, function getButtonsNumber(button) {
            if (button.config.horizontalButton === buttonConfig.horizontalButton) {
                buttonsNumber = buttonsNumber + 1;
            }
        });

        var currentButtonConfig = _.clone(buttonConfig);

        if (!isNaN(buttonId)) {
            buttonId = app.utils.generateUUID();
        }

        currentButtonConfig.transform = this.initialHeight + buttonsNumber * this.buttonHeight;
        currentButtonConfig.delay = buttonsNumber * this.buttonDelay;
        currentButtonConfig.manager = this;

        var button = new SUGAR.mobile.widgets.mobileButton.controller(
            currentButtonConfig,
            this.manager.container,
            buttonId,
            buttonsNumber
        );
        this.buttons[buttonId] = button;
    }

    setEnabledHorizontalButtonsData(horizontalButtonsData) {
        if (horizontalButtonsData && horizontalButtonsData.length > 0) {
            _.each(this.buttons, function setNewData(buttonData) {
                if (buttonData.config.data && buttonData.config.data.module) {
                    var buttonStateModified = false;

                    _.each(horizontalButtonsData, function getCorrectModule(moduleData) {
                        if (moduleData.module === buttonData.config.data.module) {
                            buttonData.checked = true;
                            buttonStateModified = true;
                        }
                    });

                    if (!buttonStateModified) {
                        buttonData.checked = false;
                    }
                }
            });
        }
    }

    getEnabledHorizontalButtonsData() {
        var enabledHorizontalButtons = [];

        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton && button.checked) {
                enabledHorizontalButtons.push(button.config.data);
            }
        });

        return enabledHorizontalButtons;
    }

    enableHorizontalButtons() {
        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton) {
                button.checked = true;
            }
        });
    }

    disableHorizontalButtons() {
        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton && button.checked) {
                button.checked = false;
            }
        });
    }

    createNewMasterButton(buttonConfig) {
        if (this.currentButtonConfig) {
            var currentButtonConfig = _.clone(this.currentButtonConfig);

            currentButtonConfig.children = buttonConfig;
            currentButtonConfig.mainButton = this;

            var masterId = app.utils.generateUUID();
            var newMasterButton = this.manager.createMasterButton(currentButtonConfig, masterId);

            currentButtonConfig.masterButton = newMasterButton;
            this.currentButtonConfig.masterButton = newMasterButton;

            this.hideWidget(true);
            newMasterButton.showWidget();
        }
    }

    getFinalPosition(buttonEntity) {
        var buttonsNumber = 1;
        var buttonFound = false;

        _.each(this.buttons, function getButtonsNumber(button, buttonId) {
            if (buttonId === buttonEntity.buttonId) {
                buttonFound = true;
            } else if (
                !buttonFound &&
                button.config.horizontalButton === buttonEntity.config.horizontalButton &&
                button.canShow()
            ) {
                buttonsNumber = buttonsNumber + 1;
            }
        });

        return {
            transform: this.initialHeight + buttonsNumber * this.buttonHeight,
            delay: buttonsNumber * this.buttonDelay
        };
    }

    showLoadingScreen(loadingScreenSettings) {
        this.manager.handleLoadingScreen(loadingScreenSettings);
    }

    showPressedFeedback() {
        this.manager.mobileButtonsOverlay.show();
        var transitionSpeed = 150;
        var targetOpacity = 0.8;

        this.manager.container.animate({
                opacity: targetOpacity
            },
            transitionSpeed,
            function wiggle() {
                this.manager.container.animate({
                        opacity: 1
                    },
                    transitionSpeed
                );
            }.bind(this)
        );
    }

    notifyButtons(checked) {
        _.each(this.buttons, function destroyMasterButton(button) {
            button.masterButtonPressed(checked);
        });
    }

    closeWidget(keepOverlay) {
        this.masterButton.prop("checked", false);

        if (!keepOverlay) {
            this.manager.mobileButtonsOverlay.hide();
        }

        this.notifyButtons(false);
    }

    hideWidget(keepOverlay) {
        this.masterButton.attr("disabled", true);
        this.masterButtonLabel.hide();
        this.closeWidget(keepOverlay);

        _.each(this.buttons, function hideAllButtons(button) {
            button.hide();
        });
    }

    showWidget() {
        this.masterButton.removeAttr("disabled");
        this.masterButtonLabel.show();
        this.manager.container.prepend(this.masterButtonLabel);
        this.manager.container.prepend(this.masterButton);
        this.masterButton.prop("checked", true);

        _.each(this.buttons, function destroyMasterButton(button) {
            button.show();
        });
    }

    goToMainWidget() {
        this.manager.goToMainWidget();
    }

    destroy() {
        _.each(this.buttons, function destroyMasterButton(button) {
            button.destroy();
        });
    }
};   SUGAR.mobile.dashlets["saved-reports-list"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.dashlets["saved-reports-list"]["templates"]["saved-reports-list"] = "{{!--\n\/*\n * Your installation or use of this SugarCRM file is subject to the applicable\n * terms available at\n * http:\/\/support.sugarcrm.com\/06_Customer_Center\/10_Master_Subscription_Agreements\/.\n * If you do not agree to all of the applicable terms or do not have the\n * authority to bind the entity as an authorized representative, then do not\n * install or use this SugarCRM file.\n *\n * Copyright (C) SugarCRM Inc. All rights reserved.\n *\/\n--}}\n\n{{#if showDrilldownButton}}\n\t<table id=\"drilldownButtonTable\"\n\t\tstyle=\"width: 100%;border-width: 1px;border-style: solid;border-bottom-style: none;border-color:#e9e9e9;\">\n\t\t<tbody>\n\t\t\t<tr>\n\t\t\t\t<td style=\"text-align: left;background: #f6f6f6;\">\n\t\t\t\t\t<button class=\"btn btn-primary\" id=\"drill_button\"\n\t\t\t\t\t\tstyle=\"margin-top: 1px;margin-bottom: 1px;margin-left: 1px;\">{{str 'LBL_WRD_DRILL_DOWN'}}\n\t\t\t\t\t<\/button>\n\t\t\t\t<\/td>\n\t\t\t<\/tr>\n\t\t<\/tbody>\n\t<\/table>\n{{\/if}}\n<div id='loadingFeedback'>\n<\/div>\n<div id='saved_report_list_contents'>\n<\/div>";
    SUGAR.mobile.dashlets["saved-reports-list"]["controller"] = 
({
    plugins                 : ["Dashlet"],
    reportData              : undefined,
    chartField              : undefined,
    reportOptions           : undefined,
    reportsData             : undefined,
    timerId                 : undefined,
    rowsNumber              : undefined,
    displayTotal            : undefined,
    showDrilldownButton     : undefined,
    currentRowsShown        : 0,
    loadOptions             : false,
    reportType              : undefined,
    isSummary               : false,
    selectedReportIsSummary : false,
    dataLoaded              : false,
    defDisplayColumns       : {},
    SORT_SEPARATOR          : "::",
    /**
     * False if no sort is applied on the list | the object with definition of the sort
     * Ex: {
     *        name:      "first_name",
     *        table_key: "self",
     *        sort_dir:  "a"
     *    }
     */
    sort                    : false,
    /**
     * List of sort configurations
     * Ex: {
     *      "first_name:self:a": {
     *          name:      "first_name",
     *          label:     "First name",
     *          table_key: "self",
     *          sort_dir:  "a",
     *      },
     *  }
     */
    availableSort           : {},

    events: {
        "click a[name=editReport]"                     : "editSavedReport",
        "click #drill_button"                          : "drillAction",
        "click [data-fieldname=\"intelligent\"] input" : "setIntelligence",
        "click th[data-fieldname][data-orderby]"       : "sortList",
    },

    extendsFrom: {
        baseType: "base-chart"
    },

    drillAction: function () {
        window.open("#bwc/index.php?module=Reports&action=DetailView&record=" + this.options.meta.view.saved_report_id);
    },

    _scheduleReload: function (delay) {
        this.timerId = setTimeout(
            _.bind(function refreshTimer() {
                this.context.resetLoadFlag();
                this.loadData({
                    complete: function reloadData() {
                        this._scheduleReload(delay);
                    }.bind(this)
                });
            }, this),
            delay
        );
    },

    initialize: function (options) {
        this.reportData = new Backbone.Model();
        return this._super("initialize", arguments);
    },

    loadData: function (options) {
        options = options || {};

        if (this.options.meta.view.saved_report_id) {
            this.getSavedReportById(this.options.meta.view.saved_report_id, options);
            this.displayTotal = this.options.meta.view.show_total_count;
            this.rowsNumber = this.options.meta.view.display_rows;
        }
    },

    showLoadingFeedback: function () {
        if (!this.dataLoaded) {
            var newElDiv = this.$el.find("#loadingFeedback");
            newElDiv.append(
                "<i name=\"placeHolderLoading\" class=\"fa fa-spinner fa-spin fa-3x fa-fw margin-top\" style=\"width: 35px;height: 35px;margin-top:0.5%;margin-left: 48%;\"></i>"
            );
        }
    },

    hideLoadingFeedback: function () {
        this.$el.find("[name=placeHolderLoading]").remove();
    },

    getSavedReportById: function (reportId, options) {
        this.dataLoaded = false;
        this.showLoadingFeedback();

        this.loadOptions = options;

        var parentModel = this.context.get("parentModel");
        var forceRefresh = options.complete ? true : false;

        var reqData = {
            reportId            : reportId,
            forceRefresh        : forceRefresh,
            usePaging           : this.rowsNumber != 0,
            linkToCurrentRecord : this.options.meta.view.intelligent
        };

        if (this.options.meta.view.sort) {
            if (this.sort == false || (this.sort != false && !this.sort.forceSort)) {
                var sortConfiguration = this.options.meta.view.sort;
                sortConfiguration = this.options.meta.view.sort.split(this.SORT_SEPARATOR);
                // eslint-disable-next-line
                if (sortConfiguration.length === 3) {
                    this.sort = {
                        name      : sortConfiguration[0],
                        table_key: sortConfiguration[1], //eslint-disable-line
                        sort_dir: sortConfiguration[2] //eslint-disable-line
                    };
                } else {
                    //backward versions compatibility (fixes problem with tables different than self)
                    window.console.log("wrong sort configuration set");
                    this.sort = false;
                }
            }
        }
        if (this.sort != false) {
            reqData = _.extend(reqData, {
                sort: this.sort
            });
            reqData.forceRefresh = true;
        }

        if (parentModel instanceof App.Bean && _.isEmpty(this.context.get("parentId") === false)) {
            reqData["linkField"] = this.options.meta.view.linked_fields;
            reqData["link"] = parentModel.get("_module").toLowerCase();
            reqData["module"] = parentModel.get("_module");
            reqData["contextId"] = parentModel.get("id");
            reqData["contextName"] = parentModel.get("name") || parentModel.get("full_name");
        }

        if (
            _.isUndefined(this.currentRowsShown) === false
            && this.loadOptions["append"] === true
        ) {
            reqData["reportOffset"] = this.currentRowsShown;
        }

        var apiUrl = app.api.buildURL("wReportsDashlet", "list/results");

        app.api.call("create", apiUrl, {
            contextData: reqData
        }, null, {
            success: _.bind(function getAllReportsList(serverData, options) {
                if (_.isEmpty(serverData) === true) {
                    this.hideLoadingFeedback();

                    return;
                }

                if (_.isUndefined(serverData.status) === false && serverData.status === "failed") {
                    App.alert.show("saved-report-error", {
                        level     : "error",
                        messages  : app.lang.getAppString(serverData.message) + serverData.reportId,
                        autoClose : false
                    });

                    this.hideLoadingFeedback();

                    return;
                }

                this.createDashletView(serverData, options);
            }, this),
            complete: options ? options.complete : null
        });
    },

    createBaseDashlet: function (serverData, options) { },

    createMatrixDashlet: function (matrixHtml) {
        var reportMatrixCss =
            "<style>.reportlistView {\
            border-top: 1px solid #000;\
            border-left: 1px solid #000;\
        }\
        table.reportlistView td, table.reportlistView th {\
            background: #fff;\
            border-bottom: 1px solid #000;\
            border-right: 1px solid #000;\
            color: #000;\
            padding: 4px;\
            text-align: center;\
            font-size: 11px;\
        }\
            table.reportlistView th, .reportlistView .reportlistViewMatrixRightEmptyData, .reportlistView .reportlistViewMatrixRightEmptyData1 {\
            background: #dcdcdc;\
            font-weight: bold;\
        }\
            </style>\
        ";

        if ($("body").hasClass("theme-dark") === true) {
            reportMatrixCss = "<style>.reportlistView {\
                border-top: 1px solid;\
                border-left: 1px solid;\
            }\
            table.reportlistView td, table.reportlistView th {\
                border-bottom: 1px solid;\
                border-right: 1px solid;\
                padding: 4px;\
                text-align: center;\
                font-size: 11px;\
            }\
                table.reportlistView th, .reportlistView .reportlistViewMatrixRightEmptyData, .reportlistView .reportlistViewMatrixRightEmptyData1 {\
                font-weight: bold;\
            }\
            table.reportlistView td {\
                background: #575757;\
            }\
                </style>\
            ";
        }

        this.$el.find("#saved_report_list_contents").html(reportMatrixCss + matrixHtml);
    },

    createDashletView: function (serverData, options) {
        this.dataLoaded = true;
        this.hideLoadingFeedback();

        if (_.isEmpty(serverData)) {
            return;
        }

        if (serverData.matrixHtml) {
            this.createMatrixDashlet(serverData.matrixHtml);
        } else if (serverData.collection && serverData.collection.length === 0) {
            this.$el.find("#saved_report_list_contents").empty();
            this.$el.find("#saved_report_list_contents").append("<div style='text-align:center'>" + app.lang.getAppString("LBL_NO_DATA_AVAILABLE") + "</div>");
        } else {
            this.createBaseDashlet(serverData, options);
            this.reportType = serverData["report_type"];
            this.isSummary = this.reportType == "summary" ? true : false;

            var titlesAreBroken = false;

            for (var headerSetIndex = serverData.headerTitles.length - 1; headerSetIndex >= 0; headerSetIndex--) {
                var headerSet = serverData.headerTitles[headerSetIndex];

                /*eslint-disable*/
                for (var headerDataIndex = 0; headerDataIndex < headerSet.length; headerDataIndex++) {
                    if (serverData.headerTitles[headerSetIndex + 1]) {
                        var hTitle = headerSet[headerDataIndex];
                        var exTitle = serverData.headerTitles[headerSetIndex + 1][headerDataIndex];
                        var majorExTitle = serverData.headerTitles[headerSetIndex + 1][0];
                        var majorTitle = serverData.headerTitles[headerSetIndex][0];
                        // eslint-disable-next-line
                        if (
                            majorTitle.indexOf("Count") > -1 &&
                            majorTitle.substr(0, majorTitle.lastIndexOf(" ")) ===
                            majorExTitle.substr(0, majorExTitle.lastIndexOf(" "))
                        ) {
                            var exCount = exTitle.substr(exTitle.lastIndexOf(" ") + 1, exTitle.length);
                            var currentCount = hTitle.substr(hTitle.lastIndexOf(" ") + 1, hTitle.length);
                            var totalCount = parseInt(exCount) + parseInt(currentCount);

                            serverData.headerTitles[headerSetIndex][headerDataIndex] =
                                hTitle.substr(0, hTitle.lastIndexOf(" ") + 1) + totalCount;

                            // eslint-disable-next-line max-depth
                            if (headerDataIndex === headerSet.length - 1) {
                                serverData.headerTitles.splice(headerSetIndex + 1, 1);
                                titlesAreBroken = true;
                            }
                        }
                    }
                }
            }
            /*eslint-enable*/

            if (titlesAreBroken) {
                var collectionIterator = 0;

                _.each(serverData.collection, function correctHeader(headerData, date) {
                    headerData.header = serverData.headerTitles[collectionIterator][0] || "";
                    collectionIterator = collectionIterator + 1;
                });
            }

            var collectionData = serverData;

            if (!this.isSummary || (this.isSummary && serverData.isSummationWithDetails)) {
                collectionData = this.getCollectionData(serverData);
            }

            var parentElement = this.$el.parent().parent();
            var title = parentElement.find(".dashlet-title")[0];

            if (title && this.displayTotal) {

                var collectionLength = _.isEmpty(collectionData.reportData.totalCount) ? collectionData.collection.length : collectionData.reportData.totalCount;

                if (this.isSummary === true) {
                    collectionLength = serverData.totalRecordsCount;
                }

                var initialTitle = this.options.meta.view.label;
                title.innerHTML = initialTitle + ": " + collectionLength + app.lang.getAppString("LBL_WRD_RECORDS");
            }

            // branching functionality as we want different things for when the report is summary
            if (collectionData.collection.length > 0 && this.isSummary != true) {
                this.formatRowsAndColumnsResults(collectionData);
            } else {
                this.formatSummaryResults(collectionData);
            }

            this._render();

            if (this.isSummary) {
                this.buildSummaryView();
            } else {
                this.buildRowsAndColumnsView(collectionData);
            }

            this.fixBwcLinks();
        }

        this.fixHeaderTitle();
    },

    buildRowsAndColumnsView: function (collectionData) {
        var rowColumnView = app.view.createView({
            name          : app.mobile.views.MobileSavedreportlistrowscolumnsView,
            model         : this.model,
            context       : this.context,
            dashletParent : this
        });

        rowColumnView.render();

        this.$el.find("#saved_report_list_contents").append(rowColumnView.$el);

        if (this.rowsNumber && this.rowsNumber != 0) { 
            var collectionLength = _.isEmpty(collectionData.reportData.totalCount) ? collectionData.collection.length : collectionData.reportData.totalCount;

            if (this.currentRowsShown >= collectionLength) {
                this.$el
                    .parent()
                    .parent()
                    .find("[data-action=\"show-more\"]")
                    .parent()
                    .parent()
                    .hide();
            } else {
                if (
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]").length === 0
                ) {
                    this.$el.addClass("list-view");
                    this.$el.append(
                        "<div><div class=\"block-footer\"><button data-action=\"show-more\" class=\"btn btn-link btn-invisible more padded\">" + app.lang.getAppString("LBL_MOBILE_SHOW_MORE") + "</button></div></div>"
                    );
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]")
                        .click(this.showMoreRecords.bind(this));
                } else {
                    // display the "Show more..." button
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]")
                        .parent()
                        .parent()
                        .show();
                }
            }
        }
    },

    buildSummaryView: function () {
        var reportData = this.serverResults;

        if (reportData.isSummationWithDetails) {
            /*eslint-disable*/
            // creating the headers
            if (!_.isEmpty(reportData.collection)) {
                for (var col in reportData.collection) {
                    if (col !== "header") {
                        var groupView = app.view.createView({
                            name: app.mobile.views.MobileSavedreportlistsummaryheaderView,
                            model: this.model,
                            context: this.context,
                            collection: reportData.collection[col],
                            headerIndex: 1,
                            showSummary: reportData.showSummary,
                            title: reportData.collection[col]["header"],
                            dashletParent: this
                        });

                        groupView.render();
                        this.$el.find("#saved_report_list_contents").append(groupView.$el);
                    }
                }
            }/*eslint-enable*/
        } else {
            var headerRow = app.view.createView({
                name          : app.mobile.views.MobileSavedreportlistsummaryrowView,
                model         : this.model,
                context       : this.context,
                collection    : reportData.collection,
                dashletParent : this
            });

            headerRow.render();
            this.$el.find("#saved_report_list_contents").append(headerRow.$el);
        }

        // showing the grandTotal if the user wants so
        if (!_.isEmpty(reportData.grandTotal) && reportData.displayTotal === true) {
            var subTables = this.$el.find("#saved_report_list_contents").children();
            var tableParent = subTables[subTables.length - 1];
            var subTableElement = tableParent.children[0];
            var tableId = subTableElement ? subTableElement.id : "id";
            var tableElement = $("#" + tableId);
            //replaced this.$el.find with general due to querySelector method uses CSS3 selectors for querying the DOM 
            //and CSS3 doesn't support ID selectors that start with a digit

            this.minTableWidth = tableElement.css("width");

            var grandTotalView = app.view.createView({
                name           : app.mobile.views.MobileSavedreportlistgrandtotalView,
                model          : this.model,
                context        : this.context,
                grandTotalData : reportData.grandTotal,
                minTableWidth  : this.minTableWidth,
                dashletParent  : this
            });

            grandTotalView.render();
            this.$el.find("#saved_report_list_contents").append(grandTotalView.$el);
        }
    },

    formatSummaryResults: function (collectionData) {
        var reportData = _.clone(collectionData);
        var serverCollection = reportData.collection;

        if (!reportData.isSummationWithDetails) {
            //if the report is a simple summary report then we must format the data received from the API
            var headers = reportData.headerTitles[0] ? reportData.headerTitles[0] : [];
            reportData.fields = [];

            for (var headerIndex = 0; headerIndex < headers.length; headerIndex++) {
                reportData.fields.push({
                    label: headers[headerIndex]
                });
            }

            // var formattedCollection         = [];
            // formattedCollection[0]          = [];
            // formattedCollection             = this.formatSimpleSummaryReportData(server_collection, formattedCollection, 0, []).formattedCollection;
            serverCollection["wIsData"] = true;
            // server_collection               = formattedCollection;
        }

        this.serverResults = {
            isSummationWithDetails : reportData.isSummationWithDetails,
            fields                 : reportData.fields,
            collection             : serverCollection,
            grandTotal             : reportData.grandTotal,
            total                  : reportData.total,
            headers                : reportData.headers,
            headerTitles           : reportData.headerTitles,
            keyPrefix              : reportData.reportData.module.toLowerCase(),
            displayTotal           : this.displayTotal,
            showSummary            : this.showSummary
        };
    },

    formatRowsAndColumnsResults: function (collectionData) {
        var serverCollection = [],
                i;

        //only show columns from Display Columns, in the order they are there
        var displayColumns = this.options.meta.view.display_columns;

        _.each(displayColumns, function checkValidColumn(columnName, columnKey) {
            if (columnName.indexOf(this.SORT_SEPARATOR) < 0) {
                var defColumnData = _.filter(this.defDisplayColumns, function getColumnData(columnData) {
                    return columnData.name === columnName;
                })[0];

                if (defColumnData) {
                    displayColumns[columnKey] = defColumnData.table_key + this.SORT_SEPARATOR + columnName;
                }
            }
        }.bind(this));

        if (displayColumns) {
            var columnsMask = []; //holds index in Display Columns and index in collection.fields
            var collectionFieldNames = [];
            _.each(collectionData.fields, function iterateOverFieldsFromDb(field, idx) {
                collectionFieldNames[idx] = field.table_key + this.SORT_SEPARATOR + field.name;
            }.bind(this));
            for (i = 0; i < displayColumns.length; i++) {
                columnsMask[i] = collectionFieldNames.indexOf(displayColumns[i]);
            }

            var collectionFields = [];
            for (i = 0; i < columnsMask.length; i++) {
                var indexOfDisplayFieldInCollection = columnsMask[i];
                collectionFields.push(collectionData.fields[indexOfDisplayFieldInCollection]);
            }
            collectionData.fields = collectionFields;

            for (i = 0; i < collectionData.collection.length; i++) {
                var newCells = [],
                        newRows = [];
                var cellsInARow = collectionData.collection[i].cells;
                var rowsInARow = collectionData.collection[i].rows;
                for (var columnIdx = 0; columnIdx < columnsMask.length; columnIdx++) {
                    var indexOfDisplayFieldInRow = columnsMask[columnIdx];
                    newCells.push(cellsInARow[indexOfDisplayFieldInRow]);
                    newRows.push(rowsInARow[indexOfDisplayFieldInRow]);
                }

                collectionData.collection[i].cells = newCells;
                collectionData.collection[i].rows = newRows;
            }
        }

        // limiting the data we show
        if (this.rowsNumber && this.rowsNumber != 0) {
            if (this.loadOptions && this.loadOptions["append"]) {
                this.currentRowsShown += parseInt(this.rowsNumber);
            } else {
                this.currentRowsShown = parseInt(this.rowsNumber);
            }
            serverCollection = collectionData.collection.slice(0, this.currentRowsShown);
        } else {
            serverCollection = collectionData.collection;
        }

        this.serverResults = {
            fields     : collectionData.fields,
            collection : serverCollection
        };
    },

    getCollectionData: function (serverData) {
        // building the collection rows with the data received from the report
        for (var j = 0; j < serverData.collection.length; j++) {
            var rows = [];

            for (var z = 0; z < serverData.collection[j].cells.length; z++) {
                var row = {};

                if (serverData.collection[j].cells[z].indexOf("<a") > -1) {
                    var newText = $(serverData.collection[j].cells[z]).text();
                    row.text = newText;
                } else {
                    row.text = serverData.collection[j].cells[z];
                }

                row.html = serverData.collection[j].cells[z];
                rows.push(row);
            }
            serverData.collection[j].rows = rows;
        }

        return serverData;
    },

    _render: function () {
        this._super("_render", arguments);

        this.$el.css("overflow-x", "auto");
        this.fixBwcLinks();

        this.showLoadingFeedback();
    },

    showMoreRecords: function () {
        var options = {
            append: true
        };

        this.getSavedReportById(this.options.meta.view.saved_report_id, options);
    },

    fixBwcLinks: function () {
        this.$el.find("a[href*=\"module=\"]").each(function goThroughElements(i, elem) {
            // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
        });
    },

    fixHeaderTitle: function () {
        if ($("body").hasClass("theme-dark") === true) {
            this.$el.parents(".dashboard").find(".dashlets__title").css("background", "#2b2d2e");
        } else {
            this.$el.parents(".dashboard").find(".dashlets__title").css("background", "#fff");
        }
    }
});;   SUGAR.mobile.dashlets["w-saved-reports-chart"] = {
        controller: {},
        meta: {},
        templates: {},
        styles: {},
    };

    SUGAR.mobile.dashlets["w-saved-reports-chart"]["controller"] = ({
    extendsFrom: {
        baseType: "saved-reports-chart",
    },

    getChartModel: function(params, config) {
        var chart = this._super("getChartModel", arguments);

        // temp fix for SUGARCrm bug
        if (!chart.fmtCount) {
            chart.fmtCount = function fmtCount() {
                return {fmtValue: function fmtValue(){
                    return false;
                }};
            };
        }

        return chart;
    },

    loadChartData: function loadChartData(loadChartDataCallback) {
        var reportId = this.meta.view.saved_report_id; //eslint-disable-line camelcase
        var screenContext = app.controller.getScreenContext();
        var parentModel = app.controller.layoutManager.getRootLayout().context.get("parentModel");
        var recordName = parentModel ? (parentModel.get("name") ? parentModel.get("name") : parentModel.get("first_name")) : "Record";

        var dataToSendForChartLoading = {
            groupType         : "simple",
            reportId          : reportId,
            record_id         : screenContext.parentModelId, //eslint-disable-line camelcase
            record_name       : recordName, //eslint-disable-line camelcase
            link              : this.meta.view.link,
            module            : screenContext.parentModule,
            dashletChartType  : this.meta.view.chart_type,
            approximateTotal  : true,
            approximateValues : true,
            hideEmptyGroups   : false
        };

        app.api.call("create", app.api.buildURL("Reports/" + reportId + "/wchart"), dataToSendForChartLoading, {
            success: _.bind(function successRetrieveWChart(data) {
                data.chartData.properties = [{type: this.meta.view.chart_type, "base_module": data.reportDefs.module}];
                data.chartData.values = [];
                data.chartData.label = ["Column"];
                data.reportData = data.reportDefs;

                _.each(data.chartData.data, function restructureData(columnData, key){
                    data.chartData.values[key] = {};
                    data.chartData.values[key].values = [columnData.recordsCount];
                    data.chartData.values[key].label = [columnData.group1_label];
                });
                
                var enumsToFetch = this.getEnums(data.reportDefs);

                if (!_.isEmpty(enumsToFetch) && !this.enums) {
                    this._loadEnumOptions(enumsToFetch, data.reportDefs)
                        .then(enums => {
                            this.enums = enums;
                            loadChartDataCallback(null, data);
                        })
                        .catch(error => {
                            loadChartDataCallback(error);
                        });
                } else {
                    loadChartDataCallback(null, data);
                }
            }, this),
            error: loadChartDataCallback,
        }, {
            skipMetadataHash: true,
        });
    },
});
;
})(SUGAR.App);
/* eslint-disable require-jsdoc */
(function bootLoad(app) {
    class wMobileBootLoader {
        constructor() {
            this.declareProperties();
        }

        declareProperties() {
            this.BASE_FILE_PATH = "src/wsystems/mobile/include/require/wMobileApp/";

            this.VIEW_LOADER = "wMobileViewLoader";
            this.FIELD_LOADER = "wMobileFieldLoader";
            this.DASHLET_LOADER = "wMobileDashletLoader";
            this.ROUTE_HANDLER = "wMobileRouteHandler";

            this.ENTITIES_MAPPING = {
                "views"    : "wMobileViewLoader",
                "fields"   : "wMobileFieldLoader",
                "dashlets" : "wMobileDashletLoader",
            };

            this.customizationTools = app.NomadController.prototype.getCustomizationTools();
        }

        applyExtensions(extensions) {
            const baseExtensions = _.filter(extensions, function getBaseExtensions(extensionData){
                return extensionData.extendsFrom.module === undefined;
            });
            
            const customExtensions = _.filter(extensions, function getBaseExtensions(extensionData){
                return typeof extensionData.extendsFrom.module === "string";
            });

            this.enhanceClasses(baseExtensions);
            this.enhanceClasses(customExtensions);
        }

        enhanceClasses(extensions) {
            _.each(extensions, function handleExtension(extensionData) {
                let _baseType = extensionData.extendsFrom.baseType;

                if (this.isBaseField(_baseType)) {
                    this.wMobileFieldLoader.extend(_baseType, extensionData);
                } else if (this.isBaseDashlet(_baseType)) {
                    this.wMobileDashletLoader.extend(_baseType, extensionData);
                } else if (this.isBaseView(_baseType)) {
                    this.wMobileViewLoader.extend(_baseType, extensionData);
                }
            }, this);
        }

        loadMobileCustomizations() {
            _.each(
                SUGAR.mobile,
                function handleEntity(entities, entityName) {
                    if (this.ENTITIES_MAPPING[entityName]) {
                        this[this.ENTITIES_MAPPING[entityName]].load(entities);
                    }
                },
                this
            );

            // reload main menu after all of our customizations have been loaded
            if (app.nomad.mainMenu) {
                app.nomad.mainMenu.dispose();
            }
            
            delete app.nomad.mainMenu;
            app.nomad._syncedAppStart();

            // trigger an event, notifying all the listeners that we have completely loaded the customizations
            app.controller.trigger("wmobile:customizations:loaded");
        }

        loadFloatingButtons() {
            let _widgets = SUGAR.mobile.widgets;
            let _buttonsTemplates = _widgets.mobileButtonsManager.templates;

            let _mobileButtonsManager = new _widgets.mobileButtonsManager.controller(
                _buttonsTemplates.mobileButtonsContainer,
                _buttonsTemplates.mobileMasterButton
            );

            SUGAR.customizationTools.mobileButtonsManager = _mobileButtonsManager;
        }

        loadManagers() {
            this.loadRequired(this.ROUTE_HANDLER);
            this.loadRequired(this.VIEW_LOADER);
            this.loadRequired(this.FIELD_LOADER);
            this.loadRequired(this.DASHLET_LOADER);
        }

        loadRequired(className) {
            let _requiredClass = window.require(this.BASE_FILE_PATH + className)[className];
            this[className] = new _requiredClass(this);
        }

        declareGlobals() {
            SUGAR.customizationTools = this.customizationTools;
            SUGAR.customizationTools.wMobileBootLoader = this;

            SUGAR.mobile.getView = function getView(viewName) {
                return SUGAR.customizationTools.sdkViews[viewName];
            };

            SUGAR.mobile.getField = function getField(fieldName) {
                return SUGAR.customizationTools.sdkFields[fieldName];
            };

            SUGAR.mobile.getDashlet = function getDashlet(dashletName) {
                return SUGAR.customizationTools.sdkDashlets[dashletName];
            };
        }

        hideLoadingScreen() {
            const _hideTimer = 3000;

            setTimeout(function hideLoadingScreen() {
                SUGAR.customizationTools.mobileButtonsManager.hideLoadingScreen();
            }, _hideTimer);
        }

        isBaseView(viewName) {
            return app.nomad.getViewClass({
                baseType: viewName
            });
        }

        isBaseField(fieldName) {
            return app.nomad.getFieldClass({
                baseType: fieldName
            });
        }

        isBaseDashlet(dashletName) {
            return SUGAR.mobile.getDashlet(dashletName);
        }
    }

    let _bootLoader = new wMobileBootLoader();

    _bootLoader.declareGlobals();
    _bootLoader.loadFloatingButtons();
    _bootLoader.hideLoadingScreen();
})(SUGAR.App);
(function(modules) {
    let _modules = new Map();
    let _requireSpecific = function(modData) {
        let _module = {};
        _module.exports = {};

        modData.functionName(_module, _require);

        _modules.set(_module.name, _module.exports);
    };

    let _require = window.require = function(name) {
        var moduleData = _modules.get(name);

        if (!moduleData) {
            for (const module of modules) {
                if (module.requireName === name) {
                    _requireSpecific(module);
		    moduleData = _modules.get(name);
                }
            }
        }

        return moduleData;
    }

    for (const module of modules) {
        _requireSpecific(module);
    }
})(
[{'requireName': 'src/wsystems/mobile/widgets/mobileButtonsManager/mobileButtonsManager', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/widgets/mobileButtonsManager/mobileButtonsManager';
/*eslint-disable*/
class MobileButtonsManager {
    constructor(containerHtml, masterButtonHtml) {
        this.masterButtons = {};
        this.masterButtonsConfig = {};

        this.createContainer(containerHtml);
        this.initialize();
    }

    initialize() {
        app.on("app:orientation:changed", this.handleDeviceOrientationChanged.bind(this));
        if (!app.controller.navigationExtended) {
            app.controller.navigationExtended = true;
            var navFunction = app.controller.navigate;
            var buttonsManager = this;

            app.controller.navigate = function (url, options) {
                navFunction.call(app.controller, url, options);

                buttonsManager.handleViewChange();
            };
        }

        document.getElementById("nomad").appendChild(document.getElementById("customizationsLoadingScreen"));
    }

    createContainer(containerHtml) {
        $("#nomad").append(containerHtml);
        this.container = $("#mobileButtonsContainer");
        this.mobileButtonsOverlay = $("#mobileButtonsOverlay");
        this.mobileButtonsLoadingScreen = $("#customizationsLoadingScreen");
        this.loadingScreenLabel = $("#customizationsLoadingScreenLabel");
        this.mobileButtonsOverlay.on("click", this.closeMasterButtons.bind(this));
        this.mobileButtonsOverlay.on("touchmove", this.closeMasterButtons.bind(this));

        this.initContainerPosition();
    }

    getInitialContainerPosition() {
        var containerSize = 100;
        var containerXPos = window.innerWidth - containerSize;
        var containerYPos = window.innerHeight - containerSize;

        var initialContainerPosition = "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)";

        return initialContainerPosition;
    }

    initContainerPosition() {
        this.container.css("transform", this.getInitialContainerPosition());
    }

    closeMasterButtons() {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                masterButton.closeWidget();
            }.bind(this)
        );
        this.hideOverlay();
    }

    hideOverlay() {
        this.mobileButtonsOverlay.hide();
    }

    dragStart(e) {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                if (e.target === masterButton.dragItemLabel || e.target.id === masterButton.dragItemIcon.id) {
                    this.active = true;
                }
            }.bind(this)
        );
    }

    dragEnd(e) {
        var transitionActivated = false;

        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                var container = masterButton.manager.container;
                var containerPosition = container.position();
                var masterButtonPosition = masterButton.masterButtonLabel.position();
                if (
                    !transitionActivated &&
                    container &&
                    this.active &&
                    (containerPosition.left + masterButtonPosition.left < 0 ||
                        containerPosition.left + masterButtonPosition.left + masterButton.masterButtonLabel.width() >
                        window.innerWidth ||
                        containerPosition.top + masterButtonPosition.top < 0 ||
                        containerPosition.top + masterButtonPosition.top + masterButton.masterButtonLabel.height() >
                        window.innerHeight)
                ) {
                    transitionActivated = true;
                    var transitionSpeed = 100;
                    var containerSize = 100;
                    var wiggleWidth = 20;
                    var containerXPos = window.innerWidth - containerSize;
                    var containerYPos = window.innerHeight - containerSize;

                    container.animate({
                            transform: "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)"
                        },
                        transitionSpeed,
                        function wiggle() {
                            container.animate({
                                    transform: "translate3d(" +
                                        (containerXPos - wiggleWidth) +
                                        "px, " +
                                        containerYPos +
                                        "px, 0px)"
                                },
                                transitionSpeed,
                                function wiggleBack() {
                                    container.animate({
                                            transform: "translate3d(" + containerXPos + "px, " + containerYPos + "px, 0px)"
                                        },
                                        transitionSpeed
                                    );
                                }
                            );
                        }
                    );
                }
            }.bind(this)
        );

        this.active = false;
    }

    drag(e) {
        if (this.active) {
            e.preventDefault();
            var currentX = 0;
            var currentY = 0;

            if (e.type === "touchmove") {
                currentX = e.touches[0].clientX;
                currentY = e.touches[0].clientY;
            } else {
                currentX = e.clientX;
                currentY = e.clientY;
            }

            _.each(
                this.masterButtons,
                function goThroughMasterButtons(masterButton) {
                    if (masterButton.masterButton.attr("checked")) {
                        masterButton.masterButton.prop("checked", false);
                        masterButton.notifyButtons(false);
                    }
                }.bind(this)
            );

            this.setTranslate(currentX, currentY);
        }
    }

    setTranslate(xPos, yPos) {
        var buttonRadius = 50;

        xPos = xPos - buttonRadius;
        yPos = yPos - buttonRadius;
        this.container.css("transform", "translate3d(" + xPos + "px, " + yPos + "px, 0)");
    }

    setEnabledHorizontalButtonsData(data) {
        return this.masterButtons.mainButton.setEnabledHorizontalButtonsData(data);
    }

    getEnabledHorizontalButtonsData() {
        return this.masterButtons.mainButton.getEnabledHorizontalButtonsData();
    }

    enableHorizontalButtons() {
        return this.masterButtons.mainButton.enableHorizontalButtons();
    }

    disableHorizontalButtons() {
        return this.masterButtons.mainButton.disableHorizontalButtons();
    }

    registerMobileButtons(newButtons) {
        _.each(
            newButtons,
            function registerButtons(buttonConfig) {
                this.masterButtonsConfig[app.utils.generateUUID()] = buttonConfig;
            },
            this
        );
    }

    createMasterButtons() {
        if (Object.keys(this.masterButtonsConfig).length > 0) {
            $("#mobileButtonsContainer").show();
            this.initContainerPosition();
            var mainButtonId = "mainButton";
            var mainButtonConfig = {
                isMainButton: true,
                masterButton: true,
                name: "d",
                label: "Forth Button",
                icon: "fab fa-wikipedia-w",
                color: "white",
                backgroundColor: "rgb(0,66,121)",
                children: this.masterButtonsConfig
            };

            this.createMasterButton(mainButtonConfig, mainButtonId, true);
            this.wrapperContainer = document.querySelector("#nomad");

            this.wrapperContainer.addEventListener("touchstart", this.dragStart.bind(this), false);
            this.wrapperContainer.addEventListener("touchend", this.dragEnd.bind(this), false);
            this.wrapperContainer.addEventListener("touchmove", this.drag.bind(this), false);

            this.wrapperContainer.addEventListener("mousedown", this.dragStart.bind(this), false);
            this.wrapperContainer.addEventListener("mouseup", this.dragEnd.bind(this), false);
            this.wrapperContainer.addEventListener("mousemove", this.drag.bind(this), false);
        } else {
            $("#mobileButtonsContainer").hide();
        }
    }

    createMasterButton(masterButtonConfig, buttonId, mainButton) {
        this.masterButtons[buttonId] = new SUGAR.mobile.widgets.mobileMasterButton.controller(
            masterButtonConfig,
            buttonId,
            this
        );

        return this.masterButtons[buttonId];
    }

    goToMainWidget() {
        _.each(
            this.masterButtons,
            function goThroughMasterButtons(masterButton) {
                masterButton.hideWidget();
            }.bind(this)
        );

        if (this.masterButtons.mainButton) {
            this.masterButtons.mainButton.showWidget();
            this.masterButtons.mainButton.closeWidget();
        }
    }

    destroyExistingButtons() {
        this.container.empty();
        this.masterButtonsConfig = {};
        _.each(this.masterButtons, function destroyMasterButton(masterButton) {
            masterButton.destroy();
        });
        delete this.masterButtons;
        this.masterButtons = {};
    }

    cleanButtons() {
        var duplicatedIds = [];
        _.each(
            this.buttonsConfig,
            function getDuplicatedButtons(buttonConfig, buttonId) {
                _.each(
                    this.buttonsConfig,
                    function checkDuplicatedButtons(dupeButtonConfig, dupeButtonId) {
                        if (
                            dupeButtonConfig.name == buttonConfig.name &&
                            dupeButtonConfig.icon == buttonConfig.icon &&
                            dupeButtonConfig.color == buttonConfig.color &&
                            dupeButtonConfig.backgroundColor == buttonConfig.backgroundColor &&
                            dupeButtonConfig.label == buttonConfig.label &&
                            buttonId !== dupeButtonId &&
                            duplicatedIds.indexOf(dupeButtonId) < 0 &&
                            duplicatedIds.indexOf(buttonId) < 0
                        ) {
                            duplicatedIds.push(dupeButtonId);
                        }
                    },
                    this
                );
            },
            this
        );

        for (var idIndex = 0; idIndex < duplicatedIds.length; idIndex++) {
            delete this.buttonsConfig[duplicatedIds[idIndex]];
        }
    }

    hideLoadingScreen(hideTimer) {
        if (hideTimer) {
            setTimeout(
                function hideLoadingScreenWidget() {
                    this.mobileButtonsLoadingScreen.css("display", "none");

                    if (app.rebrandingManager) {
                        app.rebrandingManager.handleLoadingScreen(false);
                    }
                }.bind(this),
                hideTimer
            );
        } else {
            this.mobileButtonsLoadingScreen.css("display", "none");

            if (app.rebrandingManager) {
                app.rebrandingManager.handleLoadingScreen(false);
            }
        }
    }

    handleLoadingScreen(loadingScreenSettings) {
        var loadingScreenMessage = loadingScreenSettings.message ? loadingScreenSettings.message : "Loading ...";
        this.loadingScreenLabel.text(loadingScreenMessage);

        var loadingScreenOpacity = loadingScreenSettings.opacity ? loadingScreenSettings.opacity : 0.85;
        this.mobileButtonsLoadingScreen.css("opacity", loadingScreenOpacity);

        this.showLoadingScreen();

        if (loadingScreenSettings.autoHide) {
            setTimeout(
                function hideLoadingScreenWidget() {
                    this.hideLoadingScreen();
                }.bind(this),
                loadingScreenSettings.hideTimer
            );
        }
    }

    showLoadingScreen() {
        if (app.rebrandingManager) {
            app.rebrandingManager.handleLoadingScreen(true);
        }
        this.mobileButtonsLoadingScreen.css("display", "flex");
    }

    handleDeviceOrientationChanged() {
        this.initContainerPosition();
    }

    handleViewChange() {
        this.destroyExistingButtons();
        app.controller.trigger("mobile-context-changed", this);
        this.cleanButtons();
        this.createMasterButtons();

        if (app.rebrandingManager) {
            app.rebrandingManager.handleViewChange(App.controller.getScreenContext());
        }
    }
}
    }
},
{'requireName': 'src/wsystems/mobile/widgets/mobileButton/mobileButton', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/widgets/mobileButton/mobileButton';
/*eslint-disable*/
class MobileButton {
    constructor(config, container, buttonId, buttonsNumber) {
        this.checked = config.checked;
        this.config = config;
        this.container = container;
        this.buttonId = buttonId;
        this.buttonKey = "mobileButton" + this.config.name + buttonsNumber;
        this.buttonNumber = buttonsNumber;

        if (this.config.horizontalButton) {
            this.buttonKey = this.buttonKey + "horizontal";
        }

        this.createButtonHtml();
        this.createButton();
    }

    createButtonHtml() {
        var iconHTML = `<i class="${this.config.icon}" style="font-size:20px;flex-shrink:0"></i>`;

        if (this.config.encodedIcon) {
            iconHTML = `<img src="${this.config.encodedIcon}">`;
        }

        var labelColor = this.config.labelColor ? this.config.labelColor : "#f5f5f5";

        var labelCss = `
        <div style="color: ${labelColor};position: absolute;top: 12px;left: -1247px;background-color: ${
            this.config.backgroundColor
        };border-radius: 20px;padding: 3px 8px;" class="mobileButtonInfoLabel${this.buttonKey}">
            ${this.config.label}
        </div>`;

        if (this.config.horizontalButton) {
            labelCss = `
            <div style="color: #f5f5f5;" class="mobileButtonInfoLabel${this.buttonKey}">
                ${this.config.label}
            </div>`;
        }

        this.buttonHtml =
            `
            <style>
            .masterButtonInput${this.config.manager.id}:checked ~ .${this.buttonKey} {
              background-color: ${this.config.backgroundColor};
              color: ${this.config.color};
              opacity: 1;
            }
            </style>
                <div class="mobileButton ${this.buttonKey}" id="${this.buttonId}" style="font-weight:900;z-index:-${
                this.buttonNumber
            };display:flex;justify-content:center;align-items:center;">
            ` +
            iconHTML +
            labelCss +
            `
        </div>
            `;
    }

    createButton() {
        this.container.append(this.buttonHtml);

        this.mobileButtonInfoLabel = $(".mobileButtonInfoLabel" + this.buttonKey);
        this.mobileButton = $("#" + this.buttonId);

        this.mobileButton.on("click", this.action.bind(this));
    }

    action() {
        try {
            if (this.masterWidgetCreated) {
                this.config.manager.hideWidget();
                this.config.masterButton.showWidget();
            } else if (this.config.callback && this.config.manager.masterButton.attr("checked")) {
                if (this.config.loadingScreenSettings) {
                    this.config.manager.showLoadingScreen(this.config.loadingScreenSettings);
                }
                if (this.config.horizontalButton) {
                    this.checked = !this.checked;
                    var opacity = this.checked ? 1 : 0.5;

                    this.mobileButton.css("opacity", opacity);
                } else {
                    this.config.manager.currentButtonConfig = this.config;
                }

                this.config.callback(this.config.manager);
                if (!this.config.horizontalButton) {
                    if (this.config.majorButton) {
                        this.masterWidgetCreated = true;
                    } else {
                        this.config.manager.goToMainWidget();
                    }
                }
            }
        } catch (err) {
            var buttonsManager = SUGAR.customizationTools.mobileButtonsManager;
            buttonsManager.goToMainWidget();
            buttonsManager.hideLoadingScreen();

            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: err.message,
                autoClose: true
            });
        }
    }

    show() {
        this.mobileButtonInfoLabel.show();
        this.masterButtonPressed(true);
    }

    hide() {
        this.mobileButtonInfoLabel.hide();
    }

    masterButtonPressed(checked) {
        if (checked) {
            this.animateButton();
        } else {
            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(0em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-0em)`);
            }
        }

        var transitionSpeed = 500;
        var timeoutTreshold = 200;
        var targetOpacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
        var elementTarget = this.config.horizontalButton ? this.mobileButton : this.mobileButtonInfoLabel;

        elementTarget.css("opacity", "0");

        if (checked && this.canShow()) {
            elementTarget.animate({
                    opacity: targetOpacity
                },
                transitionSpeed
            );
        }

        if (!this.config.horizontalButton) {
            elementTarget.css("left", "-9999px");
            setTimeout(
                function positionLabels() {
                    var distanceFromIcon = 5;
                    var currentWidth = distanceFromIcon + elementTarget.width();
                    elementTarget.css("left", "-" + currentWidth + "px");
                }.bind(this),
                timeoutTreshold
            );
        }
    }

    animateButton() {
        if (this.canShow()) {
            var opacity = this.config.horizontalButton && !this.checked ? 0.5 : 1;
            this.mobileButton.css("opacity", opacity);

            var finalPosition = this.config.manager.getFinalPosition(this);

            if (this.config.horizontalButton) {
                this.mobileButton.css("transform", `translateX(-${finalPosition.transform}em) translateY(-0.65em);`);
            } else {
                this.mobileButton.css("transform", `translateX(-0.65em) translateY(-${finalPosition.transform}em)`);
            }

            this.mobileButton.css("transition-delay", finalPosition.delay + "s");
        } else {
            this.mobileButton.css("opacity", "0");
        }
    }

    canShow() {
        var canShow = true;

        if (this.config.showCondition) {
            canShow = this.config.showCondition();
        }
        this.test = canShow;
        return canShow;
    }

    destroy() {}
}
    }
},
{'requireName': 'src/wsystems/mobile/widgets/mobileMasterButton/mobileMasterButton', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/widgets/mobileMasterButton/mobileMasterButton';
/*eslint-disable*/
class MobileMasterButton {
    constructor(masterButtonConfig, id, manager) {
        this.manager = manager;
        this.id = id;
        this.config = masterButtonConfig;
        this.html = SUGAR.mobile.widgets.mobileMasterButton.templates.mobileMasterButton;

        this.buttons = {};
        this.buttonsConfig = {};
        this.buttonHeight = 3.2;
        this.buttonDelay = 0.0;
        this.initialHeight = 1.5;

        this.createMasterButton();
        this.createNewButtons();
    }

    createMasterButton() {
        this.manager.container.append(this.html);

        $(".masterButtonInputPlaceHolder")
            .addClass("masterButtonInput" + this.id)
            .removeClass("masterButtonInputPlaceHolder");
        $(".masterButtonLabelPlaceHolder")
            .addClass("masterButtonLabel" + this.id)
            .removeClass("masterButtonLabelPlaceHolder");
        $(".masterButtonIconPlaceHolder")
            .addClass("masterButtonIcon" + this.id)
            .removeClass("masterButtonIconPlaceHolder");

        this.masterButton = $(".masterButtonInput" + this.id);
        this.masterButtonLabel = $(".masterButtonLabel" + this.id);
        this.masterButtonIcon = $(".masterButtonIcon" + this.id);

        this.masterButtonIcon.addClass(this.config.icon);
        this.masterButtonIcon.css("color", this.config.color);
        this.masterButtonLabel.css("background-color", this.config.backgroundColor);

        if (this.config.isMainButton) {
            this.masterButtonLabel.empty();
            this.masterButtonLabel.append(SUGAR.mobile.widgets.mobileMasterButton.templates.wSystemsLogo);
            this.masterButtonIcon = $(".masterButtonIconLogo");

            if (SUGAR.rebrandedLogo) {
                $(".masterButtonIconLogo").attr("src", SUGAR.rebrandedLogo);

            }

            if (SUGAR.rebrandedLogoSize) {
                $(".masterButtonIconLogo").css("width", SUGAR.rebrandedLogoSize);
            }

            if (SUGAR.rebrandedLogoMarginRight) {
                $(".masterButtonIconLogo").css("margin-right", SUGAR.rebrandedLogoMarginLeft);
            }

            if (SUGAR.rebrandedLogoMarginLeft) {
                $(".masterButtonIconLogo").css("margin-left", SUGAR.rebrandedLogoMarginLeft);
            }

            if (SUGAR.rebrandedLogoBackground) {
                $("#masterButtonLabel").css("background-color", SUGAR.rebrandedLogoBackground);
            }
        }

        var newIconWidth = this.masterButtonIcon.width();
        var newIconHeight = this.masterButtonIcon.height();

        if (newIconHeight === 0) {
            newIconHeight = newIconWidth;
        }

        this.masterButtonIcon.css("margin-left", this.masterButtonLabel.width() / 2 - newIconWidth / 2 + "px");
        this.masterButtonIcon.css("margin-top", this.masterButtonLabel.height() / 2 - newIconHeight / 2 + "px");

        this.masterButtonIcon.on("click", function triggerChange() {
            var nextCheckedValue = !this.masterButton.prop('checked');
            this.masterButton.prop('checked', nextCheckedValue);

            this.showPressedFeedback();
            if (!nextCheckedValue) {
                if (this.config.isMainButton) {
                    this.manager.hideOverlay();
                } else {
                    this.hideWidget();

                    this.config.mainButton.showWidget();
                }
            }

            this.notifyButtons(nextCheckedValue);
        }.bind(this));

        this.dragItem = document.querySelector("#mobileButtonsContainer");
        this.dragItemLabel = document.querySelector("#masterButtonLabel");
        this.dragItemIcon = document.querySelector("#masterButtonIcon");
        this.active = false;
    }

    createNewButtons() {
        _.each(this.config.children, this.createButton, this);
    }

    createButton(buttonConfig, buttonId) {
        var buttonsNumber = 1;
        _.each(this.buttons, function getButtonsNumber(button) {
            if (button.config.horizontalButton === buttonConfig.horizontalButton) {
                buttonsNumber = buttonsNumber + 1;
            }
        });

        var currentButtonConfig = _.clone(buttonConfig);

        if (!isNaN(buttonId)) {
            buttonId = app.utils.generateUUID();
        }

        currentButtonConfig.transform = this.initialHeight + buttonsNumber * this.buttonHeight;
        currentButtonConfig.delay = buttonsNumber * this.buttonDelay;
        currentButtonConfig.manager = this;

        var button = new SUGAR.mobile.widgets.mobileButton.controller(
            currentButtonConfig,
            this.manager.container,
            buttonId,
            buttonsNumber
        );
        this.buttons[buttonId] = button;
    }

    setEnabledHorizontalButtonsData(horizontalButtonsData) {
        if (horizontalButtonsData && horizontalButtonsData.length > 0) {
            _.each(this.buttons, function setNewData(buttonData) {
                if (buttonData.config.data && buttonData.config.data.module) {
                    var buttonStateModified = false;

                    _.each(horizontalButtonsData, function getCorrectModule(moduleData) {
                        if (moduleData.module === buttonData.config.data.module) {
                            buttonData.checked = true;
                            buttonStateModified = true;
                        }
                    });

                    if (!buttonStateModified) {
                        buttonData.checked = false;
                    }
                }
            });
        }
    }

    getEnabledHorizontalButtonsData() {
        var enabledHorizontalButtons = [];

        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton && button.checked) {
                enabledHorizontalButtons.push(button.config.data);
            }
        });

        return enabledHorizontalButtons;
    }

    enableHorizontalButtons() {
        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton) {
                button.checked = true;
            }
        });
    }

    disableHorizontalButtons() {
        _.each(this.buttons, function getButtons(button) {
            if (button.config.horizontalButton && button.checked) {
                button.checked = false;
            }
        });
    }

    createNewMasterButton(buttonConfig) {
        if (this.currentButtonConfig) {
            var currentButtonConfig = _.clone(this.currentButtonConfig);

            currentButtonConfig.children = buttonConfig;
            currentButtonConfig.mainButton = this;

            var masterId = app.utils.generateUUID();
            var newMasterButton = this.manager.createMasterButton(currentButtonConfig, masterId);

            currentButtonConfig.masterButton = newMasterButton;
            this.currentButtonConfig.masterButton = newMasterButton;

            this.hideWidget(true);
            newMasterButton.showWidget();
        }
    }

    getFinalPosition(buttonEntity) {
        var buttonsNumber = 1;
        var buttonFound = false;

        _.each(this.buttons, function getButtonsNumber(button, buttonId) {
            if (buttonId === buttonEntity.buttonId) {
                buttonFound = true;
            } else if (
                !buttonFound &&
                button.config.horizontalButton === buttonEntity.config.horizontalButton &&
                button.canShow()
            ) {
                buttonsNumber = buttonsNumber + 1;
            }
        });

        return {
            transform: this.initialHeight + buttonsNumber * this.buttonHeight,
            delay: buttonsNumber * this.buttonDelay
        };
    }

    showLoadingScreen(loadingScreenSettings) {
        this.manager.handleLoadingScreen(loadingScreenSettings);
    }

    showPressedFeedback() {
        this.manager.mobileButtonsOverlay.show();
        var transitionSpeed = 150;
        var targetOpacity = 0.8;

        this.manager.container.animate({
                opacity: targetOpacity
            },
            transitionSpeed,
            function wiggle() {
                this.manager.container.animate({
                        opacity: 1
                    },
                    transitionSpeed
                );
            }.bind(this)
        );
    }

    notifyButtons(checked) {
        _.each(this.buttons, function destroyMasterButton(button) {
            button.masterButtonPressed(checked);
        });
    }

    closeWidget(keepOverlay) {
        this.masterButton.prop("checked", false);

        if (!keepOverlay) {
            this.manager.mobileButtonsOverlay.hide();
        }

        this.notifyButtons(false);
    }

    hideWidget(keepOverlay) {
        this.masterButton.attr("disabled", true);
        this.masterButtonLabel.hide();
        this.closeWidget(keepOverlay);

        _.each(this.buttons, function hideAllButtons(button) {
            button.hide();
        });
    }

    showWidget() {
        this.masterButton.removeAttr("disabled");
        this.masterButtonLabel.show();
        this.manager.container.prepend(this.masterButtonLabel);
        this.manager.container.prepend(this.masterButton);
        this.masterButton.prop("checked", true);

        _.each(this.buttons, function destroyMasterButton(button) {
            button.show();
        });
    }

    goToMainWidget() {
        this.manager.goToMainWidget();
    }

    destroy() {
        _.each(this.buttons, function destroyMasterButton(button) {
            button.destroy();
        });
    }
}
    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/TSPCustomAlgorithm', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/TSPCustomAlgorithm';
/*eslint-disable*/
function GAInitialize() {
    for (var i = 0; i < POPULATION_SIZE; i++) {
        population.push(randomIndivial(points.length));
    }
    countDistances();
    setBestValue();
}
function GANextGeneration() {
    currentGeneration++;
    selection();
    crossover();
    mutation();
    setBestValue();
}
function tribulate() {
    for (var i = population.length >> 1; i < POPULATION_SIZE; i++) {
        population[i] = randomIndivial(points.length);
    }
}
function selection() {
    var parents = new Array();
    var initnum = 4;
    parents.push(population[currentBest.bestPosition]);
    parents.push(doMutate(best.clone()));
    parents.push(pushMutate(best.clone()));
    parents.push(best.clone());

    setRoulette();
    for (var i = initnum; i < POPULATION_SIZE; i++) {
        parents.push(population[wheelOut(Math.random())]);
    }
    population = parents;
}
function crossover() {
    var queue = new Array();
    for (var i = 0; i < POPULATION_SIZE; i++) {
        if (Math.random() < CROSSOVER_PROBABILITY) {
            queue.push(i);
        }
    }
    queue.shuffle();
    for (var i = 0, j = queue.length - 1; i < j; i += 2) {
        doCrossover(queue[i], queue[i + 1]);
    }
}
function doCrossover(x, y) {
    child1 = getChild("next", x, y);
    child2 = getChild("previous", x, y);
    population[x] = child1;
    population[y] = child2;
}
function getChild(fun, x, y) {
    solution = new Array();
    var px = population[x].clone();
    var py = population[y].clone();
    var dx, dy;
    var c = px[randomNumber(px.length)];
    solution.push(c);
    while (px.length > 1) {
        dx = px[fun](px.indexOf(c));
        dy = py[fun](py.indexOf(c));
        px.deleteByValue(c);
        py.deleteByValue(c);
        c = dis[c][dx] < dis[c][dy] ? dx : dy;
        solution.push(c);
    }
    return solution;
}
function mutation() {
    for (var i = 0; i < POPULATION_SIZE; i++) {
        if (Math.random() < MUTATION_PROBABILITY) {
            if (Math.random() > 0.5) {
                population[i] = pushMutate(population[i]);
            } else {
                population[i] = doMutate(population[i]);
            }
            i--;
        }
    }
}
function preciseMutate(orseq) {
    var seq = orseq.clone();
    if (Math.random() > 0.5) {
        seq.reverse();
    }
    var bestv = evaluate(seq);
    for (var i = 0; i < seq.length >> 1; i++) {
        for (var j = i + 2; j < seq.length - 1; j++) {
            var new_seq = swap_seq(seq, i, i + 1, j, j + 1);
            var v = evaluate(new_seq);
            if (v < bestv) {
                (bestv = v), (seq = new_seq);
            }
        }
    }
    return seq;
}
function preciseMutate1(orseq) {
    var seq = orseq.clone();
    var bestv = evaluate(seq);

    for (var i = 0; i < seq.length - 1; i++) {
        var new_seq = seq.clone();
        new_seq.swap(i, i + 1);
        var v = evaluate(new_seq);
        if (v < bestv) {
            (bestv = v), (seq = new_seq);
        }
    }
    return seq;
}
function swap_seq(seq, p0, p1, q0, q1) {
    var seq1 = seq.slice(0, p0);
    var seq2 = seq.slice(p1 + 1, q1);
    seq2.push(seq[p0]);
    seq2.push(seq[p1]);
    var seq3 = seq.slice(q1, seq.length);
    return seq1.concat(seq2).concat(seq3);
}
function doMutate(seq) {
    mutationTimes++;
    do {
        m = randomNumber(seq.length - 2);
        n = randomNumber(seq.length);
    } while (m >= n);

    for (var i = 0, j = (n - m + 1) >> 1; i < j; i++) {
        seq.swap(m + i, n - i);
    }
    return seq;
}
function pushMutate(seq) {
    mutationTimes++;
    var m, n;
    do {
        m = randomNumber(seq.length >> 1);
        n = randomNumber(seq.length);
    } while (m >= n);

    var s1 = seq.slice(0, m);
    var s2 = seq.slice(m, n);
    var s3 = seq.slice(n, seq.length);
    return s2
        .concat(s1)
        .concat(s3)
        .clone();
}
function setBestValue() {
    for (var i = 0; i < population.length; i++) {
        values[i] = evaluate(population[i]);
    }
    currentBest = getCurrentBest();

    if (bestValue === undefined || bestValue > currentBest.bestValue) {
        best = population[currentBest.bestPosition].clone();
        bestValue = currentBest.bestValue;
        UNCHANGED_GENS = 0;
    } else {
        UNCHANGED_GENS += 1;
    }
}
function getCurrentBest() {
    if (population[0][0] == 0) {
        var bestP = 0,
            currentBestValue = values[0];
    } else {
        var bestP = 0,
            currentBestValue = 100000000000;
    }

    for (var i = 1; i < population.length; i++) {
        if (values[i] < currentBestValue && population[i][0] == 0) {
            currentBestValue = values[i];
            bestP = i;
        }
    }
    return {
        bestPosition: bestP,
        bestValue: currentBestValue
    };
}
function setRoulette() {
    for (var i = 0; i < values.length; i++) {
        fitnessValues[i] = 1.0 / values[i];
    }
    var sum = 0;
    for (var i = 0; i < fitnessValues.length; i++) {
        sum += fitnessValues[i];
    }
    for (var i = 0; i < roulette.length; i++) {
        roulette[i] = fitnessValues[i] / sum;
    }
    for (var i = 1; i < roulette.length; i++) {
        roulette[i] += roulette[i - 1];
    }
}
function wheelOut(rand) {
    var i;
    for (i = 0; i < roulette.length; i++) {
        if (rand <= roulette[i]) {
            return i;
        }
    }
}
function randomIndivial(n) {
    var a = [];
    for (var i = 0; i < n; i++) {
        a.push(i);
    }
    return a.shuffle();
}
function evaluate(indivial) {
    var sum = 0;
    for (var i = 1; i < indivial.length; i++) {
        sum += dis[indivial[i]][indivial[i - 1]];
    }
    return sum;
}
function getDistance(point1, point2) {
    var d = Math.sqrt(
        (point1.latitude - point2.latitude) * (point1.latitude - point2.latitude) +
            (point1.longitude - point2.longitude) * (point1.longitude - point2.longitude)
    );
    return d;
}
function countDistances() {
    var length = points.length;
    dis = new Array(length);
    for (var i = 0; i < length; i++) {
        dis[i] = new Array(length);
        for (var j = 0; j < length; j++) {
            dis[i][j] = getDistance(points[i], points[j]);
        }
    }
}

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMapsViewChangeHandler', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMapsViewChangeHandler';
(function jsExtension(app) {
    SUGAR.mobile.extensions["extendSearchGlobalViewHeader"] = {
        extendsFrom: {
            baseType: "header"
        },

        onAfterShow() {
            var callParent = this._super("onAfterShow", arguments);

            if (this.module === "Search") {
                this.setConfig({ back: false });
            }

            return callParent;
        }
    };

    var contextButtonsClass = window.require("src/wsystems/mobile/include/require/wMapsContextButtons")
        .wMapsContextButtons;
    this.wMapsContextButtons = new contextButtonsClass();

    app.events.once("data:sync:success", function wMapsSettings() {    
        let url = app.api.buildURL("uMapsRetrieveSettings");
        let callback = function cb(data) {
            var enabledModules = [];
            var mappings = {};
            if (typeof data == "object" && data["module_mappings"]) {
                if (typeof data["module_mappings"] == "object") {
                    for (var module in data["module_mappings"]) enabledModules.push(module);
                    mappings = data["module_mappings"];
                }
            }
    
            var distanceUnitUser = data["distanceUnitUser"] ? data["distanceUnitUser"] : "";
            var distanceUnitSystem = data["measurement_unit"] ? data["measurement_unit"] : "miles";
            var defaultSettings = data["defaultSettings"] ? data["defaultSettings"] : [];
            app.uMapsData = {
                enabledModules     : enabledModules,
                mappings           : mappings,
                distanceUnitSystem : distanceUnitSystem,
                distanceUnitUser   : distanceUnitUser,
                defaultSettings    : defaultSettings
            };
            App.events.trigger("umaps-settings-loaded");
        };
        
        app.api.call("read", url, null, {
            success: callback
        });
    });

})(SUGAR.App);

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/AddDistanceFilterExtension', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/AddDistanceFilterExtension';
(function jsExtension(app) {
    const _extensionUniqueName = "wmaps-add-proximity-values-to-filters"; // set this up so that it does not conflict with other extensions
    const _entityToBeExtended = "filter-item"; // the name of the view/field/dashlet you want to extend

    const _filterEdit = "filter-edit";
    const _extendFilterEdit = "wmaps-edit-proximity-values-to-filters";

    const FIELD_NAMES = {
        name          : "field_name",
        operator      : "field_operator",
        value         : "field_value",
        betweenFields : ["__start_", "__end_"],
    };

    const appOfflineCRRFProto = app.offline.convertReadRecordsFilter;
    
    app.offline.convertReadRecordsFilter = function (options, module) {
        let superResult = appOfflineCRRFProto.apply(this, arguments);

        if (_.isUndefined(superResult) === false) {
            if (superResult.isSupported === true) {
                let moduleFields = app.metadata.getModule(module).fields;

                _.each(superResult.filterFields, function checkIfFilterFieldIsProximity (fieldName) {
                    if (superResult.isSupported === true) {
                        let fieldDef = moduleFields[fieldName] || {};

                        if (fieldDef.type === "proximity") {
                            superResult.isSupported = false;
                        }
                    }
                });
            }
        }

        return superResult;
    };

    SUGAR.mobile.extensions[_extendFilterEdit] = {
        extendsFrom: {
            baseType: _filterEdit,
        },

        renderFilters() {
            const $el = this.$el.find(".filters-items");
            const filters = this.model.get("filters");
    
            var CustomFilterItem = app.nomad.getViewClass({
                baseType: "filter-item"
            });
    
            filters.forEach((model, index) => {
                const filter = new CustomFilterItem({
                    model,
                    index,
                    module              : this.module,
                    filterableFields    : this.filterableFields,
                    filterableFieldsMap : this.filterableFieldsMap,
                    fieldsOperators     : this.fieldsOperators,
                    action              : this.isCreate ? "create" : "edit",
                    context             : this.context,
                });
    
                filter.render();
                $el.append(filter.$el);
            });
        },

        prepareOptions(options) {
            let superResult = this._super("prepareOptions", arguments);
            
            let filters = superResult.model.get("filters");

            let {filter, module} = options.data;
    
            _.each(filter && filter.filter_template, (originalFilter, index) => {
                // let fieldName = this.getFilterFieldName(originalFilter);

                filterModel = filters.models[index];

                let fieldName = filterModel.get("field_name");

                let fieldDefs = this.filterableFields[fieldName];

                if (fieldDefs.type === "proximity") {
                    let fieldOperator = filterModel.get("field_operator");

                    let fieldValue = this.getFilterValue(originalFilter, fieldName, fieldOperator);
                
                    filterModel.set("unit", fieldValue[2]);
                    filterModel.set("country", fieldValue[3]);
                }
            });
            
            return superResult;
        },

        /**
         * Get filters from local model.
         * @returns {Array} - filter_template and filter_definition.
         */
        _getFilters() {

            let superResult = this._super("prepareOptions", arguments);

            let filtersTemplates = superResult[0] || [];

            filtersTemplates.forEach( function (filterParts, index) {
                const indexCopy = index;

                for (let prop in filterParts) {
                    if (prop !== undefined) {
                        let fieldDef = this.filterableFields[prop];

                        if (fieldDef.type === "proximity") {
                            let filters = this.model.get("filters");

                            let filterModel = filters.models[indexCopy];

                            if (_.isUndefined(filterModel) === false) {
                                let extraModelValues = [];

                                _.each(FIELD_NAMES.betweenFields, function (betweenFieldName) {
                                    extraModelValues.push(filterModel.get(betweenFieldName) || "");
                                }.bind(this));

                                extraModelValues.push(filterModel.get("unit"));
                                        
                                // Pushing the country field to the extraModelValues
                                extraModelValues.push(filterModel.get("country"));

                                let filterOperator = filterModel.get(FIELD_NAMES.operator);

                                filterParts[prop] = {};
                                        
                                filterParts[prop][filterOperator] = extraModelValues;
                            }
                        }
                    }   
                }
            }.bind(this));

            return superResult;
        }
    };

    SUGAR.mobile.extensions[_extensionUniqueName] = {
        extendsFrom: {
            baseType: _entityToBeExtended,
        },

        // extend the initialize from the base view/field/dashlet
        getValueDefs(fieldNameCustom) {
            let superResult = this._super("getValueDefs", arguments);

            let labels = {
                "__start_" : "Radius",
                "__end_"   : "Postal Code",
                "unit"     : "Measurement Unit",
                "country"  : "Country"
            };

            if (superResult.type === "proximity" && fieldNameCustom) {
                superResult.name = fieldNameCustom;

                if (_.has(labels, fieldNameCustom) === true) {
                    superResult.label = labels[fieldNameCustom];
                }
            }

            return superResult;
        },

        getDisplayFields() {
            const fields = this._super("getDisplayFields", arguments);

            if (fields[fields.length - 1].type === "proximity") {
                let unitField = this.getValueDefs("unit");

                unitField.type = "enum";

                unitField.options = {
                    km    : "Kilometers",
                    miles : "Miles"
                };

                fields.push(unitField);
            } 

            if (fields[fields.length - 1].name === "unit") {
                let countryField = this.getValueDefs("country");

                countryField.type = "enum";
    
                countryField.options = {
                    "af" : "Afghanistan",
                    "ax" : "Åland Islands",
                    "al" : "Albania",
                    "dz" : "Algeria",
                    "as" : "American Samoa",
                    "ad" : "Andorra",
                    "ao" : "Angola",
                    "ai" : "Anguilla",
                    "ag" : "Antigua and Barbuda",
                    "ar" : "Argentina",
                    "am" : "Armenia",
                    "aw" : "Aruba",
                    "au" : "Australia",
                    "at" : "Austria",
                    "az" : "Azerbaijan",
                    "bs" : "Bahamas",
                    "bh" : "Bahrin",
                    "bd" : "Bangladesh",
                    "bb" : "Barbados",
                    "by" : "Belarus",
                    "be" : "Belgium",
                    "bz" : "Belize",
                    "bj" : "Benin",
                    "bm" : "Bermuda",
                    "bt" : "Bhutan",
                    "bo" : "Bolivia",
                    "ba" : "Bosnia and Herzegovina",
                    "bw" : "Botwswana",
                    "br" : "Brazil",
                    "io" : "British Indian Ocean Territory",
                    "vg" : "British Virgin Islands",
                    "bn" : "Brunei",
                    "bg" : "Bulgaria",
                    "bf" : "Burkina Faso",
                    "bi" : "Burundi",
                    "kh" : "Cambodia",
                    "cm" : "Cameroon",
                    "ca" : "Canada",
                    "cv" : "Cape Verde",
                    "bq" : "Caribbean Netherlands",
                    "ky" : "Cayman Islands",
                    "cf" : "Central African Republic",
                    "td" : "Chad",
                    "cl" : "Chile",
                    "cn" : "China",
                    "cx" : "Christmas Island",
                    "cc" : "Cocos Islands (Kepulauan Cocos)",
                    "co" : "Colombia",
                    "km" : "Comoros",
                    "cd" : "Congo",
                    "cg" : "Congo",
                    "ck" : "Cook Islands",
                    "cr" : "Costa Rica",
                    "ci" : "Côte d’Ivoire",
                    "hr" : "Croatia",
                    "cu" : "Cuba",
                    "cw" : "Curaçao",
                    "cy" : "Cyprus",
                    "cz" : "Czech Republic",
                    "dk" : "Denmark",
                    "dj" : "Djibouti",
                    "dm" : "Dominica",
                    "do" : "Dominican Republic",
                    "ec" : "Ecuador",
                    "eg" : "Egypt",
                    "sv" : "El Salvador",
                    "gq" : "Equatorial Guinea",
                    "er" : "Eritrea",
                    "ee" : "Estonia",
                    "et" : "Ethiopia",
                    "fk" : "Falkand Islands",
                    "fo" : "Faroe Islands",
                    "fj" : "Fiji",
                    "fi" : "Finland",
                    "fr" : "France",
                    "gf" : "French Guiana",
                    "pf" : "French Polynesia",
                    "ga" : "Gabon",
                    "gm" : "Gambia",
                    "ge" : "Georgia",
                    "de" : "Germany",
                    "gh" : "Ghana",
                    "gi" : "Gibraltar",
                    "gr" : "Greece",
                    "gl" : "Greenland",
                    "gd" : "Grenada",
                    "gp" : "Guadeloupe",
                    "gu" : "Guam",
                    "gt" : "Guatemala",
                    "gg" : "Guernsey",
                    "gn" : "Guinea",
                    "gw" : "Guinea-Bissau",
                    "gy" : "Guyana",
                    "ht" : "Haiti",
                    "hn" : "Honduras",
                    "hk" : "Hong Kong",
                    "hu" : "Hungary",
                    "is" : "Iceland",
                    "in" : "India",
                    "id" : "Indonesia",
                    "ir" : "Iran",
                    "iq" : "Irak",
                    "ie" : "Ireland",
                    "im" : "Isle of Man",
                    "il" : "Israel",
                    "it" : "Italy",
                    "jm" : "Jamaica",
                    "jp" : "Japan",
                    "je" : "Jersey",
                    "jo" : "Jordan",
                    "kz" : "Kazakhstan",
                    "ke" : "Kenya",
                    "ki" : "Kiribati",
                    "xk" : "Kosovo",
                    "kw" : "Kuwait",
                    "kg" : "Kyrgyzstan",
                    "la" : "Laos",
                    "lv" : "Latvia",
                    "lb" : "Lebanon",
                    "ls" : "Lesotho",
                    "lr" : "Liberia",
                    "ly" : "Libya",
                    "li" : "Liechtenstein",
                    "lt" : "Lithuania",
                    "lu" : "Luxembourg",
                    "mo" : "Macau",
                    "mk" : "Macedonia",
                    "mg" : "Madagascar",
                    "mw" : "Malawi",
                    "my" : "Malaysia",
                    "mv" : "Maldives",
                    "ml" : "Mali",
                    "mt" : "Malta",
                    "mh" : "Marshall Islands",
                    "mq" : "Martinique",
                    "mr" : "Mauritania",
                    "mu" : "Mauritius",
                    "yt" : "Mayotte",
                    "mx" : "Mexico",
                    "fm" : "Micronesia",
                    "md" : "Moldova",
                    "mn" : "Mongolia",
                    "me" : "Montenegro",
                    "ms" : "Montserrat",
                    "ma" : "Marocco",
                    "mz" : "Mozambique",
                    "mm" : "Myanmar",
                    "na" : "Namibia",
                    "nr" : "Nauru",
                    "np" : "Nepal",
                    "nl" : "Netherlands",
                    "nc" : "New Caledonia",
                    "nz" : "New Zealand",
                    "ni" : "Nicaragua",
                    "ne" : "Niger",
                    "ng" : "Nigeria",
                    "nu" : "Niue",
                    "nf" : "Norfolk Island",
                    "kp" : "North Korea",
                    "mp" : "Northern Mariana Islands",
                    "no" : "Norway",
                    "om" : "Oman",
                    "pk" : "Pakistan",
                    "pw" : "Palau",
                    "ps" : "Palestine",
                    "pa" : "Panama",
                    "pg" : "Papua New Guinea",
                    "py" : "Paraguay",
                    "pe" : "Peru",
                    "ph" : "Philippines",
                    "pn" : "Pitcairn Islands",
                    "pl" : "Poland",
                    "pt" : "Portugal",
                    "pr" : "Puerto Rico",
                    "qa" : "Quatar",
                    "re" : "Réunion",
                    "ro" : "Romania",
                    "ru" : "Russia",
                    "rw" : "Rwanda",
                    "bl" : "Saint Barthélemy",
                    "sh" : "Saint Helena",
                    "kn" : "Saint Kitts and Nevis",
                    "lc" : "Saint Lucia",
                    "mf" : "Saint Martin (Saint-Martin)",
                    "pm" : "Saint Pierre and Miquelon",
                    "vc" : "Saint Vincent and the Grenadines",
                    "ws" : "Samoa",
                    "sm" : "San Marino",
                    "st" : "São Tomé and Príncipe",
                    "sa" : "Saudi Arabia",
                    "sn" : "Senegal",
                    "rs" : "Serbia",
                    "sc" : "Seychelles",
                    "sl" : "Sierra Leone",
                    "sg" : "Singapore",
                    "sx" : "Sint Maarten",
                    "sk" : "Slovakia",
                    "si" : "Slovenia",
                    "sb" : "Solomon Islands",
                    "so" : "Somalia",
                    "za" : "South Africa",
                    "gs" : "South Georgia & South Sandwich Islands",
                    "kr" : "South Korea",
                    "ss" : "South Sudan",
                    "es" : "Spain",
                    "lk" : "Sri Lanka",
                    "sd" : "Sudan",
                    "sr" : "Suriname",
                    "sj" : "Svalbard and Jan Mayen",
                    "sz" : "Swaziland",
                    "se" : "Sweden",
                    "ch" : "Switzerland",
                    "sy" : "Syria",
                    "tw" : "Taiwan",
                    "tj" : "Tajikistan",
                    "tz" : "Tanzania",
                    "th" : "Thailand",
                    "tl" : "Timor-Leste",
                    "tg" : "Togo",
                    "tk" : "Tokelau",
                    "to" : "Tonga",
                    "tt" : "Trinidad and Tobago",
                    "tn" : "Tunisia",
                    "tr" : "Turkey",
                    "tm" : "turkmenistan",
                    "tc" : "Turks and Caicos Islands",
                    "tv" : "Tuvalu",
                    "ug" : "Uganda",
                    "ua" : "Ukraine",
                    "ae" : "United Arab Emirates",
                    "gb" : "United Kingdom",
                    "us" : "United States",
                    "um" : "U.S. Minor Outlying Islands",
                    "vi" : "U.S. Virgin Islands",
                    "uy" : "Uruguay",
                    "uz" : "Uzbekistan",
                    "vu" : "Vanuatu",
                    "va" : "Vatican City",
                    "ve" : "Venezuela",
                    "vn" : "Vietnam",
                    "wf" : "Wallis and Futuna",
                    "eh" : "Western Sahara",
                    "ye" : "Yemen",
                    "zm" : "Zambia",
                    "zw" : "Zimbabwe"
                };
    
                fields.push(countryField);
            }

            return fields;
        },

        // you can extend/overwrite anything you want from the base class
    };
})(SUGAR.App);

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/RemoveGeolocationFilter', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/RemoveGeolocationFilter';
(function removeGeolocationFilter(app) {
    const _extensionUniqueName = "wmaps-remove-geolocation-filter"; // set this up so that it does not conflict with other extensions
    const _entityToBeExtended = "filter-edit"; // the name of the view/field/dashlet you want to extend

    SUGAR.mobile.extensions[_extensionUniqueName] = {
        extendsFrom: {
            baseType: _entityToBeExtended,
        },

        initialize: function () {
            var parentResult = this._super("initialize", arguments);

            var filtersToRemove = {
                "fieldsOperators"     : ["geo_location"],
                "filterableFields"    : ["geolocation"],
                "filterableFieldsMap" : ["geolocation"]
            };

            this._removeGeolocationFilter(filtersToRemove);
            
            return parentResult;
        },

        /**
         * Remove Geolocation Filter
         * 
         * @param {Object} filtersToRemove 
         */
        _removeGeolocationFilter: function (filtersToRemove) {
            for (let filter in filtersToRemove) {
                filtersToRemove[filter].forEach(f => {
                    if (_.has(this, filter) === true && _.has(this[filter], f) === true) {
                        delete this[filter][f];
                    }
                });
            }
        },

        // you can extend/overwrite anything you want from the base class
    };
})(SUGAR.App);

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/TSPUtils', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/TSPUtils';
/* eslint-disable */
Object.defineProperties(Array.prototype, {
    "clone": {
        value: function () {
            return this.slice(0);
        },
        enumerable: false
    },
    "shuffle": {
        value: function () {
            for (var j, x, i = this.length - 1; i; j = randomNumber(i), x = this[--i], this[i] = this[j], this[j] = x);
            return this;
        },
        enumerable: false
    },
    "deleteByValue": {
        value: function (val) {
            var pos = this.indexOf(val);
            this.splice(pos, 1);
        },
        enumerable: false
    },
    "next": {
        value: function (index) {
            if (index === this.length - 1) {
                return this[0];
            } else {
                return this[index + 1];
            }
        },
        enumerable: false
    },
    "previous": {
        value: function (index) {
            if (index === 0) {
                return this[this.length - 1];
            } else {
                return this[index - 1];
            }
        },
        enumerable: false
    },
    "swap": {
        value: function (x, y) {
            if (x > this.length || y > this.length || x === y) {
                return;
            }
            var tem = this[x];
            this[x] = this[y];
            this[y] = tem;
        },
        enumerable: false
    },
    "roll": {
        value: function () {
            var rand = randomNumber(this.length);
            var tem = [];
            for (var i = rand; i < this.length; i++) {
                tem.push(this[i]);
            }
            for (var i = 0; i < rand; i++) {
                tem.push(this[i]);
            }
            return tem;
        },
        enumerable: false
    },
    "reject": {
        value: function (array) {
            return $.map(this, function(ele) {
                return $.inArray(ele, array) < 0 ? ele : null;
            });
        },
        enumerable: false
    },
});

function intersect(x, y) {
    return $.map(x, function(xi) {
        return $.inArray(xi, y) < 0 ? null : xi;
    });
}
function Point(x, y) {
    this.x = x;
    this.y = y;
}
function randomPoint() {
    var randomx = randomNumber(WIDTH);
    var randomy = randomNumber(HEIGHT);
    var randomPoint = new Point(randomx, randomy);
    return randomPoint;
}
function randomNumber(boundary) {
    return parseInt(Math.random() * boundary);
}
function distance(p1, p2) {
    return euclidean(p1.x - p2.x, p1.y - p2.y);
}
function euclidean(dx, dy) {
    return Math.sqrt(dx * dx + dy * dy);
}

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/FixSugarChartsDashlet', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/FixSugarChartsDashlet';
(function fixSugarChartsDashlet(app) {
    SUGAR.mobile.extensions["fixSugarChartsDashlet"] = {
        extendsFrom: {
            baseType: "saved-reports-chart"
        },

        _getModuleFromRelationship: function (relationship, module) {
            const firstPosition = 0;
            const cutAfterIndex = 1;

            let fieldsMeta = app.metadata.getModule(module, "fields");
            let targetField = _.filter(fieldsMeta, function getFieldByRelationship(fieldData) {
                return (fieldData.relationship === relationship);
            });

            let targetFieldName = targetField[firstPosition].name;
            let undescorePos = targetFieldName.indexOf("_");
            
            if (undescorePos > -1) {
                targetFieldName = targetFieldName.slice(undescorePos + 1);
            }

            targetFieldName = targetFieldName.charAt(firstPosition).toUpperCase() + targetFieldName.slice(cutAfterIndex);

            return targetFieldName;
        },
    };
})(SUGAR.App);
    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMobileApp/addGoToConfigButton', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMobileApp/addGoToConfigButton';
(function jsExtension(app) {
    const _extensionUniqueName = "addGoToConfigButton"; 
    const _entityToBeExtended = "login"; 

    SUGAR.mobile.extensions[_extensionUniqueName] = {
        extendsFrom: {
            baseType: _entityToBeExtended,
        },

        initialize() {
            let _initResult = this._super("initialize", arguments);

            this._initProperties();

            return _initResult;
        },

        render() {
            let _renderResult = this._super("render", arguments);

            this._addUserProfileButton();
            this._storeProfile();

            return _renderResult;
        },

        goToUserProfileView() {
            let userProfilesView = SUGAR.mobile.loadView(this.USER_PROFILES_VIEW, {
                isDynamic        : true,
                skipRegistration : true
            });

            userProfilesView.once("settings:submit", options => {
                this.render();
            });
        },

        _addUserProfileButton() {
            this.$el.find(this.SETTINGS_DIV).prepend(this.USER_PROFILES_HTML);
            this.$el.find(this.CONFIG_BTN).on("click", this.goToUserProfileView.bind(this));
        },

        _storeProfile() {
            let _profiles = {};
            const LOCAL_STORAGE_KEY = "wsysUserProfiles";
    
            let _lsProfiles = window.localStorage.getItem(LOCAL_STORAGE_KEY);
    
            if (typeof _lsProfiles === "string") {
                _profiles = JSON.parse(_lsProfiles);
            }
    
            let _loginTmpSettings = app.loginManager.getTempSetting();
            let _hasConfig = false;
    
            _.each(_profiles, function searchProfile(profileData){
                if (profileData.url === _loginTmpSettings.loginUrl) {
                    _hasConfig = true;
                }
            });
    
            if (_hasConfig == false) {
                let _profileId = app.utils.generateUUID();
                
                _profiles[_profileId] = {
                    url  : _loginTmpSettings.loginUrl,
                    user : _loginTmpSettings.loginName
                };
                
                _.each(_profiles, function createProfile(profileData, profId){
                    _profiles[profId].inUse = false;
                }, this);
        
                _profiles[_profileId].inUse = true;
        
                window.localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(_profiles));
            }
        },

        _initProperties() {
            this.USER_PROFILES_VIEW = "user-profiles";
            this.SETTINGS_DIV = ".login__settings_div";
            this.CONFIG_BTN = ".userConfig";
            this.USER_PROFILES_HTML = 
`
<a class="fast-click-highlighted">
    <i class="userConfig icondefault icon icon-user icon-size-md"></i>
</a>            
`;
        },
    };
})(SUGAR.App);

    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMobileApp/addSildeRightListView', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMobileApp/addSildeRightListView';
(function jsExtensionListView(app) {
    const listType = "inner-list";
    const newTemplate =
        SUGAR.mobile.views["add-checkbox-view-on-inner-list"].templates[
            "add-checkbox-view-on-inner-list"
        ];
    const templateContent = Handlebars.compile(newTemplate)();

    SUGAR.mobile.extensions["addSlideRightListView"] = {
        extendsFrom: {
            baseType: listType
        },

        initialize(options) {
            let callParent = this._super("initialize", arguments);

            app.controller.on(
                "mobile-reset-inner-list-checboxes",
                this.resetAllCheckboxes
            );

            return callParent;
        },

        /**
         * @resetAllCheckboxes
         *
         * Reset all the checkboxes
         *
         * using example:
         * app.controller.trigger("mobile-reset-inner-list-checboxes", { reset: true, module: app.controller.layoutManager.getRootLayout().module })
         *
         * @param {Object} options  - params of object - reset - true
         *                                               module - name of the module for checkboxes to be reseted
         */
        resetAllCheckboxes(options) {
            const reset = options.reset;
            const resetModule = options.module;
            const currentModule = app.controller.layoutManager.getRootLayout().module;

            if (reset === true && resetModule === currentModule) {
                const children = this.$el.find(".items").children();

                children.forEach(item => {
                    const jqElement = $(item);
                    const checkbox = jqElement.find(".element-detector-input");
                    const checkboxState = checkbox.prop("checked");

                    if (checkboxState === true) {
                        checkbox.prop("checked", false);
                    }
                });

                this.$el.find(".listing").attr("checked_elements_list", []);
            }
        },

        render() {
            let callParent = this._super("render", arguments);

            this.wrapElementWithCheckbox();

            return callParent;
        },

        onItemAdded() {
            let callParent = this._super("onItemAdded", arguments);

            this.wrapElementWithCheckbox();

            return callParent;
        },

        /**
         * @unMarkElementAsCheckedInBacked
         *
         *  add the checkbox on the item on rendering time
         */
        wrapElementWithCheckbox() {
            const shouldAddFunctionality = this.$el.find(".menu-container").length;

            if (shouldAddFunctionality === 0) {
                return true;
            }

            const articles = this.$el.find("article");
            if (articles && articles.length > 0) {
                articles.forEach(art => {
                    const jqArt = $(art);

                    if (jqArt.find(".element-detector-input").length === 0) {
                        jqArt.prepend(templateContent);
                    }

                    const input = jqArt.find(".element-detector-input");
                    const label = jqArt.find(".element-detector-label");
                    const artId = "input-" + jqArt.attr("data-id");

                    if (input.length > 0 && label.length > 0) {
                        input.attr("id", artId);
                        label.attr("for", artId);
                        label.click(this.setActionOnClickCheckbox.bind(this));
                        input.click(this.setActionOnClickCheckboxSafe);
                    }
                });
            }

            return true;
        },

        setActionOnClickCheckboxSafe(e) {
            e.stopPropagation();
        },
        setActionOnClickCheckbox(e) {
            e.stopPropagation();
            e.preventDefault();

            const parentElement = $(e.currentTarget.parentElement);

            parentElement.find(".element-detector-input").prop("checked", false);

            this.unMarkElementAsCheckedInBacked(parentElement);
        },

        /**
         * @unMarkElementAsCheckedInBacked
         *
         *  {Object} parentElement - parent element of the clicked item
         *  Unmark the item as unchecked in backend to be able
         *  to handle them later where we need them
         */
        unMarkElementAsCheckedInBacked(parentElement) {
            const listingElement = $(".listing");
            const checkedElements = listingElement.attr("checked_elements_list");
            const recordId = parentElement.attr("data-id");

            if (checkedElements) {
                let currentRecordsToCheck = checkedElements.split(",");

                let newValues = currentRecordsToCheck.filter(item => item != recordId);

                listingElement.attr("checked_elements_list", newValues);
            }
        }
    };
})(SUGAR.App);
    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMobileApp/handleSlideGestureBevhaviorRightListView', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMobileApp/handleSlideGestureBevhaviorRightListView';
(function jsExtensionListView(app) {
    SUGAR.mobile.extensions["addCheckBoxOnListView"] = {
        extendsFrom: {
            baseType: "context-menu"
        },

        /**
         * @onItemSwipeLeft
         *
         * @ev    {Object} - element event
         * @model {Object} - element model
         *
         * add functionality on swipe left for checkbox
         */
        onItemSwipeLeft(ev, model) {
            const shouldAddFunctionality = $(ev.currentTarget).find(".menu-container").length;

            if (shouldAddFunctionality === 0) {
                return true;
            }

            const checkbox = $(ev.currentTarget).find(".element-detector-input");

            if (checkbox.length > 0 && checkbox.prop("checked") === true) {
                checkbox.prop("checked", false);
                this.unMarkElementAsCheckedInBacked(ev);
            } else if (app.isTablet && $.__swipeHelper.swipeOrientation !== "vertical") {
                const $article = $(ev.currentTarget).closest("article");

                if (this.isItemHasContextMenuOpened($article.get(0))) {
                    return false;
                }

                if (this.isOpened()) {
                    this.hide();
                }

                this.show($article, model);
            }

            return true;
        },

        /**
         * @onItemSwipeRight
         *
         * @ev    {Object} - element event
         * @model {Object} - element model
         *
         * add functionality on swipe right for checkbox
         */
        onItemSwipeRight(ev, model) {
            const shouldAddFunctionality = $(ev.currentTarget).find(".menu-container").length;

            if (shouldAddFunctionality === 0) {
                return true;
            }

            const checkbox = $(ev.currentTarget).find(".element-detector-input");

            if (
                checkbox.length > 0 &&
                checkbox.prop("checked") === false &&
                !this.isItemHasContextMenuOpened(ev.currentTarget)
            ) {
                checkbox.prop("checked", true);
                this.markElementAsCheckedInBacked(ev);
            } else if (this.isItemHasContextMenuOpened(ev.currentTarget)) {
                this.hide();
            }

            return true;
        },

        /**
         * @markElementAsCheckedInBacked
         *
         *  {Object} el - click event
         *  Mark the item as checked in backend to be able
         *  to handle them later where we need them
         */
        markElementAsCheckedInBacked(el) {
            const listingElement = $(".listing");
            const checkedElements = listingElement.attr("checked_elements_list");
            const id = el.currentTarget.getAttribute("data-id");
            const jqCurrentEl = $(el.currentTarget);
            const jqInput = jqCurrentEl.find(".element-detector-input")[0];
            const isChecked = jqInput.checked;

            //eslint-disable-next-line
            if (!checkedElements) {
                let newCheckedElements = [id];

                listingElement.attr("checked_elements_list", newCheckedElements);
            } else {
                let currentRecordsToCheck = checkedElements.split(",");

                if (isChecked === true) {
                    currentRecordsToCheck.push(id);

                    listingElement.attr("checked_elements_list", currentRecordsToCheck);
                }
            }
        },

        /**
         * @unMarkElementAsCheckedInBacked
         *
         *  {Object} el - click event
         *  Unmark the item as unchecked in backend to be able
         *  to handle them later where we need them
         */
        unMarkElementAsCheckedInBacked(el) {
            const listingElement = $(".listing");
            const checkedElements = listingElement.attr("checked_elements_list");
            const id = el.currentTarget.getAttribute("data-id");

            if (checkedElements) {
                let currentRecordsToCheck = checkedElements.split(",");

                let newValues = currentRecordsToCheck.filter(item => item != id);

                listingElement.attr("checked_elements_list", newValues);
            }
        }
    };
})(SUGAR.App);
    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMobileApp/addHeaderViewEvents', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMobileApp/addHeaderViewEvents';
(function jsExtensionListView(app) {
    let headerViews = ["header", "headerEdit"];

    headerViews.forEach(headerViewName => {
        let uniqueViewId = app.utils.generateUUID();

        SUGAR.mobile.extensions["addHeaderViewActionEvents" + uniqueViewId] = {
            extendsFrom: {
                baseType: headerViewName
            },

            _processAction(e, actionName, options) {
                app.controller.trigger("header-view-action", { name: actionName, options });

                return this._super("_processAction", arguments);
            },

            onAfterShow() {
                app.controller.trigger("header-view-attached", { headerView: this });

                return this._super("onAfterShow", arguments);
            }
        };
    });
})(SUGAR.App);
    }
},
{'requireName': 'src/wsystems/mobile/include/javascript/wMobileApp/wMobileCustomizationsReloader', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/javascript/wMobileApp/wMobileCustomizationsReloader';
(function jsExtension(app) {
    SUGAR.mobile.extensions["wMobileCustomizationsReloader"] = {
        extendsFrom: {
            baseType: "login",
        },

        render() {
            let _renderResult = this._super("render", arguments);

            if (app.reloadCustomizationsNeeded) {
                app.reloadCustomizationsNeeded = false;
                window.location.reload();
            }

            return _renderResult;
        }
    };
})(SUGAR.App);
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsMobileButtonsFactory', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsMobileButtonsFactory';
/*eslint-disable*/
class wMapsMobileButtonsFactory {
    constructor(manager) {
        this.manager = manager;
    }

    getAllwMapsButtons() {
        var mobileButtons = this.getMainButton();
        var screenContext = app.controller.getScreenContext();

        if (screenContext.root === "Search" && !screenContext.module) {
            mobileButtons.push.apply(mobileButtons, this.getFilteringButtons());
        }

        return mobileButtons;
    }

    getMainButton() {
        var self = this;

        var mainButtonConfig = [
            {
                majorButton: true,
                name: "mapsDirectionMaster",
                label: "Maps & Directions",
                icon: "fas fa-map-marked-alt",
                color: "#f5f5f5",
                backgroundColor: "#1ea362",
                callback: function (buttonManager) {
                    buttonManager.createNewMasterButton(self.getMapsAndDirectionsButtons());
                }
            }
        ];

        return mainButtonConfig;
    }

    getMapsAndDirectionsButtons() {
        var self = this;



        var mapsAndDirectionsButtons = [
            {
                majorButton: true,
                name: "routeManagement",
                label: "Route",
                icon: "fas fa-route",
                color: "#f5f5f5",
                backgroundColor: "#23a7ff",
                showCondition: function () {
                    return self.manager.wMapsMobileButtonsVisibility.canShowRouteButton();
                },
                callback: function (buttonManager) {
                    buttonManager.createNewMasterButton(self.getRouteHandlingButtons());
                }
            },
            {
                majorButton: true,
                name: "measurementUnit",
                label: "Measurement Unit",
                icon: "fas fa-sliders-h",
                color: "#f5f5f5",
                backgroundColor: "#69b12a",
                callback: function (buttonManager) {
                    buttonManager.createNewMasterButton(self.getUnitButtons());
                }
            },
            {
                majorButton: true,
                name: "nearbyRecords",
                label: "Nearby...",
                icon: "fas fa-search-location",
                color: "#f5f5f5",
                backgroundColor: "blueviolet",
                callback: function (buttonManager) {
                    buttonManager.createNewMasterButton(self.getIntervalButtons());
                }
            },
            
        ];

        mapsAndDirectionsButtons.push.apply(mapsAndDirectionsButtons, this.getMapsButtons());

        return mapsAndDirectionsButtons;
    }

    getRouteHandlingButtons() {
        var screenContext = app.controller.getScreenContext();
        var self = this;

        var routeHandlingButtons = [
            {
                name: "manageRoute",
                label: "Manage Route",
                icon: "fas fa-cogs",
                color: "#f5f5f5",
                backgroundColor: "#008CBA",
                callback: function (buttonManager) {
                    if (app.mobile.directionsRouteCollection && app.mobile.directionsRouteCollection.length > 0) {
                        app.controller.navigate("MobileUMapsroutecollectionView");
                    } else {
                        var message = app.lang.get("WMAPS_LABEL_ALERT23");
                        app.alert.show("uMaps-mobile-error", {
                            level: "warning",
                            messages: message,
                            autoClose: true
                        });
                    }
                }
            }
        ];

        if (screenContext.modelId) {
            routeHandlingButtons.push.apply(routeHandlingButtons, this.getRoutingButtons());
        }

        return routeHandlingButtons;
    }

    getRoutingButtons() {
        var self = this;


        var routingButtons = [
            {
                name: "removeRoute",
                label: "Remove From Route",
                icon: "fas fa-minus-circle",
                color: "#f5f5f5",
                backgroundColor: "#f44336",
                showCondition: function () {
                    return self.manager.wMapsMobileButtonsVisibility.canShowRemoveFromRouteButton();
                },
                callback: function (buttonManager) {
                    self.manager.wMapsMobileButtonsManager.removeRecordFromRoute();
                }
            },
            {
                name: "addRoute",
                label: "Add To Route",
                icon: "fas fa-plus-circle",
                color: "#f5f5f5",
                backgroundColor: "#4CAF50",
                showCondition: function () {
                    return self.manager.wMapsMobileButtonsVisibility.canShowAddToRouteButton();
                },
                callback: function (buttonManager) {
                    self.manager.wMapsMobileButtonsManager.addRecordToRoute();
                }
            }
        ];

        return routingButtons;
    }

    getUnitButtons(){
        let buttons = [
            {
                name: "unitMiles",
                label: "Miles",
                icon: "fas fa-map-marker-alt",
                color: "#f5f5f5",
                backgroundColor: "#69b12a",
                callback: function (buttonManager) {
                    App.uMapsData["distanceUnitUser"] = "miles";
                }
            },
            {
                name: "unitKm",
                label: "Km",
                icon: "fas fa-map-marker-alt",
                color: "#f5f5f5",
                backgroundColor: "#69b12a",
                callback: function (buttonManager) {
                    App.uMapsData["distanceUnitUser"] = "km";
                }
            }
        ];
        
        return buttons;
    }

    getIntervalButtons() {
        //eslint-disable-next-line no-magic-numbers
        var customIntervals = [1, 5, 10, 15, 25];
        var intervalButtons = [];
        var self = this;
        var wMapsFilteringDistances = SUGAR.customizationTools.wMapsFilteringDistancesList;

        if (wMapsFilteringDistances && wMapsFilteringDistances.length > 0) {
            customIntervals = wMapsFilteringDistances;
        }

        for (var intervalIndex = 0; intervalIndex < customIntervals.length; intervalIndex++) {
            intervalButtons.push(this.generateIntervalButton(customIntervals[intervalIndex]));
        }

        intervalButtons.push(
            this.generateIntervalButton(-1, {
                name: "Custom",
                label: "Custom",
                callback: function (buttonManager) {
                    SUGAR.customizationTools.dialog.showPrompt("Distance(1-250 Miles)", {
                        defaultText: "",
                        callback: function (response) {
                            self.manager.wMapsMobileButtonsManager.filterRecordsCustomDistance(response);
                        }
                    });
                }
            })
        );

        return intervalButtons;
    }

    generateIntervalButton(customDistance, uniqueData) {
        var self = this;

        let distanceUnit = "miles";
        if (App.uMapsData) {
            if (!_.isEmpty(App.uMapsData["distanceUnitUser"])) {
                distanceUnit = App.uMapsData["distanceUnitUser"];
            } else {
                if (!_.isEmpty(App.uMapsData["distanceUnitSystem"]))
                    distanceUnit = App.uMapsData["distanceUnitSystem"];
            }
        }

        var intervalButton = {
            name: customDistance + "Interval",
            label: customDistance,
            icon: "fas fa-map-marker-alt",
            color: "#f5f5f5",
            backgroundColor: "#1A237E",
            loadingScreenSettings: {
                message: "Filtering Records...",
                autoHide: false
            },
            callback: function (buttonManager) {
                self.manager.wMapsMobileButtonsManager.filterListView(customDistance);
            }
        };

        _.each(uniqueData, function addUniqueData(dataValue, dataKey) {
            intervalButton[dataKey] = dataValue;
        });

        return intervalButton;
    }

    getFilteringButtons() {
        return [
            this.generateFilteringButton({
                name: "accountFilter",
                label: "Ac",
                backgroundColor: "#51cd15",
                data: { module: "Accounts" }
            }),
            this.generateFilteringButton({
                name: "contactFilter",
                label: "Co",
                backgroundColor: "#51cd15",
                data: { module: "Contacts" }
            }),
            this.generateFilteringButton({
                name: "leadFilter",
                label: "Le",
                backgroundColor: "#a05cff",
                data: { module: "Leads" }
            }),
            this.generateFilteringButton({
                name: "opportunityFilter",
                label: "Op",
                backgroundColor: "#a05cff",
                data: { module: "Opportunities" }
            })
        ];
    }

    generateFilteringButton(uniqueData) {
        var self = this;

        var filteringButtonData = {
            checked: self.manager.wMapsMobileButtonsManager.isFilteringButtonChecked(uniqueData.data.module),
            color: "#f5f5f5",
            icon: false,
            horizontalButton: true,
            showCondition: function () {
                return self.manager.wMapsMobileButtonsVisibility.canShowFilterModuleButton();
            },
            callback: function (buttonManager) {
                self.manager.wMapsMobileButtonsManager.filterByModule(buttonManager);
            }
        };
        _.each(uniqueData, function addUniqueData(dataValue, dataKey) {
            filteringButtonData[dataKey] = dataValue;
        });
        return filteringButtonData;
    }

    getMapsButtons() {
        var self = this;


        return [
            {
                name: "mapLauncher",
                label: "Map",
                icon: "fas fa-globe-americas",
                color: "#f5f5f5",
                backgroundColor: "teal",
                loadingScreenSettings: {
                    message: "Loading Map...",
                    autoHide: false
                },
                callback: function (buttonManager) {
                    self.manager.wMapsMobileMapManager.tryShowBingMap();
                }
            },
            {
                name: "mapDirectionLauncher",
                label: "Directions",
                icon: "fas fa-globe",
                color: "#f5f5f5",
                backgroundColor: "forestgreen",
                loadingScreenSettings: {
                    message: "Loading Map...",
                    autoHide: false
                },
                callback: function (buttonManager) {
                    self.manager.wMapsMobileMapManager.tryShowBingMap(true);
                }
            }
        ];
    }
}
module.exports.wMapsMobileButtonsFactory = wMapsMobileButtonsFactory;

    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsMobileButtonsManager', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsMobileButtonsManager';
/*eslint-disable*/
class wMapsMobileButtonsManager {
    constructor(manager) {
        this.loadingScreenTimer = 500;
        this.allowedModules = ["Accounts", "Contacts", "Leads", "Opportunities"];
        this.manager = manager;
    }

    extendBaseCollectionFunctionality() {
        // var collection = this.manager.wMapsMobileUtils.getCollection();
        // var paginate = collection.paginate;
        // var screenContext = app.controller.getScreenContext();
        // var collFetch = collection.fetch;
        // var self = this;

        // if (!collection.fetchExtended) {
        //     collection.fetchExtended = true;
        //     collection.fetch = function fetchColl(options) {
        //         if (options && options.byPtr) {
        //             collection.uMapsFiltersApplied = false;

        //             self.manager.wMapsMobileUtils.getMobileButtonsManager().disableHorizontalButtons();
        //         }

        //         if (!collection.uMapsFiltersApplied || (options && options.byPtr)) {
        //             collFetch.call(collection, options);
        //         }
        //     };

        //     collection.paginate = function paginateCollection(options) {
        //         if (collection.uMapsFiltersApplied) {
        //             self.manager.wMapsMobileUtils.getMobileButtonsManager().showLoadingScreen({
        //                 message: "Filtering Records...",
        //                 autoHide: false
        //             });
        //             self.filterListView(false);
        //         } else {
        //             paginate.call(collection, options);
        //         }
        //     };
        // }

        // if (
        //     !collection.modelToFilterBy &&
        //     !collection.module_list &&
        //     !screenContext.modelId &&
        //     collection.module !== "Recents"
        // ) {
        //     collection.fetch();
        // }
    }

    addRecordToRoute() {
        var mainLayout = this.manager.wMapsMobileUtils.getMainLayout();
        if (mainLayout.model.get("gc_latitude_c") && mainLayout.model.get("gc_longitude_c") &&
            mainLayout.model.get("gc_latitude_c") != 0 && mainLayout.model.get("gc_longitude_c") != 0) {
            if (!app.mobile.directionsRouteCollection) {
                app.mobile.directionsRouteCollection = app.data.createBeanCollection();
            }

            if (app.mobile.directionsRouteCollection.has(mainLayout.model)) {
                var message = app.lang.get("WMAPS_LABEL_ALERT30");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            } else {
                var message = app.lang.get("WMAPS_LABEL_ALERT31");
                app.alert.show("uMaps-mobile-error", {
                    level: "info",
                    messages: message,
                    autoClose: true
                });
                app.mobile.directionsRouteCollection.add(mainLayout.model);
            }

            app.controller.trigger("wMaps-collection-route-changed");
        } else {
            var message = app.lang.get("WMAPS_LABEL_ALERT32");
            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: message,
                autoClose: true
            });
        }
    }

    removeRecordFromRoute() {
        var mainLayout = this.manager.wMapsMobileUtils.getMainLayout();
        if (app.mobile.directionsRouteCollection) {
            if (app.mobile.directionsRouteCollection.has(mainLayout.model)) {
                var message = app.lang.get("WMAPS_LABEL_ALERT33");
                app.alert.show("uMaps-mobile-error", {
                    level: "info",
                    messages: message,
                    autoClose: true
                });
                app.mobile.directionsRouteCollection.remove(mainLayout.model);
            } else {
                var message = app.lang.get("WMAPS_LABEL_ALERT34");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            }
        }

        app.controller.trigger("wMaps-collection-route-changed");
    }

    isFilteringButtonChecked(moduleToFilterBy) {
        var isChecked = true;
        var collection = this.manager.wMapsMobileUtils.getCollection();
        if (
            (collection.uMapsFiltersApplied &&
                collection.uMapsFiltersApplied.length > 0 &&
                collection.uMapsFiltersApplied.indexOf(moduleToFilterBy) < 0) ||
            (app.navigatedToSearchFilter &&
                collection.modelToFilterBy &&
                collection.modelToFilterBy.module !== moduleToFilterBy)
        ) {
            isChecked = false;
        }

        return isChecked;
    }

    getModelCoordinates(recordModel, filterDistance) {
        var self = this;
        app.api.call(
            "read",
            app.api.buildURL(recordModel.module + "/" + recordModel.id), {}, {
                success: function (response) {
                    if (response.gc_latitude_c) {
                        recordModel.set("gc_latitude_c", response.gc_latitude_c);
                        recordModel.set("gc_longitude_c", response.gc_longitude_c);
                        self.filterListView(filterDistance);
                    } else {
                        self.manager.wMapsMobileUtils
                            .getMobileButtonsManager()
                            .hideLoadingScreen(self.loadingScreenTimer);
                        var message = app.lang.get("WMAPS_LABEL_ALERT35");
                        app.alert.show("uMaps-mobile-error", {
                            level: "warning",
                            messages: message,
                            autoClose: true
                        });
                    }
                },
                error: function () {
                    self.manager.wMapsMobileUtils.getMobileButtonsManager().hideLoadingScreen(self.loadingScreenTimer);
                    var message = app.lang.get("WMAPS_LABEL_ALERT36");
                    app.alert.show("uMaps-mobile-error", {
                        level: "warning",
                        messages: message,
                        autoClose: true
                    });
                }
            }
        );
    }

    filterListView(filterDistance) {
        app.controller.showBackButton = true;
        var toSendLatitude = app.user.currentLocationLat;
        var toSendLongitude = app.user.currentLocationLng;
        var screenContext = app.controller.getScreenContext();
        var collection = this.manager.wMapsMobileUtils.getCollection();
        var self = this;

        if (!filterDistance) {
            filterDistance = this.uMapsFilterDistance;
        }

        if (collection.modelToFilterBy && !collection.modelToFilterBy.get("gc_latitude_c")) {
            this.getModelCoordinates(collection.modelToFilterBy, filterDistance);
            return false;
        }

        if (screenContext.modelId) {
            var mainLayout = this.manager.wMapsMobileUtils.getMainLayout();
            var recordModel = mainLayout.model;

            if (!screenContext.modelId && collection.modelToFilterBy) {
                recordModel = collection.modelToFilterBy;
            }

            if (!recordModel.get("gc_latitude_c")) {
                this.getModelCoordinates(recordModel, filterDistance);

                return false;
            }

            toSendLatitude =
                recordModel && recordModel.get("gc_latitude_c") ?
                recordModel.get("gc_latitude_c") :
                app.user.currentLocationLat;
            toSendLongitude =
                recordModel && recordModel.get("gc_longitude_c") ?
                recordModel.get("gc_longitude_c") :
                app.user.currentLocationLng;

            // var previousButtonsData = this.manager.wMapsMobileUtils
            //     .getMobileButtonsManager()
            //     .getEnabledHorizontalButtonsData();

            app.controller.navigate("#" + recordModel.module);
            collection = this.manager.wMapsMobileUtils.getCollection();
            collection.modelToFilterBy = recordModel;
            app.modelToFilterBy = recordModel;
            app.navigatedToSearchFilter = true;
            collection.uMapsFiltersApplied = false;
            screenContext = app.controller.getScreenContext();
            collection.abortFetchRequest();

            var collFetch = collection.fetch;
            if (!collection.alreadyExtended) {
                collection.alreadyExtended = true;
                collection.fetch = function fetchColl(options) {
                    if (options && options.byPtr) {
                        delete collection.modelToFilterBy;
                        delete app.modelToFilterBy;
                    }

                    collFetch.call(collection, options);
                };
            }

            var mobileButtonsManager = this.manager.wMapsMobileUtils.getMobileButtonsManager();
            mobileButtonsManager.destroyExistingButtons();
            this.manager.wMapAddDirectionsButton(mobileButtonsManager);
            mobileButtonsManager.cleanButtons();
            mobileButtonsManager.createMasterButtons();

            // this.manager.wMapsMobileUtils
            //     .getMobileButtonsManager()
            //     .setEnabledHorizontalButtonsData(previousButtonsData);
        }

        if (collection.modelToFilterBy && screenContext.root === "Search") {
            toSendLatitude =
                collection.modelToFilterBy && collection.modelToFilterBy.get("gc_latitude_c") ?
                collection.modelToFilterBy.get("gc_latitude_c") :
                app.user.currentLocationLat;
            toSendLongitude =
                collection.modelToFilterBy && collection.modelToFilterBy.get("gc_longitude_c") ?
                collection.modelToFilterBy.get("gc_longitude_c") :
                app.user.currentLocationLng;
        }

        if (toSendLatitude && toSendLongitude) {
            collection = this.manager.wMapsMobileUtils.getCollection();
            var filteredList = this.manager.wMapsMobileUtils.getFilteredListView();
            let distanceUnit = "miles";
            if (App.uMapsData) {
                if (!_.isEmpty(App.uMapsData["distanceUnitUser"])) {
                    distanceUnit = App.uMapsData["distanceUnitUser"];
                } else {
                    if (!_.isEmpty(App.uMapsData["distanceUnitSystem"]))
                        distanceUnit = App.uMapsData["distanceUnitSystem"];
                }
            }
            var customFilter = [{
                distance: {
                    $between: [
                        filterDistance,
                        {
                            currentLocationLat: toSendLatitude,
                            currentLocationLng: toSendLongitude
                        },
                        distanceUnit
                    ]
                }
            }];

            if (
                filteredList &&
                filteredList._list &&
                filteredList._list._currentState.filter
            ) {
                _.each(filteredList._list._currentState.filter, function addExistingFilters(existingFilter) {
                    customFilter.push(existingFilter);
                });
            }

            var offset = 0;

            if (collection.uMapsFiltersApplied) {
                offset = collection.models.length;
            }

            var recordsPerRequest = 50;
            var maxNum = offset + recordsPerRequest;

            var modulesToFilter = [];

            if (screenContext.root === "Search") {
                var recordsPerRequestSearch = 20;
                maxNum = offset + recordsPerRequestSearch;

                var buttonsData = this.manager.wMapsMobileUtils
                    .getMobileButtonsManager()
                    .getEnabledHorizontalButtonsData();
                var enabledModules = [];
                _.each(buttonsData, function getButtonData(buttonData) {
                    enabledModules.push(buttonData.module);
                });

                if (enabledModules.length === 0) {
                    enabledModules = this.allowedModules;
                }

                if (collection.uMapsFiltersApplied) {
                    collection.uMapsFiltersApplied = enabledModules;
                }

                _.each(enabledModules, function getModulesList(moduleName) {
                    if (modulesToFilter.indexOf(moduleName) < 0) {
                        modulesToFilter.push(moduleName);
                    }
                });
            } else {
                modulesToFilter.push(collection.module || screenContext.module);
            }
            this.getFilteredRecords(modulesToFilter, collection, customFilter, filterDistance, maxNum);
        } else {
            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: "Cannot access user location.",
                autoClose: true
            });
        }
    }

    getFilteredRecords(modulesToFilter, collection, customFilter, filterDistance, maxNum, alreadyFilteredRecords) {
        alreadyFilteredRecords = alreadyFilteredRecords || [];
        var self = this;
        var wMapsApiUrl = "";
        wMapsApiUrl = app.api.buildURL(modulesToFilter[0], "read", undefined, {
            //eslint-disable-next-line
            erased_fields: true,
            fields: "following,my_favorite,full_name,name",
            filter: customFilter,
            //eslint-disable-next-line
            max_num: -1,
            view: "list"
        });

        app.api.call("read", wMapsApiUrl, {}, null, {
            success: function callback(response) {
                if (response.records.length === 1 && response.records[0].name === "Not geocoded") {
                    var message = app.lang.get("WMAPS_LABEL_ALERT37");
                    app.alert.show("geocode-error", {
                        level: "warning",
                        messages: message,
                        autoClose: true
                    });
                    self.manager.wMapsMobileUtils.getMobileButtonsManager().hideLoadingScreen(self.loadingScreenTimer);
                } else {
                    response.records.push.apply(response.records, alreadyFilteredRecords);
                    self.uMapsFilterDistance = filterDistance;

                    response.records = response.records.sort(function sortRecords(a, b) {
                        return a.distance > b.distance ? 1 : b.distance > a.distance ? -1 : 0;
                    });

                    if (modulesToFilter.length === 1) {
                        collection.abortFetchRequest();
                        collection.reset(response.records, {});

                        _.each(collection.models, function addDistanceElement(newCollectionModel) {
                            var attributes = newCollectionModel.attributes;
                            var elItems = $('[data-id="' + attributes.id + '"]');
                            var elItem = false;
                            var screenContext = app.controller.getScreenContext();

                            _.each(elItems, function getCorrectElement(elementItem) {
                                var moduleElement = _.filter(
                                    elementItem.children[0].children,
                                    function getModuleElement(element) {
                                        return element.classList.value.indexOf("module-name") > -1;
                                    }
                                )[0];

                                if (
                                    (screenContext.root === "Search" && moduleElement) ||
                                    (screenContext.root !== "Search" && !moduleElement)
                                ) {
                                    elItem = elementItem;
                                }
                            });

                            if (elItem) {
                                var txtElement = _.filter(elItem.children, function getModuleElement(txtEl) {
                                    return txtEl.classList.value.indexOf("txt has-access") > -1;
                                })[0];

                                var fieldElement = _.filter(txtElement.children, function getModuleElement(element) {
                                    return element.classList.value.indexOf("fields") > -1;
                                })[0];

                                if (fieldElement) {
                                    var distanceUnit = "miles";
                                    var distanceUnitDisplay = "";
                                    if (App.uMapsData) {
                                        if (!_.isEmpty(App.uMapsData["distanceUnitUser"])) {
                                            distanceUnit = App.uMapsData["distanceUnitUser"];
                                        } else {
                                            if (!_.isEmpty(App.uMapsData["distanceUnitSystem"]))
                                                distanceUnit = App.uMapsData["distanceUnitSystem"];
                                        }
                                    }
                                    if (distanceUnit === "miles") {
                                        distanceUnitDisplay = "Miles";
                                    } else if (distanceUnit === "km") {
                                        distanceUnitDisplay = "Km";
                                    }

                                    fieldElement.id = "listViewItem" + attributes.id;
                                    $("#listViewItem" + attributes.id).append(
                                        "<br><div id='distanceWidget' style='font-weight:bold;float:right;margin-top:-15px'>Distance: " +
                                        attributes.distance + " " + distanceUnitDisplay +
                                        "</div>"
                                    );

                                    app.controller.trigger("addedItem-toListView", attributes);
                                }
                            }
                        });

                        var showMoreWidget = $(".show-more-btn.show-more-bottom-btn");
                        if (response.records.length === 0) {
                            $(".no-records-found").removeClass("hide");
                            showMoreWidget.addClass("hide");
                        }

                        if (response.next_offset === -1) {
                            showMoreWidget.addClass("hide");
                        } else {
                            showMoreWidget.removeClass("hide");
                        }

                        if (!collection.uMapsFiltersApplied) {
                            collection.uMapsFiltersApplied = [];
                        }

                        self.manager.wMapsMobileUtils
                            .getMobileButtonsManager()
                            .hideLoadingScreen(self.loadingScreenTimer);

                        var screenContext = app.controller.getScreenContext();
                        if (screenContext.root === "Search") {
                            self.manager.wMapsMobileUtils
                                .getMainLayout()
                                .getComponent("header")
                                .setConfig({
                                    back: true
                                });
                        }
                        var rootLayout = App.controller.layoutManager.getRootLayout();
                        var filteredList = rootLayout.getComponent("filtered-list");

                        if (filteredList && filteredList.getCurrentList) {
                            var currentList = filteredList.getCurrentList();
                            currentList.scroll.reflow()
                        }
                    } else {
                        modulesToFilter.splice(0, 1);
                        self.getFilteredRecords(
                            modulesToFilter,
                            collection,
                            customFilter,
                            filterDistance,
                            maxNum,
                            response.records
                        );
                    }
                }
            }.bind(this),
            error: function () {
                self.manager.wMapsMobileUtils.getMobileButtonsManager().hideLoadingScreen(self.loadingScreenTimer);
                var message = app.lang.get("WMAPS_LABEL_ALERT36");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            }
        });
    }

    filterRecordsCustomDistance(response) {
        if (response.input1 && !isNaN(response.input1)) {
            var customDistance = parseFloat(response.input1);
            var maxDistance = 250;

            if (customDistance < 0) {
                customDistance = 0;
                var message = app.lang.get("WMAPS_LABEL_ALERT38");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            } else if (customDistance > maxDistance) {
                customDistance = maxDistance;
                var message = app.lang.get("WMAPS_LABEL_ALERT38");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            }

            this.filterListView(customDistance);
        } else {
            this.manager.wMapsMobileUtils.getMobileButtonsManager().hideLoadingScreen(this.loadingScreenTimer);
            var message = app.lang.get("WMAPS_LABEL_ALERT39");
            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: message,
                autoClose: true
            });
        }
    }

    filterByModule(buttonsMaster) {
        var collection = this.manager.wMapsMobileUtils.getCollection();
        app.navigatedToSearchFilter = false;
        if (!collection.customFetchFunctionality) {
            collection.customFetchFunctionality = true;
            var collFetch = collection.fetch;

            collection.fetch = function fetchColl(options) {
                buttonsMaster.disableHorizontalButtons();
                collFetch.call(collection, options);
            };
        }

        if (collection.uMapsFiltersApplied) {
            collection.abortFetchRequest();
            this.filterListView(false);
        }
    }

    isCorrectContext() {
        var screenContext = app.controller.getScreenContext();

        return (
            (screenContext.root === "Search" && !screenContext.module) ||
            (screenContext.module && this.allowedModules.indexOf(screenContext.module) > -1 && !screenContext.action) ||
            (screenContext.link &&
                this.allowedModules.indexOf(screenContext.link.charAt(0).toUpperCase() + screenContext.link.slice(1)) >
                -1 &&
                !screenContext.action)
        );
    }

    getButtons() {
        var buttons = {};

        if (this.isCorrectContext()) {
            this.extendBaseCollectionFunctionality();

            buttons = this.manager.wMapsMobileButtonsFactory.getAllwMapsButtons();
        } else {
            var uMapsRouteCollectionView = _.filter(
                this.manager.wMapsMobileUtils.getMainLayout()._components,
                function getUMapsView(component) {
                    return component.uMapsRouteCollectionView === true;
                }
            )[0];

            if (uMapsRouteCollectionView) {
                buttons = this.manager.wMapsMobileButtonsFactory.getMapsButtons();
            }
        }

        return buttons;
    }
}

module.exports.wMapsMobileButtonsManager = wMapsMobileButtonsManager;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsMobileMapManager', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsMobileMapManager';
/*eslint-disable*/
class wMapsMobileMapManager {
    constructor(manager) {
        this.allowedModules = ["Accounts", "Contacts", "Leads", "Opportunities"];
        this.loadingScreenTimer = 500;

        this.manager = manager;

        this.getMicrosoftBingMap();
        this.getCurrentUserPosition();
    }

    getCurrentUserPosition() {
        var getCurrentUserPositionTimer = 1000;
        navigator.geolocation.getCurrentPosition(function storePosition(locationData) {
            app.user.currentLocationLat = locationData.coords.latitude;
            app.user.currentLocationLng = locationData.coords.longitude;
        });

        setTimeout(this.getCurrentUserPosition, getCurrentUserPositionTimer);
    }

    getMicrosoftBingMap() {
        var timeout = 1000;
        var mapsLoadedCallback = function () {
            SUGAR.bingMapsModuleLoaded = true;
            if (Microsoft && Microsoft.Maps && Microsoft.Maps.loadModule) {
                Microsoft.Maps.loadModule("Microsoft.Maps.Directions", function directionsModuleLoaded() {
                    SUGAR.bingMapsDirectionsModuleLoaded = true;
                });
            } else {
                setTimeout(this.getMicrosoftBingMap, timeout);
            }
        };

        if (SUGAR.bingMapsModuleLoaded && !SUGAR.bingMapsDirectionsModuleLoaded) {
            mapsLoadedCallback();
        }

        if (!SUGAR.bingMapsModuleLoaded && !SUGAR.bingMapsFetchInProgress) {
            SUGAR.bingMapsFetchInProgress = true;
            var microsoftMapsUrl =
                "https://www.bing.com/api/maps/mapcontrol?key=AuIEmeKGjvNV037yKiYGV0B3cxqNmx6FWnode0Hj8tjQPjK1zJP-7GAESccoCDUA";
            var fileref = false;
            var head = false;

            fileref = document.createElement("script");
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", microsoftMapsUrl);

            if (typeof fileref != "undefined") {
                head = document.getElementsByTagName("head")[0];
            }

            if (head) {
                fileref.onreadystatechange = mapsLoadedCallback;
                fileref.onload = mapsLoadedCallback;

                head.appendChild(fileref);
            }
        }
    }

    tryShowBingMap(showDirections) {
        var self = this;
        var fromRecord = false;
        var requests = [];
        var bulkURL = app.api.buildURL("bulk");
        var collection = this.manager.wMapsMobileUtils.getCollection();
        var screenContext = app.controller.getScreenContext();

        if (screenContext.modelId) {
            fromRecord = true;
        }

        if (fromRecord) {
            requests.push({
                url: "/v10/" + screenContext.module + "/" + screenContext.modelId,
                method: "GET"
            });
        } else {
            _.each(
                collection.models,
                function buildRequests(model) {
                    if (this.allowedModules.indexOf(model.module) > -1) {
                        requests.push({
                            url: "/v10/" + model.module + "/" + model.id,
                            method: "GET"
                        });
                    }
                },
                this
            );
        }


        app.api.call(
            "create",
            bulkURL, {
                requests: requests
            }, {
                success: function (response) {
                    var allRecordsGeocoded = true;
                    var newCollection = [];

                    _.each(response, function getValidRecords(record) {
                        var model = record.contents;
                        if (model.gc_latitude_c && model.gc_longitude_c) {
                            var modelName = model.name;

                            if (!modelName) {
                                modelName = model.full_name;
                            }
                            
                            newCollection.push({
                                module: model._module,
                                id:model.id,
                                name: modelName,
                                latitude: model.gc_latitude_c,
                                longitude: model.gc_longitude_c,
                                street: model.billing_address_street,
                                city: model.billing_address_city,
                                state: model.billing_address_state,
                                postalcode: model.billing_address_postalcode,
                                country: model.billing_address_country
                            });
                        } else {
                            allRecordsGeocoded = false;
                        }
                    });

                    if (!allRecordsGeocoded && newCollection.length > 0) {
                        var message = app.lang.get("WMAPS_LABEL_ALERT24");
                        app.alert.show("uMaps-mobile-error", {
                            level: "warning",
                            messages: message,
                            autoClose: true
                        });
                    }

                    if (showDirections) {
                        self.showGoogleMaps(newCollection, showDirections, fromRecord);
                    } else {
                        self.showBingMap(newCollection, showDirections, fromRecord);
                    }
                },
                error: function () {
                    self.manager.wMapsMobileUtils.getMobileButtonsManager().hideLoadingScreen(self.loadingScreenTimer);
                    var message = app.lang.get("WMAPS_LABEL_ALERT25");
                    app.alert.show("uMaps-mobile-error", {
                        level: "warning",
                        messages: message,
                        autoClose: true
                    });
                }
            }
        );
    }

    showGoogleMaps(newCollection, showDirections, fromRecord) {
        var self = this;
        var openGoogleMap = function (newCollection, showDirections, fromRecord) {
            var urlToOpen = "https://www.google.com/maps/dir";
            if (fromRecord) {
                if (newCollection && newCollection.length > 0) {
                    urlToOpen =
                        "http://maps.google.com/?saddr=" +
                        app.user.currentLocationLat +
                        "," +
                        app.user.currentLocationLng +
                        "&daddr=" +
                        newCollection[0].latitude +
                        "," +
                        newCollection[0].longitude;

                } else {
                    var message = app.lang.get("WMAPS_LABEL_ALERT26");
                    app.alert.show("uMaps-mobile-error", {
                        level: "warning",
                        messages: message,
                        autoClose: true
                    });
                }
            } else {
                var sourceLatitude = app.user.currentLocationLat;
                var sourceLongitude = app.user.currentLocationLng;

                if (app.modelToFilterBy) {
                    var collection = self.manager.wMapsMobileUtils.getCollection();

                    var recordModel = collection.models[0];
                    sourceLatitude =
                        recordModel && recordModel.get("gc_latitude_c") ?
                            recordModel.get("gc_latitude_c") :
                            app.user.currentLocationLat;
                    sourceLongitude =
                        recordModel && recordModel.get("gc_longitude_c") ?
                            recordModel.get("gc_longitude_c") :
                            app.user.currentLocationLng;
                }

                urlToOpen = urlToOpen + "/" + sourceLatitude + "," + sourceLongitude;
                //newCollection = self.manager.wMapsMobileUtils.getOptimRoadUsingTSPAlgorithm(newCollection);

                var destinationsNumber = 0;
                var maxDestinationsNumber = 9;

                _.each(newCollection, function buildUrl(recordData) {
                    if (destinationsNumber < maxDestinationsNumber) {
                        if (destinationsNumber > 0) {
                            urlToOpen = urlToOpen + "/" + recordData.latitude + "," + recordData.longitude;
                        }

                        destinationsNumber = destinationsNumber + 1;
                    }
                });
            }

            SUGAR.customizationTools.deviceFeatures.openUrl(encodeURI(urlToOpen), {
                encode: true
            });
        };
        this.openMap(newCollection, showDirections, fromRecord, openGoogleMap);
    }

    showBingMap(newCollection, showDirections, fromRecord) {
        var self = this;
        var openBingMap = function (newCollection, showDirections, fromRecord) {
            if (Microsoft) {
                SUGAR.mobile.loadView("uMaps-mobile", {
                    isDynamic   : true,
                    skipRegistration: true
                });

                var uMapsView = _.filter(
                    self.manager.wMapsMobileUtils.getMainLayout()._components,
                    function getUMapsView(component) {
                        return component.uMapsView === true;
                    }
                )[0];

                if (newCollection && newCollection.length > 0) {
                    uMapsView.generateMap(newCollection, showDirections, fromRecord);
                } else {
                    var message = app.lang.get("WMAPS_LABEL_ALERT26");
                    app.alert.show("uMaps-mobile-error", {
                        level: "warning",
                        messages: message,
                        autoClose: true
                    });
                }
            } else if (!Microsoft || !SUGAR.bingMapsDirectionsModuleLoaded) {
                var message = app.lang.get("WMAPS_LABEL_ALERT27");
                app.alert.show("uMaps-mobile-error", {
                    level: "warning",
                    messages: message,
                    autoClose: true
                });
            }
        };
        this.openMap(newCollection, showDirections, fromRecord, openBingMap);
    }

    openMap(newCollection, showDirections, fromRecord, callback) {
        var mobileButtonsManager = this.manager.wMapsMobileUtils.getMobileButtonsManager();
        mobileButtonsManager.hideLoadingScreen(this.loadingScreenTimer);

        if (((app.user.currentLocationLat && app.user.currentLocationLng) || fromRecord) && newCollection) {
            callback(newCollection, showDirections, fromRecord);
        }

        if ((!app.user.currentLocationLat || !app.user.currentLocationLng) && !fromRecord) {
            var message = app.lang.get("WMAPS_LABEL_ALERT28");
            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: message,
                autoClose: true
            });
            mobileButtonsManager.hideLoadingScreen(loadingScreenTimer);
        }

        if (!newCollection) {
            var message = app.lang.get("WMAPS_LABEL_ALERT29");
            app.alert.show("uMaps-mobile-error", {
                level: "warning",
                messages: message,
                autoClose: true
            });
            mobileButtonsManager.hideLoadingScreen(loadingScreenTimer);
        }
    }
}

module.exports.wMapsMobileMapManager = wMapsMobileMapManager;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsContextButtons', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsContextButtons';
/*eslint-disable*/
class wMapsContextButtons {
    constructor() {
        this.handleSystemChanges();

        this.getRequired("wMapsMobileButtonsManager");
        this.getRequired("wMapsMobileUtils");
        this.getRequired("wMapsMobileButtonsFactory");
        this.getRequired("wMapsMobileButtonsVisibility");
        this.getRequired("wMapsMobileMapManager");

        app.controller.on("mobile-context-changed", this.wMapAddDirectionsButton.bind(this));
        app.mobile.wMapsContextButtons = this;
    }

    getRequired(className) {
        var requiredClass = window.require("src/wsystems/mobile/include/require/" + className)[className];
        this[className] = new requiredClass(this);
    }

    handleSystemChanges() {
        var syncAppFn = app.nomad.syncApp;
        var self = this;
        var loadingScreenTimer = 500;

        app.nomad.syncApp = function syncApp() {
            var buttonsManager = self.wMapsMobileUtils.getMobileButtonsManager();
            buttonsManager.destroyExistingButtons();
            buttonsManager.hideLoadingScreen(loadingScreenTimer);

            syncAppFn.apply(this);
        };

        var appAlertShowFn = app.alert.show;

        app.alert.show = function showAlert(...args) {
            if (arguments[1] &&
                arguments[1].messages &&
                arguments[1].messages.indexOf &&
                arguments[1].messages.indexOf("FATAL") > -1) {
                var buttonsManager = self.wMapsMobileUtils.getMobileButtonsManager();
                buttonsManager.hideLoadingScreen(loadingScreenTimer);
            }

            appAlertShowFn.apply(this, args);
        };
    }

    wMapAddDirectionsButton(mobileButtonsManager) {
        var uMapsButtons = this.wMapsMobileButtonsManager.getButtons();
        mobileButtonsManager.registerMobileButtons(uMapsButtons);
    }
}

module.exports.wMapsContextButtons = wMapsContextButtons;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsMobileUtils', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsMobileUtils';
/*eslint-disable*/
class wMapsMobileUtils {
    constructor(manager) {
        this.manager = manager;
    }

    getMobileButtonsManager() {
        return SUGAR.customizationTools.mobileButtonsManager;
    }

    getMainLayout() {
        var mainLayout = app.controller.layoutManager.getRecordLayout();

        if (!mainLayout) {
            mainLayout = app.controller.layoutManager.getRootLayout();
        }

        return mainLayout;
    }

    getCollection() {
        var screenContext = app.controller.getScreenContext();
        var collection = this.getMainLayout().collection;

        if (screenContext.root === "Search" && !screenContext.module && !screenContext.dashletId) {
            var globalSearch = this.getMainLayout().getComponent("global-search");
            if (globalSearch && globalSearch.getCurrentList) {
                collection = globalSearch.getCurrentList().collection;
            }
        }

        return collection;
    }

    getFilteredListView() {
        var filteredList = _.filter(this.getMainLayout()._components, function getFilterListView(component) {
            return component.name === "filtered-list";
        })[0];

        return filteredList;
    }

    getOptimRoadUsingTSPAlgorithm(pointsArray) {
        POPULATION_SIZE = pointsArray.length;
        ELITE_RATE = 0.3;
        CROSSOVER_PROBABILITY = 0.9;
        MUTATION_PROBABILITY = 0.01;
        UNCHANGED_GENS = 0;

        mutationTimes = 0;
        currentGeneration = 0;

        running = false;
        doPreciseMutate = true;
        bestValue = undefined;

        currentBest = {};
        best = [];
        population = [];

        values = new Array(POPULATION_SIZE);
        fitnessValues = new Array(POPULATION_SIZE);
        roulette = new Array(POPULATION_SIZE);

        var points = pointsArray;

        if (POPULATION_SIZE > 2) {
            GAInitialize();

            running = true;

            for (var t = 0; t < 1000; t++) {
                if (UNCHANGED_GENS < 30) {
                    GANextGeneration();
                } else {
                    break;
                }
            }

            var correct_order = [];
            if (best.length > 0) {
                for (var x = 0; x < best.length; x++) {
                    correct_order.push(points[best[x]]);
                }
                return correct_order;
            }
        }
        return pointsArray;
    }
}

module.exports.wMapsMobileUtils = wMapsMobileUtils;

    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMapsMobileButtonsVisibility', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMapsMobileButtonsVisibility';
/*eslint-disable*/
class wMapsMobileButtonsVisibility {
    constructor(manager) {
        this.manager = manager;
    }

    canShowRemoveFromRouteButton() {
        var mainLayout = this.manager.wMapsMobileUtils.getMainLayout();
        return app.mobile.directionsRouteCollection && app.mobile.directionsRouteCollection.has(mainLayout.model);
    }

    canShowAddToRouteButton() {
        var mainLayout = this.manager.wMapsMobileUtils.getMainLayout();
        return (
            (app.mobile.directionsRouteCollection && !app.mobile.directionsRouteCollection.has(mainLayout.model)) ||
            !app.mobile.directionsRouteCollection
        );
    }

    canShowManageRouteButton() {
        return app.mobile.directionsRouteCollection && app.mobile.directionsRouteCollection.length > 0;
    }

    canShowRouteButton() {
        var canShow = true;

        var screenContext = app.controller.getScreenContext();

        if (
            !screenContext.modelId &&
            (!app.mobile.directionsRouteCollection || app.mobile.directionsRouteCollection.length < 1)
        ) {
            canShow = false;
        }

        return canShow;
    }

    canShowFilterModuleButton() {
        var collection = this.manager.wMapsMobileUtils.getCollection();

        return collection.uMapsFiltersApplied;
    }
}

module.exports.wMapsMobileButtonsVisibility = wMapsMobileButtonsVisibility;

    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMobileApp/wMobileDashletLoader', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMobileApp/wMobileDashletLoader';
/* eslint-disable require-jsdoc */
let _baseFilePath = "src/wsystems/mobile/include/require/wMobileApp/";
let _baseClassName = "wMobileEntityLoader";
let wMobileEntityLoader = window.require(_baseFilePath + _baseClassName)[_baseClassName];

class wMobileDashletLoader extends wMobileEntityLoader {
    constructor(wMobileBootLoader) {
        super(wMobileBootLoader);

        this.BASE_ENTITY = SUGAR.mobile.getDashlet("base-dashlet");
        this.ENTITY_TYPE = "Dashlet";
    }

    extend(baseType, extensionData) {
        let _baseEntity = SUGAR.mobile.getDashlet(baseType);

        Object.assign(_baseEntity.prototype, extensionData);
    }

    loadBaseEntity(data, name, baseEntity) {
        let _entityName = this.getEntityName(name);
        let _globalName = this.getGlobalName(_entityName);

        let _customEntity = this.wMobileBootLoader.customizationTools.customization.extend(baseEntity, data.controller);

        _customEntity = this.addTemplateToEntity(_customEntity, data, name);

        this.wMobileBootLoader.customizationTools.customization.register(_customEntity, {
            metadataType: name
        });

        if (data.controller.icon) {
            app.config.ui.icons.dashlets[name] = data.controller.icon;
        }

        this.applyExtensions(name);
        app.mobile.dashlets[_globalName] = SUGAR.mobile.getDashlet(name);
    }

    addTemplateToEntity(customEntity, data, name) {
        let _templateName = this.getTemplateName(name);
        let _customEntity = customEntity;

        _customEntity = this.wMobileBootLoader.customizationTools.customization.extend(_customEntity, {
            initialize: function (options) {
                options.module = "About";

                var initResult = this._super("initialize", arguments);

                if (data.templates[name]) {
                    this.template = Handlebars.templates[_templateName];
                }

                this.loadStyles();

                return initResult;
            },

            loadStyles: function () {
                _.each(SUGAR.mobile.dashlets[name].styles, function loadStyle(styleCss, styleKey) {
                    if (!app.mobile.styles[styleKey]) {
                        app.mobile.styles[styleKey] = true;
                        $("head").append("<style type='text/css'>" + styleCss + "</style>");
                    }
                });
            }
        });

        if (data.templates[name] && !Handlebars.templates[_templateName]) {
            Handlebars.templates[_templateName] = Handlebars.compile(data.templates[name]);
        } 

        return _customEntity;
    }
    
    loadExtendedEntity(data, name) {
        let _parentData = data.controller.extendsFrom;
        let _parentType = _parentData.baseType;

        let _baseEntity = SUGAR.mobile.getDashlet(_parentType);

        if (_baseEntity) {
            this.loadBaseEntity(data, name, _baseEntity);
        }
    }
}
module.exports.wMobileDashletLoader = wMobileDashletLoader;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMobileApp/wMobileRouteHandler', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMobileApp/wMobileRouteHandler';
/* eslint-disable require-jsdoc */
class wMobileRouteHandler {
    constructor(wMobileBootLoader) {
        this.wMobileBootLoader = wMobileBootLoader;
        
        this.MOBILE = "Mobile";
        this.VIEW = "View";

        SUGAR.mobile.loadView = this.goToView.bind(this);
    }

    goToView(name, entityParams) {
        let _cleanedEntityParams = entityParams ? entityParams : {};
        let _entityName = this.getEntityName(name);
        let _globalEntityName = this.getGlobalName(name);
        let _viewToLoad = app.mobile.views[_globalEntityName];

        if (!_viewToLoad) {
            _globalEntityName = _entityName;
            _viewToLoad = app.mobile.views[_globalEntityName] || app.nomad.getViewClass(name);
            if (!_viewToLoad) {
                app.alert.show("wMobileApp-view-load-error", {
                    level     : "warning",
                    messages  : "The view: " + name + " cannot be loaded.",
                    autoClose : true
                });
                return false;
            }
        }

        if (!_cleanedEntityParams.skipRegistration) {
            let _currentUrl = app.navigation.manager.getCurrentStep().url;
            this.registerStepInHistory(_currentUrl);
        }

        _cleanedEntityParams["view"] = _viewToLoad;

        let _loadedView = app.controller.loadScreen(_cleanedEntityParams)[0];
        // set cached on false so that the layout gets disposed every time when leaving the screen
        _loadedView.layout.cached = false;

        //notifyButtonsChange
        SUGAR.customizationTools.mobileButtonsManager.handleViewChange();

        return _loadedView;
    }

    registerStepInHistory(url) {
    // this is a function that needs to be called if you navigate to another screen
    // simply call this to store the start page url in history so that you could go back to it
        var historyParams = {
            initiator: {
                name: "GENERIC"
            },
            url: url
        };
        historyParams = _.extend(historyParams, app.navigation.manager._getUrlInfo(historyParams.url));
        historyParams = _.extend({}, historyParams, {
            id             : ++app.navigation.manager._seedId,
            replaceCurrent : false
        });

        const upStepParams = app.navigation.manager._getUpStepParams(historyParams);

        _.extend(historyParams, upStepParams);

        app.navigation.history._previous = app.navigation.history._current;
        app.navigation.history._steps.push(app.navigation.history._current);
        app.navigation.history._current = _.omit(historyParams, "replaceCurrent");
        app.navigation.history._syncBrowserHistory();
    }

    routeRegisterView(globalViewName, templateName) {
        var self = this;

        let _viewRoute = {
            name  : templateName,
            steps : globalViewName,
            handler() {
                self.goToView(globalViewName);
            }
        };

        this.wMobileBootLoader.customizationTools.customization.registerRoutes([_viewRoute]);
    }

    reloadLoginView() {
        let _currentScreen = app.controller.getScreenContext();

        // reload current view
        if (_currentScreen.root === undefined) {
            app.controller.clean({
                disposeAll: true
            });

            app.controller.loadScreen({
                context: new app.Context({
                    module: "Login"
                }).prepare(),
                view: app.nomad.getViewClass("login")
            });
        } else {
            app.controller.navigate("#Search");
        }
    }

    getEntityName(name) {
        return (name.charAt(0).toUpperCase() + name.slice(1)).replace(/-/g, "");
    }

    getGlobalName(name) {
        return this.MOBILE + this.getEntityName(name) + this.VIEW;
    }
}
module.exports.wMobileRouteHandler = wMobileRouteHandler;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMobileApp/wMobileFieldLoader', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMobileApp/wMobileFieldLoader';
/* eslint-disable require-jsdoc */
let _baseFilePath = "src/wsystems/mobile/include/require/wMobileApp/";
let _baseClassName = "wMobileEntityLoader";
let wMobileEntityLoader = window.require(_baseFilePath + _baseClassName)[_baseClassName];

class wMobileFieldLoader extends wMobileEntityLoader {
    constructor(wMobileBootLoader) {
        super(wMobileBootLoader);

        this.BASE_ENTITY = app.view.NomadField;
        this.ENTITY_TYPE = "Field";
    }

    extend(baseType, extensionData) {
        let _baseEntity = app.nomad.getFieldClass({
            baseType: baseType
        });

        let _customEntity = app.nomad.extendComponent(_baseEntity, extensionData, undefined);

        app.nomad.registerComponent({
            cmp      : _customEntity,
            baseType : baseType
        });
    }

    loadBaseEntity(data, name, baseEntity) {
        let _customField = this.wMobileBootLoader.customizationTools.customization.extend(baseEntity, data.controller);

        this.wMobileBootLoader.customizationTools.customization.register(_customField, {
            metadataType: name
        });

        this.registerEntityTemplates(data.templates, name);
        this.applyExtensions(name);

        app.mobile.fields[this.getGlobalName(name)] = app.nomad.getFieldClass({
            baseType: name
        });
    }

    registerEntityTemplates(templates, name) {
        _.each(templates, function registerTemplate(templateData, templateName) {
            Handlebars.templates["f." + name + "." + templateName] = Handlebars.compile(templateData);
        });
    }

    loadExtendedEntity(data, name) {
        let _parentData = data.controller.extendsFrom;
        let _parentType = _parentData.baseType;
        let _moduleType = _parentData.module ? _parentData.module : "";

        let _baseFieldClass = app.nomad.getFieldClass({
            baseType            : _parentType,
            module              : _moduleType,
            shouldReturnDefault : true
        });

        if (_baseFieldClass) {
            this.loadBaseEntity(data, name, _baseFieldClass);
        }
    }
}
module.exports.wMobileFieldLoader = wMobileFieldLoader;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMobileApp/wMobileViewLoader', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMobileApp/wMobileViewLoader';
/* eslint-disable require-jsdoc */
let _baseFilePath = "src/wsystems/mobile/include/require/wMobileApp/";
let _baseClassName = "wMobileEntityLoader";
let MobileEntityLoader = window.require(_baseFilePath + _baseClassName)[_baseClassName];

class wMobileViewLoader extends MobileEntityLoader {
    constructor(wMobileBootLoader) {
        super(wMobileBootLoader);

        this.BASE_ENTITY = wMobileBootLoader.customizationTools.nomadView;
        this.ENTITY_TYPE = "View";
    }

    extend(baseType, extensionData) {
        let _baseEntityData = app.nomad._getComponentViewCache()[baseType];
        let _targetModules = [];

        if (_baseEntityData 
            && _baseEntityData.custom.length > 0 
            && (extensionData.extendsFrom.module === undefined || extensionData.extendsFrom.module === "")) {
            _.each(_baseEntityData.custom, function getExtendedModules(moduleData) {
                _targetModules.push(moduleData.filter.module);
            });
        }

        _targetModules.push(extensionData.extendsFrom.module);

        _.each(_targetModules, function applyExtension(moduleName) {
            let _baseClass = app.nomad.getViewClass({
                baseType : baseType,
                module   : moduleName
            });

            if (_baseClass) {
                let _customEntity = app.nomad.extendComponent(_baseClass, extensionData, undefined);

                app.nomad.registerComponent({
                    cmp      : _customEntity,
                    baseType : baseType,
                    module   : moduleName
                });

                extensionData.applied = true;
            } 
        });
    }

    loadBaseEntity(data, name, baseClass, entityName, moduleType, baseType) {
        // extend base type if there is any extension to that entity
        baseClass = this.extendClass(baseType, baseClass);

        var customMobileEntity = app.nomad.extendComponent(baseClass, data.controller, undefined);

        // extend the current view
        customMobileEntity = this.extendClass(name, customMobileEntity);

        app.mobile.views[this.getGlobalName(entityName)] = this.addTemplateToEntity(
            customMobileEntity,
            data,
            name,
            moduleType
        );

        this.wMobileBootLoader.wMobileRouteHandler.routeRegisterView(
            this.getGlobalName(entityName), this.getTemplateName(name)
        );

        this.applyExtensions(name);
        this.wMobileBootLoader.customizationTools.customization.register(app.mobile.views[this.getGlobalName(entityName)], {
            baseType: name
        });
    }

    addTemplateToEntity(mobileEntity, data, name, moduleType) {
        let _templateName = this.getTemplateName(name);

        var baseInitFn = mobileEntity.prototype.initialize;

        mobileEntity = mobileEntity.extend({
            initialize: function (options) {
                if (moduleType !== "") {
                    options.module = moduleType;
                }

                if (!options.module) {
                    options.module = "About";
                }

                let _initResult = baseInitFn.call(this, options);

                if (data.templates[name]) {
                    this.template = Handlebars.templates[_templateName];
                }

                this.loadStyles();

                return _initResult;
            },

            loadStyles: function () {
                _.each(SUGAR.mobile.views[name].styles, function loadStyle(styleCss, styleKey) {
                    if (!app.mobile.styles[styleKey]) {
                        app.mobile.styles[styleKey] = true;
                        $("head").append("<style type='text/css'>" + styleCss + "</style>");
                    }
                });
            }
        });

        if (data.templates[name]) {
            mobileEntity.prototype.template = _templateName;

            if (!Handlebars.templates[_templateName]) {
                Handlebars.templates[_templateName] = Handlebars.compile(data.templates[name]);
            }
        }

        if (!mobileEntity.prototype.headerConfig) {
            mobileEntity.prototype.headerConfig = {};
        }
        _.each(data.controller.headerConfig, function addHeaderConfig(headerOptionValue, headerOptionName) {
            mobileEntity.prototype.headerConfig[headerOptionName] = headerOptionValue;
        });

        return mobileEntity;
    }

    loadExtendedEntity(data, name, entities) {
        let _entities = entities;
        let _globalViewName = this.getGlobalName(name);

        // check if the view exists already
        if (!app.mobile.views[_globalViewName]) {
            let _parentData = data.controller.extendsFrom;
            let _parentType = _parentData.baseType;
            let _moduleType = _parentData.module ? _parentData.module : "";

            // try getting the base class from the sugar framework
            let baseEntityClass = app.nomad.getViewClass({
                baseType : _parentType,
                module   : _moduleType
            });

            // try getting the base class from the sugar sdk
            if (baseEntityClass === undefined) {
                baseEntityClass = SUGAR.mobile.getView(_parentType);
            }

            // try getting the base class from our custom classes
            if (baseEntityClass === undefined) {
                let _parentEntityName = this.getEntityName(_parentType);
                let _parentTypeName = this.getGlobalName(_parentEntityName);

                baseEntityClass = app.mobile.views[_parentTypeName];

                // try getting the base class from our custom classes that have not been created yet
                if (baseEntityClass === undefined && _entities[_parentEntityName]) {
                    this.loadExtendedEntity(_entities[_parentEntityName].data, _parentType, _entities);

                    baseEntityClass = app.mobile.views[_parentTypeName];
                }

                if (data.templates[name] === undefined && _.isObject(SUGAR.mobile.views[_parentType]) === true) {
                    data.templates[name] = SUGAR.mobile.views[_parentType].templates[_parentType];
                }
            }

            if (baseEntityClass) {
                this.loadBaseEntity(data, name, baseEntityClass, this.getEntityName(name), _moduleType, _parentType);
            }
        }
    }

    extendClass(baseType, baseClass) {
        _.each(SUGAR.mobile.extensions, function goThroughExtensions(extensionData) {
            if (extensionData.extendsFrom.baseType === baseType && !extensionData.applied) {
                var customMobileEntity = app.nomad.extendComponent(baseClass, extensionData, undefined);

                app.nomad.registerComponent({
                    cmp      : customMobileEntity,
                    baseType : baseType
                });

                baseClass = customMobileEntity;
                extensionData.applied = true;
            }
        });

        return baseClass;
    }
}
module.exports.wMobileViewLoader = wMobileViewLoader;
    }
},
{'requireName': 'src/wsystems/mobile/include/require/wMobileApp/wMobileEntityLoader', 'functionName': function(module, require) {
    module.name = 'src/wsystems/mobile/include/require/wMobileApp/wMobileEntityLoader';
/* eslint-disable require-jsdoc */
class wMobileEntityLoader {
    constructor(wMobileBootLoader) {
        this.wMobileBootLoader = wMobileBootLoader;

        this.ENTITY_TYPE = "Entity";
        this.MOBILE = "Mobile";
    }
    
    extend() {}

    load(entities) {
        var _extendedEntities = {};

        _.each(
            entities,
            function handleEntity(data, name) {
                let _entityName = this.getEntityName(name);
                
                let _complexEntity = this.loadEntity(name, data, _entityName);

                if (_complexEntity) {
                    _extendedEntities[_entityName] = _complexEntity;
                }
            },
            this
        );

        this.loadExtendedEntities(_extendedEntities);
    }

    loadEntity(name, data, entityName) {
        if (this.extendsBaseEntity(data)) {
            return {
                data : data,
                name : name
            };
        } else {
            this.loadBaseEntity(
                data,
                name,
                this.BASE_ENTITY,
                entityName,
            );
        }

        return false;
    }

    loadBaseEntity() {}

    loadExtendedEntities(entities) {
        let _entities = entities;

        _.each(
            entities,
            function handleEntity(data, name) {
                this.loadExtendedEntity(data.data, data.name, _entities);
            },
            this
        );
    }

    loadExtendedEntity() {}

    applyExtensions(name) {
        _.each(SUGAR.mobile.extensions, function getExtensionData(extensionData){
            if (extensionData.extendsFrom.baseType === name) {
                this.extend(name, extensionData);
            }
        }, this);
    }

    extendsBaseEntity(data) {
        return typeof data.controller.extendsFrom === "object";
    }

    getEntityName(name) {
        return (name.charAt(0).toUpperCase() + name.slice(1)).replace(/-/g, "");
    }

    getGlobalName(name) {
        return this.MOBILE + this.getEntityName(name) + this.ENTITY_TYPE;
    }

    getTemplateName(name) {
        return this.MOBILE.charAt(0).toLowerCase() + this.MOBILE.slice(1) + "-" + this.getEntityName(name) + "-" + this.ENTITY_TYPE.charAt(0).toLowerCase() + this.ENTITY_TYPE.slice(1);
    }
}
module.exports.wMobileEntityLoader = wMobileEntityLoader;
    }
},
{'requireName': 'custom/clients/mobile/views/user-profiles/user-profiles', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/user-profiles/user-profiles';
/**
 * Class Description
 *
 * @class user-profiles
 */
({
    headerConfig: {
        title    : "User Profiles", // title that is going to be displayed on the header when the view is on screen
        back     : true, // show the back button in the header of the view
        mainMenu : false // show the main menu button in the header of the view
    },

    events() {
        return {
            "click #addProfile": "createUserProfile" // we can register events here
        };
    },

    render(options) {
        let _result = this._super("render", arguments);

        this._initProperties();
        this._loadProfiles();

        return _result;
    },
    
    createUserProfile(ev, profileId, profileData) {
        var profileElement = app.view.createView({
            name    : app.mobile.views.MobileUserprofileView,
            model   : this.model,
            context : this.context,
            manager : this,
        });

        if (typeof profileId === "string") {
            profileElement.fillProfile(profileId, profileData);
        }

        profileElement.render();

        this.$el.find(this.USER_PROFILES_CONTAINER).append(profileElement.$el);
    },

    updateProfileData(profileId, profileData) {
        this._profiles[profileId] = profileData;

        window.localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(this._profiles));
    },

    chooseProfile(profileId) {
        _.each(this._profiles, function createProfile(profileData, profId){
            this._profiles[profId].inUse = false;
        }, this);

        this._profiles[profileId].inUse = true;

        window.localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(this._profiles));

        const settings = {
            loginUrl  : this._profiles[profileId].url,
            loginName : this._profiles[profileId].user,
        };

        app.loginManager.applyLoginSettings(app.loginManager.setTempSetting(settings));

        app.loginManager.verifyLoginSettings((errorCode, error) => {
            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSO_NOT_SUPPORTED
            ) {
                app.error.handleExternalLoginNotAvailable();
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSL_NOT_SUPPORTED
            ) {
                app.alert.show("invalid_login_settings", {
                    level     : "error",
                    messages  : app.lang.get("ERR_MOBILE_HTTPS_CONNECTION_FAILED_LOGIN"),
                    autoClose : true,
                });
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.SSL_AVAILABLE
            ) {
                
                app.alert.show("invalid_login_settings", {
                    level     : "error",
                    messages  : app.lang.get("ERR_MOBILE_HTTP_CONNECTION_FAILED_LOGIN"),
                    autoClose : true,
                });
            }

            if (
                // eslint-disable-next-line no-bitwise
                errorCode & app.loginManager.LoginSettingsErrorCode.OTHER_HTTP_ERROR
            ) {
                app.error.handleHttpError(error);
            }

            this.trigger("settings:submit");
            this.layout._header.onBackClicked();
        });

    },

    _loadProfiles() {
        _.each(this._profiles, function createProfile(profileData, profileId){
            this.createUserProfile(false, profileId, profileData);
        }, this);
    },

    _initProperties() {
        this._profiles = {};
        this.USER_PROFILES_CONTAINER = "#profilesContainer";
        this.LOCAL_STORAGE_KEY = "wsysUserProfiles";

        let _profiles = window.localStorage.getItem(this.LOCAL_STORAGE_KEY);

        if (typeof _profiles === "string") {
            this._profiles = JSON.parse(_profiles);
        }

        let _loginTmpSettings = app.loginManager.getTempSetting();
        let _hasConfig = false;

        _.each(this._profiles, function searchProfile(profileData){
            if (profileData.url === _loginTmpSettings.loginUrl) {
                _hasConfig = true;
            }
        });

        if (_hasConfig == false) {
            this.updateProfileData(app.utils.generateUUID(), {
                url   : _loginTmpSettings.loginUrl,
                user  : _loginTmpSettings.loginName,
                inUse : true
            });
        }
    },
});

    }
},
{'requireName': 'custom/clients/mobile/views/user-profile/user-profile', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/user-profile/user-profile';
/**
 * Class Description
 *
 * @class user-profiles
 */
({
    events() {
        return {
            "click #chooseProfile" : "chooseUserProfile", // we can register events here
            "change #urlInput"     : "urlChanged",
            "change #userInput"    : "userChanged"
        };
    },

    initialize(options) {
        let _initResult = this._super("initialize", arguments);

        this._initProperties();

        return _initResult;
    },
    
    chooseUserProfile(ev) {
        this._manager.chooseProfile(this._id);
    },

    userChanged(ev) {
        this._user = ev.currentTarget.value;

        this._manager.updateProfileData(this._id, {
            user : this._user,
            url  : this._url
        });
    },
    
    urlChanged(ev) {
        this._url = ev.currentTarget.value;

        this._manager.updateProfileData(this._id, {
            user : this._user,
            url  : this._url
        });
    },

    fillProfile(profileId, profileData) {
        this._url = profileData.url;
        this._user = profileData.user;
        this._canChoose = !profileData.inUse;
        this._id = profileId;
    },

    _initProperties() {
        this._manager = this.options.manager;
        this._canChoose = true;
        this._url = "";
        this._user = "";
        this._id = app.utils.generateUUID();
    },
});

    }
},
{'requireName': 'custom/clients/mobile/views/uMaps-route-collection/uMaps-route-collection', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/uMaps-route-collection/uMaps-route-collection';
({
    uMapsRouteCollectionView : true,
    loadingScreenTimer       : 500,
    allowedModules           : ["Accounts", "Contacts", "Leads", "Opportunities"],
    headerConfig             : {
        title    : "wMaps Route Collection",
        back     : true,
        mainMenu : true
    },
    extendsFrom: {
        baseType : "inner-list",
        module   : ""
    },

    events() {
        return {
            "click article": "onItemElementClick"
        };
    },

    render: function () {
        var renderResult = this._super("render", arguments);

        this.populateListView();

        return renderResult;
    },

    populateListView: function () {
        _.each(
            app.mobile.directionsRouteCollection.models,
            function removeModel(model) {
                this.collection.remove(model);
            }.bind(this)
        );

        var recordsToDisplay = app.mobile.directionsRouteCollection.models;

        _.each(
            recordsToDisplay,
            function getAttributes(model) {
                this.collection.add(model);
                this.$el
                    .find("[data-id=\"" + model.attributes.id + "\"]")
                    .append(
                        `
                        <div id="removeFromRouteButtons" style="width:30%;height: 5em;margin-top:-4em;float:right;"><i class="fas fa-minus-circle" style="float: right;font-size:  26px;color:#f44336;margin-top:0.75em; pointer-events:none;"></i></div>`
                    );
                this.$el.find(".fields").css("pointer-events", "none");
            }.bind(this)
        );
    },

    onItemElementClick: function (e) {
        if (e.target && e.target.id.indexOf("removeFromRouteButtons") > -1) {
            e.stopPropagation();
            var userResponse = confirm("Are you sure you want to remove this record from the route?");

            if (userResponse === true) {
                this.collection.remove(this.collection.get(e.currentTarget.getAttribute("data-id")));
                app.mobile.directionsRouteCollection.remove(
                    app.mobile.directionsRouteCollection.get(e.currentTarget.getAttribute("data-id"))
                );

                app.controller.trigger("wMaps-collection-route-changed");

                if (this.collection.length <= 0) {
                    app.controller.goUp();
                    app.alert.show("wMaps-mobile-error", {
                        level     : "warning",
                        messages  : "Your route is now empty.",
                        autoClose : true
                    });
                }
            }
        } else {
            this._super("onItemElementClick", arguments);
        }
    },

    getMobileButtonsManager: function () {
        return SUGAR.customizationTools.mobileButtonsManager;
    }
});
    }
},
{'requireName': 'custom/clients/mobile/views/saved-report-list-summary-row/saved-report-list-summary-row', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/saved-report-list-summary-row/saved-report-list-summary-row';
/* global app */

({
    headerFields   : null,
    normalizedRows : [],
    reportModuleLC : "",

    initialize: function (options) {
        this._super("initialize", arguments);

        this.rowsTableId = _.uniqueId();
        this.normalizedRows = [];
        this.reportModuleLC = this.options.dashletParent.serverResults.keyPrefix;
        this.headerFields = this.options.dashletParent.serverResults.fields;
    },

    render: function () {
        this._super("render", arguments);
        this.parseCollectionData();
    },

    orderRows: function (event) { },

    parseCollectionData: function (orderParam) {
        var cKeys = Object.keys(this.collection);
        var rowsContainerEl = this.$el.find(".rowsContainer");
        var darkMode = $("body").hasClass("theme-dark") === true;

        // iterate through all the cells html and append them into the table
        for (var i = 0; i < cKeys.length; i++) {
            if (cKeys[i] !== "wIsData" && cKeys[i] !== "header") {
                var currentRowData = this.collection[cKeys[i]];
                var htmlContent = "<tr class='group-line-cells'>";
                var maxCellWidth = 100;
                var cellWidth =
                    maxCellWidth / Object.keys(currentRowData).length;

                _.each(currentRowData, function createHtml(
                    cellContent,
                    cellKey
                ) {
                    if (cellKey !== "wIsData" && cellKey !== "header") {
                        var oddComparision = 2;
                        var bgColor =
                            i % oddComparision === 0 ? "#f6f6f6" : "#fff";

                        if (darkMode === true) {
                            if (i % oddComparision === 0) {
                                bgColor = "#575757";
                            } else {
                                bgColor = "#2b2d2e";
                            }
                        }

                        htmlContent =
                            htmlContent +
                            "<td class='row-column' style='text-indent:5px; height:25px; width:" +
                            cellWidth +
                            "%; text-align:left; background-color:" +
                            bgColor +
                            "; border-width:1px; border-bottom-style:solid; border-top-style:solid; border-color:#e9e9e9;'>" +
                            cellContent +
                            "</td>";
                    }
                });

                htmlContent = htmlContent + "</tr>";

                rowsContainerEl.append(htmlContent);
            }
        }
        var self = this;
        _.each(this.headerFields, function createHeader(headerData) {
            var backgroundColor = "#fff";
            var textColor = "#666";

            if (darkMode === true) {
                backgroundColor = "#2b2d2e";
                textColor = "#fff";
            }

            var headerHtml =
                "<th class=\"row-column\" style=\"text-align:left; border-width:1px; border-style:solid; background-color:" + backgroundColor + ";border-color: #e9e9e9\">\
                    <a class=\"rowHeader\" data-html=\"true\" style=\"margin-left: 5px; border-style: none;color:" + textColor + ";font-size: 13px;font-weight: bolder;\" tabindex=\"-1\">\
                    " +
                headerData.label +
                "</a>\
                </th>";

            self.$el.find(".headerContainer").append(headerHtml);
        });
    }
});
    }
},
{'requireName': 'custom/clients/mobile/views/saved-report-list-summary-details/saved-report-list-summary-details', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/saved-report-list-summary-details/saved-report-list-summary-details';
({
    initialize: function (options) {
        this._super("initialize", arguments);
    },

    render: function () {
        this.ServerResults = this.options.dashletParent.serverResults;
        this._super("render", arguments);
        this.fixBwcLinks();
    },

    fixBwcLinks: function () {
        this.$el
            .find("a[href*=\"module=\"]")
            .each(function goThroughElements(i, elem) {
                // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
            });
    }
});
    }
},
{'requireName': 'custom/clients/mobile/views/uMaps-mobile/uMaps-mobile', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/uMaps-mobile/uMaps-mobile';
({
    template     : "uMaps-mobile",
    headerConfig : {
        title    : "wMaps",
        back     : true,
        mainMenu : true
    },
    uMapsView: true,

    createPushpin: function (map, recordData) {
        var latLon = new Microsoft.Maps.Location(recordData.latitude, recordData.longitude);

        var pushpinTitle = recordData.name;
        var pushpin = new Microsoft.Maps.Pushpin(latLon, {
            title    : pushpinTitle,
            subtitle : pushpinTitle,
            color    : recordData.color
        });
        pushpin.title = pushpinTitle;
        pushpin.subtitle = pushpinTitle;

        var pindesc = "";
        if (recordData.street) pindesc += recordData.street;
        if (recordData.city) pindesc += "," + recordData.city;
        if (recordData.state) pindesc += "," + recordData.state;
        if (recordData.postalcode) pindesc += " " + recordData.postalcode;
        if (recordData.country) pindesc += " " + recordData.country;
        if (pindesc.length > 5) pindesc = "Address: " + pindesc;

        pushpin.description = pindesc;
        pushpin.module = recordData.module;
        pushpin.recordId = recordData.id;
        
        map.entities.push(pushpin);

        Microsoft.Maps.Events.addHandler(pushpin, "click", this.displayInfobox.bind(this));
    },

    generateInfoBoxHtml: function(pin) {
        var infoboxHTML =
            "<div id=\"infoboxText\" style=\"z-index:9;border-radius: 3px;background-color:#313030;opacity:0.8; color:white;border-style:solid;border-width:medium; border-color:#313030; opacity:0.8; min-height:100px;width:240px;\"><div style=\"min-height:20px;word-wrap: break-word;\"><div style=\"display:inline; width:90%;\"><a style=\"color:#00E2FF\" id=\"title_link\" record_id=\"" +
            pin.tag +
            "\">" +
            pin.title +
            "</a><span style=\"float:right; margin-right:5%;\"><a id=\"street_view_link\" pin_latitude=\"" +
            pin.geometry.bounds[0] +
            "\" pin_longitude=\"" +
            pin.geometry.bounds[1] +
            "\"><i class=\"fas fa-map-pin fa-2x\"></i></a></span></div></div><div style=\"word-wrap: break-word; top:110px;\">" +
            pin.description +
            "</div><div class=\"infobox-stalk\" style=\"width: 33px; height: 38px; overflow: hidden; position: absolute; z-index: 1; left: 20px; top: 100px;\"></div></div></div>";
        return infoboxHTML;
    },

    hideInfoBox: function(e) {
        this.pinInfobox.setOptions({
            visible: false
        });
    },

    displayInfobox: function(e) {
        if (e.targetType == "pushpin") {
            var pin = e.target;
            this.pinInfobox.setLocation(pin.getLocation());

            var infoboxHTML = this.generateInfoBoxHtml(pin);

            this.pinInfobox.setHtmlContent(infoboxHTML);

            //calculate infobox position
            var map_control_div = this.$el.find("#uMapsContainer")[0];
            var map_ctrl = this.mapCtrl;
            window.map_control_on_record = map_ctrl;
            var map_center = window.map_control_on_record.getCenter();
            var point_position = pin.getLocation();
            var offset_latitude = 0;
            var offset_longitude = 0;
            if (map_center.latitude >= point_position.latitude) {
                offset_latitude = 15;
            } else {
                offset_latitude = -120;
            }

            if (map_center.longitude >= point_position.longitude) {
                offset_longitude = -15;
            } else {
                offset_longitude = -230;
            }
            
            this.pinInfobox.setOptions({
                offset  : new Microsoft.Maps.Point(offset_longitude, offset_latitude),
                visible : true
            });

            this.pinInfobox.setMap(window.map_control_on_record);

            $("#infoboxText")
                .parent()
                .parent()
                .parent()
                .css("z-index", "0");

            setTimeout(function() {
                $("#title_link").on("click", function(evt) {
                    App.controller.navigate(`${pin.module}/${pin.recordId}`);
                });
            }, 0);

            setTimeout(function() {
                $("#street_view_link").on(
                    "click",
                    function(evt) {
                        var pin_latitude = $(evt.currentTarget).attr("pin_latitude");
                        var pin_longitude = $(evt.currentTarget).attr("pin_longitude");
                        var map_ctrl = window.map_control_on_record;
                        var self = this;

                        setTimeout(function() {
                            self.hideInfoBox();
                            map_ctrl.setView({
                                center: new Microsoft.Maps.Location(pin_latitude, pin_longitude)
                            });
                            map_ctrl.setView({ zoom: 18 });
                            map_ctrl.setView({
                                mapTypeId: Microsoft.Maps.MapTypeId.streetside
                            });
                            map_ctrl.setView({
                                mapTypeId         : Microsoft.Maps.MapTypeId.streetside,
                                streetsideOptions : {
                                    showCurrentAddress : false,
                                    onErrorLoading     : function() {
                                        message = app.lang.get("WMAPS_LABEL_ALERT18");
                                        app.alert.show("StreetSideNotAvailableOnView", {
                                            level     : "warning",
                                            messages  : message,
                                            autoClose : true
                                        });
                                    },
                                    onSuccessLoading: function() {
                                        if ($("#directionsClose").length > 0) {
                                            $("#directionsClose").css("z-index", 0);
                                            $("#infoboxText").hide();
                                        }
                                        $(".streetsideExit").on("click", function() {
                                            if ($("#directionsClose").length > 0) {
                                                $("#directionsClose").css("z-index", 999);
                                            }
                                            if ($(".ms-composite").children().length > 0) {
                                                $(".ms-composite")
                                                    .children()
                                                    .css("z-index", 0);
                                            }
                                        });
                                    }
                                }
                            });
                        }.bind(this), 800);
                    }.bind(this)
                );
            }.bind(this), 0);
        }
    },

    createWaypoint: function (directionsManager, recordData) {
        var waypoint = new Microsoft.Maps.Directions.Waypoint({
            address  : recordData.name,
            location : new Microsoft.Maps.Location(recordData.latitude, recordData.longitude)
        });

        directionsManager.addWaypoint(waypoint);
    },

    getZoom: function (locations) {
        var maxLat = -85,
                minLat = 85,
                maxAngle = 360,
                halfAngle = 180,
                medAngle = 256,
                decrease = 2,
                maxLon = -180,
                minLon = 180,
                zoom1 = 0,
                zoom2 = 0,
                i;

        // If we have a locations array, the we ned to get the MBR
        if (locations) {
            // A list of location objects, we need to get MBR
            for (i = 0; i < locations.length; i++) {
                if (locations[i].latitude > maxLat) {
                    maxLat = locations[i].latitude;
                }
                if (locations[i].latitude < minLat) {
                    minLat = locations[i].latitude;
                }
                if (locations[i].longitude > maxLon) {
                    maxLon = locations[i].longitude;
                }
                if (locations[i].longitude < minLon) {
                    minLon = locations[i].longitude;
                }
            }
        }

        //get the center of the map
        var center = {};
        center.latitude = (maxLat + minLat) / decrease;
        center.longitude = (maxLon + minLon) / decrease;

        var params = {
            mapWidth  : screen.width, // Width of your map div in pixels
            mapHeight : screen.height, // Height of your map div in pixels
            buffer    : 50 // How many pixels to add as a buffer
        };

        //Determine the best zoom level based on the map scale and bounding coordinate information
        if (maxLon != minLon && maxLat != minLat) {
            //best zoom level based on map width
            zoom1 =
                Math.log(maxAngle / medAngle * (params.mapWidth - decrease * params.buffer) / (maxLon - minLon)) /
                Math.log(decrease);
            //best zoom level based on map height
            zoom2 =
                Math.log(halfAngle / medAngle * (params.mapHeight - decrease * params.buffer) / (maxLat - minLat)) /
                Math.log(decrease);
        }
        //use the most zoomed out of the two zoom levels
        var optimZoom = zoom1 < zoom2 ? zoom1 : zoom2;

        return { zoom: optimZoom, center: center };
    },

    generateMap: function (collection, computeDirections, fromRecord) {
        this.pinInfobox = new Microsoft.Maps.Infobox(new Microsoft.Maps.Location(0, 0), {
            description     : "description",
            showCloseButton : false,
            showPointer     : false,
            offset          : new Microsoft.Maps.Point(-26, 2)
        });

        Microsoft.Maps.Events.addHandler(this.pinInfobox, "mouseleave", this.hideInfoBox.bind(this));
        
        var mapInitialLatitude = app.user.currentLocationLat;
        var mapInitialLongitude = app.user.currentLocationLng;

        if ((fromRecord || app.cameFromRecordFiltering) && collection && collection[0]) {
            mapInitialLatitude = collection[0].latitude;
            mapInitialLongitude = collection[0].longitude;
        }

        var zoomAndCenter = this.getZoom(collection);
        var directionsManager = false;

        if (zoomAndCenter.zoom === 0) {
            zoomAndCenter.zoom = 10;
        }

        if (zoomAndCenter.center) {
            var map = new Microsoft.Maps.Map(document.getElementById("uMapsContainer"), {
                credentials : "AuIEmeKGjvNV037yKiYGV0B3cxqNmx6FWnode0Hj8tjQPjK1zJP-7GAESccoCDUA",
                center      : zoomAndCenter.center,
                zoom        : zoomAndCenter.zoom
            });
            this.mapCtrl = map;
            Microsoft.Maps.Events.addHandler(map, "click", this.hideInfoBox.bind(this));

            if (!fromRecord && !app.cameFromRecordFiltering) {
                if (computeDirections) {
                    directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);
                    // Set Route Mode to driving
                    directionsManager.setRequestOptions({ routeMode: Microsoft.Maps.Directions.RouteMode.driving });

                    this.createWaypoint(directionsManager, {
                        name      : app.user.get("full_name"),
                        latitude  : mapInitialLatitude,
                        longitude : mapInitialLongitude,
                        color     : "rgb(38,135,27)"
                    });
                } else {
                    this.createPushpin(map, {
                        name      : app.user.get("full_name"),
                        latitude  : mapInitialLatitude,
                        longitude : mapInitialLongitude,
                        color     : "rgb(38,135,27)"
                    });
                }
            }

            _.each(
                collection,
                function addPushpins(recordData) {
                    recordData.color = "rgb(0,66,121)";
                    if (directionsManager) {
                        this.createWaypoint(directionsManager, recordData);
                    } else {
                        this.createPushpin(map, recordData);
                    }
                },
                this
            );

            if (directionsManager) {
                // Set the element in which the itinerary will be rendered
                directionsManager.setRenderOptions({
                    itineraryContainer: document.getElementById("uMapsRoutesContainer")
                });
                directionsManager.calculateDirections();

                this.$el.find("#uMapsRoutesContainer").hide();
            }
        }

        delete app.cameFromRecordFiltering;
    }
});

    }
},
{'requireName': 'custom/clients/mobile/views/saved-report-list-rows-columns/saved-report-list-rows-columns', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/saved-report-list-rows-columns/saved-report-list-rows-columns';
({
    initialize: function (options) {
        this._super("initialize", arguments);

        options = options || {};
        options.dashletParent = options.dashletParent || {};

        if (_.isObject(options.dashletParent.sort)) {
            this.sortName = options.dashletParent.sort.name;
            this.sortTableKey = options.dashletParent.sort.table_key;
            this.sortDir = options.dashletParent.sort.sort_dir;
        }
    },

    render: function () {
        this.ServerResults = this.options.dashletParent.serverResults;
        this._super("render", arguments);

        this.fixBwcLinks();
    },

    fixBwcLinks: function () {
        this.$el
            .find("a[href*=\"module=\"]")
            .each(function goThroughElements(i, elem) {
                // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
            });
    }
});
    }
},
{'requireName': 'custom/clients/mobile/views/saved-report-list-summary-header/saved-report-list-summary-header', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/saved-report-list-summary-header/saved-report-list-summary-header';
/* global app, _ */

({
    events: {
        "click #expandColapseButton": "expandColapseButtonClicked"
    },

    initialize: function (options) {
        this._super("initialize", arguments);

        this.header = options.title;
        this.parent = options.parent;
        this.cUUID = app.utils.generateUUID();
        this.headerIndex = options.headerIndex;
        this.showSummary = options.showSummary;
        this.tableToCollapseId = _.uniqueId();
        this.childTableVisible = true;
        this.dashletParent = options.dashletParent;

        var spacesOffset = 10;
        var spacesLeft = 5;
        this.spaces = this.headerIndex * spacesOffset - spacesLeft;

        this.darkMode = $("body").hasClass("theme-dark") === true;
    },

    render: function () {
        this._super("render", arguments);
        this.getHeader();
        var headerHtml =
            "<div data-html=\"true\" style=\"float:left; margin-left: 5px;\">" +
            this.header +
            "</div>";

        this.$el.find("." + this.tableToCollapseId).append(headerHtml);
    },

    expandColapseButtonClicked: function (event) {
        var childTable = this.$el.find("#" + event.currentTarget.name);
        if (childTable.data("visible") === false) {
            event.currentTarget.children[0].src =
                "themes/default/images/basic_search.gif?v=NDZq21b7_V0TWvcCY4J40";
            childTable.data("visible", true);
            childTable.show();
        } else {
            childTable.hide();
            childTable.data("visible", false);
            event.currentTarget.children[0].src =
                "themes/default/images/advanced_search.gif?v=NDZq21b7_V0TWvcCY4J40";
        }
    },

    getHeader: function () {
        if (
            typeof this.collection == "undefined" ||
            this.showSummary !== true
        ) {
            return;
        }

        if (this.collectionIsHeader()) {
            for (var group in this.collection) {
                if (group !== "header") {
                    var subGroupView = app.view.createView({
                        name          : "saved-report-list-summary-header",
                        model         : this.model,
                        context       : this.context,
                        collection    : this.collection[group],
                        headerIndex   : this.headerIndex + 1,
                        showSummary   : this.showSummary,
                        title         : this.collection[group]["header"],
                        dashletParent : this.dashletParent
                    });

                    subGroupView.render();

                    this.$el
                        .find("table#" + this.cUUID)
                        .find("td.group-data:first")
                        .append(subGroupView.$el.find("table:first"));
                }
            }
        } else {
            var headerRow = app.view.createView({
                name          : "saved-report-list-summary-row",
                model         : this.model,
                context       : this.context,
                collection    : this.collection,
                dashletParent : this.dashletParent
            });

            headerRow.render();

            this.$el
                .find("table#" + this.cUUID)
                .find("td.group-data:first")
                .append(headerRow.$el.find("table:first"));
        }
    },

    collectionIsHeader: function () {
        return !this.collection.wIsData;
    }
});
    }
},
{'requireName': 'custom/clients/mobile/views/saved-report-list-grand-total/saved-report-list-grand-total', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/views/saved-report-list-grand-total/saved-report-list-grand-total';
/* global app */

({
    reportModuleLC: "",

    initialize: function (options) {
        this._super("initialize", arguments);

        this.reportModuleLC = this.options.dashletParent.serverResults.keyPrefix;
        this.minTableWidth = options.minTableWidth;
        var grandTotalData = this.options.dashletParent.serverResults.grandTotal;

        this.columns = grandTotalData.columnNames;
        this.values = grandTotalData.columnValues;
        this.darkMode = $("body").hasClass("theme-dark") === true;
    },

    render: function () {
        this._super("render", arguments);
    }
});
    }
},
{'requireName': 'custom/clients/mobile/dashlets/saved-reports-list/saved-reports-list', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/dashlets/saved-reports-list/saved-reports-list';

({
    plugins                 : ["Dashlet"],
    reportData              : undefined,
    chartField              : undefined,
    reportOptions           : undefined,
    reportsData             : undefined,
    timerId                 : undefined,
    rowsNumber              : undefined,
    displayTotal            : undefined,
    showDrilldownButton     : undefined,
    currentRowsShown        : 0,
    loadOptions             : false,
    reportType              : undefined,
    isSummary               : false,
    selectedReportIsSummary : false,
    dataLoaded              : false,
    defDisplayColumns       : {},
    SORT_SEPARATOR          : "::",
    /**
     * False if no sort is applied on the list | the object with definition of the sort
     * Ex: {
     *        name:      "first_name",
     *        table_key: "self",
     *        sort_dir:  "a"
     *    }
     */
    sort                    : false,
    /**
     * List of sort configurations
     * Ex: {
     *      "first_name:self:a": {
     *          name:      "first_name",
     *          label:     "First name",
     *          table_key: "self",
     *          sort_dir:  "a",
     *      },
     *  }
     */
    availableSort           : {},

    events: {
        "click a[name=editReport]"                     : "editSavedReport",
        "click #drill_button"                          : "drillAction",
        "click [data-fieldname=\"intelligent\"] input" : "setIntelligence",
        "click th[data-fieldname][data-orderby]"       : "sortList",
    },

    extendsFrom: {
        baseType: "base-chart"
    },

    drillAction: function () {
        window.open("#bwc/index.php?module=Reports&action=DetailView&record=" + this.options.meta.view.saved_report_id);
    },

    _scheduleReload: function (delay) {
        this.timerId = setTimeout(
            _.bind(function refreshTimer() {
                this.context.resetLoadFlag();
                this.loadData({
                    complete: function reloadData() {
                        this._scheduleReload(delay);
                    }.bind(this)
                });
            }, this),
            delay
        );
    },

    initialize: function (options) {
        this.reportData = new Backbone.Model();
        return this._super("initialize", arguments);
    },

    loadData: function (options) {
        options = options || {};

        if (this.options.meta.view.saved_report_id) {
            this.getSavedReportById(this.options.meta.view.saved_report_id, options);
            this.displayTotal = this.options.meta.view.show_total_count;
            this.rowsNumber = this.options.meta.view.display_rows;
        }
    },

    showLoadingFeedback: function () {
        if (!this.dataLoaded) {
            var newElDiv = this.$el.find("#loadingFeedback");
            newElDiv.append(
                "<i name=\"placeHolderLoading\" class=\"fa fa-spinner fa-spin fa-3x fa-fw margin-top\" style=\"width: 35px;height: 35px;margin-top:0.5%;margin-left: 48%;\"></i>"
            );
        }
    },

    hideLoadingFeedback: function () {
        this.$el.find("[name=placeHolderLoading]").remove();
    },

    getSavedReportById: function (reportId, options) {
        this.dataLoaded = false;
        this.showLoadingFeedback();

        this.loadOptions = options;

        var parentModel = this.context.get("parentModel");
        var forceRefresh = options.complete ? true : false;

        var reqData = {
            reportId            : reportId,
            forceRefresh        : forceRefresh,
            usePaging           : this.rowsNumber != 0,
            linkToCurrentRecord : this.options.meta.view.intelligent
        };

        if (this.options.meta.view.sort) {
            if (this.sort == false || (this.sort != false && !this.sort.forceSort)) {
                var sortConfiguration = this.options.meta.view.sort;
                sortConfiguration = this.options.meta.view.sort.split(this.SORT_SEPARATOR);
                // eslint-disable-next-line
                if (sortConfiguration.length === 3) {
                    this.sort = {
                        name      : sortConfiguration[0],
                        table_key: sortConfiguration[1], //eslint-disable-line
                        sort_dir: sortConfiguration[2] //eslint-disable-line
                    };
                } else {
                    //backward versions compatibility (fixes problem with tables different than self)
                    window.console.log("wrong sort configuration set");
                    this.sort = false;
                }
            }
        }
        if (this.sort != false) {
            reqData = _.extend(reqData, {
                sort: this.sort
            });
            reqData.forceRefresh = true;
        }

        if (parentModel instanceof App.Bean && _.isEmpty(this.context.get("parentId") === false)) {
            reqData["linkField"] = this.options.meta.view.linked_fields;
            reqData["link"] = parentModel.get("_module").toLowerCase();
            reqData["module"] = parentModel.get("_module");
            reqData["contextId"] = parentModel.get("id");
            reqData["contextName"] = parentModel.get("name") || parentModel.get("full_name");
        }

        if (
            _.isUndefined(this.currentRowsShown) === false
            && this.loadOptions["append"] === true
        ) {
            reqData["reportOffset"] = this.currentRowsShown;
        }

        var apiUrl = app.api.buildURL("wReportsDashlet", "list/results");

        app.api.call("create", apiUrl, {
            contextData: reqData
        }, null, {
            success: _.bind(function getAllReportsList(serverData, options) {
                if (_.isEmpty(serverData) === true) {
                    this.hideLoadingFeedback();

                    return;
                }

                if (_.isUndefined(serverData.status) === false && serverData.status === "failed") {
                    App.alert.show("saved-report-error", {
                        level     : "error",
                        messages  : app.lang.getAppString(serverData.message) + serverData.reportId,
                        autoClose : false
                    });

                    this.hideLoadingFeedback();

                    return;
                }

                this.createDashletView(serverData, options);
            }, this),
            complete: options ? options.complete : null
        });
    },

    createBaseDashlet: function (serverData, options) { },

    createMatrixDashlet: function (matrixHtml) {
        var reportMatrixCss =
            "<style>.reportlistView {\
            border-top: 1px solid #000;\
            border-left: 1px solid #000;\
        }\
        table.reportlistView td, table.reportlistView th {\
            background: #fff;\
            border-bottom: 1px solid #000;\
            border-right: 1px solid #000;\
            color: #000;\
            padding: 4px;\
            text-align: center;\
            font-size: 11px;\
        }\
            table.reportlistView th, .reportlistView .reportlistViewMatrixRightEmptyData, .reportlistView .reportlistViewMatrixRightEmptyData1 {\
            background: #dcdcdc;\
            font-weight: bold;\
        }\
            </style>\
        ";

        if ($("body").hasClass("theme-dark") === true) {
            reportMatrixCss = "<style>.reportlistView {\
                border-top: 1px solid;\
                border-left: 1px solid;\
            }\
            table.reportlistView td, table.reportlistView th {\
                border-bottom: 1px solid;\
                border-right: 1px solid;\
                padding: 4px;\
                text-align: center;\
                font-size: 11px;\
            }\
                table.reportlistView th, .reportlistView .reportlistViewMatrixRightEmptyData, .reportlistView .reportlistViewMatrixRightEmptyData1 {\
                font-weight: bold;\
            }\
            table.reportlistView td {\
                background: #575757;\
            }\
                </style>\
            ";
        }

        this.$el.find("#saved_report_list_contents").html(reportMatrixCss + matrixHtml);
    },

    createDashletView: function (serverData, options) {
        this.dataLoaded = true;
        this.hideLoadingFeedback();

        if (_.isEmpty(serverData)) {
            return;
        }

        if (serverData.matrixHtml) {
            this.createMatrixDashlet(serverData.matrixHtml);
        } else if (serverData.collection && serverData.collection.length === 0) {
            this.$el.find("#saved_report_list_contents").empty();
            this.$el.find("#saved_report_list_contents").append("<div style='text-align:center'>" + app.lang.getAppString("LBL_NO_DATA_AVAILABLE") + "</div>");
        } else {
            this.createBaseDashlet(serverData, options);
            this.reportType = serverData["report_type"];
            this.isSummary = this.reportType == "summary" ? true : false;

            var titlesAreBroken = false;

            for (var headerSetIndex = serverData.headerTitles.length - 1; headerSetIndex >= 0; headerSetIndex--) {
                var headerSet = serverData.headerTitles[headerSetIndex];

                /*eslint-disable*/
                for (var headerDataIndex = 0; headerDataIndex < headerSet.length; headerDataIndex++) {
                    if (serverData.headerTitles[headerSetIndex + 1]) {
                        var hTitle = headerSet[headerDataIndex];
                        var exTitle = serverData.headerTitles[headerSetIndex + 1][headerDataIndex];
                        var majorExTitle = serverData.headerTitles[headerSetIndex + 1][0];
                        var majorTitle = serverData.headerTitles[headerSetIndex][0];
                        // eslint-disable-next-line
                        if (
                            majorTitle.indexOf("Count") > -1 &&
                            majorTitle.substr(0, majorTitle.lastIndexOf(" ")) ===
                            majorExTitle.substr(0, majorExTitle.lastIndexOf(" "))
                        ) {
                            var exCount = exTitle.substr(exTitle.lastIndexOf(" ") + 1, exTitle.length);
                            var currentCount = hTitle.substr(hTitle.lastIndexOf(" ") + 1, hTitle.length);
                            var totalCount = parseInt(exCount) + parseInt(currentCount);

                            serverData.headerTitles[headerSetIndex][headerDataIndex] =
                                hTitle.substr(0, hTitle.lastIndexOf(" ") + 1) + totalCount;

                            // eslint-disable-next-line max-depth
                            if (headerDataIndex === headerSet.length - 1) {
                                serverData.headerTitles.splice(headerSetIndex + 1, 1);
                                titlesAreBroken = true;
                            }
                        }
                    }
                }
            }
            /*eslint-enable*/

            if (titlesAreBroken) {
                var collectionIterator = 0;

                _.each(serverData.collection, function correctHeader(headerData, date) {
                    headerData.header = serverData.headerTitles[collectionIterator][0] || "";
                    collectionIterator = collectionIterator + 1;
                });
            }

            var collectionData = serverData;

            if (!this.isSummary || (this.isSummary && serverData.isSummationWithDetails)) {
                collectionData = this.getCollectionData(serverData);
            }

            var parentElement = this.$el.parent().parent();
            var title = parentElement.find(".dashlet-title")[0];

            if (title && this.displayTotal) {

                var collectionLength = _.isEmpty(collectionData.reportData.totalCount) ? collectionData.collection.length : collectionData.reportData.totalCount;

                if (this.isSummary === true) {
                    collectionLength = serverData.totalRecordsCount;
                }

                var initialTitle = this.options.meta.view.label;
                title.innerHTML = initialTitle + ": " + collectionLength + app.lang.getAppString("LBL_WRD_RECORDS");
            }

            // branching functionality as we want different things for when the report is summary
            if (collectionData.collection.length > 0 && this.isSummary != true) {
                this.formatRowsAndColumnsResults(collectionData);
            } else {
                this.formatSummaryResults(collectionData);
            }

            this._render();

            if (this.isSummary) {
                this.buildSummaryView();
            } else {
                this.buildRowsAndColumnsView(collectionData);
            }

            this.fixBwcLinks();
        }

        this.fixHeaderTitle();
    },

    buildRowsAndColumnsView: function (collectionData) {
        var rowColumnView = app.view.createView({
            name          : app.mobile.views.MobileSavedreportlistrowscolumnsView,
            model         : this.model,
            context       : this.context,
            dashletParent : this
        });

        rowColumnView.render();

        this.$el.find("#saved_report_list_contents").append(rowColumnView.$el);

        if (this.rowsNumber && this.rowsNumber != 0) { 
            var collectionLength = _.isEmpty(collectionData.reportData.totalCount) ? collectionData.collection.length : collectionData.reportData.totalCount;

            if (this.currentRowsShown >= collectionLength) {
                this.$el
                    .parent()
                    .parent()
                    .find("[data-action=\"show-more\"]")
                    .parent()
                    .parent()
                    .hide();
            } else {
                if (
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]").length === 0
                ) {
                    this.$el.addClass("list-view");
                    this.$el.append(
                        "<div><div class=\"block-footer\"><button data-action=\"show-more\" class=\"btn btn-link btn-invisible more padded\">" + app.lang.getAppString("LBL_MOBILE_SHOW_MORE") + "</button></div></div>"
                    );
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]")
                        .click(this.showMoreRecords.bind(this));
                } else {
                    // display the "Show more..." button
                    this.$el
                        .parent()
                        .parent()
                        .find("[data-action=\"show-more\"]")
                        .parent()
                        .parent()
                        .show();
                }
            }
        }
    },

    buildSummaryView: function () {
        var reportData = this.serverResults;

        if (reportData.isSummationWithDetails) {
            /*eslint-disable*/
            // creating the headers
            if (!_.isEmpty(reportData.collection)) {
                for (var col in reportData.collection) {
                    if (col !== "header") {
                        var groupView = app.view.createView({
                            name: app.mobile.views.MobileSavedreportlistsummaryheaderView,
                            model: this.model,
                            context: this.context,
                            collection: reportData.collection[col],
                            headerIndex: 1,
                            showSummary: reportData.showSummary,
                            title: reportData.collection[col]["header"],
                            dashletParent: this
                        });

                        groupView.render();
                        this.$el.find("#saved_report_list_contents").append(groupView.$el);
                    }
                }
            }/*eslint-enable*/
        } else {
            var headerRow = app.view.createView({
                name          : app.mobile.views.MobileSavedreportlistsummaryrowView,
                model         : this.model,
                context       : this.context,
                collection    : reportData.collection,
                dashletParent : this
            });

            headerRow.render();
            this.$el.find("#saved_report_list_contents").append(headerRow.$el);
        }

        // showing the grandTotal if the user wants so
        if (!_.isEmpty(reportData.grandTotal) && reportData.displayTotal === true) {
            var subTables = this.$el.find("#saved_report_list_contents").children();
            var tableParent = subTables[subTables.length - 1];
            var subTableElement = tableParent.children[0];
            var tableId = subTableElement ? subTableElement.id : "id";
            var tableElement = $("#" + tableId);
            //replaced this.$el.find with general due to querySelector method uses CSS3 selectors for querying the DOM 
            //and CSS3 doesn't support ID selectors that start with a digit

            this.minTableWidth = tableElement.css("width");

            var grandTotalView = app.view.createView({
                name           : app.mobile.views.MobileSavedreportlistgrandtotalView,
                model          : this.model,
                context        : this.context,
                grandTotalData : reportData.grandTotal,
                minTableWidth  : this.minTableWidth,
                dashletParent  : this
            });

            grandTotalView.render();
            this.$el.find("#saved_report_list_contents").append(grandTotalView.$el);
        }
    },

    formatSummaryResults: function (collectionData) {
        var reportData = _.clone(collectionData);
        var serverCollection = reportData.collection;

        if (!reportData.isSummationWithDetails) {
            //if the report is a simple summary report then we must format the data received from the API
            var headers = reportData.headerTitles[0] ? reportData.headerTitles[0] : [];
            reportData.fields = [];

            for (var headerIndex = 0; headerIndex < headers.length; headerIndex++) {
                reportData.fields.push({
                    label: headers[headerIndex]
                });
            }

            // var formattedCollection         = [];
            // formattedCollection[0]          = [];
            // formattedCollection             = this.formatSimpleSummaryReportData(server_collection, formattedCollection, 0, []).formattedCollection;
            serverCollection["wIsData"] = true;
            // server_collection               = formattedCollection;
        }

        this.serverResults = {
            isSummationWithDetails : reportData.isSummationWithDetails,
            fields                 : reportData.fields,
            collection             : serverCollection,
            grandTotal             : reportData.grandTotal,
            total                  : reportData.total,
            headers                : reportData.headers,
            headerTitles           : reportData.headerTitles,
            keyPrefix              : reportData.reportData.module.toLowerCase(),
            displayTotal           : this.displayTotal,
            showSummary            : this.showSummary
        };
    },

    formatRowsAndColumnsResults: function (collectionData) {
        var serverCollection = [],
                i;

        //only show columns from Display Columns, in the order they are there
        var displayColumns = this.options.meta.view.display_columns;

        _.each(displayColumns, function checkValidColumn(columnName, columnKey) {
            if (columnName.indexOf(this.SORT_SEPARATOR) < 0) {
                var defColumnData = _.filter(this.defDisplayColumns, function getColumnData(columnData) {
                    return columnData.name === columnName;
                })[0];

                if (defColumnData) {
                    displayColumns[columnKey] = defColumnData.table_key + this.SORT_SEPARATOR + columnName;
                }
            }
        }.bind(this));

        if (displayColumns) {
            var columnsMask = []; //holds index in Display Columns and index in collection.fields
            var collectionFieldNames = [];
            _.each(collectionData.fields, function iterateOverFieldsFromDb(field, idx) {
                collectionFieldNames[idx] = field.table_key + this.SORT_SEPARATOR + field.name;
            }.bind(this));
            for (i = 0; i < displayColumns.length; i++) {
                columnsMask[i] = collectionFieldNames.indexOf(displayColumns[i]);
            }

            var collectionFields = [];
            for (i = 0; i < columnsMask.length; i++) {
                var indexOfDisplayFieldInCollection = columnsMask[i];
                collectionFields.push(collectionData.fields[indexOfDisplayFieldInCollection]);
            }
            collectionData.fields = collectionFields;

            for (i = 0; i < collectionData.collection.length; i++) {
                var newCells = [],
                        newRows = [];
                var cellsInARow = collectionData.collection[i].cells;
                var rowsInARow = collectionData.collection[i].rows;
                for (var columnIdx = 0; columnIdx < columnsMask.length; columnIdx++) {
                    var indexOfDisplayFieldInRow = columnsMask[columnIdx];
                    newCells.push(cellsInARow[indexOfDisplayFieldInRow]);
                    newRows.push(rowsInARow[indexOfDisplayFieldInRow]);
                }

                collectionData.collection[i].cells = newCells;
                collectionData.collection[i].rows = newRows;
            }
        }

        // limiting the data we show
        if (this.rowsNumber && this.rowsNumber != 0) {
            if (this.loadOptions && this.loadOptions["append"]) {
                this.currentRowsShown += parseInt(this.rowsNumber);
            } else {
                this.currentRowsShown = parseInt(this.rowsNumber);
            }
            serverCollection = collectionData.collection.slice(0, this.currentRowsShown);
        } else {
            serverCollection = collectionData.collection;
        }

        this.serverResults = {
            fields     : collectionData.fields,
            collection : serverCollection
        };
    },

    getCollectionData: function (serverData) {
        // building the collection rows with the data received from the report
        for (var j = 0; j < serverData.collection.length; j++) {
            var rows = [];

            for (var z = 0; z < serverData.collection[j].cells.length; z++) {
                var row = {};

                if (serverData.collection[j].cells[z].indexOf("<a") > -1) {
                    var newText = $(serverData.collection[j].cells[z]).text();
                    row.text = newText;
                } else {
                    row.text = serverData.collection[j].cells[z];
                }

                row.html = serverData.collection[j].cells[z];
                rows.push(row);
            }
            serverData.collection[j].rows = rows;
        }

        return serverData;
    },

    _render: function () {
        this._super("_render", arguments);

        this.$el.css("overflow-x", "auto");
        this.fixBwcLinks();

        this.showLoadingFeedback();
    },

    showMoreRecords: function () {
        var options = {
            append: true
        };

        this.getSavedReportById(this.options.meta.view.saved_report_id, options);
    },

    fixBwcLinks: function () {
        this.$el.find("a[href*=\"module=\"]").each(function goThroughElements(i, elem) {
            // App.view.views.BaseBwcView.prototype.convertToSidecarLink(elem);
        });
    },

    fixHeaderTitle: function () {
        if ($("body").hasClass("theme-dark") === true) {
            this.$el.parents(".dashboard").find(".dashlets__title").css("background", "#2b2d2e");
        } else {
            this.$el.parents(".dashboard").find(".dashlets__title").css("background", "#fff");
        }
    }
});
    }
},
{'requireName': 'custom/clients/mobile/dashlets/w-saved-reports-chart/w-saved-reports-chart', 'functionName': function(module, require) {
    module.name = 'custom/clients/mobile/dashlets/w-saved-reports-chart/w-saved-reports-chart';
({
    extendsFrom: {
        baseType: "saved-reports-chart",
    },

    getChartModel: function(params, config) {
        var chart = this._super("getChartModel", arguments);

        // temp fix for SUGARCrm bug
        if (!chart.fmtCount) {
            chart.fmtCount = function fmtCount() {
                return {fmtValue: function fmtValue(){
                    return false;
                }};
            };
        }

        return chart;
    },

    loadChartData: function loadChartData(loadChartDataCallback) {
        var reportId = this.meta.view.saved_report_id; //eslint-disable-line camelcase
        var screenContext = app.controller.getScreenContext();
        var parentModel = app.controller.layoutManager.getRootLayout().context.get("parentModel");
        var recordName = parentModel ? (parentModel.get("name") ? parentModel.get("name") : parentModel.get("first_name")) : "Record";

        var dataToSendForChartLoading = {
            groupType         : "simple",
            reportId          : reportId,
            record_id         : screenContext.parentModelId, //eslint-disable-line camelcase
            record_name       : recordName, //eslint-disable-line camelcase
            link              : this.meta.view.link,
            module            : screenContext.parentModule,
            dashletChartType  : this.meta.view.chart_type,
            approximateTotal  : true,
            approximateValues : true,
            hideEmptyGroups   : false
        };

        app.api.call("create", app.api.buildURL("Reports/" + reportId + "/wchart"), dataToSendForChartLoading, {
            success: _.bind(function successRetrieveWChart(data) {
                data.chartData.properties = [{type: this.meta.view.chart_type, "base_module": data.reportDefs.module}];
                data.chartData.values = [];
                data.chartData.label = ["Column"];
                data.reportData = data.reportDefs;

                _.each(data.chartData.data, function restructureData(columnData, key){
                    data.chartData.values[key] = {};
                    data.chartData.values[key].values = [columnData.recordsCount];
                    data.chartData.values[key].label = [columnData.group1_label];
                });
                
                var enumsToFetch = this.getEnums(data.reportDefs);

                if (!_.isEmpty(enumsToFetch) && !this.enums) {
                    this._loadEnumOptions(enumsToFetch, data.reportDefs)
                        .then(enums => {
                            this.enums = enums;
                            loadChartDataCallback(null, data);
                        })
                        .catch(error => {
                            loadChartDataCallback(error);
                        });
                } else {
                    loadChartDataCallback(null, data);
                }
            }, this),
            error: loadChartDataCallback,
        }, {
            skipMetadataHash: true,
        });
    },
});

    }
},]
);
    SUGAR.customizationTools.mobileButtonsManager.handleViewChange();
    SUGAR.customizationTools.wMobileBootLoader.loadManagers();
    SUGAR.customizationTools.wMobileBootLoader.applyExtensions(SUGAR.mobile.extensions);
    SUGAR.customizationTools.wMobileBootLoader.loadMobileCustomizations();
    SUGAR.customizationTools.wMobileBootLoader.wMobileRouteHandler.reloadLoginView();
    SUGAR.customizationTools.wMapsFilteringDistancesList = [
5,15,30,50,100];